# FitRota Web 0.6.8 — yayın adayı

Bu paket web geliştirmelerini içerir; APK daha sonra hazırlanır. Dış hizmetlerin onayları ve hukuki inceleme kod paketinin tamamlanmasıyla verilmiş olmaz.

## Tabletten yükleme

1. GitHub ana dizinine `FitRota-0.6.8-Web-Kucuk.zip` dosyasını yükle.
2. Render Build Command:

```
python3 -m zipfile -e FitRota-0.6.8-Web-Kucuk.zip . && npm ci --include=dev && npm run build
```

3. Start Command: `npm run server`. Mevcut ortam değişkenlerini koru. Özellikle `FITROTA_SESSION_SECRET` değişmesin.
4. `FITROTA_AUTH_PROVIDERS=google`. Apple yeni girişte kaldırıldı; eski bir Apple hesabının silinmesi için iptal mekanizması korunuyor.
5. Deploy tamamlanınca PWA güncellemesini uygula veya sayfayı yeniden aç. Bu sürüm için yeni SQL yok; önceki hesap/hediye/ödül tabloları korunur.

## Neler değişti?

- Açık temada günlük antrenman kartı, giriş alanları, etiketler, koç ve Premium renk/kontrast düzeltmeleri; koyu tema korunur.
- Noktasız amblem ve yenilenmiş web uygulama ikonları.
- Profil/Ayarlar ana ekranında Premium fiyat bilgisi, özellikler, yönetim ve hediye kodu erişimi.
- 150.007 kaynaklı besin/ürün kaydı. 139.250 kayıt USDA markalı veri setindendir; tamamı Türkiye ürünü değildir. Barkod ve marka/ad/makro tekrarları bu bölümde elenir. Simit, Pınar hindi döneri, Türkiye McDonald's/Burger King/Popeyes ürünleri eklenmiştir. Domino's ABD tarihsel kayıtları ülke ve kaynak uyarısıyla bulunur; Türkiye reçetesi diye sunulmaz.
- Büyük ürün kataloğu açılışta indirilmez. Arama ilk açıldığında parça parça yüklenir; yüklenen parçalar PWA önbelleğinde çevrimdışı kullanılabilir. Yükleme kesilirse tekrar deneme düğmesi vardır. Temel besinler hemen kullanılabilir.
- Yeni ürün ekleme ekranındaki tanımsız değişken hatası giderildi. Arama yazarken geciktirilerek ve sıralama puanları bir kez hesaplanarak çalışır.
- Üyelik ekranı yakın zamanda doğrulanmış sonucu kullanır. İsteğe bağlı ödül sorgusu açılışı bekletmez. Sunucu doğrulaması olmadan Premium verilmez.
- Google CMP için ayrıca bir script adresi aramak gerekmez; AdSense kodu kullanılır. Kişisel beslenme/sağlık verileri reklam hedeflemesine eklenmez.

## AdSense

Mevcut kimlikler:
- `FITROTA_ADSENSE_CLIENT=ca-pub-9835164875546157`
- `FITROTA_ADSENSE_SLOT=1079599132`

AdSense hâlâ “Getting ready” gösteriyorsa reklam onaylanmış değildir. Yalnız site “Ready” olduktan ve yayınlanan CMP mesajı gerçek bölgelerde test edildikten sonra `FITROTA_ADS_SITE_APPROVED=true` ve `FITROTA_ADS_ENABLED=true` yapılır. Otomatik reklamları kapalı tut; bu paket yalnız Gelişim → Ödüller içindeki manuel alanı kontrol eder. Aksi halde otomatik reklamlar Premium garantisini bozabilir. `FITROTA_CMP_SCRIPT_URL` isteğe bağlıdır; boş bırakılabilir. Kullanıcı izin vermeden manuel reklam isteği gönderilmez. CMP açılamazsa reklam kapalı kalır. AB/İngiltere/İsviçre ve Türkiye gerçek cihaz testleri ayrıca yapılmalıdır; testlerde reklam servisleri taklit edilmiştir.

## Premium satın alma

Fiyatlar Türkiye için 49,99 TL/ay, ABD için 2,99 USD/ay, Avro bölgesi için 2,99 EUR/ay hedefidir. Cihaz saat dilimi yalnız ön gösterim seçer; gerçek ücret ve vergiler ödeme sağlayıcısının ekranında belirlenir. Uygulama dili fiyatı değiştirmez.

Web ödeme açmak için RevenueCat hesabında gerçek aylık ürün, `fitrota_pro` yetkisi ve kullanıcı kimliğiyle ilişkilendirilen Web Purchase Link kurulmalı; `REVENUECAT_SECRET_KEY`, `FITROTA_WEB_PURCHASE_LINK`, `REVENUECAT_MONTHLY_PACKAGE` ve `FITROTA_BILLING_ENABLED` yapılandırılmalıdır. Hukuki hazırlık ve sunucu koşulları tamamlanmadan satın alma açılmaz. Gerçek ödeme, iptal, yenileme ve hesap silme sonrası abonelik davranışı sağlayıcı test ortamında doğrulanmalıdır. Hediye kodu altyapısı ücretli abonelik başlatmadan Premium tanımlar.

## Google giriş

Web akışı sunucudadır; Google/Supabase hesaplarında OAuth uygulaması, yönlendirme adresleri, izin ekranı ve gerekli yayın/doğrulama işlemleri ayrıca tamamlanır. `FITROTA_ACCOUNT_TEST_MODE=true` özel testtir; bunu kapatmak hukuki hazırlık ve dış OAuth ayarlarının yerine geçmez. Supabase yönlendirme ve silme/yeniden giriş testi gerçek hesapta son kez yapılmalıdır.

## Hukuki metinler

`/legal/privacy`, `/legal/terms`, `/legal/deletion` güncellendi. Gizlilik metni gerçek AI/bağlam, bulut, ödül, ödeme ve reklam akışını anlatır. Dağıtım bölgesi kodda Tokyo/Frankfurt olarak sabitlenmez; kontrol edilmiş bilgiler girilir:
- `FITROTA_LEGAL_OPERATOR`, `FITROTA_LEGAL_ADDRESS`, `FITROTA_PRIVACY_EMAIL`
- `FITROTA_RETENTION_NOTICE`: gerçek saklama ve silme süreleri
- `FITROTA_REGION_NOTICE`: Render/Supabase ve ilgili hizmetlerin gerçek bölgeleri
- `FITROTA_PROCESSING_BASIS_NOTICE`: veri türü, amaç ve uygulanabilir işleme şartları
- `FITROTA_TRANSFER_NOTICE`: aktarım alıcıları, ülkeler ve geçerli mekanizma

`FITROTA_LEGAL_REVIEWED=true` gerçek inceleme tamamlandıktan sonra kullanılır; bir onay belgesi değildir. OpenAI genel destek yanıtı Türk KVKK standart sözleşmesini imzalamamıştır. İmzalanmamış bir sözleşme bu pakette imzalı veya geçerli gösterilmez. Standart sözleşme yoluna başvurulacaksa doğru taraf/rol, ekler, yetkili imzalar ve Kuruma bildirim işletmeci tarafından tamamlanır. Mesafeli satış/ön bilgilendirme, abonelik, fatura ve tüketici yükümlülükleri gerçek ödeme sağlayıcısı ve satıcı bilgilerine göre ayrıca incelenmelidir. Uygulamayı “hukuken kesin onaylı” ilan eden bir belge yoktur.

Resmî kaynaklar (4 Ekim 2026 kontrolü):
- https://www.kvkk.gov.tr/Icerik/7929/Standart-Sozlesmeler
- https://www.kvkk.gov.tr/Icerik/8170/Yurt-Disina-Kisisel-Veri-Aktariminda-Kullanilacak-Standart-Sozlesmelerde-Dikkat-Edilmesi-Gereken-Hususlara-Iliskin-Kamuoyu-Duyurusu
- https://support.google.com/adsense/answer/10960768
- https://developers.google.com/funding-choices/fc-api-docs

## Sınırlar

Render Free boşta uyursa ilk sunucu isteği gecikebilir; istemci optimizasyonu sunucu uyumasını ortadan kaldırmaz. Büyük kataloğun ilk yüklenmesi bağlantıya bağlıdır. Test sonuçları kod davranışını doğrular; canlı Google, AdSense, RevenueCat onayını veya hukuki uygunluğu garanti etmez.
