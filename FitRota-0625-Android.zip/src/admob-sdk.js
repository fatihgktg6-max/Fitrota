import {Capacitor} from '@capacitor/core';
import {AdMob, BannerAdPluginEvents} from '@capacitor-community/admob';
import {NativeAds} from './admob-client.js';
import {admobConfig} from './admob-config.js';
const ads = new NativeAds({plugin: AdMob, platform: () => Capacitor.getPlatform(), config: admobConfig,
  onHeight: height => document.documentElement.style.setProperty('--native-ad-height', `${height}px`)});
window.FitrotaAds = ads;
if (ads.available) {
  AdMob.addListener(BannerAdPluginEvents.SizeChanged, size => ads.sizeChanged(size)).catch(() => {});
  AdMob.addListener(BannerAdPluginEvents.FailedToLoad, () => {
    ads.error = 'ad_unavailable';
    ads.enqueue(() => ads.remove());
  }).catch(() => {});
}
