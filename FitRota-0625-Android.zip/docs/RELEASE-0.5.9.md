# FitRota 0.5.9 — daha sade kullanım

Bu sürüm mevcut özellikleri daha kolay bulunacak şekilde düzenler. Canlı site kendiliğinden değişmez; ZIP GitHub’a yüklendikten sonra Render’da dağıtılmalıdır.

## Ekran düzeni

- Ana menü: Bugün, Antrenman, Beslenme, Takvim, Profil.
- Bugün: bugünkü antrenman, kalori özeti ve öğün ekleme, su kaydı, günlük takvim. Ana ekrandaki kısayollar bugünün doğru sekmesini açar.
- Antrenman: Bugün / Haftam / Keşfet. Kronometre ve müzik, 60 hareketin kütüphanesi, program ayarı, özel program ve kaynaklar Keşfet içindedir. Günlük ekranda haftalık program tekrar gösterilmez.
- Beslenme: Günlüğüm / Planım / Keşfet. 80 tarif, içecekler/protein tozu, alışveriş, evdeki malzemeler ve takviyeler Keşfet içindedir. Kalori ve protein/karbonhidrat/yağ görünür; sodyum, kolesterol ve diğer besinler “Tüm besin değerlerini göster” altında açılır. Keşfet ekranlarında günlük enerji kartı tekrarlanmaz.
- Profil: Hesabım / İlerlemem / Tercihlerim / Veri & yardım. Gelişim ve ödüller buradan açılır. Tema, dil ve bildirimler ayrı sayfada; veri/yedek yönetimi ve belgeler ayrı sayfalardadır.
- Otomatik AI ve bulut seçimi: Profil → Hesabım → Otomatik AI & bulut.
- Koç robot simgesinden açılır. Uyku ve koç tercihleri açılır panelde bulunur.

## Veriler ve dağıtım

Mevcut hesaplar, izinler, AI 30 mesaj + 2 saat kotası, otomatik bulut, program/aktif seans ve beslenme kayıtlarının yapısı değişmedi. Yeni SQL çalıştırma veya mevcut verileri silme gerekmez. Render ortam değişkenlerini koru.

GitHub’a ZIP dosyasını çıkarmadan yüklediğinde tam Build Command:

```bash
python3 -m zipfile -e FitRota-0.5.9.zip . && npm ci --include=dev && npm run build
```

Start Command: `npm run server`.

Dağıtım tamamlanınca uygulamayı yeniden aç. Profil → Veri & yardım → Uygulama & gizlilik bölümünde v0.5.9 görünmelidir.

## Doğrulama

40 çekirdek/içerik/antrenman testi; yeni menü kısayolları, tüm Keşfet yolları, Profil/tercihler/veri/belgeler, açılır besin ve koç panelleri için tarayıcı akış testi; Türkçe/İngilizce, açık/koyu tema, 320/390/768/1440 px ile 128 düzen kontrolü. Mevcut içerik, 96 ekran düzeni, program değiştirme/kayıt koruma ve otomatik AI/bulut testleri de geçti. Telefon ve masaüstü ekran görüntüleri incelendi. Gerçek AI veya OAuth hizmetine ücretli çağrı yapılmadı; hesap/bulut senaryolarında test hizmetleri kullanıldı.

Web/PWA güncellemesidir. Android/iOS kaynak ve web çıktıları eşitlenir; imzalı mağaza paketi değildir.
