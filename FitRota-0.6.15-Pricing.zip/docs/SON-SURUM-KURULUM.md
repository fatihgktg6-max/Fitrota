FITROTA 0.6.15 — PUBLIC PRICING

1. FitRota-0.6.15-Pricing.zip dosyasini GitHub deponun ana dizinine yukle.
2. Render Build Command:
python3 -m zipfile -e FitRota-0.6.15-Pricing.zip . && python3 scripts/prepare-us-release.py && npm ci --include=dev && npm run build:us
3. Manual Deploy > Deploy latest commit. Live olduktan sonra asagidaki adresi ac.

Paddle Pricing page:
https://fitrota-us-gateway.fatihgktg6.workers.dev/legal/pricing

Once sayfanin acildigini kontrol et, sonra Paddle formuna yaz.
SQL, anahtar ve Cloudflare Worker degisikligi gerekmez.

Yeni sayfa giris gerektirmeyen urun/fiyat bilgisidir. Mevcut /legal/ herkese acik bilgi yolunu kullanir.
Uygulama ve odeme ekrani ABD erisim sinirini korur.
Canli fiyat hedefi: 2.99 USD/ay. Sayfa, canli odemelerin henuz acilmadigini belirtir.
Canli Paddle katalog fiyati da 2.99 USD/ay (API minor units: 299) olmali.
Mevcut sandbox urunu ve test fiyati 3 USD olarak korunur; mevcut test aboneligi degismez.
Canli odeme destegi bu pakette acilmadi.
0.6.14 su ve odeme duzeltmeleri dahildir.

Dogrulama: US build basarili. Fiyat sayfasi/ulke kapisi/uyelik icin 8 otomatik test gecti.
Mobil tarayici gorsel kontrolu ve Render'a yayin bu ortamdan yapilmadi.
