# FitRota 0.6.22 — inceleme ve düzeltmeler

Bu paket uygulamanın kaynak kodudur. AdMob eklenmemiştir. Canlı siteye veya ödeme hesaplarına bu çalışma sırasında değişiklik yapılmamıştır.

## Tamamlananlar
- Resmi FR logosu: giriş, uygulama içi marka, favicon ve PWA ikonları.
- Girişte responsive telefon önizlemesi; değerler açıkça örnek olarak işaretli.
- Başlangıç hesabı kontrolü 65 saniye yerine 15 saniyede hata/retry durumuna geçer; doğrulanmamış premium veya başka hesap verisi gösterilmez.
- US genel besin kayıtları web açılışında değil, besin araması açıldığında yüklenir. Minify uygulanır. İlk JavaScript 1.771.340 bayt, gzip 331.548 bayt.
- Yeni aramaya geçildiğinde eski katalog/topluluk sonuçları ve sayfalama iptal edilir.
- Dış kaynaklı g/ml etiketlerinde ilk miktar ve önizleme eşitlendi.
- Virgül içeren malzeme isimlerinin pantry eşleştirmesi düzeltildi.
- Kaynakta eksik makrolar, açık partialNutrition kaydıyla bilinmiyor olarak saklanır; sıfır uydurulmaz. Kalorisi eksik kaynaklar kayıt öncesi açıklanır.
- İngilizce en-US güncelleme bildirimi düzeltildi.
- Eski onay tarihi ve eski katalog mimarisi varsayan testler güncellendi; güvenlik kuralları gevşetilmedi.

## Besin kapsamı
USDA arşivi SHA256 ile doğrulandı; katalog yeniden üretildi. 453.397 markalı ABD kaydı ve arama indeksinin içerik özeti doğrulandı. Çevrimdışı başlangıç kayıtları, genel besinler ve tarifler ayrıca mevcuttur. 900.000 kayıt veya rakiplerden büyük katalog iddiası YOKTUR. Veri kaynakları ve mevcut paket etiketi her zaman ayırt edilmelidir.

## Doğrulama
`npm run build:us` başarılı. 150 otomatik test geçti (hesap/OAuth, onay, veri ayrımı, premium/Paddle, webhook, kota, su, besin ve porsiyonlar, yedek, ABD kuralları, DOM giriş/onboarding/premium akışları dahil). Son lazy-load/minify değişimi için ayrıca üretim web paketi DOM testi eklendi. Sonuçlar ayrı test çıktısı dosyalarında yer alır.

DOM testleri gerçek Android/iOS cihaz ve görsel tarayıcı testinin yerine geçmez. Bu ortamda Chromium bulunmadığından piksel düzeyinde görsel kontrol yapılmadı.

## Mağaza öncesi açık işler
- Android/iOS proje oluşturma, gerçek cihaz testleri, Google native oturum açma ve callback yapılandırması. Mevcut initializeAccount native platformda çalışmıyor; bu paket native kimlik doğrulamasını tamamlamaz.
- app.fitrotaapp.com alan adı, OAuth ve ödeme yönlendirmelerinin canlı ortamda doğrulanması. Önceki Cloudflare panel değişiklikleri bu ZIP'e otomatik aktarılmamıştır.
- Play/App Store ödeme entegrasyonu ve mağaza kurallarına uygun satın alma akışı; web Paddle testi native mağaza satın alması değildir.
- Sonraki adım: AdMob + UMP, premiumda reklamsızlık, test reklamları ve cihaz denemesi.
- AAB/IPA imzalama, mağaza beyanları ve mağaza incelemesi.

Bu nedenlerle paket düzeltilmiş test sürümüdür; mağazaya koşulsuz hazır veya hatasız olduğu iddia edilmez.

## Kurulum
Kaynak ZIP'i açın. `python3 scripts/prepare-us-release.py` doğrulanmış USDA kataloğunu indirir/kurar; ardından `npm ci --include=dev`, `npm run build:us`. Başlatma `npm run server`. Gizli anahtarlar ZIP'e konulmaz. Önce test ortamında ve gerçek cihazda doğrulayın.
