import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {JSDOM,VirtualConsole} from 'jsdom';
import {emptyState,normalizeProfile,foodTotals} from '../src/core.js';
import {localProducts} from '../src/turkish-foods.js';
import {createFoodLookup} from '../server/food-lookup.mjs';
test('verified basmati brands and oil labels keep distinct g/ml bases and unknown nutrients',()=>{
 const products=localProducts.filter(f=>/basmati|aycicek/.test(f.id));assert.equal(products.length,5);
 const rice=products.find(f=>f.brand==='Duru'),oil=products.find(f=>f.brand==='Yudum');
 assert.equal(rice.unit,'g');assert.equal(oil.unit,'ml');assert.equal(foodTotals([{custom:rice,servings:.5}]).kcal,172.5);assert.equal(foodTotals([{custom:oil,servings:.1}]).kcal,81.9);assert.equal(oil.fiber,null);
 for(const f of products){assert.ok(f.sourceURL.startsWith('https://'));assert.equal(f.market,'TR');assert.equal(f.checkedAt,'2026-10-10');}
});
test('country food search isolates US/TR caches, filters Turkey and prefers Turkish product name',async()=>{
 const urls=[],lookup=createFoodLookup({env:{FITROTA_LAUNCH_MARKET:'US'},fetcher:async url=>{urls.push(new URL(url));return Response.json({products:[{code:'8690000000001',product_name:'Oil',product_name_tr:'Ayçiçek yağı',brands:'Test',nutriments:{'energy-kcal_100g':900,proteins_100g:0,carbohydrates_100g:0,fat_100g:100}}]});}});
 assert.equal((await lookup.search('oil',{market:'US'})).items[0].name,'Oil');assert.equal((await lookup.search('oil',{market:'TR'})).items[0].name,'Ayçiçek yağı');assert.equal(urls.length,2);assert.equal(urls[0].searchParams.get('tag_0'),'united-states');assert.equal(urls[1].searchParams.get('tag_0'),'turkey');await lookup.search('oil',{market:'TR'});assert.equal(urls.length,2);
});
test('Turkish test build migrates old US state, keeps diary, finds brands and uses metric portions after restart',async()=>{
 const html=readFileSync(new URL('../index.html',import.meta.url),'utf8'),errors=[],vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
 const saved=emptyState();saved.settings.market='US';saved.settings.usReleaseRevision=1;saved.settings.lang='en';saved.settings.units='imperial';saved.profile=normalizeProfile({name:'Tester',age:30,height:178,weight:80,days:[1,3,5],budget:3,market:'US'});saved.meals['2026-10-09']=[{id:'old-meal',slot:'lunch',custom:{name:'Old meal',kcal:100,protein:2,carbs:20,fat:1},servings:1}];
 const dom=new JSDOM(html,{url:'https://fitrota.example',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){w.structuredClone=structuredClone;w.scrollTo=()=>{};w.HTMLElement.prototype.scrollTo=()=>{};w.matchMedia=()=>({matches:false,addEventListener(){},removeEventListener(){}});w.ResizeObserver=class{observe(){}disconnect(){}};w.localStorage.setItem('fitrota.account.tester',JSON.stringify(saved));w.fetch=async url=>({ok:true,json:async()=>String(url).endsWith('/me')?{user:{id:'tester'}}:String(url).endsWith('/config')?{configured:true,providers:['google']}:String(url).endsWith('/membership')?{owner:'tester',premium:false}:{}});}});
 try{await new Promise(r=>setTimeout(r,50));const e=x=>dom.window.eval(x);assert.equal(e('window.FITROTA_RELEASE.contentMarket'),'TR');assert.equal(e('state.settings.market'),'TR');assert.equal(e('state.settings.units'),'metric');assert.equal(e('state.profile.market'),'TR');assert.equal(e('state.meals["2026-10-09"][0].custom.name'),'Old meal');
 for(const q of ['Duru basmati','Yayla basmati','Reis basmati','Yudum','Orkide']){dom.window.__query=q;assert.ok(e('foodHubPool().some(f=>foodMatches(f,window.__query))'),q);}
 assert.equal(e('foodHubPool().some(f=>f.source==="branded")'),false);assert.equal(e('portionUnit(localProducts.find(f=>f.brand==="Yudum"))'),'ml');e('selectedFoodForm("tr-product-yudum-aycicek")');dom.window.document.querySelector('[name=amount]').value='10';e('saveSavedFoodEntry(document.querySelector("#saved-food-form"))');assert.equal(e('state.meals[foodDate].at(-1).custom.kcal'),81.9);assert.equal(e('state.meals[foodDate].at(-1).custom.quantityUnit'),'ml');e('persist();state=loadState()');assert.equal(e('state.settings.turkeyTestRevision'),1);assert.equal(e('state.settings.market'),'TR');assert.deepEqual(errors,[]);
 }finally{dom.window.close();}
});
