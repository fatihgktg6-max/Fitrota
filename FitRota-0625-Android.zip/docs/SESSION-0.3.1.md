# 0.3.1 — AI bağlantısını hatırla

Koç bağlantı formunda isteğe bağlı “Bu kişisel cihazda 7 gün hatırla” seçeneği var. Aynı web adresinde HttpOnly, SameSite=Strict ve HTTPS üzerinde Secure çerez kullanılır. Erişim kodu veya OpenAI anahtarı tarayıcı deposuna yazılmaz. Süre ilk girişten itibaren 7 gündür; otomatik uzamaz.

Uygulama yeniden açılınca çerez üzerinden yeni kısa süreli oturum alınır. Sunucu yeniden başlasa da erişim kodu değişmedikçe hatırlama çalışır. İstek sırasında eski sunucu oturumu geçersizse bir kez yeniden bağlanıp dener. Bağlantıyı kes seçeneği çerezi temizler ve mevcut oturumu sonlandırır. Profil düzenleme artık gereksiz çıkış yapmaz. Veri silme, yeni profil ve yedek içe aktarma bağlantıyı keser.

Bu özellik mevcut aynı-origin web/PWA sürümü içindir; başka sunucu adresi veya native uygulamada kalıcı hatırlama desteklenmez. Telefon/tablet ayrı oturum açar. Ortak cihazlarda seçeneği kullanmayın. İmzalı hatırlama çerezi taşınabilir bir yetkilendirme bilgisidir; sunucuda cihaz bazlı kalıcı iptal listesi yoktur. Çalınmış kopyaları topluca geçersiz kılmak için FITROTA_ACCESS_CODE değiştirilir. Çok kullanıcılı hesap sisteminin yerine geçmez.

Doğrulama: süre, değiştirilmiş çerez, sunucu yeniden başlatma, logout ve tarayıcı yeniden yükleme testleri. API sağlayıcısı testlerde sahtedir; ücretli çağrı yapılmaz.

Render Build Command yüklenen ZIP dosyasının tam adını kullanmalıdır. version.json yanıtında 0.3.1 görünmelidir. Güncelleme sonrası ilk girişte hatırlama kutusunu seçin.
