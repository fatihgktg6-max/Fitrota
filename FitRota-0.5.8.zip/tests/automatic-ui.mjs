import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {createCoachServer} from '../server/index.mjs';
import {emptyState,normalizeProfile,validateBackup} from '../src/core.js';
import {mockQuotaService} from './quota-fixture.mjs';
const owner='automatic-test-owner',origins=[];let snapshot=null,writes=0,offline=false,aiCalls=0;
const send=(res,data,status=200)=>{res.writeHead(status,{'Content-Type':'application/json'});res.end(JSON.stringify(data));};
const service={enabled:true,session:async()=>({user:{id:owner}}),handler:async(req,res)=>{
 if(req.url==='/account/config'){send(res,{configured:true,providers:['google'],legalReady:true});return true;}
 if(req.url==='/account/me'){send(res,{user:{id:owner,email:'test@example.test'},preferences:{aiConsent:true,autoCloud:true}});return true;}
 if(req.url==='/account/data'){
  if(offline){send(res,{error:'offline'},503);return true;}
  if(req.method==='GET')send(res,{snapshot});
  else if(req.method==='POST'){let body='';for await(const chunk of req)body+=chunk;const data=JSON.parse(body);if(data.revision!==(snapshot?.revision||0))send(res,{error:'sync_conflict'},409);else{snapshot={payload:validateBackup(data.payload),revision:(snapshot?.revision||0)+1};writes++;send(res,{revision:snapshot.revision});}}
  return true;
 }return false;
}};
const server=createCoachServer({accessCode:'automatic-test-private-code-32-characters',apiKey:'mock',model:'mock',accountService:service,quotaService:mockQuotaService(),allowedOrigins:origins,reply:async()=>{aiCalls++;return {text:'Test',source:'openai'};}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;origins.push(base);
const browser=await chromium.launch({args:['--no-sandbox']}),context=await browser.newContext({viewport:{width:390,height:844}}),p=await context.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
const seed=emptyState();seed.profile=normalizeProfile({name:'Test',age:30,height:180,weight:80,days:[1,3,5],budget:3});seed.settings.accountAiConsent=true;seed.settings.autoCloud=true;
await context.addInitScript(({owner,seed})=>{if(!localStorage.getItem('fitrota.account.'+owner))localStorage.setItem('fitrota.account.'+owner,JSON.stringify(seed));},{owner,seed});
try{
 await p.goto(base);await p.waitForFunction(()=>liveCoach?.mode==='account'&&cloudSync().ready);assert.equal(aiCalls,0);
 await p.evaluate(()=>{state.dayNotes[today()]='automatic cloud test';persist();});await p.waitForFunction(()=>cloudSync().status==='saved');assert.ok(writes>0);assert.equal(snapshot.payload.dayNotes[await p.evaluate(()=>today())],'automatic cloud test');
 await p.evaluate(()=>navigate('food'));await p.locator('[data-action="food-tab"][data-id="drinks"]').click();assert.ok(await p.locator('.supplement-grid article').count()>=17);
 await p.locator('[data-action="product-label"][data-kind="powder"]').click();for(const [name,value] of Object.entries({kcal:'400',protein:'80',carbs:'10',fat:'5'}))await p.locator(`[name="${name}"]`).fill(value);await p.locator('#product-label-form button[type="submit"]').click();
 assert.equal(await p.evaluate(()=>state.meals[today()].at(-1).custom.kcal),120);assert.equal(await p.evaluate(()=>state.meals[today()].at(-1).custom.protein),24);assert.equal(await p.evaluate(()=>state.meals[today()].at(-1).custom.sodium),null);
 await p.locator('[data-action="food-tab"][data-id="drinks"]').click();await p.locator('[data-action="product-label"][data-kind="drink"]').click();for(const [name,value] of Object.entries({name:'Label drink',kcal:'50',protein:'1',carbs:'10',fat:'0'}))await p.locator(`[name="${name}"]`).fill(value);await p.locator('#product-label-form button[type="submit"]').click();assert.equal(await p.evaluate(()=>state.meals[today()].at(-1).custom.kcal),125);
 await p.locator('[data-action="food-tab"][data-id="supplements"]').click();assert.equal(await p.locator('.supplement-grid article').count(),28);await p.selectOption('[name="supplement-category"]','vitamin');assert.equal(await p.locator('.supplement-grid article').count(),13);await p.locator('#supplement-search').fill('B12');assert.equal(await p.locator('.supplement-grid article').count(),1);
 const robot=p.locator('.coach-launcher'),before=await robot.boundingBox();await p.mouse.move(before.x+25,before.y+25);await p.mouse.down();await p.mouse.move(60,180,{steps:10});await p.mouse.up();assert.equal(await p.evaluate(()=>page),'food');assert.ok(await p.evaluate(()=>state.settings.coachPosition.y<.5));await p.reload();await p.waitForFunction(()=>liveCoach?.mode==='account');assert.ok((await robot.boundingBox()).y<400);
 await p.waitForFunction(()=>cloudSync().status==='saved');const savedWrites=writes;
 offline=true;await p.evaluate(async()=>{state.dayNotes[today()]='offline preserved';persist();await flushCloudSave();});assert.equal(await p.evaluate(()=>cloudSync().status),'offline');assert.equal(writes,savedWrites);offline=false;await p.evaluate(()=>flushCloudSave());assert.equal(snapshot.payload.dayNotes[await p.evaluate(()=>today())],'offline preserved');
 snapshot={...snapshot,revision:snapshot.revision+1,payload:structuredClone(snapshot.payload)};snapshot.payload.dayNotes[await p.evaluate(()=>today())]='other device';const beforeConflict=writes;await p.evaluate(async()=>{state.dayNotes[today()]='local conflicting';persist();await flushCloudSave();});assert.equal(await p.evaluate(()=>cloudSync().status),'conflict');assert.equal(writes,beforeConflict);await p.evaluate(()=>resolveCloudConflict('cloud'));assert.equal(await p.evaluate(()=>state.dayNotes[today()]),'other device');
 const second=await browser.newContext();const p2=await second.newPage();await p2.goto(base+'/#account');await p2.waitForFunction(()=>state.profile&&cloudSync().ready);assert.equal(await p2.evaluate(()=>state.dayNotes[today()]),'other device');await second.close();
 snapshot=null;await p.evaluate(()=>pollAutomaticCloud());assert.equal(await p.evaluate(()=>cloudSync().status),'conflict');await p.evaluate(()=>resolveCloudConflict('cloud'));assert.equal(await p.evaluate(()=>state.settings.autoCloud),false);
 await p.evaluate(()=>{disconnectCoach();state.settings.accountAiConsent=false;saveState(state);});await p.reload();await p.waitForFunction(()=>accountInfo.user);assert.equal(await p.evaluate(()=>liveCoach),null);
 for(const width of [320,390,768]){await p.setViewportSize({width,height:844});for(const tab of ['drinks','supplements']){await p.evaluate(tab=>{navigate('food');foodFilter=tab;render();},tab);assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);}}await p.screenshot({path:'qa/automatic-services-mobile.png',fullPage:true});
 assert.deepEqual(errors,[]);console.log('PASS: automatic account AI with zero messages; debounced save, offline retry, remote restore, conflict and cloud deletion; drag/reload; drinks and label macros; 28 supplement guides. Mock services only.');
}finally{await browser.close();await new Promise(r=>server.close(r));}
