import {supportedLanguages} from './i18n.js';
import {isUSFoodVisible} from './us-food-policy.js';
import {snackProducts} from './snack-foods.js';
import {localProducts} from './turkish-foods.js';
import {legacyNutrition} from './legacy-food.js';
import {trainingPrescription,balancedMealPlan} from './science.js';
import {exercises,foods} from './catalog.js';
export const SCHEMA=1;
export const uid=()=>globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
export function dayKey(date=new Date()){ const d=new Date(date); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
export function dateOf(key){return new Date(`${key}T12:00:00`);}
export function addDays(key,n){const d=dateOf(key);d.setDate(d.getDate()+n);return dayKey(d);}
export function weekStart(key=dayKey()){const d=dateOf(key);return addDays(key,-((d.getDay()+6)%7));}
export function emptyState(){return {version:SCHEMA,foodCatalogRevision:2,profile:null,createdAt:new Date().toISOString(),settings:{usReleaseRevision:typeof window!=='undefined'&&window.FITROTA_RELEASE?.market==='US'?1:0,lang:typeof window!=='undefined'&&window.FITROTA_RELEASE?.market==='US'?'en':'tr',units:typeof window!=='undefined'&&window.FITROTA_RELEASE?.market==='US'?'imperial':'metric',coach:'warm',reminders:false,theme:'system',market:typeof window!=='undefined'&&window.FITROTA_RELEASE?.market==='US'?'US':'TR',restSound:false,accountAiConsent:false,coachProfileConsent:false,cloudPrivateDetails:false,autoCloud:false,servicesPrompted:false,coachPosition:null},workoutPlans:{},dayNotes:{},monthGoals:{},shoppingItems:[],pantry:{},restTimer:null,stopwatch:{elapsed:0,startedAt:0,running:false,laps:[]},legalAcceptance:null,workouts:{},meals:{},water:{},measurements:[],events:[],weeks:{},claims:[],shopping:{},chat:[],customPlans:[],weeklyPlan:null,savedFoods:[],activeWorkout:null,mealPlans:{},nutritionPreferences:{mode:"off",text:"",seed:0},demo:false};}
export function normalizeProfile(raw){
 const p={name:String(raw.name||'').trim().slice(0,40),age:Number(raw.age),height:Number(raw.height),weight:Number(raw.weight),goal:raw.goal||'maintain',equipment:raw.equipment||'home',level:raw.level||'beginner',trainingStyle:raw.trainingStyle||'auto',minutes:Number(raw.minutes)||30,days:(raw.days||[]).map(Number),diet:raw.diet||'omnivore',allergens:raw.allergens||[],dislikes:String(raw.dislikes||'').slice(0,200),budget:Number(raw.budget)||2,calories:raw.calories?Number(raw.calories):null,protein:raw.protein?Number(raw.protein):null,health:!!raw.health,sex:['male','female'].includes(raw.sex)?raw.sex:'unspecified',activity:['low','light','moderate','high'].includes(raw.activity)?raw.activity:'unspecified',nutritionRisk:!!raw.nutritionRisk};
 if(!p.name)throw Error('name');
 if(!Number.isFinite(p.age)||p.age<18||p.age>100)throw Error('age');
 if(!Number.isFinite(p.height)||p.height<120||p.height>230)throw Error('height');
 if(!Number.isFinite(p.weight)||p.weight<35||p.weight>300)throw Error('weight');
 if(!['maintain','strength','muscle','lose','gain'].includes(p.goal))throw Error('goal');
 if(!['home','gym'].includes(p.equipment)||!['beginner','regular'].includes(p.level))throw Error('equipment');
 if(!['auto','fullbody','upperlower','bodypart','ppl'].includes(p.trainingStyle))throw Error('trainingStyle');
 if(![15,20,30,45,60].includes(p.minutes))throw Error('minutes');
 p.days=[...new Set(p.days)].sort();
 if(p.days.length<1||p.days.length>6||p.days.some(d=>!Number.isInteger(d)||d<0||d>6))throw Error('days');
 if(!['omnivore','vegetarian','vegan'].includes(p.diet))throw Error('diet');
 if(!Array.isArray(p.allergens)||p.allergens.some(a=>!['milk','egg','gluten','nuts','fish','soy','sesame','peanut','shellfish','mustard','celery'].includes(a)))throw Error('allergens');
 if(![1,2,3].includes(p.budget))throw Error('budget');
 if(p.calories!==null&&(!Number.isFinite(p.calories)||p.calories<1200||p.calories>5000))throw Error('calories');
 if(p.protein!==null&&(!Number.isFinite(p.protein)||p.protein<20||p.protein>250))throw Error('protein');
 return p;
}
export function workoutPlan(profile,{minutes=profile.minutes,equipment=profile.equipment,date=dayKey(),gentle=false}={}){return trainingPrescription(profile,{minutes,equipment,date,gentle},exercises);}
export function allowedDiaryFoods(p){const exclude=p.dislikes.toLocaleLowerCase('tr').split(',').map(x=>x.trim()).filter(Boolean);return foods.filter(f=>(p.market!=='US'&&!(typeof window!=='undefined'&&window.FITROTA_RELEASE?.market==='US')||isUSFoodVisible(f))&&!f.allergens.some(a=>p.allergens.includes(a))&&(p.diet==='omnivore'||f.diet==='vegan'||p.diet===f.diet)&&f.cost<=p.budget&&!exclude.some(x=>JSON.stringify(f.ingredients).toLocaleLowerCase('tr').includes(x)));}
export function allowedFoods(p){return allowedDiaryFoods(p).filter(f=>f.type!=='ingredient');}
export function pantryMatch(food,text=''){
 const normalize=value=>String(value).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replaceAll('ı','i').replace(/[,;\n]\s*/g,',').trim();
 const pantry=','+normalize(text)+',';
 const missing=(food.ingredients||[]).filter(i=>!i.slice(0,2).some(name=>pantry.includes(','+normalize(name)+',')));
 return {missing,ratio:food.ingredients?.length?1-missing.length/food.ingredients.length:0};
}
export function createMealPlan(p,date=dayKey(),preferences={}){
 let pool=allowedFoods(p);const mode=preferences.mode||'off',text=preferences.text||'';
 if(mode==='only')pool=pool.filter(f=>pantryMatch(f,text).missing.length===0);
 if(mode==='prefer'&&text.trim()){
  pool=pool.filter(f=>{const group=pool.filter(x=>x.type===f.type),best=Math.max(...group.map(x=>pantryMatch(x,text).ratio));return pantryMatch(f,text).ratio>=best;});
 }
 return balancedMealPlan(p,addDays(date,Number(preferences.seed)||0),pool);
}
export const nutrientFields=['kcal','protein','carbs','fat','fiber','sugar','saturatedFat','sodium','cholesterol','potassium','calcium','iron'];
export const nutrientLimits={kcal:3000,protein:300,carbs:300,fat:300,fiber:300,sugar:300,saturatedFat:300,sodium:100000,cholesterol:10000,potassium:100000,calcium:100000,iron:1000};
export function nutritionSnapshot(food){return Object.fromEntries(nutrientFields.map(k=>[k,Number.isFinite(food[k])?food[k]:null]));}
export function foodTotals(log=[]){const totals=Object.fromEntries(nutrientFields.map(k=>[k,0]));totals.entries=log.length;totals.missing=Object.fromEntries(nutrientFields.map(k=>[k,0]));for(const m of log){const f=m.custom||m.nutrition||foods.find(x=>x.id===m.foodId);for(const k of nutrientFields){if(Number.isFinite(f?.[k]))totals[k]+=f[k]*m.servings;else totals.missing[k]++;}}return totals;}

export function scheduledWeekdays(s){return s.weeklyPlan?s.weeklyPlan.days.map((p,i)=>p.off?null:i).filter(i=>i!==null):s.profile.days;}
export function ensureWeek(s,date=dayKey()){
 const start=weekStart(date);if(s.weeks[start])return s.weeks[start];
 const dates=Array.from({length:7},(_,i)=>addDays(start,i));
 // Freeze the target for this week. Changes to profile days take effect next week.
 const planned=dates.filter(d=>d>=dayKey(new Date(s.createdAt))&&scheduledWeekdays(s).includes(dateOf(d).getDay()));
 s.weeks[start]={start,planned,createdAt:new Date().toISOString()};return s.weeks[start];
}
export function weekProgress(s,start=weekStart()){
 const w=s.weeks[start];if(!w)return {done:0,total:0,percent:0,complete:false};
 const done=w.planned.filter(d=>s.workouts[d]?.completed).length,total=w.planned.length;
 return {done,total,percent:total?Math.round(done/total*100):0,complete:total>0&&done===total};
}
export function claimReward(s,kind,start=kind==='monthly'?dayKey().slice(0,7)+'-01':weekStart(),now=Date.now()){
 if(s.demo)throw Error('demo');
 const key=kind==='weekly'?`week:${start}`:`month:${start.slice(0,7)}`;
 if(s.claims.some(c=>c.key===key))throw Error('claimed');
 if(kind==='weekly'&&!weekProgress(s,start).complete)throw Error('incomplete');
 if(kind==='monthly'){
  const dates=s.monthGoals?.[start.slice(0,7)]?.planned||[],today=dayKey(new Date(now));
  if(!dates.length||dates.some(d=>d>today||!s.workouts[d]?.completed))throw Error('incomplete');
 }
 if(!['weekly','monthly'].includes(kind))throw Error('kind');
 const days=kind==='weekly'?1:30;
 // Local preview receipt only. A production server must verify and issue entitlements.
 const receipt={id:uid(),key,kind,days,earnedAt:new Date(now).toISOString(),status:'preview'};s.claims.push(receipt);return receipt;
}
export function shoppingList(plan){const map=new Map();for(const m of plan){const f=foods.find(x=>x.id===m.foodId);if(!f)continue;for(const [tr,en,amount,unit] of f.ingredients){const key=tr+'|'+unit;const old=map.get(key)||{key,name:[tr,en],amount:0,unit};old.amount+=amount*m.servings;map.set(key,old);}}return [...map.values()];}
export function completeWorkout(s,date,session){
 if(date!==dayKey())throw Error('date');
 if(s.workouts[date]?.completed)throw Error('duplicate');
 if(!session?.plan?.items?.length)throw Error('empty');
 const all=session.plan.items.every((e,i)=>Array.from({length:e.sets},(_,j)=>session.sets[`${i}:${j}`]?.done).every(Boolean));
 if(!all)throw Error('sets');
 s.workouts[date]={...session,completed:true,completedAt:new Date().toISOString()};s.activeWorkout=null;
}
export function coachReply(message,s,lang='tr'){
 const en=lang==='en',p=s.profile,text=message.toLocaleLowerCase('tr');
 if(/ağrı|agrı|acı|pain|bayıl|chest|göğüs ağr|nefes darl/.test(text))return en?'Stop the activity if you have pain. I cannot assess symptoms. Seek professional care; severe chest pain, fainting or major breathing difficulty need urgent help.':'Ağrı varsa aktiviteyi durdur. Belirti değerlendirmesi yapamam. Bir sağlık uzmanına danış; şiddetli göğüs ağrısı, bayılma veya belirgin nefes darlığında acil yardım al.';
 if(/takviye|supplement|ilaç|doz|steroid/.test(text))return en?'I cannot choose supplements or doses for you. A clinician or pharmacist can check needs, interactions and product safety.':'Senin için takviye veya doz seçemem. Hekim ya da eczacı ihtiyacı, etkileşimleri ve ürün güvenliğini değerlendirebilir.';
 if(/yemek|ye|meal|food|kalori|eat/.test(text)){const list=allowedFoods(p).slice(0,3).map(f=>f.name[en?1:0]).join(', ');return en?`Your saved preferences allow these starter options: ${list||'none in the current catalog'}. Open Nutrition to see portions and estimated values. Check labels and cross-contact risks for allergies.`:`Kayıtlı tercihlerine uyan başlangıç seçenekleri: ${list||'mevcut katalogda uygun tarif yok'}. Porsiyon ve yaklaşık değerler Beslenme ekranında. Alerjiler için etiket ve çapraz temas riskini ayrıca kontrol et.`;}
 if(/dakika|vakt|minute|time|salon|gym/.test(text))return en?'Use “Adapt today” to preview a shorter workout or switch to home equipment. Nothing changes until you approve.':'“Bugünü uyarla” ile kısa antrenmanı veya ev seçeneğini önizle. Onaylamadan programın değişmez.';
 if(/uyku|sleep/.test(text))return en?'Try a consistent bedtime and a quieter wind-down routine. You can add your own bedtime reminder in Calendar.':'Düzenli bir yatış saati ve daha sakin bir akşam rutini deneyebilirsin. Takvimden kendine uyku hatırlatıcısı ekleyebilirsin.';
 const progress=weekProgress(s);return en?`This week: ${progress.done}/${progress.total} planned sessions complete. ${s.settings.coach==='direct'?'Choose one manageable next step.':s.settings.coach==='energetic'?'Let’s keep your momentum! One small step today.':'A missed day does not erase your progress.'} You can log meals, adapt your workout, or plan a reminder. This is a rules-based offline response, not AI.`:`Bu hafta ${progress.total} planlı antrenmanın ${progress.done} tanesi tamamlandı. ${s.settings.coach==='direct'?'Şimdi yapabileceğin tek bir adım seç.':s.settings.coach==='energetic'?'Haydi, bugün küçük bir adımla devam edelim!':'Bir günü kaçırman önceki emeğini silmez.'} Öğün kaydedebilir, antrenmanı uyarlayabilir veya hatırlatıcı oluşturabilirsin. Bu yanıt çevrimdışı kurallı yardımcıdan gelir; AI değildir.`;
}
export function validateBackup(value){
 if(!value||value.version!==SCHEMA||typeof value!=='object')throw Error('version');
 const s=emptyState();if(value.profile)s.profile=normalizeProfile(value.profile);
 const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
 const validDate=v=>typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v)&&Number.isFinite(dateOf(v).getTime())&&dayKey(dateOf(v))===v;
 const validText=(v,n=100)=>typeof v==='string'&&v.length<=n;
 const validId=v=>typeof v==='string'&&/^[a-zA-Z0-9-]{1,100}$/.test(v);
 const finite=(v,min,max)=>typeof v==='number'&&Number.isFinite(v)&&v>=min&&v<=max;
 const safePlan=p=>{if(!object(p)||!validId(p.id)||!Array.isArray(p.title)||p.title.length!==2||p.title.some(t=>!validText(t,120))||!finite(p.minutes,0,240)||!Array.isArray(p.items)||p.items.length>20)throw Error('plan');return {...p,items:p.items.map(e=>{const base=exercises.find(x=>x.id===e.id);if(!base||!finite(e.sets,1,5)||!Number.isInteger(e.sets))throw Error('exercise');if(e.minutes!==undefined&&!finite(e.minutes,1,120))throw Error('exercise_minutes');return {...base,sets:e.sets,minutes:e.minutes??base.minutes,rest:finite(e.rest,0,600)?e.rest:base.rest,reps:validText(e.reps,40)?e.reps:base.reps};})};};
 const safeSession=w=>{if(!object(w)||!validDate(w.date)||!object(w.sets))throw Error('session');const plan=safePlan(w.plan),sets={};for(const [key,v] of Object.entries(w.sets)){if(!/^\d{1,2}:\d$/.test(key)||!object(v))throw Error('set');const item=plan.items[Number(key.split(':')[0])];if(!item||Number(key.split(':')[1])>=item.sets)throw Error('set');if(v.weight!==undefined&&!finite(v.weight,0,500))throw Error('weight');if(v.reps!==undefined&&!finite(v.reps,0,1000))throw Error('reps');sets[key]={done:!!v.done,...(v.weight!==undefined?{weight:v.weight}:{}),...(v.reps!==undefined?{reps:v.reps}:{})};}return {...w,plan,sets};};
 for(const key of ['workouts','meals','water','weeks','mealPlans','shopping'])if(value[key]!==undefined&&!object(value[key]))throw Error(key);
 for(const [date,w] of Object.entries(value.workouts||{})){if(!validDate(date)||w.date!==date)throw Error('date');s.workouts[date]=safeSession(w);}
 for(const [date,list] of Object.entries(value.meals||{})){
  if(!validDate(date)||!Array.isArray(list)||list.length>100)throw Error('meals');
  s.meals[date]=list.map(m=>{
   const f=foods.find(f=>f.id===m.foodId),basic=f?.type==='ingredient'&&!m.custom;
   if(!object(m)||!validId(m.id)||!f&&!m.custom||!finite(m.servings,basic?0.01:0.25,basic?20:5)||!['breakfast','lunch','dinner','snack'].includes(m.slot))throw Error('meal');
   const safeNutrition=n=>{if(!object(n))throw Error('nutrition');const safe={};for(const k of nutrientFields){if(n[k]===null||n[k]===undefined){if(k==='kcal'||(['protein','carbs','fat'].includes(k)&&n.calorieOnly!==true&&n.partialNutrition!==true))throw Error('nutrition');safe[k]=null;}else{if(!finite(n[k],0,nutrientLimits[k]))throw Error('nutrition');safe[k]=n[k];}}return safe;};
   const clean={id:m.id,foodId:m.foodId,slot:m.slot,servings:m.servings};
   if(m.custom){if(!validText(m.custom.name,80)||!m.custom.name.trim())throw Error('meal');clean.custom={name:m.custom.name,...safeNutrition(m.custom)};if(m.custom.calorieOnly===true)clean.custom.calorieOnly=true;if(m.custom.partialNutrition===true)clean.custom.partialNutrition=true;if(Number.isFinite(m.custom.quantity)&&m.custom.quantity>0&&m.custom.quantity<=2000&&['g','ml','serving'].includes(m.custom.quantityUnit)){clean.custom.quantity=m.custom.quantity;clean.custom.quantityUnit=m.custom.quantityUnit;}if(typeof m.custom.sourceURL==='string'&&(/^https:\/\/world\.openfoodfacts\.org\/product\/[0-9]{8,14}$/.test(m.custom.sourceURL)||/^https:\/\/fdc\.nal\.usda\.gov\/food-details\/[0-9]+\/nutrients$/.test(m.custom.sourceURL)||[...localProducts,...snackProducts].some(f=>f.sourceURL===m.custom.sourceURL)))clean.custom.sourceURL=m.custom.sourceURL;}
   if(m.nutrition&&!m.custom)clean.nutrition=safeNutrition(m.nutrition);
   return clean;
  });
 }

 if(value.foodCatalogRevision!==2){for(const list of Object.values(s.meals))for(const m of list){const values=legacyNutrition[m.foodId],food=foods.find(f=>f.id===m.foodId);if(values&&!m.custom){m.custom={name:food.name[0]+' · eski kayıt',kcal:values[0],protein:values[1],carbs:values[2],fat:values[3]};}}}
 for(const [date,amount] of Object.entries(value.water||{})){if(!validDate(date)||!finite(amount,0,24))throw Error('water');s.water[date]=amount;}
 for(const [start,w] of Object.entries(value.weeks||{})){if(!validDate(start)||start!==weekStart(start)||!object(w)||!Array.isArray(w.planned)||w.planned.length>7||w.planned.some(d=>!validDate(d)||d<start||d>addDays(start,6)))throw Error('week');s.weeks[start]={...w,planned:[...new Set(w.planned)]};}
 for(const [date,plan] of Object.entries(value.mealPlans||{})){if(!validDate(date)||!Array.isArray(plan)||plan.length>4)throw Error('mealPlan');s.mealPlans[date]=plan.map(m=>{if(!['breakfast','lunch','dinner','snack'].includes(m.slot)||!(m.foodId===null||foods.some(f=>f.id===m.foodId))||!finite(m.servings,.25,5))throw Error('mealPlan');return m;});}
 for(const key of ['measurements','events','claims','chat','customPlans'])if(value[key]!==undefined&&(!Array.isArray(value[key])||value[key].length>5000))throw Error(key);
 s.measurements=(value.measurements||[]).map(m=>{if(!validId(m.id)||!validDate(m.date)||!finite(m.weight,35,300)||(m.waist!=null&&!finite(m.waist,30,250)))throw Error('measurement');return m;});
 s.events=(value.events||[]).map(e=>{if(!validId(e.id)||!validText(e.title,100)||!Number.isFinite(Date.parse(e.at))||!['workout','meal','sleep','other'].includes(e.type))throw Error('event');return e;});
 s.claims=(value.claims||[]).map(c=>{if(!validId(c.id)||!validText(c.key)||![1,3,30].includes(c.days)||!Number.isFinite(Date.parse(c.earnedAt)))throw Error('claim');return {...c,status:'preview'};});
 s.chat=(value.chat||[]).slice(-80).map(m=>{if(!['user','assistant'].includes(m.role)||!validText(m.text,10000)||(m.displayText!==undefined&&!validText(m.displayText,1000)))throw Error('chat');return {...m,source:m.source==='openai'?'openai':'local',delivery:m.delivery==='pending'?'failed':m.delivery};});
 s.customPlans=(value.customPlans||[]).map(safePlan);
 if(value.weeklyPlan!=null){const w=value.weeklyPlan;if(!object(w)||!validText(w.title,80)||!Array.isArray(w.days)||w.days.length!==7)throw Error('weeklyPlan');s.weeklyPlan={title:w.title,days:w.days.map(p=>{const day=safePlan(p);if(typeof p.off!=='boolean'||p.off&&day.items.length||!p.off&&!day.items.length)throw Error('weeklyDay');return {...day,off:p.off};})};}
 if(value.savedFoods!==undefined&&(!Array.isArray(value.savedFoods)||value.savedFoods.length>300))throw Error('savedFoods');
 s.savedFoods=(value.savedFoods||[]).map(f=>{if(!object(f)||!validId(f.id)||!validText(f.name,80)||!f.name.trim()||!['g','ml','serving'].includes(f.unit)||!validText(f.brand||'',80)||!validText(f.barcode||'',14))throw Error('savedFood');const n={};for(const k of nutrientFields){if(f[k]==null){if(['kcal','protein','carbs','fat'].includes(k))throw Error('savedFood');n[k]=null;}else{if(!finite(f[k],0,nutrientLimits[k]))throw Error('savedFood');n[k]=f[k];}}return {id:f.id,name:f.name,unit:f.unit,brand:f.brand||'',barcode:f.barcode||'',...n};});
 for(const [key,v] of Object.entries(value.shopping||{}))if(!['__proto__','constructor','prototype'].includes(key)&&typeof v==='boolean')s.shopping[key]=v;
 s.settings={usReleaseRevision:value.settings?.usReleaseRevision===1?1:0,lang:supportedLanguages.includes(value.settings?.lang)?value.settings.lang:'tr',units:value.settings?.units==='imperial'?'imperial':'metric',coach:['warm','direct','energetic','roast','analyst','planner'].includes(value.settings?.coach)?value.settings.coach:'warm',reminders:!!value.settings?.reminders,theme:['system','light','dark'].includes(value.settings?.theme)?value.settings.theme:'system',market:['TR','US','EU'].includes(value.settings?.market)?value.settings.market:'TR',restSound:!!value.settings?.restSound,accountAiConsent:value.settings?.accountAiConsent===true,coachContextConsent:value.settings?.coachContextConsent===true,coachProfileConsent:value.settings?.coachProfileConsent===true,cloudPrivateDetails:value.settings?.cloudPrivateDetails===true,autoCloud:value.settings?.autoCloud===true,servicesPrompted:value.settings?.servicesPrompted===true,coachPosition:object(value.settings?.coachPosition)&&finite(value.settings.coachPosition.x,0,1)&&finite(value.settings.coachPosition.y,0,1)?{x:value.settings.coachPosition.x,y:value.settings.coachPosition.y}:null};
 for(const key of ['workoutPlans','dayNotes','monthGoals','pantry'])if(value[key]!==undefined&&!object(value[key]))throw Error(key);
 for(const [date,p] of Object.entries(value.workoutPlans||{})){if(!validDate(date))throw Error('date');s.workoutPlans[date]=safePlan(p);}
 for(const [date,note] of Object.entries(value.dayNotes||{})){if(!validDate(date)||!validText(note,2000))throw Error('note');s.dayNotes[date]=note;}
 for(const [month,g] of Object.entries(value.monthGoals||{})){if(!/^\d{4}-\d{2}$/.test(month)||!validDate(month+'-01')||!object(g)||!Array.isArray(g.planned)||g.planned.length>31||g.planned.some(d=>!validDate(d)||!d.startsWith(month)))throw Error('month');s.monthGoals[month]={month,planned:[...new Set(g.planned)].sort(),createdAt:g.createdAt};}
 for(const [key,v] of Object.entries(value.pantry||{}))if(!['__proto__','constructor','prototype'].includes(key)&&key.length<=200&&typeof v==='boolean')s.pantry[key]=v;
 if(value.shoppingItems!==undefined&&(!Array.isArray(value.shoppingItems)||value.shoppingItems.length>200))throw Error('shoppingItems');
 s.shoppingItems=(value.shoppingItems||[]).map(x=>{if(!object(x)||!validId(x.id)||!validText(x.name,80)||!x.name.trim()||!finite(x.amount,.01,10000)||!['g','kg','ml','l','adet'].includes(x.unit)||!['produce','protein','dairy','pantry','other'].includes(x.category))throw Error('shoppingItem');return {id:x.id,name:x.name,amount:x.amount,unit:x.unit,category:x.category};});
 if(value.restTimer){const r=value.restTimer;if(!object(r)||!finite(r.endAt,0,Date.now()+600000)||!finite(r.remaining,0,600)||!finite(r.total,15,600)||typeof r.paused!=='boolean')throw Error('restTimer');s.restTimer={endAt:r.endAt,remaining:r.remaining,total:r.total,paused:r.paused};}
 if(value.stopwatch){const q=value.stopwatch;if(!object(q)||!finite(q.elapsed,0,604800000)||!finite(q.startedAt,0,Date.now()+60000)||typeof q.running!=='boolean'||!Array.isArray(q.laps)||q.laps.length>50||q.laps.some(v=>!finite(v,0,604800000)))throw Error('stopwatch');s.stopwatch={elapsed:q.elapsed,startedAt:q.startedAt,running:q.running,laps:q.laps};}
 if(value.legalAcceptance&&object(value.legalAcceptance)&&validText(value.legalAcceptance.version,30)&&Number.isFinite(Date.parse(value.legalAcceptance.at)))s.legalAcceptance={version:value.legalAcceptance.version,at:value.legalAcceptance.at};
 s.demo=!!value.demo;s.createdAt=Number.isFinite(Date.parse(value.createdAt))?value.createdAt:s.createdAt;
 if(value.activeWorkout&&value.activeWorkout.date===dayKey())s.activeWorkout=safeSession(value.activeWorkout);
 if(value.nutritionPreferences){const n=value.nutritionPreferences;s.nutritionPreferences={mode:["off","prefer","only"].includes(n.mode)?n.mode:"off",text:String(n.text||"").slice(0,2000),seed:Number.isInteger(n.seed)&&n.seed>=0&&n.seed<100000?n.seed:0};}
 return s;
}
