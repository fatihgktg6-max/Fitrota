# FitRota 0.5.0 — kapsamlı test sürümü

Canlı GitHub/Render sürümü değiştirilmedi. Paket, test ve sonraki kurulum aşaması içindir; mağaza yayınına tamamen hazır olduğu iddia edilmez.

| İstek | Bu paketteki durum |
|---|---|
| Dağınık ekranları düzenle | Ana ekran özet; antrenman, beslenme, takvim ve profil ayrıldı. Robot koç korunuyor. |
| Gün gün antrenman | Haftalık gün kartları; A/B tüm vücut, üst/alt vücut ve toparlanma; set/tekrar/dinlenme/ısınma ve ilerleme açıklaması. |
| Gün gün beslenme | 7 günlük görünüm, dört öğün, hedefe yaklaşık porsiyon, alternatifler ve alışveriş listesi. |
| Bilimsel kaynaklar | WHO, ACSM 2026, Mifflin–St Jeor ve CoFID incelendi; hesaplama varsayımları ayrıca açıklandı. Uzman onayı yapılmış değildir. |
| Kullanıcı sözleşmeleri | Koşullar, gizlilik/aydınlatma ve veri silme taslakları; ayrı onaylar, çevrimiçi URL’ler ve çevrimdışı görüntüleme. İşletmeci bilgileri/hukuk incelemesi eksik. |
| Google/Apple hesabı | Web/PWA için PKCE, şifreli HttpOnly oturum, ayrı cihaz kayıt alanı, açık seçimle bulut yedeği/silme. Sağlayıcı/veritabanı bağlanmadan kapalı. Yerel Android/iOS giriş SDK entegrasyonu henüz yapılmadı. |
| Günlük kalori | Profil ve aktiviteyle başlangıç tahmini; özel durumlarda hesaplama kapalı; manuel hedef ayrı. Kaydedilen/kalan enerji ve makrolar. |
| FatSecret benzeri beslenme düzeni | Tarih seçimi, öğün başlıkları, ekleme/düzenleme/silme, önceki günü kopyalama, etiketle kendi besinini girme. Markanın tasarımı/veritabanı kopyalanmadı. |
| Kronometre | Başlat/duraklat/sıfırla/tur, kalıcı sayaç; antrenman toplam süresi ve ayrı set dinlenmesi. |
| Müzik | Üç moda göre dokuz parça önerisi; Spotify/YouTube dış bağlantıları. Uygulama içi müzik yayını yok. |
| Hareket anlatımı | 21 özgün SVG hareket şeması, adım adım metin ve duraklatma. Şematik çizim; eğitmen incelemesi ve gerçek cihaz erişilebilirlik testi beklenir. |

## Kayıtların korunması

- Eski profiller, setler, notlar, su, ölçüm ve takvim verileri korunur.
- ≤0.4.1 öğün tahminleri eski değerleriyle saklanır; yeni CoFID tarifleri geçmiş toplamları değiştirmez.
- Hesap değişince başka kullanıcının cihaz profili açılmaz. Misafir verisi açık seçim olmadan hesaba/buluta aktarılmaz.
- Bulut yedeğinde revision kontrolü; farklı sekmede hesap değişiminde hesap kimliği kontrolü.
- JSON dışa/içe aktarımı devam eder. Günlük notu pencereyi kapatarak kaydetme korunur.

## Yapılan doğrulamalar

Ortam: Node.js 24.19.0, Chromium/Playwright. Proje hedefi Node 22+; bu turda ayrı Node 22 koşusu yapılmadı.

- 39 birim/sunucu testi: 16 temel, 6 özellik, 3 AI, 6 yeni bilimsel/hesaplama, 5 pilot sunucu, 3 hesap güvenliği.
- Yeni ekran testinde 96 kombinasyon: 2 dil × 2 tema × 3 ekran genişliği × 8 rota; taşma ve çalışma zamanı hatası yok.
- Mevcut UI testleri: profil oluşturma, su, uyarlama, set devamı/tamamlama, takvim, dil, özel plan, yedek, ölçüm, silme; ayrıca 48 özellik yerleşim kontrolü.
- Yeni UI akışları: günlük tarih, porsiyon düzeltme, özel besin, kalori hesabı, 7 gün, kronometre/tur/yenileme, dinlenme, müzik, hareket şeması, onaylar ve kullanıcılar arası yerel kayıt ayrımı.
- Sahte sağlayıcıyla AI bağlantısı, hata/yeniden deneme/iptal; hatırlanan oturum; uyku formu; PWA güncellemesi, çevrimdışı açılış ve API önbellek dışlama.
- Web geliştirme sunucusu, çevrimiçi/çevrimdışı sözleşme açılışı ve kaynak gizli dosya yolunun sunulmaması.
- Android/iOS kaynak eşitlemesi başarılı. İmzalı APK/AAB/IPA üretilmedi; telefon/tablet üzerinde fiziksel cihaz testi yapılmadı.

Gerçek OpenAI çağrısıyla ücretli test yapılmadı. Gerçek Google/Apple hesabı ve gerçek Supabase/RLS testleri, anahtarlar/proje bulunmadığından yapılamadı. Apple iptal yolunun gerçek sağlayıcıda doğrulanması özellikle gereklidir. Güvenlik testleri bağımsız penetrasyon testi değildir.

## Açık kalan kurulumlar

`ACCOUNT-SETUP.md`: Supabase, Google, Apple, yönlendirmeler ve gerçek ortam testleri.

`PUBLICATION-LEGAL.md`: işletmeci kimliği, veri saklama/aktarım koşulları, ülkelere göre hukuk incelemesi, mağaza beyanları ve silme gereksinimleri.

`CONTENT-SOURCES.md`: kaynaklar, lisans, veri satırları ve sağlık içeriğinin sınırları.

Kullanıcı başına AI kotası, ödeme/abonelik doğrulaması, gerçek ödül hakkı ve reklam eklenmedi. Pilot AI erişimi herkesin kullanacağı ticari hesap sistemine henüz bağlanmış değildir. Yayınlama sonraki aşamadır.
