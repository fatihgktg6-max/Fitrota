FITROTA 0.6.14 — ODEME VE SU KAYDI DUZELTMESI

Mevcut 0.6.12 kurulumu icin:
1. FitRota-0.6.14-Paddle-Water-Fix.zip dosyasini GitHub deposunun ana dizinine yukle.
2. Render Build Command:
python3 -m zipfile -e FitRota-0.6.14-Paddle-Water-Fix.zip . && python3 scripts/prepare-us-release.py && npm ci --include=dev && npm run build:us
3. Manual Deploy > Deploy latest commit.
SQL ve ortam degiskenlerini yeniden girmen gerekmiyor.

Degisiklikler:
- Odeme: Supabase'in basarili, bos 201 cevabini JSON okuma hatasi sayan kod duzeltildi.
- Odeme hatalari icin daha anlasilir mesajlar ve guvenli hata kodlari eklendi.
- Su: Cihaza yazma basarisizsa miktar geri alinir; kaydedilmemis degisiklik buluta/gorevlere gonderilmez.
- ABD biriminde dugmeler tam 8 US fl oz, metrik birimde 250 ml ekler/cikarir.
- Eski su kayitlari ve yedek formati korunur. Birim degisimi eski miktarlari degistirmez.
- Sifirda azaltma, mevcut 6 litre kayit sinirinda ekleme devre disidir. Sinir bir tuketim onerisi degildir.
- Gun degisince su karti yenilenir. Eski gune ait dugme yeni gunu yanlislikla degistirmez.
- Miktar ve dugmeler mobil icin ayri satirlarda; erisilebilir etiketler gorunen birimle aynidir.

Dogrulama: 31 otomatik test gecti (water, paddle, accounts); US build basarili.
Tarayici bu calisma ortaminda baslatilamadi; mobil gorsel kontrol ve canli sunucu testi yapilmadi.
Paket henuz Render'a uygulanmadi. Paddle kodu SANDBOX ile sinirlidir, gercek odeme almaz.

Yukleme sonrasi: sayfayi yenile; su ekle/cikar ve yeniden yukleyip saklandigini kontrol et.
Odeme testinde hata devam ederse yeni hata metnini/kodunu ilet. Gizli anahtarlari paylasma.
