# FitRota 0.5.5

Günlük spor ve beslenme düzeni için web/PWA test sürümü. Android/iOS kaynakları dahildir; imzalı mağaza paketi değildir. Canlı siteye otomatik gönderilmez.

Yeni akış: **Bugün → Antrenman → Beslenme → Takvim → Diğer/Profil**. Robot koç düğmesi ayrıca erişilebilir. Antrenmanda Programım / Sayaç & müzik / Hareketler; beslenmede Günlüğüm / Haftalık plan / Tarifler bulunur.

- Günlere göre antrenman ve toparlanma; süreye uygun başlangıç planları.
- 80 tarif ve 160 temel besin, CoFID 2021 kaynak kodlarıyla hesaplanan değerler; günlük enerji tahmini, öğün/porsiyon kaydı, kendi etiketinden besin ekleme.
- Kronometre, tur kaydı, set arası sayaç, dış müzik önerileri ve 60 hareketin yazılı adım adım anlatımı.
- Google/Apple web OAuth, ayrı kullanıcı alanları, isteğe bağlı bulut yedeği ve hesap silme altyapısı. Kendi sağlayıcı ve veritabanı ayarları olmadan devre dışıdır.
- Uygulama içi ve herkese açık kullanıcı belgesi taslakları. Gerçek işletmeci bilgisi ve hukuki inceleme beklenir.

Ayrıntılar: [Sürüm raporu](docs/RELEASE-0.5.0.md), [bilimsel kaynaklar](docs/CONTENT-SOURCES.md), [hesap kurulumu](docs/ACCOUNT-SETUP.md), [yayın belgeleri](docs/PUBLICATION-LEGAL.md).

## Yerel geliştirme

Node.js 22+: `npm ci`, `npm run check`, `npm run dev`. Son komut derlenmiş uygulamayı ve kullanıcı belgelerini `http://127.0.0.1:4173` üzerinden sunar; ücretli AI çağrısı yapmaz.

Üretim sunucusu: `server/.env.example` alanlarını kendi sunucu ortamında yapılandırıp `npm run server`. Gerçek API ve service-role anahtarları yalnız sunucuda tutulur; kaynak depoya veya HTML’e eklenmez.

Derleyici, mevcut sıfır-CDN çevrimdışı yaklaşımı koruyarak modül kaynaklarını sıralı tek HTML paketine toplar. `src/app.js` ve `src/upgrade.js` arayüz kapsamını paylaşır; doğrudan tarayıcıya modül dosyası olarak bağlanmaz. `index.html`, `FitRota-Onizleme.html`, `dist/` derlenmiş çıktılardır.

## Sınırlar

Doğrulanmış web/PWA hesabıyla AI kod girmeden açılır. Hesap başına 30 mesaj ve sonrasında 1 saat bekleme uygulanır; kurulum için database/002_ai_quota.sql gereklidir. Mağaza ödeme/ödül doğrulaması ve reklam etkin değildir. Android/iOS yerel giriş entegrasyonu ve gerçek cihaz testleri beklenir. İçerikler bireysel uzman onaylı diyet/antrenman reçetesi değildir. Bu paket tüm ülkelerde mağaza yayınına hazır sayılmaz.

0.5.1: geçici hesap hizmeti hatasında oturum korunur. Apple girişinde iptal ayarları aranır. `npm run check:config` gizli değerleri göstermeden sunucu ayarlarını kontrol eder. Ayrıntılar: docs/RELEASE-0.5.1.md.


0.5.5: 60 hareket, 80 tarif, 160 temel besin. Gram/porsiyon hesabına sodyum, kolesterol, şeker, doymuş yağ, potasyum, kalsiyum ve demir eklendi. Eksik kaynak değerleri bilinmiyor olarak korunur. Tarifler kahvaltı/öğle/akşam/ara öğün olarak ayrıldı; gramlı malzemeler ve adım adım hazırlık gösterilir. Ayrıntılar: docs/RELEASE-0.5.5.md.
