// Preserve historical estimates from <=0.4.1 when migrating old meal logs.
export const legacyNutrition={oats:[420,23,54,12],eggs:[410,24,38,18],fruitoat:[340,9,64,6],chicken:[540,43,55,16],lentil:[490,22,76,10],potato:[460,16,73,11],fish:[580,36,49,26],pasta:[510,23,84,8],tofu:[450,29,38,20],yogurt:[190,12,28,4],apple:[200,7,24,10],nuts:[220,5,27,12]};
