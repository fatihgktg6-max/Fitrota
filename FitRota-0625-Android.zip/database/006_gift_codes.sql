-- Run once in the Supabase SQL Editor. Safe to re-run. Requires auth.users.
begin;
create table if not exists public.fitrota_gift_codes (
 code_hash text primary key check(code_hash ~ '^[a-f0-9]{64}$'),
 label text not null default '', days integer not null check(days between 1 and 3650),
 max_uses integer not null check(max_uses between 1 and 100000),
 used_count integer not null default 0 check(used_count between 0 and max_uses),
 redeem_before timestamptz not null, disabled boolean not null default false,
 created_at timestamptz not null default clock_timestamp()
);
create table if not exists public.fitrota_gift_grants (
 user_id uuid primary key references auth.users(id) on delete cascade,
 premium_until timestamptz not null
);
create table if not exists public.fitrota_gift_redemptions (
 code_hash text not null references public.fitrota_gift_codes(code_hash),
 user_id uuid not null references auth.users(id) on delete cascade,
 redeemed_at timestamptz not null default clock_timestamp(),
 primary key(code_hash,user_id)
);
create table if not exists public.fitrota_gift_attempts (
 user_id uuid primary key references auth.users(id) on delete cascade,
 window_start timestamptz not null, attempts integer not null
);
alter table public.fitrota_gift_codes enable row level security;
alter table public.fitrota_gift_grants enable row level security;
alter table public.fitrota_gift_redemptions enable row level security;
alter table public.fitrota_gift_attempts enable row level security;
revoke all on public.fitrota_gift_codes,public.fitrota_gift_grants,public.fitrota_gift_redemptions,public.fitrota_gift_attempts from public,anon,authenticated;
grant select,insert,update,delete on public.fitrota_gift_codes,public.fitrota_gift_grants,public.fitrota_gift_redemptions,public.fitrota_gift_attempts to service_role;

-- Operator only: run in SQL Editor, never expose through a client-side admin screen.
create or replace function public.fitrota_issue_gift(p_days integer,p_max_uses integer default 1,p_redeem_before timestamptz default (clock_timestamp()+interval '30 days'),p_label text default '')
returns jsonb language plpgsql security invoker set search_path='' as $$
declare raw text; h text;
begin
 if p_days is null or p_days not between 1 and 3650 or p_max_uses is null or p_max_uses not between 1 and 100000 or p_redeem_before is null or p_redeem_before<=clock_timestamp() or not isfinite(p_redeem_before) then raise exception 'invalid_gift_options'; end if;
 raw:='FR'||upper(replace(gen_random_uuid()::text,'-',''));
 h:=encode(sha256(convert_to(raw,'UTF8')),'hex');
 insert into public.fitrota_gift_codes(code_hash,days,max_uses,redeem_before,label) values(h,p_days,p_max_uses,p_redeem_before,left(coalesce(p_label,''),120));
 return jsonb_build_object('code',raw,'id',h,'days',p_days,'maxUses',p_max_uses,'redeemBefore',p_redeem_before);
end; $$;

create or replace function public.fitrota_gift_status(p_user_id uuid)
returns jsonb language sql security invoker set search_path='' as $$
 select jsonb_build_object('premiumUntil',(select premium_until from public.fitrota_gift_grants where user_id=p_user_id and premium_until>clock_timestamp()));
$$;

create or replace function public.fitrota_redeem_gift(p_user_id uuid,p_code_hash text)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare t timestamptz:=clock_timestamp(); tries integer; c public.fitrota_gift_codes%rowtype; ending timestamptz;
begin
 if p_user_id is null then raise exception 'signin_required'; end if;
 -- Upsert locks the user's attempt row and serializes their concurrent redemptions.
 insert into public.fitrota_gift_attempts(user_id,window_start,attempts) values(p_user_id,t,1)
 on conflict(user_id) do update set
 attempts=case when public.fitrota_gift_attempts.window_start<=t-interval '15 minutes' then 1 else least(public.fitrota_gift_attempts.attempts+1,6) end,
 window_start=case when public.fitrota_gift_attempts.window_start<=t-interval '15 minutes' then t else public.fitrota_gift_attempts.window_start end
 returning attempts into tries;
 if tries>5 then return jsonb_build_object('error','gift_rate_limit'); end if;
 select * into c from public.fitrota_gift_codes where code_hash=p_code_hash for update;
 if not found then return jsonb_build_object('error','gift_invalid'); end if;
 if exists(select 1 from public.fitrota_gift_redemptions where code_hash=p_code_hash and user_id=p_user_id) then return jsonb_build_object('error','gift_already_used'); end if;
 if c.disabled or c.redeem_before<=t or c.used_count>=c.max_uses then return jsonb_build_object('error','gift_invalid'); end if;
 insert into public.fitrota_gift_grants(user_id,premium_until) values(p_user_id,t+make_interval(days=>c.days))
 on conflict(user_id) do update set premium_until=greatest(public.fitrota_gift_grants.premium_until,t)+make_interval(days=>c.days)
 returning premium_until into ending;
 insert into public.fitrota_gift_redemptions(code_hash,user_id) values(p_code_hash,p_user_id);
 update public.fitrota_gift_codes set used_count=used_count+1 where code_hash=p_code_hash;
 return jsonb_build_object('premiumUntil',ending,'days',c.days);
end; $$;
revoke all on function public.fitrota_issue_gift(integer,integer,timestamptz,text),public.fitrota_gift_status(uuid),public.fitrota_redeem_gift(uuid,text) from public,anon,authenticated;
grant execute on function public.fitrota_issue_gift(integer,integer,timestamptz,text),public.fitrota_gift_status(uuid),public.fitrota_redeem_gift(uuid,text) to service_role;
commit;
