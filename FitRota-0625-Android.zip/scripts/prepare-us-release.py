"""Reproducible source preparation: download verified public USDA data, build US index.
No credentials or user records are read. This script runs during Render build.
"""
from pathlib import Path
import hashlib,json,subprocess,sys,urllib.request,zipfile
root=Path(__file__).resolve().parent.parent
meta=json.loads((root/'docs/US-CATALOG.json').read_text())
target=root/'content/us-foods.sqlite'
import importlib.util
spec=importlib.util.spec_from_file_location('catalog_integrity',root/'scripts/catalog-integrity.py')
verifier=importlib.util.module_from_spec(spec);spec.loader.exec_module(verifier)
def verified():
 try:return verifier.catalog_digest(target)==(meta['records'],meta['contentSHA256'])
 except (OSError,RuntimeError, __import__('sqlite3').Error):return False
if target.exists() and verified():
 print('Verified US catalog already prepared');sys.exit(0)
source=root/'research/usda-branded.zip';source.parent.mkdir(exist_ok=True)
if not source.exists() or hashlib.file_digest(source.open('rb'),'sha256').hexdigest()!=meta['sha256']:
 print('Downloading public USDA US product data...',flush=True)
 request=urllib.request.Request(meta['source'],headers={'User-Agent':'FitRota-US-Catalog/0.6.11'})
 temporary=source.with_suffix('.download')
 with urllib.request.urlopen(request,timeout=120) as response,temporary.open('wb') as out:
  while chunk:=response.read(1024*1024):out.write(chunk)
 if hashlib.file_digest(temporary.open('rb'),'sha256').hexdigest()!=meta['sha256']:raise RuntimeError('USDA file checksum changed; review the new dataset before deploying')
 temporary.replace(source)
with zipfile.ZipFile(source) as archive:
 if archive.testzip() is not None:raise RuntimeError('USDA archive is corrupt')
subprocess.run([sys.executable,str(root/'scripts/build-us-catalog.py')],cwd=root,check=True)
if not verified():raise RuntimeError('US catalog records do not match the verified release')
print('US catalog prepared and verified',flush=True)
