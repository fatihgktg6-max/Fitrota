import {PADDLE_WEBHOOK_PATH} from './paddle.mjs';
import {paddleCheckoutHTML} from './paddle-checkout.mjs';
import {adsTxt} from './ads.mjs';
import {createBillingService} from './billing.mjs';
import {createQuotaService} from './quota.mjs';
import {createAccounts} from './accounts.mjs';
// Single-owner pilot server. Provider credentials stay on the server.
// HTTPS reverse proxy required when exposing outside loopback.
import http from 'node:http';
import {timingSafeEqual,createHash,createHmac,randomBytes,randomUUID} from 'node:crypto';
import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import {fileURLToPath,pathToFileURL} from 'node:url';
import path from 'node:path';
import {generateCoachReply,parseCoachPayload} from './ai.mjs';
const accounts=createAccounts();
const project=fileURLToPath(new URL('../',import.meta.url));
const digest=v=>createHash('sha256').update(v).digest();
const equal=(a,b)=>timingSafeEqual(digest(a),digest(b));
export function createCoachServer({accessCode,apiKey,model,launchMarket=process.env.FITROTA_LAUNCH_MARKET||'',countryProxySecret=process.env.FITROTA_COUNTRY_PROXY_SECRET||'',aiEnabled=process.env.FITROTA_AI_ENABLED!=='false',premiumModel=process.env.OPENAI_PREMIUM_MODEL||model,allowedOrigins=[],dailyLimit=100,ledgerFile=path.join(project,'.data/ai-usage.json'),reply=generateCoachReply,now=()=>Date.now(),accountService=accounts,quotaService=createQuotaService(),billingService=createBillingService()}={}){
 if(typeof accessCode!=='string'||accessCode.length<32||accessCode.startsWith('sk-'))throw Error('FITROTA_ACCESS_CODE must be a random 32+ character code, not a provider key.');
 if(!Number.isInteger(dailyLimit)||dailyLimit<1||dailyLimit>10000)throw Error('Invalid daily limit');
 const rememberName='fitrota_remember';
 const sign=value=>createHmac('sha256',accessCode).update('fitrota-remember-v1:'+value).digest('base64url');
 const remembered=req=>{try{const raw=(req.headers.cookie||'').split(';').map(v=>v.trim()).find(v=>v.startsWith(rememberName+'='))?.slice(rememberName.length+1)||'';const [payload,signature]=raw.split('.');if(!payload||!signature||!equal(sign(payload),signature))return false;const data=JSON.parse(Buffer.from(payload,'base64url'));return Number.isFinite(data.exp)&&data.exp>now()&&data.exp<=now()+7*86400000;}catch{return false;}};
 const setRemember=(req,res,enable)=>{const payload=Buffer.from(JSON.stringify({exp:now()+7*86400000,nonce:randomBytes(16).toString('hex')})).toString('base64url');const secure=!/^localhost(:|$)|^127\.0\.0\.1(:|$)/.test(req.headers.host||'');res.setHeader('Set-Cookie',`${rememberName}=${enable?payload+'.'+sign(payload):''}; Path=/session; HttpOnly; SameSite=Strict; Max-Age=${enable?604800:0}${secure?'; Secure':''}`);};
 const sessions=new Map(),attempts=new Map();let active=0,quotaQueue=Promise.resolve();const minute=[];
 async function consumeBudget(){const task=quotaQueue.then(async()=>{const day=new Date(now()).toISOString().slice(0,10);let ledger={day,used:0};try{const saved=JSON.parse(await readFile(ledgerFile,'utf8'));if(saved.day===day){if(!Number.isInteger(saved.used)||saved.used<0)throw Error('ledger_invalid');ledger=saved;}}catch(e){if(e.code!=='ENOENT')throw e;}if(ledger.used>=dailyLimit)throw Error('usage_limit');ledger.used++;await mkdir(path.dirname(ledgerFile),{recursive:true});const temp=ledgerFile+'.tmp';await writeFile(temp,JSON.stringify(ledger),{mode:0o600});await rename(temp,ledgerFile);});quotaQueue=task.catch(()=>{});return task;}
 const send=(res,code,data)=>{if(res.destroyed||res.writableEnded)return;res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});res.end(JSON.stringify(data));};
 async function body(req){if(!(req.headers['content-type']||'').startsWith('application/json'))throw Error('json_required');let bytes=0,chunks=[];for await(const chunk of req){bytes+=chunk.length;if(bytes>32000)throw Error('body_too_large');chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw Error('invalid_json');}}
 const configured=()=>aiEnabled&&!!apiKey&&!!model;
 const server=http.createServer(async(req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');
  // Only this exact server-to-server path bypasses the visitor country gate.
  // Requests must still pass Paddle signature + timestamp verification before any write.
  if(req.url===PADDLE_WEBHOOK_PATH){
   if(req.method!=='POST')return send(res,405,{error:'method'});
   if(!billingService.paddle?.configured)return send(res,503,{error:'billing_not_configured'});
   try{
    if(!(req.headers['content-type']||'').startsWith('application/json'))return send(res,415,{error:'json_required'});
    const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>262144)return send(res,413,{error:'body_too_large'});chunks.push(chunk);}
    return send(res,200,await billingService.paddle.webhook(Buffer.concat(chunks),req.headers['paddle-signature']));
   }catch(error){return send(res,error.message==='invalid_paddle_signature'?401:error.message==='invalid_paddle_event'?400:503,{error:['invalid_paddle_signature','invalid_paddle_event'].includes(error.message)?error.message:'billing_unavailable'});}
  }
  // The origin must be private behind a country-aware trusted reverse proxy.
  // Never trust a user-supplied country header without the proxy credential.
  if(launchMarket==='US'&&!req.url.startsWith('/legal/')&&req.url!=='/healthz'){
   if(countryProxySecret.length<32)return send(res,503,{error:'country_gate_not_configured'});
   const proxyToken=req.headers['x-fitrota-proxy-token'];
   if(typeof proxyToken!=='string'||!equal(proxyToken,countryProxySecret))return send(res,403,{error:'trusted_proxy_required'});
   if(req.headers['x-fitrota-country']!=='US')return send(res,403,{error:'market_not_available'});
  }
  if(req.url==='/healthz'&&req.method==='GET')return send(res,200,{ok:true});
  const origin=req.headers.origin;
  // Exact allowlist, no wildcard or reflected Origin. Native origins must be explicitly listed.
  if(origin&&!allowedOrigins.includes(origin))return send(res,403,{error:'origin_not_allowed'});
  if(origin){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type');res.setHeader('Access-Control-Allow-Methods','POST, DELETE, GET, OPTIONS');}
  if(req.method==='OPTIONS'){res.writeHead(204);res.end();return;}
  if(new URL(req.url,'http://local').pathname==='/paddle-checkout'&&req.method==='GET'){
   if(!billingService.paddle?.configured)return send(res,503,{error:'billing_not_configured'});
   res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end(paddleCheckoutHTML(billingService.paddle.publicConfig().token));return;
  }
  const accountCoach=['/account/ai-session','/account/coach'].includes(req.url);let accountOwner,membership;
  if(req.url==='/ads.txt'&&req.method==='GET'){res.writeHead(200,{'Content-Type':'text/plain','Cache-Control':'no-cache'});res.end(adsTxt());return;}
  if(req.url==='/coach-config'&&req.method==='GET')return send(res,200,{mode:accountService.enabled?'account':'pilot',configured:configured()});
  if(!accountCoach&&await accountService.handler(req,res))return;
  const assets={'/manifest.webmanifest':'application/manifest+json','/pwa.js':'text/javascript','/sw.js':'text/javascript','/icon-192.png':'image/png','/icon-512.png':'image/png','/apple-touch-icon.png':'image/png','/icon.svg':'image/svg+xml','/version.json':'application/json'};
  if(req.method==='GET'&&(/^\/catalog\/[a-f0-9]{16}\.json$/.test(req.url)||/^\/app-[a-f0-9]{16}\.js$/.test(req.url))){
   try{const zipped=/\bgzip\b/.test(req.headers['accept-encoding']||''),file=path.join(project,'dist',req.url.slice(1)+(zipped?'.gz':'')),data=await readFile(file);res.writeHead(200,{'Content-Type':req.url.endsWith('.json')?'application/json':'text/javascript; charset=utf-8','Cache-Control':'public,max-age=31536000,immutable','Vary':'Accept-Encoding',...(zipped?{'Content-Encoding':'gzip'}:{})});res.end(data);}catch{send(res,404,{error:'not_found'});}return;
  }
  if(req.method==='GET'&&Object.hasOwn(assets,req.url)){
   try{const data=await readFile(path.join(project,'dist',req.url.slice(1)));res.writeHead(200,{'Content-Type':assets[req.url],'Cache-Control':'no-cache','Service-Worker-Allowed':'/'});res.end(data);}catch{send(res,404,{error:'not_found'});}return;
  }
  if((req.url==='/'||req.url==='/index.html')&&req.method==='GET'){
   try{const html=await readFile(path.join(project,'dist/index.html'),'utf8');res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});const gpc=req.headers['sec-gpc']==='1';res.end(html.replace('<head>','<head><script>window.FITROTA_GPC='+JSON.stringify(gpc)+';</script>'));}catch{send(res,503,{error:'build_required'});}return;
  }
  try{
   if(accountCoach){
    if(!accountService.enabled)return send(res,503,{error:'account_not_configured'});
    if(req.url==='/account/ai-session'&&req.method!=='GET'||req.url==='/account/coach'&&req.method!=='POST')return send(res,405,{error:'method'});
    if(req.method==='POST'&&(!origin||!allowedOrigins.includes(origin)))return send(res,403,{error:'origin_not_allowed'});
    const current=await accountService.session(req,res);
    if(!current)return send(res,401,{error:'signin_required'});
    if(!configured())return send(res,503,{error:'ai_not_configured'});
    accountOwner=current.user.id;membership=await billingService.status(accountOwner);
    if(req.url==='/account/ai-session'){const quota=membership.premium?billingService.premiumQuota(membership):(await quotaService.status(accountOwner)).quota;return send(res,200,{configured:true,mode:'account',owner:accountOwner,quota});}
    if(req.headers['x-fitrota-owner']!==current.user.id)return send(res,409,{error:'account_changed'});
   }
   if(req.url==='/session'&&req.method==='GET'){
    if(!remembered(req))return send(res,401,{error:'session_expired'});
    if(!configured())return send(res,503,{error:'ai_not_configured'});
    for(const [key,s] of sessions)if(s.expiry<=now())sessions.delete(key);
    const rememberHash=digest(req.headers.cookie||'').toString('hex');for(const [key,s] of sessions)if(s.rememberHash===rememberHash)sessions.delete(key);
    if(sessions.size>=64)return send(res,429,{error:'usage_limit'});
    const token=randomBytes(32).toString('base64url'),expiry=now()+12*3600000;sessions.set(digest(token).toString('hex'),{expiry,rememberHash});
    return send(res,200,{configured:true,sessionToken:token,expiresAt:new Date(expiry).toISOString()});
   }
   if(req.url==='/session'&&req.method==='DELETE')setRemember(req,res,false);
   if(req.url==='/session'&&req.method==='POST'){
    const ip=req.socket.remoteAddress||'unknown';for(const [key,v] of attempts)if(v.until<=now())attempts.delete(key);
    if(attempts.size>1000)return send(res,429,{error:'usage_limit'});
    const a=attempts.get(ip)||{count:0,until:now()+60000};if(a.count>=10)return send(res,429,{error:'usage_limit'});a.count++;attempts.set(ip,a);
    const data=await body(req);if(typeof data.accessCode!=='string'||data.accessCode.length>200||!equal(data.accessCode,accessCode))return send(res,401,{error:'unauthorized'});
    if(!configured())return send(res,503,{error:'ai_not_configured'});
    for(const [key,s] of sessions)if(s.expiry<=now())sessions.delete(key);
    if(sessions.size>=64)return send(res,429,{error:'usage_limit'});
    setRemember(req,res,data.remember===true);
    const token=randomBytes(32).toString('base64url'),expiry=now()+12*60*60*1000;sessions.set(digest(token).toString('hex'),{expiry});
    return send(res,200,{configured:true,sessionToken:token,expiresAt:new Date(expiry).toISOString()});
   }
   if(!accountCoach){
   const raw=(req.headers.authorization||'').replace(/^Bearer /,'');const hash=digest(raw).toString('hex'),session=sessions.get(hash);
   if(!session||session.expiry<=now()){sessions.delete(hash);return send(res,401,{error:'session_expired'});}
   if(req.url==='/session'&&req.method==='DELETE'){sessions.delete(hash);return send(res,200,{ok:true});}
   if(req.url==='/health'&&req.method==='GET')return send(res,200,{ok:true,configured:configured(),mode:'single-owner-pilot'});
   }
   if(!['/coach','/account/coach'].includes(req.url)||req.method!=='POST')return send(res,404,{error:'not_found'});
   if(!configured())return send(res,503,{error:'ai_not_configured'});
   while(minute.length&&minute[0]<now()-60000)minute.shift();
   if(minute.length>=10||active>=2)return send(res,429,{error:'usage_limit'});
   const payload=await body(req);if(accountCoach&&payload.consent!==true)return send(res,400,{error:'consent_required'});parseCoachPayload(payload,{premium:membership?.premium===true});
   // Re-check after awaiting request body, then reserve the concurrency slot synchronously.
   if(active>=2||minute.length>=10)return send(res,429,{error:'usage_limit'});active++;minute.push(now());
   const controller=new AbortController();const disconnect=()=>{if(!res.writableEnded)controller.abort();};res.on('close',disconnect);
   let reservation,quota;
   try{
    if(accountCoach&&membership.premium){quota=billingService.premiumQuota(membership);}else if(accountCoach){reservation=randomUUID();const result=await quotaService.reserve(accountOwner,reservation);quota=result.quota;if(!result.allowed){reservation=null;res.setHeader('Retry-After',String(Math.max(1,Math.ceil((Date.parse(quota.resetAt)-Date.parse(quota.serverNow))/1000))));return send(res,429,{error:'account_quota_exhausted',quota});}}
    if(!membership?.premium)await consumeBudget();const result=await reply(payload,{apiKey,model:membership?.premium?premiumModel:model,signal:controller.signal,premium:membership?.premium===true});
    // Keep the reservation after a generated reply, including client disconnects.
    reservation=null;send(res,200,{...result,...(accountCoach?{quota}:{})});
   }catch(error){
    if(reservation){try{error.quota=(await quotaService.refund(accountOwner,reservation)).quota;}catch{/* Fail closed. A failed refund must never grant extra messages. */}}
    throw error;
   }finally{active--;res.off('close',disconnect);}
  }catch(error){const message=error.message||'';const status=['account_temporarily_unavailable','quota_unavailable','billing_unavailable','reward_unavailable','reward_database_not_ready'].includes(message)?503:message==='body_too_large'?413:message==='json_required'?415:message==='usage_limit'||message==='provider_rate_limit'?429:message==='premium_required'?403:/invalid_|last_message/.test(message)?400:error.name==='TimeoutError'?504:502;const safe=['premium_required','billing_unavailable','reward_unavailable','reward_database_not_ready','quota_unavailable','account_temporarily_unavailable','body_too_large','json_required','usage_limit','provider_rate_limit','invalid_json','invalid_messages','invalid_message','last_message_must_be_user','provider_error'];send(res,status,{error:error.name==='TimeoutError'?'timeout':safe.includes(message)?message:'request_failed',...(error.quota?{quota:error.quota}:{})});}
 });
 server.requestTimeout=35000;server.headersTimeout=10000;return server;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){
 const port=Number(process.env.PORT||8787),host=process.env.HOST||'127.0.0.1';
 const origins=(process.env.FITROTA_ALLOWED_ORIGINS||`http://127.0.0.1:${port},http://localhost:${port}`).split(',').map(x=>x.trim()).filter(Boolean);
 try{const server=createCoachServer({accessCode:process.env.FITROTA_ACCESS_CODE||process.env.FITROTA_DEV_TOKEN,apiKey:process.env.OPENAI_API_KEY,model:process.env.OPENAI_MODEL,allowedOrigins:origins,dailyLimit:Number(process.env.FITROTA_DAILY_CALL_LIMIT||100),ledgerFile:process.env.FITROTA_USAGE_FILE});server.listen(port,host,()=>console.log(`FitRota pilot server listening on ${host}:${port}. Provider credentials are never printed.`));}catch(e){console.error(e.message);process.exit(1);}
}
