from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json
root=Path(__file__).resolve().parent.parent
output=root.parent/'FitRota-0.6.11-US-Web.zip'
excluded={'dist','node_modules','.git','.data','.gradle','build','.idea','DerivedData','research','qa','android','ios'}
with ZipFile(output,'w',ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root)
  if not p.is_file() or p.is_symlink() or any(x in excluded for x in rel.parts):continue
  if rel.as_posix() in ['index.html','FitRota-Onizleme.html']:continue
  if p.name.startswith('.env') and p.name!='.env.example':continue
  if '.sqlite' in p.name:continue
  if p.suffix in {'.sqlite','.download','.jks','.keystore','.p12','.p8','.zip','.mobileprovision'} or p.name in {'local.properties','.apple-client-secret'}:continue
  z.write(p,rel.as_posix())
with ZipFile(output) as z:
 assert z.testzip() is None
 assert json.loads(z.read('package.json'))['version']=='0.6.11'
 assert 'src/branded-foods.js' in z.namelist()
 assert not any(n.startswith('dist/') for n in z.namelist())
print(output,output.stat().st_size)
