let notificationPlugin=null;
export function nativeNotifications(){const cap=window.Capacitor;if(!cap?.isNativePlatform?.())return null;return notificationPlugin??=(cap.registerPlugin?cap.registerPlugin('LocalNotifications'):cap.Plugins.LocalNotifications);}
export async function syncNotifications(events,enabled){
 const plugin=nativeNotifications();if(!plugin)return {native:false};
 const pending=await plugin.getPending();if(pending.notifications.length)await plugin.cancel({notifications:pending.notifications.map(n=>({id:n.id}))});
 if(!enabled)return {native:true,enabled:false};
 let permission=await plugin.checkPermissions();if(permission.display!=='granted')permission=await plugin.requestPermissions();
 if(permission.display!=='granted')throw Error('permission');
 const upcoming=events.filter(e=>!e.done&&new Date(e.at)>new Date()).sort((a,b)=>a.at.localeCompare(b.at)).slice(0,50);
 await plugin.schedule({notifications:upcoming.map((e,i)=>({id:i+1,title:'FitRota',body:e.title,schedule:{at:new Date(e.at)},sound:undefined}))});
 return {native:true,enabled:true,count:upcoming.length};
}
