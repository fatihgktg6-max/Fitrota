# FitRota 0.4.0 — günlük kullanım güncellemesi

## Notlardan uygulananlar

| İstek | Uygulamadaki karşılığı |
|---|---|
| İsteğe bağlı koyu tema | Üst menüden hızlı tema değişimi; Ayarlar'da açık/koyu/cihaza göre. Tercih yeniden açılışta korunur. |
| Aylık hedefe Premium hediyesi | Takvim ayının planlı günleri sabitlenir. Hepsi tamamlandığında 30 günlük (arayüzde 1 ay) Premium kazanım önizlemesi otomatik, bir kez kaydedilir. Dinlenme günleri ve demo kayıtları ödül üretmez. |
| Bölgesel Premium fiyatı | Türkiye 49,99 TL/ay; ABD $2.99/ay, planlanan fiyat olarak. Avrupa fiyatı belirlenmedi. Satın alma düğmesi kapalı. |
| Müzik önerileri | Antrenman ekranında odaklan/enerji/sakinleş tercihi ve Spotify/YouTube arama bağlantıları. Dahili lisanslı müzik oynatıcısı veya otomatik çalma değildir. |
| Yalnız set arası sayaç | Set tamamlanınca hareketin dinlenme süresi; 30/60/90/120 saniye seçimi, duraklat/sürdür/bitir. Son setten sonra gereksiz sayaç başlamaz. Saat temelli sayım, uygulama açıkken isteğe bağlı ses. |
| Seçimlerine göre kişiselleştirme | Spor ve beslenme ekranlarında hedef, süre, ekipman, gün sayısı veya beslenme/bütçe özeti; profil son adımında rota özeti. |
| Programı gün gün görme | Haftalık şerit, önceki/sonraki hafta, takvimden açılan günlük program. Hareket, set, tekrar ve dinlenme ayrıntıları. |
| Günlük not | Her tarih için 2.000 karaktere kadar not, yerel kayıt ve yedek desteği. AI'ye otomatik gönderilmez. |
| Alternatif hareket | Aynı kas grubundan, mevcut ekipmana uygun ve programda tekrarlanmayan seçenekler. Uygulama onaydan sonra o güne özeldir; değişen hareketin setleri sıfırlanır, diğerleri korunur. Tamamlanmış kayıtlar değiştirilmez. |
| Alışverişi yenileme | 1/3/7 günlük birleşik miktarlar; kategoriler, alındı/evde var, yalnız eksikler, özel ürün ekle/sil, işaret temizleme onayı ve metin dışa aktarma. |
| Genel kalite | Yenilenen giriş ve profil özeti, iki tema, küçük ekran düzenlemeleri ve azaltılmış hareket tercihi desteği. |

## Nasıl kullanılır?

- Tema: üstteki güneş düğmesi veya Ayarlar → Görünüm & deneyim.
- Program: Antrenman → Programım → bir güne dokun. Aynı ekranda not kaydet veya alternatif seç.
- Sayaç: Antrenmana başla → yaptığın seti işaretle. Elle süre seçmek de mümkün. Ayarlar'da ses açılabilir.
- Alışveriş: Beslenme → Alışveriş listesi. Evde var işaretini yalnız gereken miktar gerçekten elindeyse kullan; envanter miktarı otomatik ölçülmez. Alındı işaretleri seçilen tarih/aralık için tutulur, evde var işaretleri sen kaldırana kadar kalır.
- Premium: Ödüller → bölge seçimi. Şimdilik ödeme yok; yerel kazanım gerçek abonelik değildir.

## Aylık hedef kuralları

Hedef, uygulama ilgili ayda ilk açıldığında o anki profil günlerine göre oluşturulur. Kayıt tarihinden önceki günler sayılmaz. Mevcut ayın hedefi profil düzenlemesiyle küçülmez. Haftalık program günleri değişse bile aylık ödüle dahil tarihler günlük programda ayrıca belirtilir. Gelecek günler tamamlanmış gibi sayılamaz. Eski önizleme kazanımları korunur ve aynı ay için ikinci ödül üretilmez.

Herkese açık gerçek ödül/abonelik için kullanıcı hesabı, sunucuda güvenilir etkinlik kaydı, kötüye kullanım kontrolü ve mağaza ödeme doğrulaması gerekir. Bu pakette bunlar yapılmış gibi gösterilmez. Fiyatlar taslak olup para çekilmez.

## Yayın

Bu paketin dosya adı **FitRota-0.4.0.zip**. GitHub deposunun köküne ZIP'i açmadan yükleyin. İndirirken adın sonuna ek gelirse Render komutundaki adla eşleştirin.

Render Build Command:

```sh
python3 -m zipfile -e FitRota-0.4.0.zip . && npm ci --include=dev && npm run build
```

Start Command değişmez: `HOST=0.0.0.0 node server/index.mjs`.

Mevcut OpenAI anahtarı ve FitRota erişim kodu değişmez. Dağıtım tamamlandığında `https://fitrota.onrender.com/version.json` adresinde `0.4.0` görünmelidir. Uygulamadaki Güncelle düğmesiyle yeni sürüme geçin. Site verilerini temizlemeyin.

## Kayıt ve cihaz sınırları

0.3.x yerel kayıtları yeni alanların varsayılanlarıyla açılır. Temalar, günlükler, program değişiklikleri, alışveriş ürünleri ve aylık hedefler yedeğe dahildir. Güncellemeden önce Ayarlar → Yedeği indir önerilir. Eski sürüme dönmek yeni alanları kaybettirebilir; eski sürümde 0.4 yedeği açmayın.

Oturum hatırlama önceki 0.3.1 davranışını korur. Her cihazın yerel verisi ve oturumu ayrıdır. Web tarayıcısında uygulama tamamen kapalıyken dinlenme alarmı garantisi yoktur. Gerçek Android/iOS imzalı mağaza paketleri ve fiziksel cihaz doğrulaması bu ZIP'e dahil değildir.

## Geliştirme doğrulaması

`npm run check`, `npm run test:server`, `npm run test:ui`, `npm run test:features`, `npm run test:coach`, `npm run test:remember`, `npm run test:release`. Browser testleri için `npx playwright install chromium` gerekir. Android/iOS kaynak eşitlemesi: `npm run native:sync`.

GitHub yalnız ZIP tutuyorsa ZIP'in içindeki Actions iş akışı kendiliğinden etkin olmaz. Çalıştırmak için kaynak ağaç dosyalarının depo kökünde bulunması gerekir.
