# Ürün ve teknik devam planı

## Üzerinde anlaşılmış ürün

Spor + beslenme + motivasyon + takvim ve hatırlatıcılar. AI kullanıcının planını günlük koşullara uyarlamaya yardımcı olacak. Kullanıcı kendi programını da girebilecek. Haftalık/aylık hedefler gelişmiş AI hediyesi kazandıracak. Android ve iPhone; ABD, Avrupa, Türkiye. Abonelik opsiyonel. Taslak değiştirilebilir.

## İlk sürümün bilinçli sınırları

- Hesapsız ve yerel kayıt. Başka telefona otomatik aktarım yok; JSON yedek var.
- Tarih/saat cihazın yerel bölgesindedir. Saat dilimi değiştiren kullanıcıların gelecek bildirimleri yeniden planlaması gerekir.
- Egzersiz kataloğu basit başlangıç içerikleriyle sınırlı. İleri dönemlendirme ve kişinin ilerlemesine göre otomatik yük önerisi yok.
- Kilo hedefinden otomatik kalori açığı/fazlası üretilmiyor. Kullanıcı/uzman hedef girebilir.
- Öğün önerilerinin toplamı günlük besin gereksinimini karşılama iddiası taşımaz.
- Tarif maliyeti canlı fiyat değil, göreli 1/2/3 sınıfıdır. Bölgesel market/veri sağlayıcısı yok.
- Alerjen filtresi katalog alanlarına dayanır; çapraz bulaş ve paketli ürün varyasyonları bilinmez.
- Gerçek AI mesajlaşma akışı v0.2’de uygulandı. Standart/gelişmiş abonelik ayrımı ve ücretli erişim hâlâ taslak. Ödül yerel önizleme.
- Müzik entegrasyonu, takviye bilgi kütüphanesi, ayrıntılı uyku takibi ve egzersiz videoları sonraki sürüme kaldı.
- Native uygulamadaki bildirim, dosya indirme/ithal etme ve safe-area davranışı fiziksel cihaz testinden geçmedi. WebView indirilen dosyaları paylaşmak için Filesystem/Share eklentisi gerekebilir.
- Tasarım adı, ikon ve uygulama kimliği geçici. Marka araştırması yapılmadı.

## Bir sonraki anlamlı geliştirme

1. Kullanıcının tableti üzerinde çalışan debug APK üretip ekranları ve bildirimleri test et.
2. İsim, renk, ekranlar ve ilk sürümün ücretli/ücretsiz sınırlarını kullanıcının deneyiminden sonra sabitle.
3. Kimlik doğrulama ve cihazlar arası eşitleme: kullanıcıya ait veriler için erişim denetimi, güvenli saklama, hesap/veri silme.
4. Gerçek AI: sağlayıcı anahtarı sunucuda; kullanıcı rızası, ihtiyaç kadar veri paylaşımı, kişi/gün kota, hata mesajları ve zaman aşımı. Model yanıtlarını doğrudan plan veritabanına yazma; şemalı öneri, deterministik doğrulama ve kullanıcı onayı.
5. Ödeme: App Store ve Play satın alma makbuzları sunucuda doğrulanmalı. İstemciden gelen `premium:true` veya yerel ödül kaydı asla güvenilmez.
6. Ödül servisinde sunucunun zamanına göre dönem anahtarı, sabit hedef, kazanım başına benzersiz kayıt ve transaction gerekir. Ücretli kullanıcıya bonus kullanım hakkı ayrı tutulmalı. Hediye bitişi ücretlendirme başlatmamalı.
7. Uzman içerik incelemesi, genişletilmiş tarif/malzeme veri tabanı, İngilizce metin editörlüğü, bölge/dil ve birim testleri.
8. Mağaza hazırlığı: release imzası, ekran görüntüleri, gizlilik metni, veri beyanları ve gerçek cihaz erişilebilirlik testi. Bunlar henüz yapılmadı.

## v0.2 AI güncellemesi

Gerçek AI istemci/sunucu akışı uygulandı. Canlı hesap/sunucu henüz bağlanmadı. Güncel kurulum ve güvenlik sınırları için `LIVE-AI.md` esas alınmalıdır. Önceki v0.1 adaptör-only tanımı artık geçerli değildir.
