"""Generate an offline SR Legacy 2018 manual-search catalogue from official USDA CSV.
Source: https://fdc.nal.usda.gov/fdc-datasets/FoodData_Central_sr_legacy_food_csv_2018-04.zip
Download into research/usda-sr.zip. Generated JS is shipped; CSV archive is excluded.
"""
from pathlib import Path
from zipfile import ZipFile
import csv,io,json,re,math
root=Path(__file__).resolve().parent.parent
z=ZipFile(root/'research/usda-sr.zip')
def rows(file):
 path=next(n for n in z.namelist() if n.endswith('/'+file))
 return csv.DictReader(io.StringIO(z.read(path).decode('utf-8-sig')))
fields={1008:('kcal','KCAL'),1003:('protein','G'),1005:('carbs','G'),1004:('fat','G'),1079:('fiber','G'),2000:('sugar','G'),1258:('saturatedFat','G'),1253:('cholesterol','MG'),1093:('sodium','MG'),1092:('potassium','MG'),1087:('calcium','MG'),1089:('iron','MG')}
units={int(r['id']):r['unit_name'].upper() for r in rows('nutrient.csv')}
for id,(_,unit) in fields.items():assert units[id]==unit,(id,units[id])
nutrients={}
for r in rows('food_nutrient.csv'):
 id=int(r['nutrient_id'])
 if id not in fields:continue
 try:n=float(r['amount'])
 except ValueError:continue
 if not math.isfinite(n) or n<0:continue
 nutrients.setdefault(r['fdc_id'],{})[fields[id][0]]=n
# Readable Turkish keywords preserve source distinctions. Original full English name remains.
words=[('with skin','derili'),('without skin','derisiz'),('skinless','derisiz'),('boneless','kemiksiz'),('low fat','az yağlı'),('fat free','yağsız'),('fat-free','yağsız'),('reduced fat','azaltılmış yağlı'),('skim','yağsız'),('with added salt','tuz eklenmiş'),('without salt','tuzsuz'),('salt added','tuz eklenmiş'),('no salt added','tuz eklenmemiş'),('pan-fried','tavada kızarmış'),('stir-fried','tavada hızlı pişmiş'),('deep fried','bol yağda kızarmış'),('whole wheat','tam buğday'),('whole-wheat','tam buğday'),('raw','çiğ'),('cooked','pişmiş'),('boiled','haşlanmış'),('steamed','buharda pişmiş'),('stewed','sulu pişmiş'),('fried','kızarmış'),('grilled','ızgara'),('roasted','fırınlanmış'),('baked','fırında pişmiş'),('broiled','üst ızgarada pişmiş'),('dried','kurutulmuş'),('frozen','dondurulmuş'),('canned','konserve'),('drained','süzülmüş'),('beef','dana eti'),('pork','domuz eti'),('lamb','kuzu eti'),('veal','dana eti'),('chicken','tavuk'),('turkey','hindi'),('duck','ördek'),('fish','balık'),('salmon','somon'),('tuna','ton balığı'),('sardines','sardalya'),('cod','morina'),('shrimp','karides'),('mackerel','uskumru'),('sausage','sosis'),('sausages','sosis'),('frankfurter','sosis'),('frankfurters','sosis'),('salami','salam'),('bologna','salam'),('cheese','peynir'),('yogurt','yoğurt'),('milk','süt'),('butter','tereyağı'),('cream','krema'),('eggs','yumurta'),('egg','yumurta'),('rice','pirinç'),('oats','yulaf'),('oat','yulaf'),('bulgur','bulgur'),('pasta','makarna'),('macaroni','makarna'),('spaghetti','spagetti'),('bread','ekmek'),('flour','un'),('wheat','buğday'),('barley','arpa'),('corn','mısır'),('quinoa','kinoa'),('beans','fasulye'),('lentils','mercimek'),('chickpeas','nohut'),('peas','bezelye'),('nuts','kuruyemiş'),('almonds','badem'),('walnuts','ceviz'),('hazelnuts','fındık'),('peanuts','yer fıstığı'),('cashews','kaju'),('pistachios','antep fıstığı'),('sesame','susam'),('sunflower','ayçiçek'),('pumpkin','kabak'),('seeds','çekirdek'),('potatoes','patates'),('potato','patates'),('eggplant','patlıcan'),('onions','soğan'),('onion','soğan'),('tomatoes','domates'),('tomato','domates'),('peppers','biber'),('pepper','biber'),('carrots','havuç'),('carrot','havuç'),('spinach','ıspanak'),('broccoli','brokoli'),('cabbage','lahana'),('cauliflower','karnabahar'),('cucumber','salatalık'),('lettuce','marul'),('zucchini','kabak'),('mushrooms','mantar'),('garlic','sarımsak'),('apples','elma'),('apple','elma'),('bananas','muz'),('banana','muz'),('oranges','portakal'),('orange','portakal'),('grapes','üzüm'),('strawberries','çilek'),('peaches','şeftali'),('pear','armut'),('pears','armut'),('cherries','kiraz'),('lemon','limon'),('lemonade','limonata'),('apricots','kayısı'),('avocados','avokado'),('watermelon','karpuz'),('melon','kavun'),('olive oil','zeytinyağı'),('canola oil','kanola yağı'),('oil','yağ'),('juice','meyve suyu'),('water','su'),('coffee','kahve'),('tea','çay'),('chocolate','çikolata'),('cookies','kurabiye'),('crackers','kraker'),('candy','şekerleme'),('chips','cips'),('ice cream','dondurma'),('ice-cream','dondurma'),('honey','bal'),('sugar','şeker'),('salt','tuz'),('soup','çorba'),('sauce','sos'),('brown','esmer'),('white','beyaz'),('sweet','tatlı'),('plain','sade'),('whole','tam'),('lean','yağsız'),('ground','kıyılmış')]
output=[]
for row in rows('food.csv'):
 id=row['fdc_id'];n=nutrients.get(id,{})
 if any(k not in n for k in ['kcal','protein','carbs','fat']):continue
 en=row['description'];tr=en.lower()
 for word,translation in words:tr=re.sub(r'\b'+re.escape(word)+r'\b',translation,tr)
 output.append({'id':'usda-'+id,'code':id,'name':[tr[0].upper()+tr[1:],en],'source':'usda','unit':'g',**{k:n.get(k) for k,_ in fields.values()}})
assert len({f['id'] for f in output})==len(output)
assert len(output)>5000
(root/'src/usda-foods.js').write_text('// USDA FoodData Central SR Legacy 2018; CC0. Historical source values, not current brand labels.\nexport const usdaFoods='+json.dumps(output,ensure_ascii=False,separators=(',',':'))+';\n')
print(len(output),'source-ID distinct USDA records with complete energy and macros')
