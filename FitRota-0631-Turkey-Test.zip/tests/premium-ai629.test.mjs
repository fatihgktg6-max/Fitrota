import {test} from 'node:test';import assert from 'node:assert/strict';
import {createCoachServer} from '../server/index.mjs';import {createBillingService} from '../server/billing.mjs';
const env={FITROTA_BILLING_ENABLED:'true',REVENUECAT_SECRET_KEY:'mock-server-secret',REVENUECAT_ENTITLEMENT:'fitrota_pro',FITROTA_REVENUECAT_SANDBOX:'true',FITROTA_PREMIUM_PRODUCTS:'fitrota_premium_monthly,fitrota_premium_monthly:monthly',FITROTA_LEGAL_OPERATOR:'Test',FITROTA_PRIVACY_EMAIL:'test@example.test',FITROTA_LEGAL_ADDRESS:'Test address',FITROTA_RETENTION_NOTICE:'Test retention',FITROTA_REGION_NOTICE:'Test regions',FITROTA_PROCESSING_BASIS_NOTICE:'Test basis',FITROTA_TRANSFER_NOTICE:'Test transfer',FITROTA_LEGAL_REVIEWED:'true'};
for(const privateMode of [false,true])test('server-verified Play test subscription grants Premium AI without free quota; private mode '+privateMode,async()=>{
 const owner='premium-owner';let providerCalls=0,quotaCalls=0;const origins=[];
 const billingService=createBillingService({env:{...env,FITROTA_ACCOUNT_TEST_MODE:String(privateMode),FITROTA_LEGAL_REVIEWED:privateMode?'false':'true'},fetcher:async url=>{assert.ok(url.endsWith('/'+owner));return Response.json({subscriber:{entitlements:{fitrota_pro:{product_identifier:'fitrota_premium_monthly',expires_date:'2099-01-01T00:00:00Z'}},subscriptions:{'fitrota_premium_monthly:monthly':{is_sandbox:true}}}});}});
 const accountService={enabled:true,handler:async()=>false,session:async req=>req.headers.cookie==='session=owner'?{user:{id:owner}}:null};
 const quotaService={status:async()=>{quotaCalls++;throw Error('free quota should not run');},reserve:async()=>{quotaCalls++;throw Error('free quota should not run');}};
 const server=createCoachServer({accessCode:'mock-access-code-longer-than-thirty-two',apiKey:'mock-key',model:'free-model',premiumModel:'premium-model',allowedOrigins:origins,accountService,billingService,quotaService,launchMarket:'',reply:async(payload,options)=>{providerCalls++;assert.equal(options.premium,true);assert.equal(options.model,'premium-model');return {text:'Mock Premium reply',source:'openai'};}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;origins.push(base);
 try{const headers={Origin:base,Cookie:'session=owner','X-Fitrota-Owner':owner,'Content-Type':'application/json'};
 const session=await fetch(base+'/account/ai-session',{headers});assert.equal(session.status,200);const info=await session.json();assert.equal(info.owner,owner);assert.equal(info.quota.unlimited,true);
 const reply=await fetch(base+'/account/coach',{method:'POST',headers,body:JSON.stringify({consent:true,messages:[{role:'user',content:'Hello'}],context:{coach:'warm'}})});assert.equal(reply.status,200);assert.equal((await reply.json()).quota.unlimited,true);assert.equal(providerCalls,1);assert.equal(quotaCalls,0);
 const forged=await fetch(base+'/account/coach',{method:'POST',headers:{...headers,'X-Fitrota-Owner':'another-owner'},body:JSON.stringify({consent:true,messages:[{role:'user',content:'Hello'}]})});assert.equal(forged.status,409);assert.equal(providerCalls,1);
 }finally{await new Promise(r=>server.close(r));}
});
