# FitRota 0.6.23 — Android AdMob integration candidate

This is source code, not a signed APK/AAB and not a completed store release.
The existing web build remains available. Do not upload this candidate to production.

Implemented:
- Capacitor Android project com.fitrota.app, versionCode 623.
- AdMob plugin 8.2.0, supplied Android application ID and banner ID.
- Google test banner enabled by default in src/admob-config.js.
- UMP consent update/form before advertising, privacy options from Advertising privacy.
- Non-personalized banner; no health/food/profile targeting fields.
- Ads require a signed-in owner, verified server membership and freshly verified native billing.
- Premium, opt-out, unknown entitlement, logout and background states suppress the banner.
- Native advertising never loads web AdSense/CMP scripts.
- Adaptive banner space reserved below navigation; physical-device layout still requires validation.
- Android launch icon uses the provided FitRota logo. Android backup disabled.

Validation: see tests/admob.test.mjs for consent, account-switch and late asynchronous response cases.
Build web: npm ci --include=dev && npm run build:us
Sync Android: npx cap sync android
Android toolchain: install the JDK and Android SDK required by Capacitor 8 and this project's Gradle configuration.

RELEASE BLOCKERS:
1. src/upgrade.js currently skips initializeAccount on native devices. Implement native Google sign-in plus authenticated backend requests; localhost relative API URLs are not a native account integration. Never embed the gateway secret in the app.
2. src/revenuecat-config.js is in test mode and its Android production public API key is empty. Configure Google Play subscription, RevenueCat entitlement fitrota_pro and offering, then test purchase/restore/cancel with license testers. The web Paddle flow is not the native store flow.
3. Signed AAB, upload key, Play Console internal test and physical-device checks have not been performed. This environment lacks the Android SDK and only has JDK 17.
4. Verify UMP published US message, opt-out, premium purchase removal, account switching, keyboard/navigation layout and lifecycle on Android with TEST ads. Confirm banner format matches the supplied ad unit. Only then disable testMode for a release candidate.
5. Complete the Play Console ads declaration and Data safety/health declarations based on actual shipping behavior, not this scaffold. Keep app-ads.txt at the developer website.

No Play Console publication or production ad activation has been performed.
