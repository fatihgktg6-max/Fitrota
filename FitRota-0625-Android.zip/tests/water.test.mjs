import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {emptyState,validateBackup} from '../src/core.js';
const source=await readFile(new URL('../src/water.js',import.meta.url),'utf8');
const units=(await readFile(new URL('../src/units.js',import.meta.url),'utf8')).replace(/^export /gm,'');
function fixture(imperial=false){
 let date='2026-10-06',saved=null,failed=false,queued=0,notice='',timer,card={dataset:{date},outerHTML:''};
 const state=emptyState();state.settings.units=imperial?'imperial':'metric';
 const context=vm.createContext({state,today:()=>date,t:(tr,en)=>en,preciseNumber:n=>Number(n).toLocaleString('en-US',{maximumFractionDigits:1}),icon:()=>'',btn:(text,action,style,extra)=>`<button data-action="${action}" ${extra}>${text}</button>`,document:{hidden:false,querySelector:selector=>selector==='.daily-water'?card:null},setInterval:fn=>{timer=fn;},toast:text=>{notice=text;},saveState:s=>{if(failed)return false;saved=JSON.stringify(s);return true;},queueCloudSave:()=>queued++,queueRewardSync:()=>queued++});
 vm.runInContext(units+'\n'+source,context);
 return {state,context,add:()=>context.updateWater('water-plus',{dataset:{date}}),minus:()=>context.updateWater('water-minus',{dataset:{date}}),restore:()=>validateBackup(JSON.parse(saved)),fail:()=>{failed=true;},get queued(){return queued;},get notice(){return notice;},get card(){return card;},nextDay:()=>{date='2026-10-07';},tick:()=>timer()};
}
test('water survives reload and unit changes without rewriting historical amounts',()=>{
 const f=fixture();f.state.water['2026-10-05']=4;f.add();f.add();assert.equal(f.restore().water['2026-10-06'],2);f.minus();assert.equal(f.restore().water['2026-10-06'],1);assert.equal(f.restore().water['2026-10-05'],4);
 f.state.settings.units='imperial';assert.match(f.context.waterCard(),/8\.5 US fl oz/);f.add();assert.ok(Math.abs(f.context.waterAmount()-(250+8*29.5735295625))<.000001);f.minus();assert.ok(Math.abs(f.context.waterAmount()-250)<.000001);
});
test('failed storage rolls back water and does not send unsaved data to cloud or rewards',()=>{
 const f=fixture();f.fail();f.add();assert.equal(Object.hasOwn(f.state.water,'2026-10-06'),false);assert.equal(f.queued,0);assert.match(f.notice,/could not be saved/);
 f.state.water['2026-10-06']=4;f.minus();assert.equal(f.state.water['2026-10-06'],4);
});
test('zero and upper limits, malformed input, and accessible US controls',()=>{
 const f=fixture(true);assert.match(f.context.waterCard(),/data-action="water-minus"[^>]*disabled/);assert.match(f.context.waterCard(),/aria-label="Add 8 US fl oz"/);f.minus();assert.equal(f.context.waterAmount(),0);
 for(let i=0;i<100;i++)f.add();assert.ok(f.context.waterAmount()<=6000);assert.match(f.context.waterCard(),/data-action="water-plus"[^>]*disabled/);assert.match(f.context.waterCard(),/not an intake recommendation/);
 const value=f.context.waterAmount();f.context.updateWater('water',{dataset:{value:'NaN'}});assert.equal(f.context.waterAmount(),value);assert.doesNotThrow(()=>f.restore());
});
test('midnight refresh preserves yesterday and stale buttons cannot edit the new day',()=>{
 const f=fixture();f.add();f.nextDay();f.context.updateWater('water-minus',{dataset:{date:'2026-10-06'}});assert.equal(f.state.water['2026-10-06'],1);assert.equal(f.state.water['2026-10-07'],undefined);assert.match(f.notice,/new day/);f.tick();assert.match(f.card.outerHTML,/data-date="2026-10-07"/);f.add();assert.equal(f.restore().water['2026-10-07'],1);assert.equal(f.restore().water['2026-10-06'],1);
});
