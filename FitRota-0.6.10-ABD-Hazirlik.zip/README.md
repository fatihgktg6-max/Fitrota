# FitRota 0.6.10 — ABD web/PWA hazırlığı

Güncel kurulum, ülke kapısı ve tamamlanması gereken panel işlemleri: [ABD-YAYIN-0610.md](docs/ABD-YAYIN-0610.md). US build: `npm run build:us`. Canlı ayarlar bu paket hazırlanırken değiştirilmedi.

# FitRota 0.6.9 — Veri güvenliği güncellemesi

Güncel veri envanteri, değişiklikler, hukuki açık işler ve dağıtım komutu: [docs/KVKK-VERI-AKISI-069.md](docs/KVKK-VERI-AKISI-069.md). Yeni paket: FitRota-0.6.9-Veri-Guvenligi.zip. Eski sürüm komutları aşağıda tarihsel açıklamalardır; yeni paket için üstteki belgeyi kullan.

# FitRota Web 0.6.8

Web yayın adayı. Kurulum ve dış hizmetlerde kalan işlemler: [Son sürüm kurulum rehberi](docs/SON-SURUM-KURULUM.md).

```
npm ci --include=dev
npm run build
npm run server
```

- Google giriş; Apple giriş düğmesi kaldırılmıştır.
- 150.007 kaynaklı besin/ürün; büyük katalog gerektiğinde yüklenir.
- Aydınlık/koyu tema; Profil içinde Premium ve hediye kodu.
- Sunucudan doğrulanan üyelik, RevenueCat web ödeme entegrasyonu, izin kontrollü manuel AdSense alanı.
- Her dış hizmet canlı hesap yapılandırması ve gerekli onayları ister; bu paket kendiliğinden onay sağlamaz.

`npm test` temel testleri, `node tests/release068-ui.mjs` web sürüm testlerini çalıştırır. Playwright Chromium gerektirir.
