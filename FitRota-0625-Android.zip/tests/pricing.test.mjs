import test from 'node:test';
import assert from 'node:assert/strict';
import {createCoachServer} from '../server/index.mjs';
import {createCountryGateway} from '../deploy/us-proxy/worker.mjs';
import {MONTHLY_PRICES} from '../server/billing.mjs';
test('pricing is public through the existing gateway while app and checkout stay US-only',async()=>{
 const secret='p'.repeat(40);let accounts=0;
 const server=createCoachServer({accessCode:'a'.repeat(40),launchMarket:'US',countryProxySecret:secret,accountService:{handler:async()=>{accounts++;return false;}},billingService:{}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;
 try{
  const gateway=createCountryGateway(req=>fetch(base+new URL(req.url).pathname,{method:req.method,headers:req.headers}));
  const env={FITROTA_ORIGIN:'https://fitrota.onrender.com',FITROTA_COUNTRY_PROXY_SECRET:secret};
  const r=await gateway(new Request('https://gateway.test/legal/pricing'),env);assert.equal(r.status,200);const html=await r.text();assert.match(html,/\$2\.99/);assert.match(html,/USD \/ month/);assert.match(html,/Coming soon/);assert.match(html,/renew monthly until cancelled/);assert.match(html,/mailto:fitrotaaa@gmail.com/);assert.doesNotMatch(html,/<script|test_[a-z0-9]|pri_[a-z0-9]/);assert.match(r.headers.get('content-security-policy'),/form-action 'none'/);
  for(const route of ['/app','/account/membership','/paddle-checkout']){assert.equal((await gateway(new Request('https://gateway.test'+route),env)).status,403);assert.equal((await fetch(base+route)).status,403);}
  const refund=await gateway(new Request('https://gateway.test/legal/refunds'),env);assert.equal(refund.status,200);const policy=await refund.text();assert.match(policy,/approval is not guaranteed/);assert.match(policy,/Account deletion does not cancel billing/);assert.match(policy,/https:\/\/paddle.net/);assert.match(html,/href="\/legal\/refunds"/);
  assert.equal((await fetch(base+'/legal/refunds',{method:'POST'})).status,405);
  assert.equal((await fetch(base+'/legal/pricing?review=1')).status,200);
  assert.equal((await fetch(base+'/legal/pricing',{method:'POST'})).status,405);
  assert.equal(await(await fetch(base+'/legal/pricing',{method:'HEAD'})).text(),'');assert.equal(accounts,0);
  assert.equal(MONTHLY_PRICES.find(p=>p.country==='US').amount,2.99);
 }finally{await new Promise(r=>server.close(r));}
});
