# FitRota 0.5.8 — otomatik hizmetler

Web/PWA güncellemesi. ZIP canlı siteyi kendiliğinden değiştirmez; GitHub'a dosyaları yükleyip Render'da yayımla. Android/iOS kaynakları dahildir, imzalı mağaza paketi değildir. Mevcut Google sağlayıcı kurulumu korunur; Apple ancak sağlayıcı ve iptal ayarları hazırsa kullanılabilir.

## Kullanım

Profil/Ayarlar → Otomatik hizmet ayarları: AI ve bulut için iki ayrı seçimi bir kez onayla. Google/Apple giriş ekranında da aynı seçimler bulunur. Tercihler cihazdaki hesap alanında hatırlanır. AI otomatik bağlanır, erişim kodu istenmez; bağlantı mesaj göndermez veya kota tüketmez. Paylaşımı aynı ayardan kapatabilirsin. Mevcut 30 mesaj + 2 saat kotası korunur.

Bulut izni sonrası değişiklikler yaklaşık 1,5 saniyelik bekleme ile hesabına kaydedilir. Uygulama açık ve bağlantı varken çalışır; kapalı uygulamada arka plan kaydı garantisi yoktur. Çevrimdışı kayıtlar cihazda korunur; bağlantı gelince yeniden denenir. Başka cihazda giriş yapıp bulut iznini açtığında, boş cihaz profiline bulut kaydı yüklenir. Açık uygulama uzak değişiklikleri 30 saniyede kontrol eder. İki cihazda farklı değişiklik varsa seçim gerekir; otomatik birleştirme yapılmaz. Bulut kopyasının silinmesi diğer açık cihazda da seçim doğurur. Çıkış yapma, henüz yüklenemeyen hesabına özel yerel kayıtlarını silmez; hesabı/cihaz verisini silme ayrı işlemdir. Otomatik yedeği kapatmak mevcut bulut kopyasını silmez.

Robot simgesini parmakla sürükle; konumu bu cihazda hatırlanır ve ekran boyutu değişince görünür alanda kalır. Klavye oklarıyla da taşınır. Hareket azaltma tercihi animasyonu durdurur. Konumu hizmet ayarından sıfırlayabilirsin.

Beslenme → İçecekler: 17 yeni CoFID içecek kaydı, mevcut süt seçenekleri, gramla günlük kayıt. Marka etiketinde miktar ml ise etiket formunu kullan. Protein tozu formunda paketindeki kalori/protein/karbonhidrat/yağ değerlerini yaz; tükettiğin gramla hesaplanır. Örneğin 100 g için 400 kcal ve 80 g protein, 30 g için 120 kcal ve 24 g protein yapar. Bilinmeyen mikro besinler sıfır sayılmaz. Sütle hazırlanıyorsa süt ayrıca kaydedilir.

Beslenme → Takviyeler: 13 vitamin, 7 mineral, 5 spor takviyesi ve 3 diğer başlık; toplam 28 kaynaklı rehber. Kategori ve arama bulunur. Vegan tercihinde B12 kaynak planlaması hatırlatılır; sağlık kısıtlarında uzman değerlendirmesi gösterilir. Rehber kişisel eksiklik tanısı veya doz reçetesi değildir. NIH ODS ve NHS kaynak bağlantıları kartlarda bulunur. Tüm olası takviyeleri kapsamaz.

## Kurulum

Bu güncelleme yeni SQL istemez. Önceki hesap/veri ve kota tabloları, 003_ai_cooldown_2h.sql ile 2 saatlik düzen hazır olmalıdır. Render ortam değişkenleri korunur.

Build Command: `npm ci && npm run build`

Start Command: `npm run server`

## Doğrulama

40 çekirdek/içerik/antrenman testi; OAuth seçimlerinin korunmasını da içeren hesap testleri; otomatik AI, bulut kaydı, çevrimdışı yeniden deneme, yeni cihaz geri yükleme, çakışma/silme, robot sürükleme/yeniden yükleme, etiket oranları ve rehber filtreleri için tarayıcı testi. Mevcut içerik, özel hesap, hesap koçu ve 96 düzen kontrolü de çalıştırıldı. AI ve hesap testlerinde sahte sağlayıcı kullanıldı; gerçek kullanıcı hesabında dağıtım sonrası kontrol gerekir.
