import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {mkdir} from 'node:fs/promises';
import {createCoachServer} from '../server/index.mjs';
import {emptyState,normalizeProfile} from '../src/core.js';
const owner='10000000-0000-4000-8000-000000000001',other='10000000-0000-4000-8000-000000000002';
let premium=false,fail=false;const expiry=new Date(Date.now()+30*86400000).toISOString(),origins=[];
const accountService={enabled:true,handler:async(req,res)=>{
 let data,status=200;
 if(req.url==='/account/config')data={configured:true,providers:['google'],legalReady:true};
 else if(req.url==='/account/me')data={user:{id:owner,email:'test@example.test'},preferences:{aiConsent:false,autoCloud:false}};
 else if(req.url==='/account/billing-config')data={enabled:false,giftCodesEnabled:true,webCheckout:false,prices:[],adsEnabled:false};
 else if(req.url==='/account/membership'){if(fail){status=503;data={error:'gift_unavailable'};}else data={owner,premium,expiresAt:premium?expiry:null,source:premium?'gift_code':null};}
 else if(req.url==='/account/redeem-gift'){
  assert.equal(req.headers['x-fitrota-owner'],owner);let body='';for await(const c of req)body+=c;const code=JSON.parse(body).code;
  if(code!=='FR'+'A'.repeat(32)){status=400;data={error:'gift_invalid'};}else if(premium){status=409;data={error:'gift_already_used'};}else{premium=true;data={ok:true,premiumUntil:expiry,days:30};}
 }else if(req.url==='/account/rewards')data={enrolled:false};else return false;
 res.writeHead(status,{'Content-Type':'application/json'});res.end(JSON.stringify(data));return true;
}};
const server=createCoachServer({accessCode:'ui-test-only-32-characters-long-secret',allowedOrigins:origins,accountService});await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;origins.push(base);
const browser=await chromium.launch({args:['--no-sandbox']}),ctx=await browser.newContext({viewport:{width:390,height:844}}),p=await ctx.newPage(),errors=[];p.on('pageerror',e=>errors.push(e.message));
const seed=emptyState();seed.profile=normalizeProfile({name:'Test',age:30,height:180,weight:80,days:[1,3,5]});seed.settings.theme='dark';seed.settings.servicesPrompted=true;
await ctx.addInitScript(({owner,seed})=>localStorage.setItem('fitrota.account.'+owner,JSON.stringify(seed)),{owner,seed});await mkdir('qa',{recursive:true});
try{
 await p.goto(base);await p.waitForFunction(()=>accountInfo.user?.id&&membershipState().config);
 await p.waitForFunction(()=>document.documentElement.dataset.theme==='dark');
 assert.equal(await p.evaluate(()=>getComputedStyle(document.documentElement).backgroundColor),'rgb(11, 16, 32)');
 await p.locator('.mobile-brand [data-action="membership"]').click();await p.locator('#gift-code').fill('BAD');await p.locator('[data-action="gift-redeem"]').click();await p.locator('#gift-code-result').filter({hasText:'Kod geçersiz'}).waitFor();
 await p.locator('#gift-code').fill('FR'+'A'.repeat(32));await p.locator('#gift-code').press('Enter');await p.waitForFunction(()=>isPremium());assert.equal(await p.locator('.mobile-brand .brand-title').textContent(),'FitRotaPremium');await p.locator('#gift-code-result').filter({hasText:'Hediye kodun kullanıldı'}).waitFor();
 await p.screenshot({path:'qa/gift-success-mobile.png',fullPage:true});await p.evaluate(()=>closeModal());
 for(const width of [320,390,768,850,900,1280]){await p.setViewportSize({width,height:844});await p.evaluate(()=>render());assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,'width '+width);}
 await p.screenshot({path:'qa/black-premium-desktop.png',fullPage:true});await p.setViewportSize({width:390,height:844});await p.screenshot({path:'qa/black-premium-mobile.png',fullPage:true});
 for(const page of ['food','workout','coach','settings','rewards']){await p.evaluate(page=>navigate(page),page);assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,page);}
 await p.evaluate(async()=>{await showMembership();});await p.locator('#gift-code').fill('FR'+'A'.repeat(32));await p.locator('[data-action="gift-redeem"]').click();await p.locator('#gift-code-result').filter({hasText:'zaten kullandın'}).waitFor();
 await p.evaluate(()=>{closeModal();state.settings.theme='light';navigate('home');});await p.screenshot({path:'qa/light-premium-mobile.png',fullPage:true});
 await p.evaluate(other=>{accountInfo.user={id:other};render();},other);assert.equal(await p.evaluate(()=>isPremium()),false);assert.equal(await p.locator('.mobile-brand .brand-premium').count(),0);
 await p.evaluate(owner=>{accountInfo.user={id:owner};},owner);fail=true;await p.evaluate(async()=>{await refreshMembership();render();});assert.equal(await p.evaluate(()=>isPremium()),true);assert.equal(await p.evaluate(()=>membershipState().status),'unavailable');
 await p.evaluate(()=>{accountInfo.user=null;render();});await p.locator('.mobile-brand [data-action="membership"]').click();assert.equal(await p.locator('#gift-code').count(),0);assert.ok((await p.locator('.gift-code-section').textContent()).includes('giriş yap'));
 assert.deepEqual(errors,[]);console.log('PASS: amethyst theme, Premium header, code validation/redemption/reuse, account isolation, preservation during temporary outage, guest flow, responsive pages. Mock account/API.');
}finally{await browser.close();await new Promise(r=>server.close(r));}
