"""Reproduce CoFID 2021 data and original FitRota recipes. Requires openpyxl.
Download official Excel to research/cofid.xlsx; Render uses generated JS directly.
"""
from pathlib import Path
import json, openpyxl
root=Path(__file__).resolve().parent.parent
book=openpyxl.load_workbook(root/'research/cofid.xlsx',read_only=True,data_only=True)
rows={r[0]:r for r in book['1.3 Proximates'].values if r[0]}
minerals={r[0]:r for r in book['1.4 Inorganics'].values if r[0]}
original=json.loads((root/'content/original-food-specs.json').read_text())
spec={k:[*v,'other'] for k,v in original['spec'].items()}
for line in (root/'content/ingredient-expansion.tsv').read_text().splitlines():
 k,code,tr,category,allergens,cost=line.split('\t');spec[k]=[code,tr,allergens.split(',') if allergens else [],int(cost),category]
# Assign legacy ingredient categories without changing their nutrient rows or amounts.
for category,keys in {'grain':['oat','bread','bulgur','rice','pasta'],'fruit':['apple','banana'],'dairy':['yog','milk','cottage'],'egg':['egg'],'legume':['bean','chickpea','lentil','tofu'],'vegetable':['tomato','potato','broccoli','carrot'],'nut':['seed','almond'],'meat':['chicken','turkey'],'fish':['salmon'],'drink':['soy'],'fat':['oil']}.items():
 for k in keys:spec[k][-1]=category
keys=['kcal','protein','carbs','fat','fiber','sugar','saturatedFat','sodium','cholesterol','potassium','calcium','iron']
def num(value):
 if value=='Tr':return 0.0  # Trace is below reporting precision, not missing.
 try:return float(value)
 except (ValueError,TypeError):return None
ings={}
for k,(code,tr,allergens,cost,category) in spec.items():
 r=rows[code];m=minerals[code]
 values={n:num(r[i]) for n,i in {'kcal':12,'protein':9,'carbs':11,'fat':10,'fiber':25,'sugar':16,'saturatedFat':27,'cholesterol':46}.items()}
 values.update({n:num(m[i]) for n,i in {'sodium':7,'potassium':8,'calcium':9,'iron':12}.items()})
 assert all(values[n] is not None for n in keys[:4]),(k,values)
 ings[k]={'code':code,'name':[tr,r[1]],**values,'allergens':allergens,'cost':cost,'category':category}

recipes=[]
for id,tr,en,typ,parts in original['specs']:
 method='bowl' if typ in ['breakfast','snack'] else 'pasta' if 'pasta' in id else 'warm-bowl'
 recipes.append([id,tr,en,typ,parts,method,10 if typ!='main' else 30])
for line in (root/'content/recipe-expansion.tsv').read_text().splitlines():
 parts=line.split('\t');parts[-1]=int(parts[-1]);recipes.append(parts)
assert len(recipes)==80
meat={'chicken','turkey','chicken-thigh','beef','mince','lamb'}
fish={'salmon','cod','mackerel','trout','haddock','prawn','tuna','tuna-oil','sardine'}
dairy={k for k,v in ings.items() if 'milk' in v['allergens'] or v['category']=='egg'}
# Original preparation steps. Source technique reference is FoodSafety.gov, not copied recipe text.
def prepare(k,g):
 n=ings[k]['name'];amount=f'{g:g} g'
 if k in meat:
  temp='74°C' if k in {'chicken','turkey','chicken-thigh'} else '71°C' if k=='mince' else '63°C'
  rest=' Bütün kırmızı et parçasını 3 dakika dinlendir.' if k in {'beef','lamb'} else ''
  enrest=' Rest whole red-meat cuts for 3 minutes.' if rest else ''
  return [f'{n[0]} için eti ayrı tahtada hazırla. Merkezini termometreyle {temp} olacak şekilde pişir.{rest} Kemik/deri ve tarifte dışlanan yağı ayır; piştikten sonra {amount} tart.',f'Prepare {n[1]} on a separate board. Cook to {temp} internally, checked with a thermometer.{enrest} Remove bone/skin and excluded fat; weigh {amount} after cooking.']
 if k in fish:
  if k in {'tuna','tuna-oil','sardine'}:return [f'{n[0]} konservesini süz; süzülmüş yenebilir kısımdan {amount} tart.',f'Drain {n[1]}; weigh {amount} of the drained edible portion.']
  return [f'{n[0]} için balık/karidesi merkezinde 63°C olacak şekilde pişir. Kılçık, deri veya kabuğu ayır; piştikten sonra {amount} yenebilir kısım tart.',f'Cook fish/prawns for {n[1]} to an internal 63°C. Remove bones, skin or shells; weigh {amount} edible portion after cooking.']
 if k in {'egg','eggwhite','eggyolk'}:return [f'Yumurtayı akı ve sarısı katılaşana kadar haşla. Kabuklarını soy; listedeki yumurta kısmından {amount} tart.',f'Boil eggs until whites and yolks are firm. Peel and weigh {amount} of the specified egg component.']
 if k in {'oat','bulgur','quinoa','buckwheat'}:return [f'{n[0]} için {amount} kuru ürün tart. Paketindeki su oranı ve süreyle pişir; sade su eklemek hesaplanan enerjiyi değiştirmez.',f'Weigh {amount} dry {n[1]}. Cook with the water ratio and time on the packet; plain water does not change calculated energy.']
 if k in {'rice','brownrice','pasta','whitepasta','couscous','barley','lentil','redlentil','chickpea','bean','haricot','blackeye'}:return [f'{n[0]} ürününü tuzsuz suda paket talimatıyla pişir, süz ve pişmiş halde {amount} tart. Kuru gramı bu pişmiş gram yerine kullanma.',f'Cook {n[1]} in unsalted water following packet instructions, drain, then weigh {amount} cooked. Do not substitute dry weight for cooked weight.']
 if k=='tofu':return [f'Tofuyu buharda paket talimatına göre pişir, süz ve piştikten sonra {amount} tart.',f'Steam tofu following packet instructions, drain, and weigh {amount} after cooking.']
 if k=='potato' or k=='sweetpotato':return [f'{n[0]} için patatesi fırında yumuşayana kadar pişir; yenebilir kısımdan pişmiş halde {amount} tart.',f'Bake the potato until tender, then weigh {amount} cooked edible portion for {n[1]}.']
 if k in {'potato-boiled','broccoli','carrot','spinach-cooked','zucchini-cooked','eggplant','cauliflower','cabbage-cooked','pea','beet','leek','greenbean'}:return [f'{n[0]} sebzesini listede belirtilen şekilde tuzsuz haşla veya buharda pişir. Suyunu süzüp pişmiş halde {amount} tart.',f'Boil/steam {n[1]} without salt as listed. Drain and weigh {amount} cooked.']
 if ings[k]['category'] in {'vegetable','fruit'}:return [f'{n[0]} ürününü yıka, yenmeyen kısmı ayır ve {amount} tart. Sebzeyi ince doğra; meyveyi küçük parçalara böl.',f'Wash {n[1]}, remove inedible parts and weigh {amount}. Slice vegetables finely; cut fruit into small pieces.']
 return [f'{n[0]} ürününden {amount} tart; varsa paketindeki kullanıma hazırlama talimatını izle.',f'Weigh {amount} of {n[1]}; follow preparation instructions on its packet, if any.']
finish={
'bowl':['Hazırlanan malzemeleri bir kasede karıştır. Yoğurt veya içecek varsa yulafın üzerine ekle; meyve ve çekirdeği en son yerleştir.','Combine prepared ingredients in a bowl. Add listed yogurt/drink to oats; top with fruit and seeds.'],
'porridge':['Pişmiş yulafa listedeki süt veya soya içeceğini karıştır. Kısık ateşte 2–3 dakika kıvam ver; meyve, baharat ve kuruyemişi üzerine ekle.','Stir the listed milk/soy drink into cooked oats. Simmer 2–3 minutes to thicken; top with fruit, spices and nuts.'],
'plate':['Hazırlanan ana malzemeyi tabağa yerleştir. Tahıl, patates, sebze veya ekmeği yanında ayrı sun. Listedeki yağı sebzelere dağıt.','Plate the prepared main ingredient. Serve grain, potato, vegetables or bread alongside; distribute listed oil over vegetables.'],
'warm-bowl':['Pişmiş tahıl, bakliyat veya tofuyu sebzelerle geniş tavada birleştir. Listedeki yağı ekleyip kısık ateşte 3–5 dakika ısıt; yapışırsa biraz su ekle.','Combine cooked grain, legumes or tofu with vegetables in a wide pan. Add listed oil and warm gently for 3–5 minutes; add water if needed.'],
'salad':['Pişmiş malzemeleri soğutup doğranmış çiğ sebzelerle karıştır. Listedeki yağ ve limonu ayrı kapta karıştırıp ekle. Peyniri varsa en son ufala.','Cool cooked ingredients and toss with chopped raw vegetables. Mix listed oil and lemon separately, add, then crumble any listed cheese on top.'],
'wrap':['Tortillayı kuru tavada hafif ısıt. Malzemeleri ortasına yerleştir, varsa yoğurt veya humusu yay. Yanları içeri katlayıp sıkıca sar.','Warm the tortilla briefly in a dry pan. Add fillings in the centre and spread listed yogurt/hummus. Fold sides inward and roll firmly.'],
'pasta':['Domatesi veya konserve domatesi listedeki yağla tavada 5–8 dakika pişir. Pişmiş makarna ve diğer malzemeleri ekleyip karıştır. Yoğun kıvamı birkaç kaşık makarna suyu ile aç.','Cook listed tomato/canned tomato with the oil for 5–8 minutes. Stir in cooked pasta and remaining ingredients. Loosen with a few spoonfuls of pasta water if needed.'],
'soup':['Haşlanmış mercimek, havuç ve patatesi tencereye al. İnce doğranmış soğanı ve 250–350 g sade suyu ekle; 10–15 dakika kaynat. İstersen blenderdan geçir; listedeki yağ ve ekmeği servis aşamasında ekle.','Put cooked lentils, carrot and potato in a pot. Add finely chopped onion and 250–350 g plain water; simmer 10–15 minutes. Blend if preferred; add listed oil and serve with bread.'],
'stew':['Listelenen pişmiş bakliyat/et, sebze, domates ve yağı tencereye al. Gerekiyorsa 100–150 g sade su ekleyerek kapağı kapalı 10–15 dakika hafifçe kaynat. Pirinç veya ekmeği yanında sun.','Combine listed cooked legumes/meat, vegetables, tomato and oil in a pot. Add 100–150 g plain water if needed and simmer covered for 10–15 minutes. Serve rice/bread alongside.'],
 'toast':['Ekmeği kuru tavada veya tost makinesinde kızart. Hazırlanan malzemeleri üzerine yerleştir; varsa peynir/tofuyu ayrı ısıtıp ekle. Meyveli tostta meyveyi kızartmadan en son koy.','Toast bread in a dry pan/toaster. Top with prepared ingredients; warm cheese/tofu separately if preferred. For fruit toast, add fruit last without toasting it.']}
foods=[];mainIndex=0
for id,tr,en,typ,parts,method,minutes in recipes:
 parts=[(k,float(q)) for k,q in (p.split(':') for p in parts.split())]
 totals={n:round(sum(ings[k][n]*q/100 for k,q in parts),1) if all(ings[k][n] is not None for k,q in parts) else None for n in keys}
 prep=[prepare(k,g) for k,g in parts]
 steps=[['Miktarlar 1 porsiyon içindir. Malzemeleri listedeki kuru/pişmiş ve yenebilir kısım durumuna göre tart; seçtiğin porsiyon sayısıyla çarp.','Amounts are for 1 serving. Weigh in the listed dry/cooked edible state; multiply by your chosen servings.'],*prep,finish[method],['Ek yağ, tuz, sos veya şeker kullanırsan bunları günlüğe ayrıca ekle. Hazırladığın toplam tarifi eşit porsiyonlara böl.','Log any additional oil, salt, sauce or sugar separately. Divide the prepared recipe into equal servings.']]
 slot=typ
 if typ=='main':slot='lunch' if mainIndex%2==0 else 'dinner';mainIndex+=1
 foods.append({'id':id,'name':[tr,en],'type':typ,'mealSlot':slot,'mealSlots':['lunch','dinner'] if typ=='main' else [typ],'emoji':'🥣' if typ=='breakfast' else '🥗','minutes':minutes,'cost':max(ings[k]['cost'] for k,q in parts),'diet':'omnivore' if any(k in meat|fish for k,q in parts) else 'vegetarian' if any(k in dairy for k,q in parts) else 'vegan','allergens':sorted({a for k,q in parts for a in ings[k]['allergens']}),**totals,'ingredients':[[*ings[k]['name'],q,'g'] for k,q in parts],'ingredientAmounts':[[k,q] for k,q in parts],'sourceCodes':[ings[k]['code'] for k,q in parts],'methodSteps':steps,'steps':[' '.join(step[i] for step in steps) for i in range(2)]})
basic=[]
for k,i in ings.items():
 diet='omnivore' if i['category'] in ['meat','fish'] else 'vegetarian' if i['category']=='egg' or any(a in i['allergens'] for a in ['milk','egg']) else 'vegan'
 basic.append({**i,'id':'basic-'+k,'type':'ingredient','diet':diet,'defaultGrams':1 if k=='salt' else 10 if i['category'] in ['fat','condiment'] else 100,'ingredients':[[*i['name'],100,'g']],'sourceCodes':[i['code']]})
assert len(basic)==160,len(basic)
text='// CoFID 2021 subset; Crown copyright, Open Government Licence v3.0. See docs/CONTENT-SOURCES.md.\n'
for name,data in [('nutrientIngredients',ings),('curatedFoods',foods),('basicFoods',basic)]:text+='export const '+name+'='+json.dumps(data,ensure_ascii=False,separators=(',',':'))+';\n'
(root/'src/food-data.js').write_text(text)
print(len(foods),'original recipes;',len(basic),'traced basic foods')
