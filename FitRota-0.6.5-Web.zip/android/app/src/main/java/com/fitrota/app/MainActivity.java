package com.fitrota.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
