import {test} from 'node:test';
import assert from 'node:assert/strict';
import {PGlite} from '@electric-sql/pglite';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createGiftService} from '../server/gifts.mjs';
import {createBillingService} from '../server/billing.mjs';
const a='10000000-0000-4000-8000-000000000001',b='10000000-0000-4000-8000-000000000002';
const env={FITROTA_GIFT_CODES_ENABLED:'true',SUPABASE_URL:'https://example.supabase.co',SUPABASE_SERVICE_ROLE_KEY:'private'};
async function database(){const d=new PGlite();await d.exec(`create role anon;create role authenticated;create role service_role bypassrls;create schema auth;create table auth.users(id uuid primary key);insert into auth.users values('${a}'),('${b}');`);const sql=await readFile(new URL('../database/006_gift_codes.sql',import.meta.url),'utf8');await d.exec(sql);await d.exec(sql);return d;}
async function issue(d,days=30,uses=1){return (await d.query("select public.fitrota_issue_gift($1,$2,clock_timestamp()+interval '1 day','test') v",[days,uses])).rows[0].v;}
async function redeem(d,user,hash){return (await d.query('select public.fitrota_redeem_gift($1::uuid,$2) v',[user,hash])).rows[0].v;}
test('atomic uses, duplicate prevention, stacking, persistent attempts and expired/disabled codes',async()=>{
 const d=await database();try{
  const c=await issue(d,30,1);assert.match(c.code,/^FR[A-F0-9]{32}$/);assert.equal(c.id,createHash('sha256').update(c.code).digest('hex'));
  const r=await redeem(d,a,c.id);assert.ok(Date.parse(r.premiumUntil)>Date.now()+29*86400000);
  assert.equal((await redeem(d,a,c.id)).error,'gift_already_used');assert.equal((await redeem(d,b,c.id)).error,'gift_invalid');
  const c2=await issue(d,7,2);const stacked=await redeem(d,a,c2.id);assert.equal(Date.parse(stacked.premiumUntil)-Date.parse(r.premiumUntil),7*86400000);
  await redeem(d,b,c2.id);assert.equal((await d.query('select used_count from public.fitrota_gift_codes where code_hash=$1',[c2.id])).rows[0].used_count,2);
  const expired=await issue(d);await d.query("update public.fitrota_gift_codes set redeem_before=clock_timestamp()-interval '1 second' where code_hash=$1",[expired.id]);assert.equal((await redeem(d,a,expired.id)).error,'gift_invalid');
  const disabled=await issue(d);await d.query('update public.fitrota_gift_codes set disabled=true where code_hash=$1',[disabled.id]);assert.equal((await redeem(d,a,disabled.id)).error,'gift_invalid');
  assert.equal((await redeem(d,a,null)).error,'gift_rate_limit');
  await d.query("update public.fitrota_gift_attempts set window_start=clock_timestamp()-interval '16 minutes' where user_id=$1",[a]);assert.equal((await redeem(d,a,null)).error,'gift_invalid');
  // Deleting an account removes its entitlement, but never restores the used-code budget.
  await d.query('delete from auth.users where id=$1',[a]);assert.equal((await d.query('select count(*)::int n from public.fitrota_gift_grants where user_id=$1',[a])).rows[0].n,0);assert.equal((await d.query('select used_count from public.fitrota_gift_codes where code_hash=$1',[c.id])).rows[0].used_count,1);
 }finally{await d.close();}
});
test('simultaneous redemption of last use cannot grant two accounts; client roles cannot mint/read/redeem',async()=>{
 const d=await database();try{const c=await issue(d);const results=await Promise.all([redeem(d,a,c.id),redeem(d,b,c.id)]);assert.equal(results.filter(x=>x.premiumUntil).length,1);
  for(const role of ['anon','authenticated']){await d.exec('set role '+role);await assert.rejects(issue(d));await assert.rejects(redeem(d,a,c.id));await assert.rejects(d.query('select * from public.fitrota_gift_grants'));await assert.rejects(d.query('select * from public.fitrota_gift_codes'));await assert.rejects(d.query('select public.fitrota_gift_status($1::uuid)',[a]));await d.exec('reset role');}
  await d.exec('set role service_role');assert.ok((await issue(d)).code);
 }finally{await d.close();}
});
test('only hashes leave server; invalid input consumes database limiter; gifts work without paid billing',async()=>{
 const until=new Date(Date.now()+86400000).toISOString(),calls=[];
 const fetcher=async(url,opt)=>{calls.push({url,body:JSON.parse(opt.body)});return Response.json({premiumUntil:until});};
 const gifts=createGiftService({env,fetcher});const code='FR'+'A'.repeat(32);
 await gifts.redeem(a,' '+code.toLowerCase()+' ');assert.equal(calls[0].body.p_user_id,a);assert.equal(calls[0].body.p_code_hash,createHash('sha256').update(code).digest('hex'));assert.ok(!JSON.stringify(calls).includes(code));
 await gifts.redeem(a,'bad');assert.equal(calls[1].body.p_code_hash,null);
 const bill=createBillingService({env,fetcher});assert.equal(bill.config().enabled,false);assert.equal(bill.config().giftCodesEnabled,true);const s=await bill.status(a);assert.equal(s.premium,true);assert.equal(s.source,'gift_code');assert.equal(s.owner,a);
 const unavailable=createGiftService({env,fetcher:async()=>new Response('{}',{status:404})});await assert.rejects(unavailable.redeem(a,code),/gift_unavailable/);
 await assert.rejects(createGiftService({env:{}}).redeem(a,code),/gift_disabled/);
 const expired=createBillingService({env,fetcher:async()=>Response.json({premiumUntil:'2001-01-01'})});assert.equal((await expired.status(a)).premium,false);
});
test('gift verification failure preserves verified purchases; RevenueCat outage preserves verified gifts',async()=>{
 const config={...env,FITROTA_BILLING_ENABLED:'true',REVENUECAT_SECRET_KEY:'secret',FITROTA_REGION_NOTICE:'Test region notice',FITROTA_PROCESSING_BASIS_NOTICE:'Test basis notice',FITROTA_TRANSFER_NOTICE:'Test transfer notice',FITROTA_LEGAL_REVIEWED:'true',FITROTA_LEGAL_OPERATOR:'Operator',FITROTA_PRIVACY_EMAIL:'a@example.test',FITROTA_LEGAL_ADDRESS:'Address',FITROTA_RETENTION_NOTICE:'Retention'};
 const until=new Date(Date.now()+86400000).toISOString();
 for(const giftFails of [true,false]){
  const billing=createBillingService({env:config,fetcher:async url=>{
   if(url.endsWith('/fitrota_gift_status'))return giftFails?new Response('{}',{status:503}):Response.json({premiumUntil:until});
   if(url.endsWith('/fitrota_reward_cycle'))return Response.json({enrolled:false});
   return giftFails?Response.json({subscriber:{entitlements:{fitrota_pro:{product_identifier:'monthly',expires_date:until}},subscriptions:{monthly:{is_sandbox:false}}}}):new Response('{}',{status:503});
  }});
  const s=await billing.status(a);assert.equal(s.premium,true);assert.equal(s.source,giftFails?'purchase':'gift_code');
 }
});
