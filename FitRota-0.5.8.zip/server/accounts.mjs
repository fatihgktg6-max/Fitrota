import {randomBytes,createHash,createCipheriv,createDecipheriv,timingSafeEqual} from 'node:crypto';
import {validateBackup} from '../src/core.js';
import {legalConfig,legalDocuments,legalHTML,LEGAL_VERSION} from './legal.mjs';
export function accountTestConfig(env={}){
 const emails=(env.FITROTA_TEST_EMAILS||'').split(',').map(x=>x.trim().toLowerCase());
 const valid=emails.length>0&&emails.length<=10&&emails.every(x=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(x));
 return {enabled:env.FITROTA_ACCOUNT_TEST_MODE==='true'&&valid,emails:valid?new Set(emails):new Set()};
}
export function createAccounts({env=process.env,fetcher=fetch,now=()=>Date.now()}={}){
 const c=legalConfig(env),base=env.SUPABASE_URL||'',key=env.SUPABASE_PUBLISHABLE_KEY||'',admin=env.SUPABASE_SERVICE_ROLE_KEY||'',secret=env.FITROTA_SESSION_SECRET||'',origin=env.FITROTA_PUBLIC_ORIGIN||'';
 const validURL=(v,loop=false)=>{try{const u=new URL(v);return (u.protocol==='https:'||loop&&u.protocol==='http:'&&['localhost','127.0.0.1'].includes(u.hostname))&&u.origin===v;}catch{return false;}};
 const test=accountTestConfig(env),testMode=env.FITROTA_ACCOUNT_TEST_MODE==='true';
 const enabled=validURL(base)&&validURL(origin,true)&&!!key&&!!admin&&secret.length>=32&&(testMode?test.enabled:c.ready);
 const providers=enabled?[...new Set((env.FITROTA_AUTH_PROVIDERS||'google').split(',').map(x=>x.trim()).filter(x=>x==='google'||!testMode&&x==='apple'&&env.APPLE_CLIENT_ID?.trim()&&env.APPLE_CLIENT_SECRET?.trim()))]:[];
 const allowedTester=(user,provider)=>!testMode||(provider==='google'&&test.emails.has((user.email||'').toLowerCase())&&user.identities?.some(i=>i.provider==='google'&&i.identity_data?.email_verified===true&&(i.identity_data.email||'').toLowerCase()===(user.email||'').toLowerCase()));
 const cryptoKey=createHash('sha256').update(secret).digest(),secure=origin.startsWith('https:');
 const send=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
 const seal=data=>{const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',cryptoKey,iv),body=Buffer.concat([cipher.update(JSON.stringify(data)),cipher.final()]);return Buffer.concat([iv,cipher.getAuthTag(),body]).toString('base64url');};
 const open=value=>{try{const buf=Buffer.from(value||'','base64url');const d=createDecipheriv('aes-256-gcm',cryptoKey,buf.subarray(0,12));d.setAuthTag(buf.subarray(12,28));const data=JSON.parse(Buffer.concat([d.update(buf.subarray(28)),d.final()]));return data.exp>now()?data:null;}catch{return null;}};
 const read=(req,name)=>open((req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith(name+'='))?.slice(name.length+1));
 const cookie=(res,name,data,maxAge=2592000)=>{const value=data?seal({...data,exp:now()+maxAge*1000}):'';if(value.length>3800)throw Error('session_too_large');const previous=res.getHeader('Set-Cookie')||[];res.setHeader('Set-Cookie',[...(Array.isArray(previous)?previous:[previous]),`${name}=${value}; Path=/account; HttpOnly; SameSite=Lax; Max-Age=${data?maxAge:0}${secure?'; Secure':''}`]);};
 const api=async(path,{method='GET',token,body,adminMode=false}={})=>{const res=await fetcher(base+path,{method,headers:{apikey:adminMode?admin:key,Authorization:'Bearer '+(adminMode?admin:token||key),'Content-Type':'application/json'},...(body!==undefined?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(12000),redirect:'error'});let data;try{data=await res.json();}catch{data={};}if(!res.ok){const error=Error(data.code==='P0001'?'sync_conflict':'account_provider_error');error.status=res.status;throw error;}return data;};
 async function readBody(req){let size=0,chunks=[];if(!(req.headers['content-type']||'').startsWith('application/json'))throw Error('json_required');for await(const chunk of req){size+=chunk.length;if(size>1024*1024)throw Error('body_too_large');chunks.push(chunk);}return JSON.parse(Buffer.concat(chunks).toString());}
 async function session(req,res){if(!enabled)return null;let s=read(req,'fitrota_account');if(!s)return null;
  try{let user;try{user=await api('/auth/v1/user',{token:s.access});}catch(err){if(err.status!==401)throw err;const token=await api('/auth/v1/token?grant_type=refresh_token',{method:'POST',body:{refresh_token:s.refresh}});s={...s,access:token.access_token,refresh:token.refresh_token};cookie(res,'fitrota_account',s);user=await api('/auth/v1/user',{token:s.access});}if(!user?.id)return null;if(testMode&&s.testConsent!==true||!allowedTester(user,s.provider)){cookie(res,'fitrota_account',null);return null;}return {s,user};}catch(error){if([400,401,403].includes(error.status)){cookie(res,'fitrota_account',null);return null;}throw Error('account_temporarily_unavailable');}}
 const publicUser=u=>({id:u.id,email:u.email||'',provider:u.app_metadata?.provider||''});
 const attempts=new Map();
 async function handler(req,res){const url=new URL(req.url,'http://local');
  if(url.pathname.startsWith('/legal/')){const id=url.pathname.split('/')[2],docs=legalDocuments(c);if(req.method!=='GET'){send(res,405,{error:'method'});return true;}if(id==='config'){send(res,200,{...c,documents:docs});return true;}if(!docs[id]){send(res,404,{error:'not_found'});return true;}res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end(legalHTML(docs[id],c));return true;}
  if(!url.pathname.startsWith('/account'))return false;
  if(url.pathname==='/account/config'&&req.method==='GET'){send(res,200,{configured:enabled,providers,legalReady:c.ready,testMode,version:LEGAL_VERSION,nativeReady:false});return true;}
  if(!enabled){send(res,503,{error:'account_not_configured'});return true;}
  if(!['GET','POST','DELETE'].includes(req.method)){send(res,405,{error:'method'});return true;}
  if(req.method!=='GET'&&req.headers.origin!==origin){send(res,403,{error:'origin_not_allowed'});return true;}
  try{
   if(url.pathname==='/account/login'&&req.method==='POST'){
    const ip=req.socket.remoteAddress||'',recent=(attempts.get(ip)||[]).filter(t=>t>now()-60000);if(recent.length>=10){send(res,429,{error:'login_limit'});return true;}if(attempts.size>10000)attempts.clear();attempts.set(ip,[...recent,now()]);
    const body=await readBody(req);if(!providers.includes(body.provider)||body.terms!==LEGAL_VERSION||testMode&&body.testConsent!==true){send(res,400,{error:'consent_required'});return true;}
    const verifier=randomBytes(32).toString('base64url'),state=randomBytes(24).toString('base64url');cookie(res,'fitrota_oauth',{verifier,state,provider:body.provider,accepted:LEGAL_VERSION,testConsent:testMode&&body.testConsent===true,aiConsent:body.aiConsent===true,autoCloud:body.autoCloud===true},600);
    const dest=new URL(base+'/auth/v1/authorize');dest.searchParams.set('provider',body.provider);dest.searchParams.set('redirect_to',origin+'/account/callback?state='+state);dest.searchParams.set('code_challenge',createHash('sha256').update(verifier).digest('base64url'));dest.searchParams.set('code_challenge_method','s256');
    send(res,200,{url:dest.href});return true;
   }
   if(url.pathname==='/account/callback'&&req.method==='GET'){
    const flow=read(req,'fitrota_oauth'),state=url.searchParams.get('state')||'',code=url.searchParams.get('code');cookie(res,'fitrota_oauth',null);
    const equal=flow&&state.length===flow.state.length&&timingSafeEqual(Buffer.from(state),Buffer.from(flow.state));if(!equal||!code)throw Error('invalid_oauth');
    const token=await api('/auth/v1/token?grant_type=pkce',{method:'POST',body:{auth_code:code,code_verifier:flow.verifier}});if(!token.access_token||!token.refresh_token)throw Error('invalid_oauth');
    const user=await api('/auth/v1/user',{token:token.access_token});if(!user.id)throw Error('invalid_oauth');
    if(testMode&&flow.testConsent!==true||!allowedTester(user,flow.provider)){cookie(res,'fitrota_account',null);send(res,403,{error:'test_access_denied'});return true;}
    cookie(res,'fitrota_account',{access:token.access_token,refresh:token.refresh_token,provider:flow.provider,providerRefresh:token.provider_refresh_token||'',providerToken:flow.provider==='apple'?token.provider_token||'':'',signedIn:now(),terms:flow.accepted,testConsent:flow.testConsent===true,aiConsent:flow.aiConsent===true,autoCloud:flow.autoCloud===true});
    res.writeHead(303,{Location:'/#account','Cache-Control':'no-store'});res.end();return true;
   }
   const current=await session(req,res);if(!current){send(res,401,{error:'signin_required'});return true;}const {s,user}=current;
   if(req.method!=='GET'&&req.headers['x-fitrota-owner']!==user.id){send(res,409,{error:'account_changed'});return true;}
   if(url.pathname==='/account/me'&&req.method==='GET'){send(res,200,{user:publicUser(user),preferences:{aiConsent:s.aiConsent===true,autoCloud:s.autoCloud===true}});return true;}
   if(url.pathname==='/account/logout'&&req.method==='POST'){await api('/auth/v1/logout?scope=local',{method:'POST',token:s.access});cookie(res,'fitrota_account',null);send(res,200,{ok:true});return true;}
   if(url.pathname==='/account/data'&&req.method==='GET'){const rows=await api('/rest/v1/fitrota_snapshots?user_id=eq.'+encodeURIComponent(user.id)+'&select=payload,revision,updated_at',{token:s.access});send(res,200,{snapshot:rows[0]||null});return true;}
   if(url.pathname==='/account/data'&&req.method==='POST'){
    const body=await readBody(req);if(body.consent!==LEGAL_VERSION||!Number.isInteger(body.revision)||body.revision<0){send(res,400,{error:'consent_required'});return true;}
    const payload=validateBackup(body.payload);if(payload.demo){send(res,400,{error:'demo_not_allowed'});return true;}
    const result=await api('/rest/v1/rpc/fitrota_save_snapshot',{method:'POST',token:s.access,body:{document:payload,expected_revision:body.revision,consent_version:LEGAL_VERSION}});send(res,200,{revision:result});return true;
   }
   if(url.pathname==='/account/data'&&req.method==='DELETE'){await api('/rest/v1/fitrota_snapshots?user_id=eq.'+encodeURIComponent(user.id),{method:'DELETE',token:s.access});send(res,200,{ok:true});return true;}
   if(url.pathname==='/account/delete'&&req.method==='POST'){
    const body=await readBody(req);if(body.confirm!=='DELETE'){send(res,400,{error:'confirm_required'});return true;}if(now()-s.signedIn>10*60000){send(res,409,{error:'recent_signin_required'});return true;}
    if(s.provider==='apple'){
     const token=s.providerRefresh||s.providerToken;if(!env.APPLE_CLIENT_ID||!env.APPLE_CLIENT_SECRET||!token){send(res,409,{error:'apple_revocation_required'});return true;}
     const rev=await fetcher('https://appleid.apple.com/auth/revoke',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:env.APPLE_CLIENT_ID,client_secret:env.APPLE_CLIENT_SECRET,token,token_type_hint:s.providerRefresh?'refresh_token':'access_token'}),signal:AbortSignal.timeout(12000),redirect:'error'});if(!rev.ok)throw Error('apple_revocation_failed');
    }
    await api('/auth/v1/admin/users/'+encodeURIComponent(user.id),{method:'DELETE',adminMode:true});cookie(res,'fitrota_account',null);send(res,200,{ok:true});return true;
   }
   send(res,404,{error:'not_found'});return true;
  }catch(e){const safe=['account_temporarily_unavailable','invalid_oauth','consent_required','sync_conflict','apple_revocation_failed','body_too_large','json_required'];send(res,e.message==='account_temporarily_unavailable'?503:e.message==='sync_conflict'?409:e.message==='body_too_large'?413:400,{error:safe.includes(e.message)?e.message:'account_request_failed'});return true;}
 }
 return {handler,session,enabled};
}
