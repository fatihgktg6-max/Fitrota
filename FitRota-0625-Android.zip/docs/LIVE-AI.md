# Gerçek AI koç — v0.2

## Yapılan değişiklik

Koç ekranı artık `coachReply()` ile hazır yanıt üretmez. Mesajları gerçek HTTP isteğiyle FitRota sunucusuna gönderir; sunucu OpenAI Responses API çağrısını yapar. Bağlantı yoksa cevap uydurmaz, bağlantı formunu açar. Eski yerel mesajlar “eski yerel yardımcı kaydı” olarak etiketlenir ve yeni AI konuşma bağlamına gönderilmez.

Gerçek sağlayıcıya bağlanmak için **sunucu ortamında geçerli API anahtarı ve erişilebilir model adı** gerekir. Bu teslimde anahtar yoktur; ücretli sağlayıcı çağrısı veya canlı sunucu yayını yapılmadı. Bu nedenle dosyayı tek başına açmak AI’yi etkinleştirmez.

## Bağlantı

1. `npm ci && npm run build` çalıştır.
2. `server/.env.example` dosyasını `server/.env` olarak kopyala.
3. `OPENAI_API_KEY` ve `OPENAI_MODEL` değerlerini sunucuda doldur. Anahtarı sohbete veya istemci koduna koyma.
4. FitRota pilot erişim kodunu üret: `node -e "console.log(require('node:crypto').randomBytes(32).toString('base64url'))"`. Bu değeri sunucunun `FITROTA_ACCESS_CODE` ayarına yaz. Bu bir OpenAI anahtarı değildir; tek sahipli pilot giriş kodudur.
5. `npm run server:configured` çalıştır.
6. Aynı bilgisayarda `http://127.0.0.1:8787` adresini aç. Koç → Bağlan → FitRota erişim kodu → veri paylaşımı onayı.
7. Oturum açıldıktan sonra koç ekranı gerçek API yanıtı alır. Erişim kodu yalnızca oturum açılırken kullanılır; oturum tokenı bellekte tutulur, yedek veya localStorage’a girmez. Sayfa kapatılınca yeniden giriş gerekir.

Tablet/telefon için erişilebilir bir HTTPS sunucusu gerekir. Pilot sunucu başlangıçta yalnızca loopback üzerinde dinler. Kontrollü bir HTTPS reverse proxy arkasında HOST ayarıyla yayınlanabilir. `FITROTA_ALLOWED_ORIGINS` içine yalnızca gerçek uygulama adreslerini yaz; native paket için ilgili originleri açıkça ekle. Rastgele origin yansıtma veya `*` yoktur. Dosya önizlemesinin `null` originine varsayılan izin verilmez; tercihen sunucunun sunduğu uygulama sayfasını kullan.

## Davranış ve sınırlar

- Son 12 uygun sohbet mesajı, koç tarzı, hedef, ekipman, beslenme tercihi, alerjenler, sağlık kısıtı işareti ve kısa antrenman özeti gönderilir. İsim/boy/kilo/ölçüm geçmişi otomatik gönderilmez. Kullanıcı bunları mesajına yazarsa mesaj içeriği doğal olarak gönderilir.
- Sağlayıcı yanıtı metin olarak gösterilir; HTML çalıştırılmaz. Model programı, takvimi veya ödülü doğrudan değiştiremez.
- Yanıt bekleme göstergesi, iptal, zaman aşımı, oturum süresi, kota hatası ve mesajı çoğaltmadan tekrar deneme uygulanmıştır.
- Oturumlar 12 saatlik ve bellek içidir. Sunucu yeniden başlayınca oturumlar kapanır.
- Günde 100 çağrı varsayılan sınırı vardır; sayı ortam değişkeniyle ayarlanır. Kota aynı süreçte dosyaya atomik yazılır. Üretim barındırmada bu dosya kalıcı diskte olmalı. Çok sunuculu kullanım için ortak veri tabanı gerekir.
- Dakikada 10 istek ve aynı anda 2 sağlayıcı çağrısı sınırı vardır. Oturum açmada deneme sınırı uygulanır.
- İptal edilen/başarısız sağlayıcı denemeleri kota tüketebilir. İptal, sağlayıcı tarafındaki olası ücreti geri alma garantisi değildir.
- `store:false` kullanılır; bu sağlayıcının tüm veri işleme koşullarını kaldırmaz.
- Bu tek sahipli pilot erişimidir. Kamuya açık çok kullanıcılı hesap ve abonelik hizmeti değildir. Üyelik ve gerçek hediye hakları ayrı geliştirme konusudur.

## Testler

`npm test` (19 mantık/adaptör testi), `npm run test:server` (4 HTTP/oturum testi), `npm run test:coach` (tarayıcı → gerçek yerel HTTP sunucusu → sahte sağlayıcı), `npm run test:ui` (önceki uygulama akışları).

Canlı OpenAI anahtarı kullanılmadı. Mock sağlayıcı yalnızca test dosyalarında yer alır; üretim sunucusu `generateCoachReply` üzerinden OpenAI’a gider.
