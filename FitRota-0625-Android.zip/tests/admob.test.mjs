import test from 'node:test';
import assert from 'node:assert/strict';
import {NativeAds} from '../src/admob-client.js';
const free={owner:'u1',verified:true,premium:false,optOut:false,foreground:true};
function setup(overrides={}) {
 const calls=[];const heights=[];
 const plugin=Object.fromEntries(['initialize','showBanner','removeBanner'].map(k=>[k,async x=>calls.push([k,x])]));
 plugin.requestConsentInfo=async()=>({canRequestAds:true,status:'NOT_REQUIRED'});
 Object.assign(plugin,overrides);
 return {calls,heights,ads:new NativeAds({plugin,platform:()=> 'android',config:{enabled:true,testMode:true},onHeight:h=>heights.push(h)})};
}
test('unverified, premium, opt-out, signed-out and background do not request ads',async()=>{
 for(const change of [{verified:false},{premium:true},{optOut:true},{owner:null},{foreground:false}]){
  let requests=0;const {ads,calls}=setup({requestConsentInfo:async()=>{requests++;}});
  await ads.update({...free,...change});assert.equal(requests,0);assert.equal(calls.length,0);
 }
});
test('free uses Google test banner and premium removes it',async()=>{
 const {ads,calls,heights}=setup();await ads.update(free);await ads.update(free);
 const shown=calls.filter(c=>c[0]==='showBanner');assert.equal(shown.length,1);
 assert.equal(shown[0][1].adId,'ca-app-pub-3940256099942544/6300978111');assert.equal(shown[0][1].npa,true);
 ads.sizeChanged({height:50});assert.equal(heights.at(-1),50);
 await ads.update({...free,premium:true});assert.equal(calls.at(-1)[0],'removeBanner');assert.equal(heights.at(-1),0);
});
test('late consent cannot show ads after sign out',async()=>{
 let resolve;const {ads,calls}=setup({requestConsentInfo:()=>new Promise(r=>resolve=r)});
 const first=ads.update(free);await new Promise(r=>setImmediate(r));
 const next=ads.update({...free,owner:null});resolve({canRequestAds:true});await Promise.all([first,next]);
 assert.equal(calls.some(c=>c[0]==='showBanner'),false);
});
test('late show is removed when premium activates',async()=>{
 let resolve;const {ads,calls}=setup({showBanner:()=>new Promise(r=>resolve=r)});
 const first=ads.update(free);await new Promise(r=>setImmediate(r));
 const next=ads.update({...free,premium:true});resolve();await Promise.all([first,next]);
 assert.equal(calls.at(-1)[0],'removeBanner');assert.equal(ads.visible,false);
});
test('consent denial and consent failure remain closed',async()=>{
 for(const fn of [async()=>({canRequestAds:false}),async()=>{throw Error('offline')}]){
 const {ads,calls}=setup({requestConsentInfo:fn});await ads.update(free);assert.equal(calls.length,0);
 }
});
test('owner changes remove the old banner before new request',async()=>{
 const {ads,calls}=setup();await ads.update(free);await ads.update({...free,owner:'u2'});
 assert.deepEqual(calls.map(c=>c[0]),['initialize','showBanner','removeBanner','showBanner']);
});
test('privacy choices remove ad and respect revocation',async()=>{
 let requests=0;const {ads,calls}=setup({requestConsentInfo:async()=>({canRequestAds:true,privacyOptionsRequirementStatus:++requests>1?'REQUIRED':'NOT_REQUIRED'}),showPrivacyOptionsForm:async()=>({canRequestAds:false})});
 await ads.update(free);await ads.privacyOptions();assert.equal(calls.at(-1)[0],'removeBanner');assert.equal(ads.visible,false);
});
test('failed native billing refresh invalidates ad eligibility',async()=>{
 const {NativeBilling}=await import('../src/revenuecat-client.js');
 const billing=new NativeBilling({purchases:{getCustomerInfo:async()=>{throw Error('offline')}},ui:{},config:{},platform:()=> 'android'});
 billing.configured=true;billing.owner='u1';billing.listener=1;billing.verified=true;billing.info={entitlements:{active:{}}};
 const task=billing.refresh('u1');assert.equal(billing.verified,false);await assert.rejects(task,/offline/);
 assert.equal(billing.verified,false);
});
