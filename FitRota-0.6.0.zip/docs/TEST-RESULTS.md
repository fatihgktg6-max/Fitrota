# FitRota 0.5.6
40 birim testi ve 5 PostgreSQL/HTTP kota testi geçti. Yeni haftalık program ekranları TR/EN ve mobil/tablet/masaüstünde doğrulandı. Hesaplı koç iki saatlik kota yenilenmesi ve mevcut akışlarda 96 düzen kontrolü geçti. Chromium; gerçek cihaz, canlı OpenAI/Supabase işlemi ve mağaza derlemesi yapılmadı.

---
# FitRota 0.5.5 test sonucu

- npm run check: 35 birim testi ve derleme geçti.
- npm run test:content-ui: gram/porsiyon, mikro toplamlar, bilinmeyen değerler, yeniden açılma, 80 tarif kategorisi/arama/detay ve 60 hareket filtresi geçti.
- npm run test:v05: mevcut uygulama akışları ve 96 düzen kontrolü geçti.
- npm run test:features: mevcut özellikler ve 48 düzen kontrolü geçti.
- npm run test:account-coach: onay, erişim kodsuz hesaplı koç, yeniden açılma, kota bekleme/yenileme ve cihaz saatinden bağımsızlık geçti; sahte sağlayıcı kullanıldı.

Chromium ile doğrulandı; gerçek Android/iPhone cihaz testi, canlı OpenAI çağrısı ve imzalı mağaza derlemesi yapılmadı. Canlı GitHub/Render değiştirilmedi.

---

# FitRota 0.4.0 test sonucu

- 16 çekirdek işlev testi: geçti.
- 6 yeni özellik/veri uyumluluğu testi: geçti. Ay hedefi sabitleme, kayıt tarihi, gelecek gün kontrolü, tek ödül, demo/boş hedef engeli, alternatif hareket izolasyonu, dinlenme sayacı ve 0.3 yedek geçişi.
- 3 AI veri/yanıt testi: geçti.
- 5 HTTP/oturum testi: geçti.
- Mevcut arayüz akışları: geçti (profil, antrenman, öğün, takvim, yedek, silme, dil, özel program).
- Yeni arayüz: tema kalıcılığı, notlarda HTML kaçışlama, günlük alternatifler, sayacı duraklat/devam/bitir, haftalık alışveriş, evde var, özel ürün, bölgesel fiyatlar geçti.
- Açık/koyu tema × 390/768/1440 piksel × 8 ekran: 48 yatay taşma kontrolü geçti. Yakalanan JavaScript hatası yok.
- Gerçek istemci/sunucu akışı + sahte AI sağlayıcısı: geçti. Tekrar deneme, iptal, sohbet temizleme ve onay.
- 7 günlük cihaz hatırlama: yeniden açılma ve çıkış testleri geçti.
- PWA: uyku formu, güncelleme bildirimi, güncellemede kayıtların korunması ve çevrimdışı uygulama kabuğu testi geçti.
- Android/iOS Capacitor kaynak eşitlemesi: geçti. İmzalı mağaza derlemesi yapılmadı.
- npm audit: kontrol sırasında 0 bilinen açık.

Tarayıcı doğrulaması Chromium ile yapıldı. Gerçek iPhone/Safari ve Android cihaz testi yapılmadı. Ücretli OpenAI çağrısı veya gerçek satın alma yapılmadı. Ödül kayıtları yerel önizlemedir; sunucuda gerçek abonelik oluşturulmaz.

Bu paket hazırlanırken GitHub/Render'a yeni dosya yazılmadı. 0.4.0'ın canlı olması için sürüm belgesindeki yükleme/dağıtım adımı gereklidir.
