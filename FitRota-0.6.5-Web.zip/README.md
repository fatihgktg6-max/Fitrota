# FitRota 0.6.3 — RevenueCat test entegrasyonu

Bu paket 0.6.2'nin mevcut JavaScript + Capacitor yapısını korur. Angular projesine dönüştürülmedi. `src/revenuecat-client.js` SDK akışını, `src/membership.js` mevcut Premium ekranını yönetir. SDK modülleri esbuild ile çevrimdışı HTML'e paketlenir.

- Public Test Store anahtarı bağlıdır; gerçek para alınmaz.
- `fitrota_pro`, güncel offering, aylık/yıllık/ömür boyu paketler; dinamik yerel mağaza fiyatları.
- Satın alma, geri yükleme, `presentPaywallIfNeeded`, Customer Center, CustomerInfo dinleyicisi ve uygulamaya dönüşte yenileme.
- Backend aylık/yıllık abonelik ve ömür boyu işlemi RevenueCat REST API'den doğrular. Sandbox işlemleri sunucuda varsayılan olarak reddedilir. Client flags sunucudaki AI yetkisini açmaz.
- Native mevcut sürümde Google/Apple hesap girişi henüz etkin değil. Bu test APK'sı anonim RevenueCat kimliği kullanır. Cihaz güncellemesi bu kimliği korur; yeniden kurulumda mağaza geri yüklemesi gerekir. Mevcut uygulama hesabı sağlanırsa SDK sabit kullanıcı ID'siyle configure/logIn yapar. Tam hesaplar arası/cross-platform AI Premium erişimi için native hesap girişi ayrıca tamamlanmalıdır.
- Render/web sayfası native Capacitor paywall açmaz. Mevcut web ödeme akışı korunmuştur ve ayrı web ödeme sağlayıcısı gerektirir.

## Şimdi test etmek

1. ZIP'i depo köküne bu isimle yükle. Render kullanıyorsan aşağıdaki Build Command yeni ZIP adını kullanmalı.
2. Android için kaynak dosyaları açıp `npm ci`, `npm run check`, `npx cap sync android` çalıştır. Paket içindeki Android APK workflow'u kaynakların depo kökünde bulunduğunu varsayar; yalnız ZIP içeren depoda mevcut unzip workflow'u güncel ZIP'i açmalıdır.
3. Debug APK oluştur: `cd android && ./gradlew assembleDebug`. Bu çalışma ortamında APK veya Xcode derlemesi yapılmadı.
4. APK'da Premium seçenekleri → ödeme ekranını aç. Monthly, Yearly, Lifetime'ı ayrı test kullanıcılarıyla dene. İptal, bekleyen ödeme, geri yükleme ve yeniden açma akışlarını kontrol et. RevenueCat test müşteri kaydında `fitrota_pro` aktif olmalı.
5. Customer Center için dashboard'da Customer Center yapılandırmasını tamamla. Test Store ve gerçek mağazalar aynı yönetim davranışlarını sunmayabilir; gerçek iptal/iade akışlarını mağaza sandbox'ında doğrula.

## Gerçek mağazaya geçmeden

`src/revenuecat-config.js` içinde testMode=false yap; Android ve iOS için aynı RevenueCat projesinin ayrı PUBLIC SDK anahtarlarını ekle. Secret API anahtarını bu dosyaya koyma. Test modunda Android release derlemesi engellenir.

Google Play / App Store'da monthly ve yearly otomatik yenilenen ürünleri, lifetime tüketilmeyen tek seferlik ürünü oluştur. Gerçek mağaza ürünlerini `fitrota_pro` entitlement'ına ve current olarak belirlenen `default` offering'in `$rc_monthly`, `$rc_annual`, `$rc_lifetime` paketlerine bağla; yayımlanmış paywall bu offering'i kullanmalı. Ürün ID'leri mağazada farklıysa backend allowlist'ini tam ID'lerle güncelle.

Server-only ayarlar: REVENUECAT_SECRET_KEY, REVENUECAT_ENTITLEMENT=fitrota_pro, FITROTA_PREMIUM_PRODUCTS=monthly,yearly,lifetime, FITROTA_LIFETIME_PRODUCTS=lifetime. FITROTA_BILLING_ENABLED=true yalnız gerçek işletmeci/hesap ayarları tamamlandığında. FITROTA_REVENUECAT_SANDBOX=false üretimde kalmalı. Sandbox kabulü yalnız ayrı geliştirme sunucusunda açılmalı.

Native hesap girişini tamamla ve aynı backend kullanıcı ID'sini SDK'ya geçir. Sunucu AI yetkisini kullanıcı oturumuyla RevenueCat'ten doğrular; anonim cihaz test Premium'u sunucuda sınırsız AI açmaz. İstemciden premium=true kabul edilmez.

iOS için `npx cap sync ios`, Xcode'da In-App Purchase capability ve imzalama ayarları gerekir. SDK >= iOS15; mevcut proje iOS15 kullanır. Android launchMode singleTop yapıldı. Güvenli güncelleme için com.fitrota.app ID'si ve mağaza imzalama anahtarı aynı kalmalı, versionCode artmalı.

## Doğrulama

`npm run check`: uygulama çekirdek testleri ve RevenueCat satın alma/kimlik/hata testleri.
`npm run test:premium`: sunucu yetkilendirmesi, görev ödülleri ve mevcut Premium tarayıcı akışı.
`node tests/revenuecat-ui.mjs`: üç yerel fiyat, lifetime erişimi, paywall, restore, Customer Center ve hesap izolasyonu (mock SDK).
Gerçek cihaz işlemi, mağaza ürünü, ödeme, iptal/iade ve native giriş bu testlerle doğrulanmış sayılmaz.

Belgeler: https://www.revenuecat.com/docs/getting-started/installation/capacitor • https://www.revenuecat.com/docs/tools/paywalls/displaying-paywalls • https://www.revenuecat.com/docs/tools/customer-center/customer-center-capacitor

---

# FitRota 0.6.2

Son sürüm: Premium rozeti, Tatlı sert koç, sunucuda abonelik doğrulama ve iki aylık görev ödülü. Yeni `database/005_premium_rewards.sql` dosyasını kur. Gerçek satın alma, Apple ve kamuya açık Google ayarları için [Premium kurulum rehberi](docs/PREMIUM-SETUP.md) ve [sürüm raporu](docs/RELEASE-0.6.2.md). Ödeme/reklam/Apple servisleri hesap ve anahtarları bağlanmadan açılmaz.

Günlük spor ve beslenme düzeni için web/PWA test sürümü. Android/iOS kaynakları dahildir; imzalı mağaza paketi değildir. Canlı siteye otomatik gönderilmez.

Yeni akış: **Bugün → Antrenman → Beslenme → Takvim → Profil**. Bugün ekranında antrenman, öğün ekleme, su ve günlük takvim bulunur. Antrenmanda Bugün / Haftam / Keşfet; beslenmede Günlüğüm / Planım / Keşfet bulunur. Sayaç, müzik, hareketler, tarifler, birleşik besin havuzu ve takviyeler ilgili Keşfet bölümündedir. Hesap, gelişim, ödüller, tercihler ve veri yönetimi Profil başlıklarına ayrılmıştır. Robot koç ayrıca erişilebilir.

- Günlere göre antrenman ve toparlanma; süreye uygun başlangıç planları.
- 92 tarif ve toplam 10.745 kaynaklı besin/tarif kaydı; CoFID 2021, USDA SR Legacy 2018 ve altı Türk üretici etiketi; günlük enerji tahmini, öğün/porsiyon kaydı, kendi etiketinden besin ekleme.
- Kronometre, tur kaydı, set arası sayaç, dış müzik önerileri ve 60 hareketin yazılı adım adım anlatımı.
- Google/Apple web OAuth, ayrı kullanıcı alanları, ayrı izinle otomatik bulut yedeği ve hesap silme altyapısı. Kendi sağlayıcı ve veritabanı ayarları olmadan devre dışıdır.
- Uygulama içi ve herkese açık kullanıcı belgesi taslakları. Gerçek işletmeci bilgisi ve hukuki inceleme beklenir.

Ayrıntılar: [Sürüm raporu](docs/RELEASE-0.6.1.md), [bilimsel kaynaklar](docs/CONTENT-SOURCES.md), [hesap kurulumu](docs/ACCOUNT-SETUP.md), [yayın belgeleri](docs/PUBLICATION-LEGAL.md).

## Yerel geliştirme

Node.js 22+: `npm ci`, `npm run check`, `npm run dev`. Son komut derlenmiş uygulamayı ve kullanıcı belgelerini `http://127.0.0.1:4173` üzerinden sunar; ücretli AI çağrısı yapmaz.

Üretim sunucusu: `server/.env.example` alanlarını kendi sunucu ortamında yapılandırıp `npm run server`. Gerçek API ve service-role anahtarları yalnız sunucuda tutulur; kaynak depoya veya HTML’e eklenmez.

Derleyici, mevcut sıfır-CDN çevrimdışı yaklaşımı koruyarak modül kaynaklarını sıralı tek HTML paketine toplar. `src/app.js` ve `src/upgrade.js` arayüz kapsamını paylaşır; doğrudan tarayıcıya modül dosyası olarak bağlanmaz. `index.html`, `FitRota-Onizleme.html`, `dist/` derlenmiş çıktılardır.

## Sınırlar

Doğrulanmış web/PWA hesabıyla AI kod girmeden açılır. Hesap başına 30 mesaj ve sonrasında 2 saat bekleme uygulanır; kurulum için database/002_ai_quota.sql ve ardından database/003_ai_cooldown_2h.sql gereklidir. Mağaza ödeme/ödül doğrulaması ve reklam etkin değildir. Android/iOS yerel giriş entegrasyonu ve gerçek cihaz testleri beklenir. İçerikler bireysel uzman onaylı diyet/antrenman reçetesi değildir. Bu paket tüm ülkelerde mağaza yayınına hazır sayılmaz.

0.5.1: geçici hesap hizmeti hatasında oturum korunur. Apple girişinde iptal ayarları aranır. `npm run check:config` gizli değerleri göstermeden sunucu ayarlarını kontrol eder. Ayrıntılar: docs/RELEASE-0.5.1.md.


0.5.6: 60 hareket, 80 tarif, 160 temel besin. Gram/porsiyon hesabına sodyum, kolesterol, şeker, doymuş yağ, potasyum, kalsiyum ve demir eklendi. Eksik kaynak değerleri bilinmiyor olarak korunur. Tarifler kahvaltı/öğle/akşam/ara öğün olarak ayrıldı; gramlı malzemeler ve adım adım hazırlık gösterilir. Ayrıntılar: docs/RELEASE-0.5.6.md.

0.5.6: seçilebilir Full Body, üst/alt ve bölgesel split, itiş/çekiş/bacak; 1–6 gün ve ayrı haftalık program ekranı. AI kotası artık 30 mesaj + 2 saat. Güncelleme: docs/RELEASE-0.5.6.md.

0.5.7: tüm hareket adları İngilizce; haftalık program anında değişir, tamamlanmış ve aktif seans kayıtları korunur. docs/RELEASE-0.5.7.md.

0.5.8: ayrı izin sonrası otomatik AI ve bulut yedeği; sürüklenebilir robot; 28 vitamin/mineral/takviye rehberi, 17 yeni içecek ve protein tozu etiket hesabı. docs/RELEASE-0.5.8.md.

0.5.9: beş ana bölüm, üçlü bölüm sekmeleri, Keşfet menüleri ve gruplu Profil. Besin ayrıntıları ve koç tercihleri açılır panellerde. Günlük kısayollar doğru güne ve sekmeye gider; kayıt yapısı değişmez. docs/RELEASE-0.5.9.md.

## GitHub’a ZIP yükleyerek Render güncelleme

ZIP dosyasını depo köküne `FitRota-0.6.3-RevenueCat.zip` adıyla yükle. Render Build Command:

```bash
python3 -m zipfile -e FitRota-0.6.3-RevenueCat.zip . && npm ci --include=dev && npm run build
```

Start Command: `npm run server`. Ortak besin paylaşımı için `database/004_shared_foods.sql` dosyasını Supabase SQL Editor’da yeni sorguda çalıştır. Önceki hesap/AI SQL dosyaları zaten kuruluysa tekrar gerekmez. Markalı ürün araması ayrıca API anahtarı istemez; internet ve Open Food Facts erişimi gerekir. `FITROTA_FOOD_LOOKUP=false` bu aramayı kapatır. Kaynak dosyaları zaten çıkarıp GitHub’a yüklediysen ZIP çıkarma adımı gerekmez.

0.6.0: Pazartesi–Pazar özel program; gün kopyalama, OFF, set/tekrar/dinlenme/sıra. Birleşik besin, marka ve barkod araması; pişirme durumuna göre filtreleme; kalıcı özel etiketler ve açık seçimle ortak havuz. Ayrıntılar: docs/RELEASE-0.6.0.md.

0.6.1: 10.745 kayıt, sucuk/sosis/beyaz-süzme peynir üretici etiketleri ve 12 Türk yemeği örneği. Kolesterol, demir ve diğer mikro besinler doğrudan görünür. AI bağlantı şeridi kaldırıldı; izin, kota ve sohbet işlevleri korunur. Yeni SQL gerekmez. docs/RELEASE-0.6.1.md.