# FitRota 0.6.10 — ABD web/PWA yayınına hazırlık

5 Ekim 2026. Öncelik ABD pazarıdır. Türkiye altyapısına taşıma yapılmadı. Mevcut Render Frankfurt / Supabase Tokyo bölgeleri korunur; bu bir ABD veri merkezi veya ABD içinde saklama iddiası değildir. Kod paketi, tek başına mağaza onayı, vergi kaydı, ödeme hesabı, sağlayıcı sözleşmesi veya hukuk görüşü değildir.

## Pakette tamamlananlar

- Google girişi, Supabase hesabı, OpenAI ve mevcut abonelik entegrasyonu korundu.
- İngilizce başlangıç için `npm run build:us` eklendi. Yeni misafir profilinde English ve US pazar varsayılanıdır; eski kayıtların dili değiştirilmez. ABD aylık fiyatı USD olarak gösterilir, gerçek fiyat ve vergiler ödeme sağlayıcısında doğrulanır.
- Ayrı, herkese açık `/legal/health` Consumer Health Data Privacy Policy sayfası eklendi. Ana sayfa altından, ilk profil kurulumundan ve kullanıcı belgelerinden erişilir.
- Yerel sağlık kaydı onayı İngilizcede gerçek veri türleri ve amacına göre düzeltildi. Onay kaydı artık eski sabit sürüm yerine gösterilen belgenin sürümünü kullanır.
- AI bağlantısı, profil bağlamı, gelişim bağlamı, bulut yedeği ve özel not/sohbet paylaşımı ayrı seçimlerle çalışır.
- Global Privacy Control (`navigator.globalPrivacyControl` veya `Sec-GPC: 1`) reklam onayına üstün tutulur. Google reklam/CMP betikleri ve reklam birimi yüklenmez. Oturum/isteğe bağlı servisler bu reklam tercihinden bağımsızdır.
- Reklamdan çıkış cihaz genelinde saklanır; hesap değişiminde ve yeniden yüklemede korunur. Açık seçimle geri alınabilir; aktif GPC sinyali geri alınamaz. Sonradan çıkış seçildiğinde sayfa yeniden yüklenerek önceki reklam betikleri kaldırılır. Önceki gönderimler geri alınmaz.
- `/healthz` anahtar veya kullanıcı bilgisi göstermeyen canlılık kontrolüdür.
- ABD dışı dağıtımı engellemek için güvenilir ülke proxy kapısı eklendi. Eksik/yanlış proxy kimliği, bilinmeyen ülke veya US dışı ülke reddedilir. Dil/saat dilimi/IP başlığını tek başına güvenilir ülke kabul etmez.

## Build ve start

GitHub'a bu ZIP'i yükle. Build:

```sh
python3 -m zipfile -e FitRota-0.6.10-ABD-Hazirlik.zip . && npm ci --include=dev && npm run build:us
```

Start: `npm run server`. Mevcut `FITROTA_SESSION_SECRET` değerini değiştirme. Bu sürüm için yeni SQL yok; database/001–006 değişikliklerinin gerçekten uygulandığı doğrulanmalıdır.

**build:us yalnız dil/pazar varsayılanını belirler, ülke engeli değildir.**

## Gerçek ABD erişim kapısı kurulumu

Ülke kapısını açmadan önce güvenilir ters proxy gerekir:

1. Proxy istemciden gelen `X-Fitrota-Country` ve `X-Fitrota-Proxy-Token` başlıklarını siler.
2. Bakımı yapılan GeoIP/ülke verisi üzerinden gerçek ziyaretçi ülkesini belirler; bilinmeyen ülkeye US demez.
3. Node origin erişimi proxyyle sınırlanır. TLS kullanılır. Proxy aynı origin ve OAuth callback isteklerinin tamamını kapsar.
4. Proxy yeni `X-Fitrota-Country: US` ve sunucuyla paylaşılan 32+ karakterli `X-Fitrota-Proxy-Token` değerini ekler. Anahtar tarayıcıya, repoya, URL'ye veya kayıtlara yazılmaz.
5. Node'da `FITROTA_LAUNCH_MARKET=US` ve aynı `FITROTA_COUNTRY_PROXY_SECRET` ayarlanır. Kapı yapılandırılmadan market US açılırsa uygulama 503 döner; yanlış kimlik/ülke 403 döner.
6. ABD / ABD dışı / belirsiz ülke, doğrudan origin, sahte başlık ve Google callback uçtan uca test edilir.

`/legal/*` ve `/healthz` ülke kapısının dışında kalır; bunlar uygulama kullanımı/sağlık kayıtlarını açmaz. Eski kullanıcılarda önceki indirilen çevrimdışı PWA kopyasını veya VPN kullanımını bu kapı yok edemez. Kamuya açık AdSense inceleme sayfaları ve bot trafiği proxyde değerlendirilmelidir; crawler için tüm uygulamayı başlıksız açan bir istisna ekleme.

## Panelde yapılması gereken gerçek işlemler

Bunlar bu çalışma sırasında erişilemeyen hesaplarda olduğundan tamamlanmış sayılmaz:

- Veri sorumlusunun tam posta adresi ve Render/Supabase/OpenAI gerçek kayıt/yedek saklama süreleri; veri işleme ve aktarım dayanakları.
- Sağlayıcı DPA/alt işleyen koşulları, özel sağlık verisine ilişkin yükümlülükler. Türkiye'de işletmecilik ve işlemenin KVKK kapsamını yalnız ABD dağıtımı otomatik kaldırmaz.
- Google OAuth üretim durumu, yalnız temel kimlik/e-posta/profil kapsamları, doğru Supabase callback ve FitRota dönüş URL'si; gerçek farklı kullanıcı hesabıyla oturum yenileme testi.
- AdSense site durumu `Ready`; uygun reklam/mesaj politikaları. Önceki ekran görüntüsündeki `Getting ready` onay değildir. Google'ın yayıncı programı ve ABD gizlilik mesajları ayrıca gerçek panelde doğrulanmalıdır.
- Google reklam JavaScript'i uygulama origininde çalışır. Beslenme/ölçüm/sağlık tercihleri hedefleme parametresi olarak gönderilmese de bu, üçüncü taraf kodunun bütün davranışlarına güvence değildir. Üretimde gerçek ağ trafiği doğrulanmalı; gerekirse hassas uygulama verisine erişemeyen ayrı reklam/marketing originine taşınmalıdır. NPA reklam veri aktarımını sıfırlamaz.
- RevenueCat canlı ürün/entitlement/checkout, Türkiye'deki gerçek işletmeci için uygun ödeme hesabı, vergiler, para birimi, yenileme onayı, makbuz ve müşteri iptal portalı. ABD müşterisi olması işletmeciyi ABD işletmesi yapmaz. Sahte ülke/adresle ödeme hesabı açılmaz.
- Gerçek test/sandbox satın alma, yenileme, iptal, iade ve hesap silme senaryoları. Hesap silmek aboneliği iptal etmez. Doğrulama çalışmıyorsa ücret alınmamalıdır.
- ABD eyalet tüketici sağlık verisi ve gizlilik yükümlülükleri: Washington/Nevada ve sunulan diğer eyaletler için kapsam/istisnalar değerlendirilir. CCPA eşiklerine ulaşılıp ulaşılmadığı da değerlendirilir; sağlık kanunları aynı eşikleri kullanıyor varsayılmaz.
- Reklam geliri için AdSense ödeme kimliği/hesabı; ücretli satış ve yerel vergi/fatura yükümlülükleri.
- APK ve App Store bu çalışma kapsamında değildir; web/PWA önceliklidir. Mağaza ülke seçimi web erişimini tek başına engellemez.

## Sağlık verisi hak talepleri iş akışı

Başvuru kanalı: fitrotaaa@gmail.com. Operatör bu hesabı düzenli kontrol eder; erişilebilirliğini gerçek e-posta ile test eder. Parola/API anahtarı/kimlik belgesi istenmez; talep için gerekli en az kimlik doğrulaması yapılır.

İstek geldiğinde tarih, doğrulama durumu, kapsam ve uygulanacak yasal süre kaydedilir. Yerel JSON dışa aktarma araçları, Supabase aktif kayıtları ve daha önce gönderilmiş OpenAI verileri ayrı değerlendirilir. Sağlayıcı/alt işleyen kopyaları, yedekler ve istisnalar incelenir; yalnız aktif satır silindi diye bütün veriler silindi denmez. Reddedilen talep gerekçesi ve aynı e-posta üzerinden itiraz olanağı bildirilir; hak kullandığı için temel hizmetlerde ayrım yapılmaz. Washington için hak/süreler RCW 19.373.040 üzerinden uygulanır. Otomatik e-posta gönderimi bu pakette yoktur.

## Veri ihlali müdahalesi

FitRota'nın günlük kilo/öğün gibi sağlık kayıtları ve birden çok bilgi kaynağı FTC HBNR kapsamını gündeme getirir; HIPAA dışı olmak yükümlülük yok demek değildir. Sağlayıcı kimlik bilgileri veya sağlık verisi sızıntısında:

1. İhlali sınırla, ilgili hizmeti durdur, anahtarları güvenli biçimde döndür; hassas kayıtları kanıtsız silme.
2. Öğrenme zamanı, etkilenen kullanıcılar/veri türleri, sağlayıcılar ve yetkisiz paylaşımı belirle; yalnız siber saldırıların ihlal oluşturduğunu varsayma.
3. FTC HBNR ve ilgili eyalet yükümlülüklerini değerlendir. Kullanıcı, FTC ve gerektiğinde medya bildirimi süre/şekillerini resmî güncel rehbere göre uygula; açıklanamayan gecikme yapma.
4. Kullanıcıya olay, veri türleri, alınan önlemler ve destek iletişimini bildir. Gelecekteki güvenlik ve izinsiz paylaşım nedenini gider.

Bu bir çalışma prosedürüdür; imzalı sağlayıcı anlaşması, tamamlanmış bildirim veya olay yaşanmadığı güvencesi değildir.

## Resmî kaynaklar

- KVKK Kanun kapsamı/aktarım: https://www.kvkk.gov.tr/Icerik/6649/Personal-Data-Protection-Law
- FTC sağlık uygulaması aracı: https://www.ftc.gov/business-guidance/resources/mobile-health-apps-interactive-tool
- FTC HBNR: https://www.ftc.gov/business-guidance/resources/complying-ftcs-health-breach-notification-rule-0
- Washington sağlık verisi onayları: https://app.leg.wa.gov/RCW/default.aspx?cite=19.373.030
- Washington hak talepleri: https://app.leg.wa.gov/RCW/default.aspx?cite=19.373.040
- California / GPC: https://oag.ca.gov/privacy/ccpa
- FTC abonelik/ROSCA: https://www.ftc.gov/business-guidance/blog/2016/09/negative-options-make-them-positive
- FTC güncel abonelik kural çalışması: https://www.ftc.gov/news-events/news/press-releases/2026/03/ftc-seeks-public-comment-response-advance-notice-proposed-rulemaking-regarding-negative-option
- AdSense onay durumu: https://support.google.com/adsense/answer/12170222?hl=en
- RevenueCat web ödeme: https://www.revenuecat.com/docs/web/payment-integrations

FTC’nin 2024 Click-to-Cancel kuralı güncel yürürlükteymiş gibi kullanılmadı; FTC’nin Mart 2026 açıklaması iptal edilmiş 2024 kuralına atıf yapıyor. Abonelik incelemesi ROSCA/FTC Act ve uygulanacak eyalet kurallarına dayanmalıdır.

Bildirim kanalı için e-posta yanında kullanıcıya posta tercihinin nasıl bildirileceği sunuldu. Operatör olay bildiriminde ek uygulama/web bildirimi ve güncel FTC kurallarını uygulamalıdır.

## Hazır Cloudflare Worker seçeneği

`deploy/us-proxy/worker.mjs` isteğe bağlı ülke proxy uygulamasıdır; canlıya dağıtılmadı. Cloudflare panelindeki Workers düzenleyicisinde bu dosyayı kullanabilir veya ilgili klasörde Wrangler ile dağıtabilirsin. `FITROTA_ORIGIN=https://fitrota.onrender.com` ve Secrets altında `FITROTA_COUNTRY_PROXY_SECRET` gereklidir. Aynı secret Render'a girilir, ziyaretçiye gösterilmez. Bu sağlayıcı mevcut altyapıya ek bir veri alıcısı olur; DPA, alt işleyenler, kayıt/saklama ve aktarım açıklamaları kurulmadan önce tamamlanmalıdır.

- Ülke `request.cf.country` üzerinden platformdan alınır, istemcinin ülke başlığı kabul edilmez.
- US dışı/bilinmeyen ülke origin'e gönderilmez. Hukuk sayfaları herkese açık kalır.
- OAuth redirectleri proxy tarafından takip edilmez; secret Google veya Supabase'e aktarılmaz.
- İstek gövdeleri okunup konsola yazılmaz. Cookie ve Sec-GPC başlıkları origin'e iletilir; sağlık/hesap yanıtları cache edilmez.
- Worker'ın yayımlanan adresi uygulamanın yeni public origin'i olur: Render `FITROTA_PUBLIC_ORIGIN`, `FITROTA_ALLOWED_ORIGINS`, Supabase Site URL/redirect allowlist ve Google Branding bağlantıları buna göre değiştirilmelidir. Google OAuth'un Supabase callback adresi durduk yere değiştirilmez.
- Oturum secret'ını korumak önemlidir; yeni domain'de eski origin'in cookie/localStorage verileri kendiliğinden taşınmaz. Eski cihazdan JSON dışa aktarımı gerekebilir. Render/Supabase eski kayıtları bu dosyayı yüklemekle silinmez.
- Worker testleri Node Request nesnesi ve taklit origin ile geçti. Gerçek Cloudflare/Render OAuth akışı, Workers plan sınırları, cache ve yurt dışı erişim ayrıca test edilmeden production kapısı açılmaz.

Kaynaklar: https://developers.cloudflare.com/workers/runtime-apis/request/ ve https://developers.cloudflare.com/workers/configuration/secrets/

## Doğrulama sonucu

38 sunucu/hesap/ödeme testinin tamamı, 3 ülke proxy testi, mevcut çekirdek test zincirleri ve iki tarayıcı reklam/gizlilik testi geçti. Derleme başarılı. Sağlayıcı işlemleri taklit edildi; gerçek satın alma, Google hesabı, AdSense onayı ve proxy dağıtımı gerçekleştirilmedi.
