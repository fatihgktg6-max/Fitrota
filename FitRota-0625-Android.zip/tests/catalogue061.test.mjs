import {test} from 'node:test';import assert from 'node:assert/strict';
import {usdaFoods} from '../src/usda-foods.js';import {localProducts,turkishRecipes,turkishRecipeIngredients} from '../src/turkish-foods.js';import {foods} from '../src/catalog.js';import {additionalFoods} from '../src/expanded-foods.js';import {foodTotals,emptyState,validateBackup} from '../src/core.js';
test('offline catalogue exceeds 5000 without manufacturing portion variants; original USDA descriptions and units are preserved',()=>{
 assert.equal(usdaFoods.length,7793);assert.equal(new Set(usdaFoods.map(f=>f.code)).size,7793);assert.equal(foods.length+additionalFoods.length+usdaFoods.length+localProducts.length,10762);
 for(const f of usdaFoods){assert.equal(f.unit,'g');assert.equal(f.source,'usda');assert.match(f.code,/^\d+$/);assert.ok(f.name[1].length);for(const k of ['kcal','protein','carbs','fat'])assert.ok(Number.isFinite(f[k])&&f[k]>=0);for(const k of ['sodium','cholesterol','iron'])assert.ok(f[k]===null||Number.isFinite(f[k])&&f[k]>=0);}
 const egg=usdaFoods.find(f=>f.name[1]==='Egg, whole, raw, fresh');assert.equal(egg.kcal,143);assert.equal(egg.cholesterol,372);assert.equal(egg.iron,1.75);
});
test('Turkish manufacturer labels retain reported nutrients, unknowns, and sodium conversion',()=>{
 const get=id=>localProducts.find(f=>f.id===id);const sucuk=get('tr-product-pinar-klasik-sucuk');assert.equal(sucuk.kcal,402);assert.equal(sucuk.cholesterol,null);assert.equal(sucuk.iron,null);
 const cheese=get('tr-product-sutas-suzme-peynir');assert.ok(cheese);assert.equal(cheese.kcal,218);assert.equal(cheese.sodium,720);assert.equal(cheese.calcium,340);assert.equal(cheese.sodiumFromSalt,true);
 assert.equal(localProducts.filter(f=>f.name[0].includes('Sosis')).length,2);for(const f of localProducts)assert.ok(f.sourceURL.startsWith('https://'));
});
test('Turkish dish portions calculate from weighed raw/cooked ingredients and preserve missing values',()=>{
 assert.equal(turkishRecipes.length,12);for(const f of turkishRecipes)for(const key of ['kcal','protein','carbs','fat','sodium','iron','cholesterol']){const rows=f.ingredientAmounts.map(([id,g])=>[turkishRecipeIngredients[id][key],g]);if(rows.some(([v])=>v===null))assert.equal(f[key],null);else assert.ok(Math.abs(f[key]-rows.reduce((sum,[v,g])=>sum+v*g/100,0))<.001);}
 const meat=turkishRecipes.find(f=>f.id==='tr-recipe-karniyarik');assert.equal(meat.diet,'omnivore');assert.ok(meat.kcal>300);assert.match(turkishRecipeIngredients.egg.name[1],/raw/);assert.match(turkishRecipeIngredients.bean.name[1],/boiled/);
});
test('source attribution and micronutrients survive backup; arbitrary URLs are stripped',()=>{
 const state=emptyState();const label=localProducts[0];state.meals['2026-10-03']=[{id:'label',foodId:'custom',slot:'lunch',servings:1,custom:{name:'Sucuk',kcal:label.kcal*.5,protein:label.protein*.5,carbs:label.carbs*.5,fat:label.fat*.5,cholesterol:null,iron:null,sourceURL:label.sourceURL}}];let restored=validateBackup(state);assert.equal(restored.meals['2026-10-03'][0].custom.sourceURL,label.sourceURL);assert.equal(foodTotals(restored.meals['2026-10-03']).kcal,201);assert.equal(foodTotals(restored.meals['2026-10-03']).missing.iron,1);
 state.meals['2026-10-03'][0].custom.sourceURL='https://fdc.nal.usda.gov/food-details/171287/nutrients';assert.ok(validateBackup(state).meals['2026-10-03'][0].custom.sourceURL);state.meals['2026-10-03'][0].custom.sourceURL='https://example.com/untrusted';assert.equal(validateBackup(state).meals['2026-10-03'][0].custom.sourceURL,undefined);
});
