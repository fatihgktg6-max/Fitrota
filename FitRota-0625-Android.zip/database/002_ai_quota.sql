-- Run once in Supabase SQL Editor after 001_accounts.sql. Safe to re-run.
-- Only the trusted server service_role can read or mutate quotas.
begin;
create table if not exists public.fitrota_ai_quotas (
 user_id uuid primary key references auth.users(id) on delete cascade,
 used integer not null default 0 check (used between 0 and 30),
 reset_at timestamptz,
 cycle uuid not null default gen_random_uuid()
);
create table if not exists public.fitrota_ai_requests (
 request_id uuid primary key,
 user_id uuid not null references public.fitrota_ai_quotas(user_id) on delete cascade,
 cycle uuid not null
);
create index if not exists fitrota_ai_requests_owner on public.fitrota_ai_requests(user_id);
alter table public.fitrota_ai_quotas enable row level security;
alter table public.fitrota_ai_requests enable row level security;
revoke all on public.fitrota_ai_quotas, public.fitrota_ai_requests from public, anon, authenticated;
grant select, insert, update, delete on public.fitrota_ai_quotas, public.fitrota_ai_requests to service_role;

create or replace function public.fitrota_ai_quota(p_user_id uuid, p_action text default 'status', p_request_id uuid default null)
returns jsonb language plpgsql security invoker set search_path = '' as $$
declare
 q public.fitrota_ai_quotas%rowtype;
 moment timestamptz;
 request_cycle uuid;
 accepted boolean := true;
begin
 if p_user_id is null or p_action is null or p_action not in ('status','reserve','refund') or
    (p_action <> 'status' and p_request_id is null) then
  raise exception 'Invalid quota request';
 end if;
 insert into public.fitrota_ai_quotas(user_id) values(p_user_id) on conflict do nothing;
 select * into q from public.fitrota_ai_quotas where user_id=p_user_id for update;
 moment := clock_timestamp();
 if q.reset_at is not null and q.reset_at <= moment then
  q.used := 0; q.reset_at := null; q.cycle := gen_random_uuid();
  delete from public.fitrota_ai_requests where user_id=p_user_id;
 end if;
 if p_action = 'reserve' then
  select cycle into request_cycle from public.fitrota_ai_requests where request_id=p_request_id and user_id=p_user_id;
  if request_cycle = q.cycle then
   accepted := true; -- Idempotent reservation in the current cycle.
  elsif q.used >= 30 then
   accepted := false;
  else
   insert into public.fitrota_ai_requests(request_id,user_id,cycle) values(p_request_id,p_user_id,q.cycle);
   q.used := q.used + 1;
   if q.used=30 then q.reset_at := moment + interval '1 hour'; end if;
  end if;
 elsif p_action = 'refund' then
  delete from public.fitrota_ai_requests where request_id=p_request_id and user_id=p_user_id returning cycle into request_cycle;
  if request_cycle = q.cycle then
   q.used := greatest(0,q.used-1);
   if q.used<30 then q.reset_at := null; end if;
  end if;
 end if;
 update public.fitrota_ai_quotas set used=q.used, reset_at=q.reset_at, cycle=q.cycle where user_id=p_user_id;
 return jsonb_build_object('allowed',accepted,'quota',jsonb_build_object(
  'limit',30,'used',q.used,'remaining',30-q.used,'blocked',q.used>=30,
  'resetAt',q.reset_at,'serverNow',moment));
end;
$$;
revoke all on function public.fitrota_ai_quota(uuid,text,uuid) from public, anon, authenticated;
grant execute on function public.fitrota_ai_quota(uuid,text,uuid) to service_role;
commit;
