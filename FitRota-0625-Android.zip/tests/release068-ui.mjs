import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {createCoachServer} from '../server/index.mjs';
const server=createCoachServer({accessCode:'release-test-only-32-character-secret',accountService:{enabled:false,handler:async(req,res)=>{if(!req.url.startsWith('/account/'))return false;res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify(req.url==='/account/config'?{configured:false,providers:['google']}:{enabled:false,prices:[{country:'TR',currency:'TRY',amount:49.99}],adsEnabled:false}));return true;}}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const b=await chromium.launch({args:['--no-sandbox']}),ctx=await b.newContext({viewport:{width:390,height:844},timezoneId:'Europe/Istanbul'}),p=await ctx.newPage(),errors=[],catalogRequests=[];
p.on('pageerror',e=>{errors.push(e.message);console.error(e.stack);});p.on('request',r=>{if(r.url().includes('/catalog/'))catalogRequests.push(r.url());});
try{
 await p.goto('http://127.0.0.1:'+server.address().port);await p.locator('[data-action=demo]').click();assert.equal(catalogRequests.length,0,'catalog must not load at startup');
 await p.evaluate(()=>{state.settings.theme='light';navigate('settings');});assert.equal(await p.locator('.premium-settings').count(),1);assert.match(await p.locator('.premium-settings').innerText(),/49,99/);
 await p.evaluate(()=>showAccount());assert.equal(await p.locator('[data-provider=apple]').count(),0);await p.evaluate(()=>closeModal());
 for(const theme of ['light','dark','light']){for(const screen of ['home','workout','food','progress','settings','coach']){await p.evaluate(({theme,screen})=>{state.settings.theme=theme;navigate(screen);}, {theme,screen});assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,theme+' '+screen);} }
 await p.evaluate(()=>{state.settings.theme='light';navigate('home');});await p.screenshot({path:'qa/release068-light.png',fullPage:true});
 const colors=await p.locator('.daily-workout').evaluate(el=>({color:getComputedStyle(el).color,background:getComputedStyle(el).backgroundImage}));assert.equal(colors.color,'rgb(255, 255, 255)');assert.match(colors.background,/rgb\(57, 56, 106\)/);
 await p.evaluate(()=>{navigate('food');pickFood('snack');});await p.waitForFunction(()=>catalogState().status==='ready',{},{timeout:120000});assert.equal(await p.evaluate(()=>foodHubPool().length),150007);
 for(const query of ['simit','döner','dominos','burger king','popayes','mc donalds']){await p.locator('#unified-food-search').fill(query);await p.waitForTimeout(180);assert.ok(await p.locator('.food-result').count(),query);}
 await p.locator('#unified-food-search').fill('simit sarayı');await p.waitForTimeout(180);await p.locator('[data-id=tr-simitsarayi-simit]').click();await p.locator('#saved-food-form [name=amount]').fill('100');await p.locator('#saved-food-form button[type=submit]').click();assert.ok(await p.evaluate(()=>state.meals[foodDate].some(e=>e.custom?.kcal===344.5)));
 await p.evaluate(()=>foodLabel());await p.locator('#food-label-form').waitFor();await p.evaluate(()=>closeModal());
 await p.evaluate(()=>navigate('settings'));await p.screenshot({path:'qa/release068-premium.png',fullPage:true});
 assert.deepEqual(errors,[]);console.log('PASS lazy 150007-food catalogue, six brand/local searches, portion logging, new label modal, Apple removed, light/dark/light layouts and Premium card.');
}finally{await b.close();await new Promise(r=>server.close(r));}
