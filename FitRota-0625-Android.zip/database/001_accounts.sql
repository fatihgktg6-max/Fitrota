-- Run in your own Supabase SQL editor. Stores an explicit user-requested snapshot.
create table if not exists public.fitrota_snapshots (
 user_id uuid primary key references auth.users(id) on delete cascade,
 payload jsonb not null check (octet_length(payload::text) <= 1048576),
 revision bigint not null default 1,
 consent_version text not null,
 updated_at timestamptz not null default now()
);
alter table public.fitrota_snapshots enable row level security;
drop policy if exists own_snapshot on public.fitrota_snapshots;
create policy own_snapshot on public.fitrota_snapshots for all to authenticated
 using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
revoke all on public.fitrota_snapshots from anon;
grant select,insert,update,delete on public.fitrota_snapshots to authenticated;
-- SECURITY INVOKER keeps RLS enforced, including inside this RPC.
create or replace function public.fitrota_save_snapshot(document jsonb, expected_revision bigint, consent_version text)
returns bigint language plpgsql security invoker set search_path = public as $$
declare result bigint;
begin
 if auth.uid() is null then raise exception 'unauthenticated'; end if;
 if expected_revision = 0 then
  insert into public.fitrota_snapshots(user_id,payload,revision,consent_version)
  values(auth.uid(),document,1,consent_version) on conflict do nothing returning revision into result;
 else
  update public.fitrota_snapshots set payload=document,revision=revision+1,
   consent_version=fitrota_save_snapshot.consent_version,updated_at=now()
  where user_id=auth.uid() and revision=expected_revision returning revision into result;
 end if;
 if result is null then raise exception 'sync_conflict'; end if;
 return result;
end $$;
revoke all on function public.fitrota_save_snapshot(jsonb,bigint,text) from public,anon;
grant execute on function public.fitrota_save_snapshot(jsonb,bigint,text) to authenticated;
