# FitRota 0.5.1 — hesap dayanıklılığı düzeltmesi

0.5.0 özellikleri korunur. GitHub/Render canlı sürümü bu paketle otomatik değişmez.

- Hesap sağlayıcısının geçici hatası oturum çerezini silmez. İşlem 503 ve tekrar dene mesajıyla durur; sağlayıcı düzelince oturum kullanılabilir.
- Gerçek geçersiz oturum yenileme sonrası hâlâ reddedilirse kapatılır. Hata sırasında korumalı silme/kaydetme yapılmaz.
- Apple istemci kimliği/sırrı yoksa Apple giriş sağlayıcısı açılmaz. Gerçek token iptali ayrıca test edilmelidir.
- `npm run check:config`: sunucuda gizli değerleri göstermeden eksik ayarları raporlar. Ağ isteği yapmaz ve anahtar geçerliliği/hukuk uygunluğu kanıtı değildir.
- Altı hesap ve iki ayar testi geçti; üç yeni hesap regresyon senaryosu ve iki ayar kontrol senaryosu içerir.

Google/Apple sağlayıcı kurulumu, Supabase SQL uygulaması ve gerçek hesap testleri, yerel mobil giriş entegrasyonu, işletmeci/hukuk bilgileri hâlâ gereklidir. Kullanıcı bazlı AI kotası, ödeme ve reklam bu düzeltmenin kapsamında değildir.
