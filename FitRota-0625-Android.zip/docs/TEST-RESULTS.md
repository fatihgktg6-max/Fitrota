# FitRota 0.5.6
40 birim testi ve 5 PostgreSQL/HTTP kota testi geçti. Yeni haftalık program ekranları TR/EN ve mobil/tablet/masaüstünde doğrulandı. Hesaplı koç iki saatlik kota yenilenmesi ve mevcut akışlarda 96 düzen kontrolü geçti. Chromium; gerçek cihaz, canlı OpenAI/Supabase işlemi ve mağaza derlemesi yapılmadı.

---
# FitRota 0.5.5 test sonucu

- npm run check: 35 birim testi ve derleme geçti.
- npm run test:content-ui: gram/porsiyon, mikro toplamlar, bilinmeyen değerler, yeniden açılma, 80 tarif kategorisi/arama/detay ve 60 hareket filtresi geçti.
- npm run test:v05: mevcut uygulama akışları ve 96 düzen kontrolü geçti.
- npm run test:features: mevcut özellikler ve 48 düzen kontrolü geçti.
- npm run test:account-coach: onay, erişim kodsuz hesaplı koç, yeniden açılma, kota bekleme/yenileme ve cihaz saatinden bağımsızlık geçti; sahte sağlayıcı kullanıldı.

Chromium ile doğrulandı; gerçek Android/iPhone cihaz testi, canlı OpenAI çağrısı ve imzalı mağaza derlemesi yapılmadı. Canlı GitHub/Render değiştirilmedi.

---

# FitRota 0.4.0 test sonucu

- 16 çekirdek işlev testi: geçti.
- 6 yeni özellik/veri uyumluluğu testi: geçti. Ay hedefi sabitleme, kayıt tarihi, gelecek gün kontrolü, tek ödül, demo/boş hedef engeli, alternatif hareket izolasyonu, dinlenme sayacı ve 0.3 yedek geçişi.
- 3 AI veri/yanıt testi: geçti.
- 5 HTTP/oturum testi: geçti.
- Mevcut arayüz akışları: geçti (profil, antrenman, öğün, takvim, yedek, silme, dil, özel program).
- Yeni arayüz: tema kalıcılığı, notlarda HTML kaçışlama, günlük alternatifler, sayacı duraklat/devam/bitir, haftalık alışveriş, evde var, özel ürün, bölgesel fiyatlar geçti.
- Açık/koyu tema × 390/768/1440 piksel × 8 ekran: 48 yatay taşma kontrolü geçti. Yakalanan JavaScript hatası yok.
- Gerçek istemci/sunucu akışı + sahte AI sağlayıcısı: geçti. Tekrar deneme, iptal, sohbet temizleme ve onay.
- 7 günlük cihaz hatırlama: yeniden açılma ve çıkış testleri geçti.
- PWA: uyku formu, güncelleme bildirimi, güncellemede kayıtların korunması ve çevrimdışı uygulama kabuğu testi geçti.
- Android/iOS Capacitor kaynak eşitlemesi: geçti. İmzalı mağaza derlemesi yapılmadı.
- npm audit: kontrol sırasında 0 bilinen açık.

Tarayıcı doğrulaması Chromium ile yapıldı. Gerçek iPhone/Safari ve Android cihaz testi yapılmadı. Ücretli OpenAI çağrısı veya gerçek satın alma yapılmadı. Ödül kayıtları yerel önizlemedir; sunucuda gerçek abonelik oluşturulmaz.

Bu paket hazırlanırken GitHub/Render'a yeni dosya yazılmadı. 0.4.0'ın canlı olması için sürüm belgesindeki yükleme/dağıtım adımı gereklidir.


# FitRota 0.6.1 test sonuçları — 3 Ekim 2026

- npm run check: 44 çekirdek, bilim/hesap, içerik, antrenman ve yeni katalog testi geçti; üretim derlemesi geçti.
- Yeni katalog: 7.793 farklı USDA kaynak kimliği, dört zorunlu makro, 100 g birimi, bilinen yumurta enerji/kolesterol/demir değerleri; altı Türk üretici etiketi, tuz-sodyum dönüşümü ve bilinmeyen mikro değerler doğrulandı. 12 Türk yemeğinin tüm makro/sodyum/demir/kolesterol hesapları gramlı malzemeleriyle karşılaştırıldı.
- Yeni UI: sucuk, sosis, ters sıralı peynir/beyaz, suzem peynir, karnıyarık ve İngilizce çok kelimeli USDA araması geçti. 50 g süzme peynir 109 kcal/360 mg sodyum, 100 g çiğ yumurta 372 mg kolesterol; kaynak ve miktar yedek/yeniden açılışta korundu. Mikro besinler açılır ok olmadan görünür; AI bağlantı şeridi yok, koç ayarları erişilebilir.
- test:layout + test:content-ui: görünür mikro besinler, gruplu gezinme, öğün kategorileri, tarif ölçekleme, eksik veri ve günlük düzenleme; 128 duyarlı yerleşim geçti. Yeni katalog 320/390/768/1280 genişliklerinde taşmadı.
- test:weekly-food: 7 birim/veritabanı/sağlayıcı testi ve UI geçti. Gerçek PostgreSQL RPC üzerinde iki ayrı hesap ürün paylaşımı, görünür ortak arama, hata halinde cihazdaki kaydın korunması, özel haftalık program/OFF/kopyalama ve 32 duyarlı yerleşim doğrulandı.
- test:coach + test:remember + test:automatic: AI istemci/sunucu akışı, hatalar, tekrar/iptal, oturum kalıcılığı, kodsuz hesap AI'si ve otomatik bulut izin/çakışma düzeni geçti. Gerçek OpenAI çağrısı yapılmadı; sağlayıcı yanıtları test içinde taklit edildi.
- test:server: 7 HTTP/oturum/izin/kota testi geçti.
- npm run native:sync: Android/iOS/web varlıkları eşitlendi. Android/iOS build numarası 18. İmzalı mağaza paketi veya gerçek mobil cihaz testi yapılmadı.
- ZIP bütünlüğü ve sürüm/veri dosyası varlığı kontrol edildi. Bu teslimde GitHub/Render'a yazma yapılmadı.
