import test from 'node:test';
import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';
import {createPaddleService,verifyPaddleSignature} from '../server/paddle.mjs';
import {createCoachServer} from '../server/index.mjs';
const stamp=Date.parse('2026-10-06T00:00:00Z'),owner='11111111-1111-4111-8111-111111111111';
const uid='22222222-2222-4222-8222-222222222222';
const price='pri_'+'a'.repeat(26),txn='txn_'+'b'.repeat(26),sub='sub_'+'c'.repeat(26);
const env={FITROTA_PADDLE_ENABLED:'true',PADDLE_ENVIRONMENT:'sandbox',PADDLE_API_KEY:'server-secret',PADDLE_WEBHOOK_SECRET:'webhook-secret',SUPABASE_URL:'https://db.test',SUPABASE_SERVICE_ROLE_KEY:'db-secret',PADDLE_CLIENT_TOKEN:'test_'+'a'.repeat(27),PADDLE_PRICE_ID:price,FITROTA_PUBLIC_ORIGIN:'https://app.test',FITROTA_PADDLE_TEST_EMAILS:'tester@example.com'};
const user={id:owner,email:'tester@example.com',email_confirmed_at:'2026-01-01T00:00:00Z'};
const period={starts_at:'2026-10-01T00:00:00Z',ends_at:'2026-11-01T00:00:00Z'};
const items=[{price:{id:price,billing_cycle:{interval:'month',frequency:1}},quantity:1}];
const sign=raw=>'ts='+stamp/1000+';h1='+createHmac('sha256',env.PADDLE_WEBHOOK_SECRET).update(stamp/1000+':').update(raw).digest('hex');
const payload=(type,data,at='2026-10-06T00:00:00Z')=>Buffer.from(JSON.stringify({event_id:'evt_'+'e'.repeat(26),event_type:type,occurred_at:at,data}));
function fixture(){
 const memory={pending:[],subscriptions:[],refunds:[],requests:[],transaction:{id:txn,status:'completed',subscription_id:sub,custom_data:{fitrota_user_id:owner},currency_code:'USD',items,billing_period:period},subscription:{id:sub,status:'active',custom_data:{fitrota_user_id:owner},items,current_billing_period:period,management_urls:{cancel:'https://sandbox-customer-portal.paddle.com/customer'}}};
 const fetcher=async(url,options={})=>{
  const u=new URL(url),body=options.body?JSON.parse(options.body):null;memory.requests.push({url,options,body});let result=[];
  if(u.hostname==='sandbox-api.paddle.com'){
   if(u.pathname.startsWith('/transactions'))result=memory.transaction;
   else if(u.pathname.startsWith('/subscriptions'))result=memory.subscription;
   else throw Error('unexpected_provider_path');
   return Response.json({data:result});
  }
  if(u.pathname.endsWith('fitrota_paddle_claim_checkout'))result=true;
  else if(u.pathname.endsWith('fitrota_paddle_record_payment')){
   const current=memory.subscriptions[0];if(!current||Date.parse(body.p_occurred_at)>Date.parse(current.occurred_at))memory.subscriptions=[{subscription_id:body.p_subscription_id,user_id:body.p_user_id,transaction_id:body.p_transaction_id,occurred_at:body.p_occurred_at}];return new Response(null,{status:204});
  }else if(u.pathname.endsWith('fitrota_paddle_checkouts')){
   if(body){memory.pending.push(body);return new Response(null,{status:201});}result=memory.pending.filter(x=>x.transaction_id===u.searchParams.get('transaction_id')?.slice(3));
  }else if(u.pathname.endsWith('fitrota_paddle_subscriptions'))result=memory.subscriptions.filter(x=>u.searchParams.has('user_id')?x.user_id===u.searchParams.get('user_id').slice(3):x.subscription_id===u.searchParams.get('subscription_id').slice(3));
  else if(u.pathname.endsWith('fitrota_paddle_refunds')){if(body){memory.refunds.push(body);return new Response(null,{status:201});}result=memory.refunds.filter(x=>x.transaction_id===u.searchParams.get('transaction_id')?.slice(3));}
  else throw Error('unexpected_database_path');return Response.json(result);
 };
 return {memory,service:createPaddleService({env,fetcher,now:()=>stamp})};
}
test('webhook signatures reject forgery, raw-byte changes, expired/future timestamps; rotated h1 supported',()=>{
 const raw=Buffer.from('{"a":1}');assert.equal(verifyPaddleSignature(raw,sign(raw),env.PADDLE_WEBHOOK_SECRET,stamp),true);
 assert.equal(verifyPaddleSignature(raw,sign(raw),env.PADDLE_WEBHOOK_SECRET,stamp+6000),false);
 assert.equal(verifyPaddleSignature(raw,sign(raw),env.PADDLE_WEBHOOK_SECRET,stamp-6000),false);
 assert.equal(verifyPaddleSignature(Buffer.from('{ "a":1}'),sign(raw),env.PADDLE_WEBHOOK_SECRET,stamp),false);
 assert.equal(verifyPaddleSignature(raw,sign(raw)+';ts='+stamp/1000,env.PADDLE_WEBHOOK_SECRET,stamp),false);
 assert.equal(verifyPaddleSignature(raw,'h1='+'0'.repeat(64)+';'+sign(raw),env.PADDLE_WEBHOOK_SECRET,stamp),true);
});
test('checkout is sandbox-only, verified tester-only, server-priced and persisted before exposing transaction',async()=>{
 const {service,memory}=fixture();assert.equal(service.allowed(user),true);assert.equal(service.allowed({...user,email_confirmed_at:null}),false);
 await assert.rejects(service.checkout({...user,email:'other@example.com'}),/paddle_test_only/);
 const result=await service.checkout(user);assert.equal(result.transactionId,txn);assert.equal(memory.pending[0].user_id,owner);
 const request=memory.requests.find(x=>x.url.endsWith('/transactions'));assert.deepEqual(request.body.items,[{price_id:price,quantity:1}]);assert.equal(request.body.custom_data.fitrota_user_id,owner);
 assert.equal(JSON.stringify(result).includes('server-secret'),false);
 assert.equal(createPaddleService({env:{...env,PADDLE_ENVIRONMENT:'live'}}).configured,false);
 assert.equal(createPaddleService({env:{...env,FITROTA_PADDLE_TEST_EMAILS:''}}).configured,false);
});
test('Premium requires known checkout, verified completed payment and current paid subscription',async()=>{
 const {service,memory}=fixture(),raw=payload('transaction.completed',{id:txn});
 await service.webhook(raw,sign(raw));assert.equal((await service.status(owner)).premium,false);
 await service.checkout(user);await service.webhook(raw,sign(raw));assert.equal((await service.status(owner)).premium,true);
 assert.equal((await service.status(uid)).premium,false);
 for(const state of ['past_due','trialing','canceled','paused']){memory.subscription.status=state;assert.equal((await service.status(owner)).premium,false);}
 memory.subscription.status='active';memory.transaction.billing_period={...period,ends_at:'2026-10-05T00:00:00Z'};assert.equal((await service.status(owner)).premium,false);
 memory.transaction.billing_period=period;memory.transaction.origin='subscription_payment_method_change';assert.equal((await service.status(owner)).premium,false);
});
test('spoofed checkout metadata and wrong product never grant Premium',async()=>{
 const {service,memory}=fixture();await service.checkout(user);memory.transaction.custom_data.fitrota_user_id=uid;
 const raw=payload('transaction.completed',{id:txn});await service.webhook(raw,sign(raw));assert.equal(memory.subscriptions.length,0);
 memory.transaction.custom_data.fitrota_user_id=owner;memory.transaction.items=[{price:{id:'pri_'+'z'.repeat(26)},quantity:1}];await service.webhook(raw,sign(raw));assert.equal(memory.subscriptions.length,0);
});
test('refund before payment blocks access; pending/rejected refunds do not revoke; retries are safe',async()=>{
 const {service,memory}=fixture();await service.checkout(user);
 for(const status of ['pending_approval','rejected']){const raw=payload('adjustment.updated',{transaction_id:txn,action:'refund',status});await service.webhook(raw,sign(raw));}
 assert.equal(memory.refunds.length,0);
 const refund=payload('adjustment.updated',{transaction_id:txn,action:'refund',status:'approved'});await service.webhook(refund,sign(refund));
 const payment=payload('transaction.completed',{id:txn});await service.webhook(payment,sign(payment));await service.webhook(payment,sign(payment));assert.equal((await service.status(owner)).premium,false);
});
test('actual SQL enforces monotonic payments, immutable ownership, rate limits and no client grants',async()=>{
 const db=new PGlite();await db.exec('create schema auth;create table auth.users(id uuid primary key);create role anon;create role authenticated;create role service_role;');
 await db.exec(await readFile(new URL('../database/007_paddle_sandbox.sql',import.meta.url),'utf8'));
 await db.query('insert into auth.users values($1),($2)',[owner,uid]);
 const record=(who,t,at)=>db.query('select public.fitrota_paddle_record_payment($1,$2,$3,$4)',[who,sub,t,at]);
 await record(owner,txn,'2026-10-06');await record(owner,'txn_'+'d'.repeat(26),'2026-10-05');await record(uid,'txn_'+'f'.repeat(26),'2026-10-07');
 assert.equal((await db.query('select * from public.fitrota_paddle_subscriptions')).rows[0].transaction_id,txn);
 assert.equal((await db.query('select public.fitrota_paddle_claim_checkout($1) as ok',[owner])).rows[0].ok,true);
 assert.equal((await db.query('select public.fitrota_paddle_claim_checkout($1) as ok',[owner])).rows[0].ok,false);
 await db.exec('set role authenticated');await assert.rejects(db.query('select * from public.fitrota_paddle_subscriptions'),/permission denied/);await assert.rejects(record(owner,txn,'2026-10-08'),/permission denied/);await db.exec('reset role');await db.close();
});
test('only exact webhook route bypasses country gate, unsigned requests still rejected',async()=>{
 const {service}=fixture();const server=createCoachServer({accessCode:'x'.repeat(32),launchMarket:'US',countryProxySecret:'s'.repeat(32),allowedOrigins:[],billingService:{paddle:service},accountService:{enabled:false,handler:async()=>false}});
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const base='http://127.0.0.1:'+server.address().port;
 try{
  assert.equal((await fetch(base+'/account/membership')).status,403);
  assert.equal((await fetch(base+'/webhooks/paddle/sandbox/')).status,403);
  const raw=payload('subscription.updated',{id:sub});
  assert.equal((await fetch(base+'/webhooks/paddle/sandbox',{method:'POST',headers:{'Content-Type':'application/json'},body:raw})).status,401);
  assert.equal((await fetch(base+'/webhooks/paddle/sandbox',{method:'POST',headers:{'Content-Type':'application/json','Paddle-Signature':sign(raw)},body:raw})).status,200);
 }finally{await new Promise(resolve=>server.close(resolve));}
});
test('browser passes only server transaction to Paddle and blocks live data/account switches',async()=>{
 const {createContext,runInContext}=await import('node:vm');
 const source=(await readFile(new URL('../src/membership.js',import.meta.url),'utf8')).split('let paddleScriptPromise;')[1];
 const calls=[],context=createContext({window:{Paddle:{Environment:{set:v=>calls.push(v)},Initialize:v=>calls.push(v),Checkout:{open:v=>calls.push(v)}}},accountInfo:{user:{id:owner}},Error,Promise,setTimeout,clearTimeout,document:{},t:(_a,b)=>b,toast:()=>{}});
 runInContext('let paddleScriptPromise;'+source,context);
 const data={environment:'sandbox',token:env.PADDLE_CLIENT_TOKEN,transactionId:txn};
 await context.openPaddleCheckout(data);assert.equal(calls[0],'sandbox');assert.equal(calls[2].transactionId,txn);assert.equal(calls[2].items,undefined);assert.equal(calls[2].customData,undefined);
 await assert.rejects(context.openPaddleCheckout({...data,environment:'live'}),/invalid_checkout/);
 context.accountInfo.user={id:uid};await context.openPaddleCheckout(data);assert.equal(context.window.__fitrotaPaddleOwner,uid);
});
