import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {pantryMatch,allowedFoods,normalizeProfile,emptyState,validateBackup,foodTotals} from '../src/core.js';
test('pantry accepts full USDA ingredient labels containing commas without substring matches',()=>{
 const p=normalizeProfile({name:'Test',age:25,height:180,weight:80,days:[1,3,5],budget:1});
 const f=allowedFoods(p).find(x=>x.id==='us-recipe-pancakes');
 assert.equal(pantryMatch(f,f.ingredients.map(i=>i[1]).join(', ')).missing.length,0);
 assert.equal(pantryMatch({ingredients:[['Oil','Oil',10,'g']]},'olive oil').missing.length,1);
 assert.equal(pantryMatch(f,'').ratio,0);
});
function fixture(){
 const c={structuredClone,preciseNumber:String,portionUnit:()=> 'g',window:{},app:{addEventListener(){}},modalRoot:{addEventListener(){}},clearTimeout(){},setTimeout(){},paintFoodResults(){}};
 vm.createContext(c);vm.runInContext(readFileSync(new URL('../src/food-hub.js',import.meta.url),'utf8').replace(/^import .*;$/gm,''),c);return c;
}
test('typing a new food query invalidates in-flight community and catalog responses immediately',()=>{
 const c=fixture();vm.runInContext("foodHub().community=[{id:'old'}];foodHub().catalog=[{id:'old'}];foodHub().catalogMore=true;foodHub().remoteMore=true;foodHub().seq=5;foodHub().catalogSeq=7;window.__catalogAbort={abort(){window.aborted=true}};handleUnifiedFoodInput({target:{id:'unified-food-search',value:'milk',closest(){return null}}})",c);
 const h=c.window.__foodHub;assert.equal(h.query,'milk');assert.equal(h.seq,6);assert.equal(h.catalogSeq,8);assert.equal(h.community.length,0);assert.equal(h.catalog.length,0);assert.equal(h.catalogMore,false);assert.equal(h.remoteMore,false);assert.equal(c.window.aborted,true);
});
test('external gram/ml labels initialize to 100 units even with US display units',()=>{
 const c=fixture();Object.assign(c,{t:(tr,en)=>en,loc:x=>Array.isArray(x)?x[1]:x,esc:String,modal(){},selectField:()=>'',portionShortcuts:()=>'',field:(label,name,type,value)=>{c.amount=value;return '';},imperialUnits:()=>true,foodAmountPreview:(f,factor)=>{c.factor=factor;return '';},labels:{slots:{snack:['Ara','Snack']}},nutrientFields:[],foodSourceLabel:()=>'',btn:()=>''});
 vm.runInContext("foodHubPool=()=>[{key:'test',name:['Milk','Milk'],unit:'g',source:'external',kcal:50,sourceURL:'https://world.openfoodfacts.org/product/12345678'}];selectedFoodForm('test')",c);
 assert.equal(c.amount,100);assert.equal(c.factor,1);
});

test('partial source labels preserve unknown macros across backup and totals',()=>{
 const s=emptyState();s.meals['2026-10-07']=[{id:'partial-label',foodId:'custom',slot:'snack',servings:1,custom:{name:'Source label',partialNutrition:true,kcal:100,protein:null,carbs:20,fat:2}}];
 const restored=validateBackup(JSON.parse(JSON.stringify(s)));const entry=restored.meals['2026-10-07'][0];assert.equal(entry.custom.partialNutrition,true);assert.equal(entry.custom.protein,null);const sum=foodTotals([entry]);assert.equal(sum.kcal,100);assert.equal(sum.missing.protein,1);assert.equal(sum.carbs,20);
 s.meals['2026-10-07'][0].custom.kcal=null;assert.throws(()=>validateBackup(s));
});
