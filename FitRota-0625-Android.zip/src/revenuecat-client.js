export class NativeBilling {
  constructor({purchases, ui, config, platform, onChange = () => {}}) {
    Object.assign(this, {purchases, ui, config, platform, onChange});
    this.configured = false;
    this.verified = false;
    this.owner = undefined;
    this.info = null;
    this.offering = null;
    this.tail = Promise.resolve();
    this.busy = false;
    this.listener = null;
  }
  get available() { return ['android', 'ios'].includes(this.platform()); }
  get entitlement() { return this.info?.entitlements?.active?.[this.config.entitlement] ?? null; }
  get active() { return this.entitlement?.isActive === true; }
  clear() { this.verified = false; this.info = null; this.offering = null; this.onChange(this); }
  enqueue(work) {
    const next = this.tail.then(work);
    this.tail = next.catch(() => {});
    return next;
  }
  async identify(owner) {
    if (!this.available) throw Error('native_only');
    owner = owner || null;
    if (!this.configured) {
      const key = this.config.testMode ? this.config.testApiKey :
        this.platform() === 'android' ? this.config.androidApiKey : this.config.iosApiKey;
      if (!key || (!this.config.testMode && key.startsWith('test_'))) throw Error('store_key_missing');
      await this.purchases.configure({apiKey: key, ...(owner ? {appUserID: owner} : {})});
      this.configured = true;
      this.owner = owner;
    } else if (this.owner !== owner) {
      this.clear();
      const result = owner ? await this.purchases.logIn({appUserID: owner}) : await this.purchases.logOut();
      this.owner = owner;
      this.info = result.customerInfo;
    }
    if (this.listener === null) {
      // Read again under the identity queue; never apply an unscoped listener payload.
      this.listener = await this.purchases.addCustomerInfoUpdateListener(() => {
        this.enqueue(async () => {
          this.info = (await this.purchases.getCustomerInfo()).customerInfo;
          this.onChange(this);
        }).catch(() => {});
      });
    }
  }
  refresh(owner) {
    this.verified = false;
    this.onChange(this);
    return this.enqueue(async () => {
      await this.identify(owner);
      this.info = (await this.purchases.getCustomerInfo()).customerInfo;
      this.verified = true;
      this.onChange(this);
      return this.info;
    });
  }
  offerings(owner) {
    return this.enqueue(async () => {
      await this.identify(owner);
      const offerings = await this.purchases.getOfferings();
      this.offering = offerings.current;
      if (!this.offering?.availablePackages?.length) throw Error('offering_missing');
      return this.offering;
    });
  }
  async action(owner, work) {
    if (this.busy) throw Error('purchase_busy');
    this.busy = true;
    try {
      return await this.enqueue(async () => {
        await this.identify(owner);
        const result = await work();
        this.info = (await this.purchases.getCustomerInfo()).customerInfo;
        this.onChange(this);
        return result;
      });
    } finally { this.busy = false; }
  }
  purchase(owner, identifier) {
    return this.action(owner, async () => {
      const {current} = await this.purchases.getOfferings();
      const aPackage = current?.availablePackages?.find(p => p.identifier === identifier);
      if (!aPackage) throw Error('offering_missing');
      return this.purchases.purchasePackage({aPackage});
    });
  }
  paywall(owner) {
    return this.action(owner, async () => {
      const {current} = await this.purchases.getOfferings();
      if (!current?.availablePackages?.length) throw Error('offering_missing');
      const {result} = await this.ui.presentPaywallIfNeeded({
        requiredEntitlementIdentifier: this.config.entitlement,
        offering: current, displayCloseButton: true,
      });
      if (result === 'ERROR') throw Error('paywall_error');
      return result;
    });
  }
  restore(owner) { return this.action(owner, () => this.purchases.restorePurchases()); }
  manage(owner) { return this.action(owner, () => this.ui.presentCustomerCenter()); }
  async dispose() {
    await this.tail;
    if (this.listener !== null) await this.purchases.removeCustomerInfoUpdateListener({listenerToRemove: this.listener});
    this.listener = null;
  }
}
export function billingError(error) {
  if (error?.userCancelled || String(error?.code) === '1') return 'cancelled';
  if (String(error?.code) === '20') return 'pending';
  return error?.message || 'purchase_failed';
}
