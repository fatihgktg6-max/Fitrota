# FitRota 0.5.2 — sade antrenman ve hesapla AI

## Değişiklikler

- Hareket animasyonları, oynatma düğmesi ve çizim kodu kaldırıldı. Hareket adımları, kas grubu ve güvenli uygulama açıklamaları korunur.
- Antrenman sayfasında önce bugünün programı ve başlat/devam düğmesi; sonra haftalık takvim bulunur. Hareketler ayrı kartlarda set, tekrar/süre ve dinlenmeyle gösterilir. Sıfır süreli ısınma/sakinleşme ve dinlenme etiketleri gösterilmez. İpuçları ve özel plan ayarları açılır bölüme taşındı.
- Web/PWA hesabı kurulmuş kullanıcı AI koç için ayrıca erişim kodu girmez. Onay sonrası `/account/ai-session` doğrulama yapar, `/account/coach` her mesajda aynı HttpOnly hesap oturumunu doğrular. Başka sekmede hesap değişirse kayıt sahibinin kontrolü isteği reddeder. OpenAI anahtarı sunucuda kalır.
- Hesap profiline ait paylaşım seçimi hatırlanır. Bağlantıyı kesmek bu seçimi kapatır. Google/Apple hesabından çıkış veya sağlayıcıda geçersiz oturum yeni AI isteğini reddeder.
- Hesap hizmeti kurulmamış özel test sürümünde pilot bağlantı, “Geliştirici test bağlantısı” açılır bölümündedir. “7 gün hatırla” varsayılan açık; ortak cihaz için kapatılabilir. Erişim kodu uygulamaya gömülmez, anonim ücretli AI açılmaz.

## Doğrulama

Birim, pilot sunucu ve hesap testleri; kod istemeyen hesap koçu için sunucu izin/onay/hesap değişimi testleri ve tarayıcı akışı. Tarayıcı testinde onay, yenilemeyle geri bağlanma ve oturum iptalinde isteğin durması doğrulandı. Antrenman/beslenme/kayıt akışları ve 96 dil/tema/genişlik/rota düzeni kontrol edildi. Sahte sağlayıcı kullanıldı; ücretli OpenAI çağrısı yapılmadı.

## Kalan kurulumlar

Gerçek Supabase/Google/Apple hesabı ve sunucu AI anahtar/model ayarları hâlâ işletmecinin projesinde kurulmalıdır. Kurulmadan kullanıcıya “AI hazır” denmez. Yerel Android/iOS giriş SDK entegrasyonu ve fiziksel cihaz testi henüz tamamlanmamıştır; yeni hesapla AI yolu web/PWA içindir. Kullanıcı başına 30 mesaj/1 saat kotası, Premium ödeme ve reklam bu sürümde eklenmedi. Genel pilot günlük maliyet sınırı hesap AI isteklerinde de korunur; bu sınır kullanıcı başına kota değildir.

Bu paket GitHub/Render canlı sürümünü kendiliğinden değiştirmez.
