# FitRota Android 0.6.24

This is a device-test build, not a verified store release.

Changes: native Google Credential Manager sign-in using the supplied public Web client ID; Supabase ID-token exchange on the existing account server with nonce, terms, provider and origin validation; remote HTTPS native HTTP transport with the HttpOnly account cookie; high-resolution launcher resources of matching mipmap types; dark launch theme and WebView/loading background; automatic removal of compressed server-only assets before Gradle packaging.

Deploy the same ZIP to Render: existing environment settings remain required. Build command:

python3 -m zipfile -e FitRota-0624-Android.zip . && python3 scripts/prepare-us-release.py && npm ci --include=dev && npm run build:us

Start: npm run server

Native API host: https://fitrota-us-gateway.fatihgktg6.workers.dev
US country access remains enforced. No proxy secrets are included in the app.

Google Cloud: add an Android OAuth client in the same project as the supplied Web client, package com.fitrota.app, development signing SHA-1:
72:74:E1:74:75:A9:13:DD:30:04:CC:AE:CE:3A:E2:8A:FB:E5:02:D9

The bundled debug-test.keystore and its android password are public development credentials only. They keep test APK signing stable. Never use this development key to sign a store release. Play App Signing requires its own registered SHA-1 and production upload key.

Install on a device with Google Play Services for the native account picker. Devices without those services have not been tested/supported by this integration.

Validation: npm run check passed (existing server/billing/food/core tests and web build); 33 targeted native-account/account/AdMob tests passed; npm run build:us, cap sync android, native:prepare passed. XML parsed and archive CRC checked. No Android SDK/JDK21 is available in the authoring environment, so native Gradle, physical Google authentication, splash rendering and real billing remain unverified. Run the supplied Actions workflow and inspect the resulting APK on device.

RevenueCat production Android public API key, Play products/offering, purchase tests, AdMob device consent tests and signed AAB are still required before public release.
