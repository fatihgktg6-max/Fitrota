# FitRota 0.3.0 doğrulama

- 16 çekirdek test: başarılı.
- 3 AI istemci/yanıt ayrıştırma testi: başarılı.
- 4 HTTP sunucu testi: başarılı; oturum, origin, rol, süre ve kota.
- Tarayıcı akışları: onboarding, antrenman, beslenme, takvim, yedek alma/geri yükleme, silme ve dil değişimi başarılı.
- 390, 768 ve 1440 pikselde sekiz ekran: yatay taşma veya yakalanan JS hatası yok.
- Koç bağlantısı, yeniden deneme, iptal, sohbet silme, bellekte oturum: başarılı.
- Yeni sürüm testi: robot düğmesi, uyku onayı, gece yarısını aşan saatler, geçersiz süre, kullanıcıya Türkçe özet, önbellek izolasyonu, çevrimdışı açılış ve kullanıcı onaylı güncelleme başarılı.
- Güncelleme sırasında profil, antrenman, öğün, ölçüm, etkinlik ve sohbet korunumu doğrulandı. Bu test sırasında bulunan antrenman hareket sürelerinin yeniden yüklenmede değişmesi düzeltildi.
- npm audit: denetim sırasında bilinen açık sayısı 0. Bu bütün güvenlik risklerinin yokluğu anlamına gelmez.
- Capacitor Android/iOS sync: başarılı. İmzalı native derleme ve fiziksel cihaz testleri yapılmadı.

AI testleri sahte sağlayıcı ile yapıldı; ücretli OpenAI çağrısı yapılmadı. Gerçek hesap modeli ve sunucu anahtarı bu paketin testinde kullanılmadı. Tarayıcı testleri Chromium üzerinde; gerçek Safari/Android cihaz doğrulaması ayrıca gerekli.

GitHub bağlantısı yazma işlemlerinde 403 döndürdüğü için bu paket doğrudan depoya veya Render'a yayınlanamadı. ZIP içindeki sürüm ve dist/version.json 0.3.0 olarak doğrulandı.
