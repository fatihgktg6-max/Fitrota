import {isUSFoodVisible} from '../src/us-food-policy.js';
import {DatabaseSync} from 'node:sqlite';
import {fileURLToPath} from 'node:url';
// Public nutrition records only. No user identifiers or diary records in this database.
export function createUSCatalog({filename=fileURLToPath(new URL('../content/us-foods.sqlite',import.meta.url)),now=()=>Date.now()}={}){
 let db,count;const cache=new Map();
 function open(){if(!db){db=new DatabaseSync(filename,{readOnly:true});count=db.prepare('SELECT count(*) AS n FROM foods').get().n;}return db;}
 function search(query,offset=0){const q=String(query||'').trim().slice(0,100),start=Math.max(0,Math.min(5000,Number(offset)||0));if(q.length<2)return {items:[],count:count||0,more:false};const key=q.toLowerCase()+'|'+start,c=cache.get(key);if(c&&c.until>now())return c.data;
 const database=open(),tokens=q.toLowerCase().match(/[\p{L}\p{N}]+/gu)?.slice(0,8)||[];let rows=[];
 if(/^\d{8,14}$/.test(q))rows=database.prepare('SELECT data FROM foods WHERE barcode=? LIMIT 1').all(q);
 else if(tokens.length){const match=tokens.map(t=>'"'+t+'"*').join(' AND ');rows=database.prepare('SELECT foods.data FROM food_search JOIN foods ON foods.rowid=food_search.rowid WHERE food_search MATCH ? ORDER BY rank LIMIT 51 OFFSET ?').all(match,start);}
 const data={items:rows.slice(0,50).map(r=>JSON.parse(r.data)).filter(isUSFoodVisible),count,more:rows.length>50,offset:start,source:'USDA FoodData Central',market:'US',license:'CC0 / public domain'};if(cache.size>=100)cache.delete(cache.keys().next().value);cache.set(key,{until:now()+300000,data});return data;
 }
 return {search,close(){db?.close();db=null;}};
}
