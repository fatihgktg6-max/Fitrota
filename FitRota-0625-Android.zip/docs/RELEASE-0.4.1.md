# FitRota 0.4.1 — kullanım düzeltmeleri

Bu sürüm test için hazırlanmıştır; canlı siteye veya mağazalara gönderilmemiştir.

- Kullanıcı bölge seçimi ve taslak abonelik fiyatları kaldırıldı. Premium alanı yalnızca “yakında” bilgisini gösterir; satın alma yapmaz.
- Günlük notlar pencere kapatıldığında veya başka bir uygulama penceresi açıldığında da kaydedilir. Notlar cihazda kalır. Tarayıcı sekmesini doğrudan kapatmadan önce not penceresini kapatın veya Kaydet’e basın.
- İsim ve beslenme tercihleri gibi antrenman dışı profil değişiklikleri aktif antrenmanın set kayıtlarını sıfırlamaz. Ekipman veya sağlık kısıtı değişirse planı yeniden oluşturmak için aktif oturum sıfırlanır.
- Haftalık programda bugünün kartı küçük ekranlarda görünür konuma kaydırılır.

## Doğrulama

Bu sürümde npm run check başarılı: 25 birim testi, JavaScript sözdizimi ve üretim derlemesi. npm run test:features başarılı: notu kapatarak kaydetme ve yeniden yükleme, isim düzenlerken aktif oturumu koruma, taslak fiyatların kaldırılması ve mevcut özellik akışları; 48 ekran/tema yerleşim kontrolü, çalışma zamanı hatası yok. npm run native:sync başarılı.

Android/iOS kaynakları eşitlendi; bu işlem imzalı APK/AAB/IPA oluşturmaz veya gerçek cihaz testi yerine geçmez. Önceki sürümün test raporları tarihseldir; bu turda tüm sunucu ve AI test paketleri yeniden çalıştırılmadı.

## Sonraki aşama

Kişisel hesaplar, kalıcı kullanıcı bazlı AI kotası, doğrulanmış Premium hakkı, otomatik mağaza fiyatlandırması, reklam ve yayınlama sonraki aşamaya bırakıldı. Mevcut AI erişim kodu sistemi ve ödül önizlemesi devam eder.
