# FitRota — Google girişini genel erişime açmadan önce

4 Ekim 2026. Bu dosya uygulamanın veri akışını ve tamamlanacak işlemleri açıklar; imzalı sözleşme veya hukuk görüşü değildir. Test modu da veri koruma yükümlülüklerinden muafiyet sağlamaz.

## Hazır olan uygulama davranışı

Google girişinde kullanım koşulları/aydınlatma bağlantıları ve kısa veri akışı açıklaması bulunur. AI ve otomatik bulut yedeği ayrı ve başlangıçta seçilmemiş tercihlerdir. Kullanıcı tercihlerini sonradan değiştirebilir. Mevcut yedeği silmek ayrı işlemdir. Giriş ve bulut istekleri sunucunun bildirdiği metin sürümünü kullanır.

## İşleme ve aktarım envanteri

| İşlem | Veri | Hizmetler | Tetikleyici |
|---|---|---|---|
| Google giriş | Hesap kimliği, paylaşılan e-posta, oturum belirteçleri; bağlantı/güvenlik bilgileri | Google, Supabase, Render üzerinde FitRota | Google ile devam et |
| Bulut yedeği | Profil, sağlık tercihleri, günlükler, ölçümler, antrenman, takvim, not ve sohbetler | Render, Supabase | Manuel kaydet veya ayrı otomatik yedek tercihi |
| AI koç | Gönderilen mesaj ve izin verilen bağlam; ayrıca seçilirse gelişim özeti | Render, OpenAI | AI bağlantısı ve mesaj gönderme |
| Ödül/hediye | Hesap kimliği, görev tarihleri ve tamamlanma işaretleri, kod kullanımı | Render, Supabase | İlgili özelliğin kullanımı |
| Premium satın alma | Hesap kimliği ve abonelik/ödeme durumu; kart bilgisi ödeme sağlayıcısında | RevenueCat ve gerçek ödeme sağlayıcısı | Satın alma akışı |
| Reklam | Bağlantı, cihaz ve rıza tercihleri | Google AdSense/CMP | Reklam yapılandırması ve kullanıcı tercihi |

Sağlayıcının ticari adı, sözleşmenin tarafı olan tüzel kişiyle aynı kabul edilmemelidir. Her hizmetin gerçek sözleşme tarafı, rolü, işleme/destek/alt işleyen ülkeleri, saklama süreleri ve güvenlik tedbirleri kendi hesabındaki belgelerle doğrulanmalıdır. Google girişinin yönleri ve sağlayıcı rolleri ayrıca değerlendirilmelidir; bütün taraflar otomatik olarak veri işleyen sayılmaz. Render bölgesi ile Supabase bölgesi ayrı kontrol edilir. AB bölgesi seçmek tek başına KVKK aktarım dayanağı sağlamaz.

## Eldeki cevapların anlamı

- OpenAI: Gönderilen destek cevabı Türk KVKK standart sözleşmesini imzalamıyor veya onaylamıyor; satış/uyum kanalına yönlendiriyor.
- Render: Belge merkezindeki DPA ve raporlara yönlendirme alınmış. Bunun Türk KVKK aktarım mekanizmasını tek başına karşıladığı doğrulanmış değil.
- Supabase: Paylaşılan cevap destek talebinin alındığını bildiriyor. İmzalı aktarım sözleşmesi gösterilmedi.
- Google OAuth/AdSense teknik onayı, FitRota'nın veri sorumlusu yükümlülüklerini üstlenmeleri anlamına gelmez.

## Somut tamamlanacak işler

1. Veri sorumlusunun gerçek adı, başvuru adresi ve iletişim bilgilerini; uygulamanın hizmet verdiği ülkeleri doğrula. Adres bu belgede tahmin edilmez.
2. Her veri kategorisi için KVKK madde 5/6 işleme şartını, özel nitelikli veri tedbirlerini ve madde 9 aktarım mekanizmasını hukuk incelemesiyle belirle. Genel bir “yurt dışına aktarımı kabul ediyorum” kutusu düzenli aktarımın dayanağı yerine kullanılmaz.
3. Standart sözleşme yoluna gidilecekse tarafların rollerine uygun resmî metni ve eklerini kullan; zorunlu hükümleri değiştirme. İki tarafın yetkili imzaları ve gerekli yetki belgelerini tamamla; imzaların tamamlanmasından itibaren beş iş günü içinde Kuruma bildirim sürecini yerine getir. DPA/GDPR SCC tek başına Türk standart sözleşmesinin imzalandığını göstermez.
4. Sağlayıcı bu düzenlemeyi karşılayamıyorsa alternatif geçerli mekanizmayı uzmanla değerlendir veya o veri akışı için altyapıyı değiştir. Yalnız Google'ı kaldırmak, yabancı sunucu/veritabanı kullanımını ortadan kaldırmaz.
5. Doğrulanan bilgileri FITROTA_REGION_NOTICE, FITROTA_RETENTION_NOTICE, FITROTA_PROCESSING_BASIS_NOTICE ve FITROTA_TRANSFER_NOTICE alanlarına yaz; kaynak belgeleri sakla. Anahtar, şifre veya kişisel kimlik belgesini GitHub'a koyma.
6. Gerçek inceleme tamamlandıktan sonra FITROTA_LEGAL_REVIEWED=true kullanılır. Bu anahtarı açmak hukuki incelemeyi yapmaz. Genel Google erişimi için OAuth ayarları, yönlendirmeler ve gerçek hesapla giriş/çıkış/silme testi de tamamlanır.

## Bu paketle yapılmayanlar

Sağlayıcı adına imza atılmadı. KVKK bildirimi gönderilmedi. Canlı Render ayarları değiştirilmedi. Genel erişim, reklam onayı ve ücretli satın alma açılmadı. Başvuru/satıcı bilgileri doğrulanmadan sözleşmeler “kesin onaylı” gösterilmedi.

## Resmî kaynaklar

- https://www.kvkk.gov.tr/Icerik/2053/Yurtdisina-Aktarim
- https://www.kvkk.gov.tr/Icerik/7929/Standart-Sozlesmeler
- https://www.kvkk.gov.tr/Icerik/8170/Yurt-Disina-Kisisel-Veri-Aktariminda-Kullanilacak-Standart-Sozlesmelerde-Dikkat-Edilmesi-Gereken-Hususlara-Iliskin-Kamuoyu-Duyurusu
