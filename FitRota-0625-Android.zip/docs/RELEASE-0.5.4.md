# FitRota 0.5.4 — Hesap başına AI kotası

Bu sürüm ücretsiz hesaba 30 AI mesajı verir. İlk mesajdan itibaren her saat sıfırlama yapılmaz: 30. mesaj için hak ayrıldığı anda 1 saatlik bekleme başlar. Bekleme tamamlandığında 30 yeni mesaj açılır. Telefon/tablet, sekme, yeniden giriş ve uygulama/sunucu yeniden başlatılması hakları sıfırlamaz. Koç ekranında kalan haklar, geri sayım ve “Kotayı yenile” düğmesi bulunur. Cihaz saatini değiştirmek sunucudaki bekleme süresini değiştirmez.

## Kurulum (mevcut çalışan 0.5.3 üzerine)

1. Supabase → doğru proje → SQL Editor → New query. `database/002_ai_quota.sql` içeriğinin tamamını yapıştır ve **Run**. `Success. No rows returned` beklenir. Eski hesap/veri SQL'ini tekrar çalıştırman gerekmez. Bu SQL yeniden çalıştırılabilir; eski kullanıcı kayıtlarını silmez.
2. GitHub deposunun köküne `FitRota-0.5.4.zip` yükle. ZIP'i telefonda çıkartman gerekmez.
3. Render → Fitrota → Settings → Build Command:

   ```sh
   python3 -m zipfile -e FitRota-0.5.4.zip . && npm ci --include=dev && npm run build
   ```

   Start Command mevcut şekilde kalır:

   ```sh
   HOST=0.0.0.0 node server/index.mjs
   ```

4. Render → Manual Deploy → Deploy latest commit. `Live` olduğunda web uygulamasını açıp yenile. Ana ekrana eklenmiş PWA'da güncelleme bildirimi varsa güncelle.
5. Hesabınla giriş yap → AI koç. Kalan hak `30 / 30` görünmeli; başarılı yanıt sonrası `29 / 30` olmalı. Başka cihazda aynı hesapla açınca aynı kota görünür; ekran en geç yaklaşık 30 saniyede güncel durumu sorgular veya “Kotayı yenile” ile hemen sorgulanır.

Yeni ortam değişkeni gerekmez. Çalışan hesabın `SUPABASE_URL` ve `SUPABASE_SERVICE_ROLE_KEY` değerlerini sunucu zaten kullanır. Service role anahtarı uygulama içine, GitHub'a veya kullanıcıya verilmez. “Kota hizmeti hazır değil” hatasında önce SQL'in doğru Supabase projesinde çalıştığını ve Render'ın aynı projeyi kullandığını kontrol et.

## Uygulama davranışı ve sınırlar

- Kota PostgreSQL'de saklanır. Her istek doğrulanmış hesap sahibine yazılır; tarayıcıdan gönderilen `premium`, kullanıcı ID'si, ödül veya fiyat ayarı hak arttıramaz.
- Hak ayırma tek veritabanı işlemi içinde kullanıcı satırını kilitler. Aynı hesaptan eşzamanlı istekler veya farklı sunucular 30 sınırını aşamaz.
- Provider hatasında hak geri verilir. Yanıt üretilmişse kullanıcı bağlantıyı kesse de hak tüketilmiş sayılır. Sunucu işlem ortasında çökerse veya veritabanı erişimi sırasında hak iadesi başarısız olursa bir hak tüketilmiş kalabilir; fazladan hak verilmez. Sonraki saatlik yenileme bunu sıfırlar.
- Veritabanı kota hizmeti erişilemiyorsa AI isteği açılmaz. Sayaç yalnız localStorage'da tutulmaz.
- Tamamlanan yanıtlarda kullanıcı ve AI yanıtı birlikte tek hak sayılır; koçu açmak, kota durumunu sorgulamak ve yeniden giriş yapmak hak tüketmez. Uzun yanıtın devamını isteyen yeni bir mesaj yeni hak tüketir.
- Sunucunun mevcut günlük maliyet koruması, dakika ve eşzamanlı istek sınırları ayrıca geçerlidir. Kalan kişisel hak olması bunları kaldırmaz. Günlük koruma hâlen yerel sunucu dosyasındadır; çok sunuculu/genel yayında toplam maliyet kontrolü ayrıca taşınmalıdır.
- Premium ödeme doğrulaması bu sürümde bağlanmadı. Önizleme ödülleri veya ayarlar ücretsiz kotayı kaldırmaz. Gerçek ödeme/mağaza doğrulaması gelmeden “sınırsız Premium” aktif edilmez.
- Eski pilot erişim kodu yolu geliştirici testi için korunur; kullanıcı hesap yolu kotalıdır. Genel yayında test ve pilot erişimin ayrıca kapatılması gerekir.
- Bu paket hesap için özel test sürümüdür. Yasal yayın onayları, mağaza ödeme/reklam entegrasyonu ve yerel Android/iOS OAuth cihaz testleri tamamlanmış sayılmaz. PWA/web testi mevcut çalışan akışla devam eder.
- Hesap silindiğinde AI kota ve hak ayırma satırları da silinir. En fazla mevcut kota döngüsünün 30 hak kimliği saklanır; bu tablolara sohbet metni yazılmaz.

## Kontrol

```sh
npm ci --include=dev
npm run check
npm run test:accounts
npm run test:server
npm run test:quota
npm run test:account-coach
npm run test:private-account
```

Kota SQL'i PGlite üzerinde gerçek PostgreSQL motoruyla test edilir: kurulumun tekrar çalışması, 30 sınırı, yenileme, idempotent iade, farklı kullanıcılar, anon/authenticated erişim reddi ve diske yazma/yeniden açma. HTTP entegrasyonu doğrulanmış kimlik, sahte sahip reddi, kota aşımı, provider hatasında iade ve sunucuyu yeniden açmayı test eder. Mobil tarayıcı testi geri sayım, form kilidi, yeniden açma ve cihaz saati değişimini kontrol eder. Bunlar canlı OpenAI harcaması veya canlı Supabase değişikliği yapmaz.
