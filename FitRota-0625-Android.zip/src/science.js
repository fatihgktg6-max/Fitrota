// Calculation choices are documented separately from source recommendations.
export const evidenceSources=[
 ['FoodSafety.gov · Safe cooking','https://www.foodsafety.gov/food-safety-charts/safe-minimum-internal-temperatures'],
 ['ACE · Exercise library','https://www.acefitness.org/resources/everyone/exercise-library/'],
 ['NASM · Exercise library','https://www.nasm.org/resource-center/exercise-library'],
 ['WHO · Physical activity','https://www.who.int/news-room/fact-sheets/detail/physical-activity'],
 ['ACSM · Resistance training 2026','https://acsm.org/resistance-training-guidelines-update-2026/'],
 ['Mifflin–St Jeor · Energy equation','https://pubmed.ncbi.nlm.nih.gov/2305711/'],
 ['WHO · Healthy diet','https://www.who.int/health-topics/healthy-diet'],
 ['CoFID 2021 · Food composition','https://www.gov.uk/government/publications/composition-of-foods-integrated-dataset-cofid'],
 ['NIDDK · Adult weight planning','https://www.niddk.nih.gov/health-information/weight-management/body-weight-planner']
];
export function energyEstimate(p){
 if(!p||p.age<18||p.age>78||p.health||p.nutritionRisk||!['female','male'].includes(p.sex)||!['low','light','moderate','high'].includes(p.activity))return {available:false,reason:'profile'};
 const bmi=p.weight/(p.height/100)**2;
 if(bmi<18.5||bmi>=40)return {available:false,reason:'individual'};
 const factor={low:1.2,light:1.375,moderate:1.55,high:1.725}[p.activity];
 const resting=10*p.weight+6.25*p.height-5*p.age+(p.sex==='male'?5:-161);
 const maintenance=Math.round(resting*factor);
 // Conservative product starting offsets, not a validated weight-loss prediction.
 const adjustment=p.goal==='lose'?-Math.min(300,maintenance*.1):['gain','muscle'].includes(p.goal)?Math.min(200,maintenance*.07):0;
 const kcal=Math.round((maintenance+adjustment)/10)*10;
 if(kcal<1500||kcal>4000)return {available:false,reason:'individual'};
 return {available:true,kcal,maintenance,resting:Math.round(resting),factor,adjustment:Math.round(adjustment),range:[Math.round(kcal*.9/10)*10,Math.round(kcal*1.1/10)*10]};
}
export function nutritionTarget(p){const e=energyEstimate(p);return {kcal:p?.calories|| (e.available?e.kcal:null),protein:p?.protein||null,source:p?.calories?'manual':e.available?'estimate':'none',estimate:e};}
export function balancedMealPlan(p,date,pool){
 const target=nutritionTarget(p).kcal,offset=Math.floor(Date.parse(date+'T12:00:00Z')/86400000),used=new Set();
 return ['breakfast','lunch','dinner','snack'].map((slot,i)=>{
  let list=pool.filter(f=>f.type===({lunch:'main',dinner:'main'}[slot]||slot));const fresh=list.filter(f=>!used.has(f.id));if(fresh.length)list=fresh;
  const f=list[((offset*3+i*5)%list.length+list.length)%list.length];if(!f)return {slot,foodId:null,servings:1};used.add(f.id);
  const share=[.25,.3,.3,.15][i],servings=target?Math.max(.5,Math.min(2.5,Math.round(target*share/f.kcal*4)/4)):1;
  return {slot,foodId:f.id,servings};
 });
}
export function trainingPrescription(p,{minutes=p.minutes,equipment=p.equipment,date,gentle=false}={},catalog){
 const day=new Date(date+'T12:00:00'),weekday=day.getDay(),ordered=[1,2,3,4,5,6,0].filter(d=>p.days.includes(d)),index=Math.max(0,ordered.indexOf(weekday)),seed=Math.floor(Date.parse(date+'T12:00:00Z')/604800000);
 const restricted=p.health&&!gentle;
 if(restricted)return {id:'plan-'+date,date,title:['Uzman onaylı plan gerekli','Professional plan needed'],minutes:0,warmup:0,cooldown:0,items:[],restricted:true};
 if(p.trainingStyle&&p.trainingStyle!=='auto')return selectedTraining(p,{minutes,equipment,date,gentle},catalog);
 const planned=p.days.includes(weekday),consecutive=p.days.includes((weekday+6)%7),split=ordered.length>=4;
 let mode=gentle||!planned?'recovery':split?(index===4?'conditioning':index%2?'lower':'upper'):consecutive&&index>0?'recovery':(seed+index)%2?'fullB':'fullA';
 const gym={fullA:['legpress','row','chestpress','legcurl','deadbug','calf'],fullB:['hipthrust','pulldown','chestpress','legpress','shoulderpress','birddog'],upper:['chestpress','row','pulldown','shoulderpress','curl','triceps'],lower:['legpress','hipthrust','legcurl','calf','deadbug','birddog']};
 const home={fullA:['squat','pushup','hinge','pronew','deadbug','calf'],fullB:['lunge','pushup','bridge','pronew','birddog','wallslide'],upper:['pushup','pronew','wallslide','deadbug'],lower:['squat','hinge','bridge','calf','birddog']};
 const names={fullA:['Tüm vücut A','Full body A'],fullB:['Tüm vücut B','Full body B'],upper:['Üst vücut','Upper body'],lower:['Alt vücut','Lower body'],recovery:['Toparlanma & hareketlilik','Recovery & mobility'],conditioning:['Yürüyüş & merkez','Walking & core']};
 const ids=['recovery','conditioning'].includes(mode)?['walk','mobility']:(equipment==='gym'?gym:home)[mode];
 const warmup=mode==='recovery'?0:minutes>=30?5:3,cooldown=mode==='recovery'?0:2;let used=warmup+cooldown;
 const items=[];
 for(const id of ids){const base=catalog.find(e=>e.id===id);if(!base)continue;const movement=['walk','mobility'].includes(id);const sets=movement?1:p.level==='beginner'?2:3,rest=movement?0:['deadbug','birddog','calf','wallslide','pronew'].includes(id)?60:90;
  let cost=movement?(id==='walk'?Math.max(5,minutes-5):5):Math.ceil(sets*.6+(sets-1)*rest/60+1);
  if(used+cost>minutes)continue;
  const e={...base,sets,rest,minutes:cost};if(id==='walk')e.reps=cost+' dk / min';items.push(e);used+=cost;
 }
 return {id:'plan-'+date,date,title:names[mode],minutes:used,warmup,cooldown,items,mode,planned,short:minutes<30,consecutive:planned&&consecutive,progression:['recovery','conditioning'].includes(mode)?['Rahat konuşabildiğin tempoda yürü; gerekirse süreyi azalt. Bu toparlanma gününde ağırlık artırma hedefi yok.','Walk at an easy conversational pace; shorten as needed. This recovery session has no load-increase target.']:['Son sette 2–3 tekrar daha yapabilecek kontrollü yük seç. Tüm setlerde üst tekrar sınırına iki antrenmanda rahatça ulaşırsan en küçük yük artışını dene. Ağrı veya teknik bozulmada artırma.','Choose a controlled load leaving about 2–3 repetitions in reserve. After reaching the top of the rep range comfortably in two sessions, try the smallest load increase. Do not increase through pain or poor form.']};
}
export function stopwatchElapsed(timer,now=Date.now()){return Math.max(0,(timer?.elapsed||0)+(timer?.running?Math.max(0,now-timer.startedAt):0));}

// Explicit styles are product templates, not trainer-reviewed individual prescriptions.
export function trainingStyleName(style){return ({auto:['Otomatik başlangıç','Automatic starter'],fullbody:['Full Body · Tüm vücut','Full Body'],upperlower:['Split · Üst / Alt','Split · Upper / Lower'],bodypart:['Bölgesel split','Body-part split'],ppl:['İtiş / Çekiş / Bacak','Push / Pull / Legs']})[style]||['Otomatik başlangıç','Automatic starter'];}
export function selectedTraining(p,{minutes,equipment,date,gentle},catalog){
 const dateMs=Date.parse(date+'T12:00:00Z'),dayNumber=Math.floor((dateMs-Date.parse('2026-01-05T12:00:00Z'))/86400000),weekday=new Date(date+'T12:00:00').getDay(),ordered=[1,2,3,4,5,6,0].filter(d=>p.days.includes(d));
 const index=ordered.indexOf(weekday),cycle={fullbody:['fullA','fullB'],upperlower:['upper','lower'],ppl:['push','pull','legs'],bodypart:['chest','back','legs','shoulders','arms']}[p.trainingStyle];
 const week=Math.floor(dayNumber/7),ordinal=week*ordered.length+Math.max(index,0);
 let mode=gentle||index<0?'recovery':cycle[((ordinal%cycle.length)+cycle.length)%cycle.length];
 // Full-body days placed consecutively alternate training and recovery, including Sun/Mon.
 let recoveryAdjusted=false;
 if(p.trainingStyle==='fullbody'&&mode!=='recovery'){
  let previousStrength=-Infinity;
  for(let offset=-14;offset<=0;offset++){
   const n=dayNumber+offset,wd=((n%7)+7)%7,localWeekday=wd===6?0:wd+1;
   if(!p.days.includes(localWeekday))continue;
   if(n-previousStrength>1)previousStrength=n;
   else if(offset===0){mode='recovery';recoveryAdjusted=true;}
  }
 }
 const regular=p.level==='regular',press=regular?'benchpress':'chestpress';
 const gym={fullA:['legpress',press,'row','legcurl','deadbug','calf'],fullB:['hipthrust','pulldown','dumbbell-bench','goblet-squat','lateral-raise','birddog'],upper:[press,'row','pulldown','shoulderpress','curl','triceps'],lower:['legpress','hipthrust','legcurl','calf','leg-extension','deadbug'],push:[press,'shoulderpress','incline-bench','lateral-raise','triceps','cable-fly'],pull:['pulldown','row','chest-supported-row','face-pull','curl','hammer-curl'],legs:['legpress','legcurl','hipthrust','calf','leg-extension','deadbug'],chest:[press,'incline-bench','cable-fly','triceps'],back:['pulldown','row','chest-supported-row','curl'],shoulders:['shoulderpress','lateral-raise','face-pull','deadbug'],arms:['curl','triceps','hammer-curl','overhead-triceps','deadbug']};
 const home={fullA:['squat','pushup','pronew','hinge','deadbug','calf'],fullB:['lunge','pushup','bridge','pronew','wallslide','birddog'],upper:['pushup','pronew','wallslide','deadbug'],lower:['squat','hinge','bridge','calf','birddog'],push:['pushup','wallslide','knee-pushup','deadbug'],pull:['pronew','wallslide','birddog','deadbug'],legs:['squat','hinge','bridge','calf','birddog'],chest:['pushup','knee-pushup','wallslide','deadbug'],back:['pronew','wallslide','birddog','deadbug'],shoulders:['wallslide','pronew','side-plank','deadbug'],arms:['pushup','knee-pushup','wallslide','deadbug']};
 const names={fullA:['Tüm vücut A','Full body A'],fullB:['Tüm vücut B','Full body B'],upper:['Üst vücut','Upper body'],lower:['Alt vücut','Lower body'],push:['İtiş · Göğüs / Omuz / Triceps','Push · Chest / Shoulders / Triceps'],pull:['Çekiş · Sırt / Biceps','Pull · Back / Biceps'],legs:['Bacak / Kalça / Baldır','Legs / Glutes / Calves'],chest:['Göğüs + Triceps','Chest + Triceps'],back:['Sırt + Biceps','Back + Biceps'],shoulders:['Omuz + Merkez','Shoulders + Core'],arms:['Kol + Merkez','Arms + Core'],recovery:['Dinlenme & hareketlilik','Rest & mobility']};
 let ids=mode==='recovery'?['walk','mobility']:(equipment==='gym'?gym:home)[mode];
 if(!regular&&equipment==='gym')ids=[...new Set(ids.map(id=>({'dumbbell-bench':'chestpress','incline-bench':'chestpress','goblet-squat':'legpress','cable-fly':'chestpress','chest-supported-row':'row','face-pull':'wallslide','overhead-triceps':'triceps'}[id]||id)))];
 const warmup=mode==='recovery'?0:minutes>=30?5:3,cooldown=mode==='recovery'?0:2;let used=warmup+cooldown;const items=[];
 const compound=new Set(['benchpress','dumbbell-bench','incline-bench','legpress','hipthrust','row','pulldown','shoulderpress','goblet-squat','chest-supported-row','squat','pushup','lunge','hinge']);
 for(const id of ids){const base=catalog.find(e=>e.id===id);if(!base||base.level==='advanced')continue;const movement=['walk','mobility'].includes(id),sets=movement?1:regular?3:2,rest=movement?0:compound.has(id)?regular?120:90:60;
  const cost=movement?(id==='walk'?Math.max(5,minutes-5):5):Math.ceil(sets*(base.reps.includes('taraf')?1.2:.6)+(sets-1)*rest/60+1);
  if(used+cost>minutes)continue;
  const reps=movement?(id==='walk'?cost+' dk / min':base.reps):base.reps.includes('taraf')?base.reps:compound.has(id)?(regular&&p.goal==='strength'?'6–8':'8–12'):['deadbug','birddog','wallslide'].includes(id)?base.reps:'12–15';
  items.push({...base,sets,rest,minutes:cost,reps});used+=cost;
 }
 const notes=[];
 if(recoveryAdjusted)notes.push(['Ardışık tüm vücut gününde toparlanma seçildi. Daha ayrı günler seçerek tam seansları artırabilirsin.','Recovery replaces a consecutive full-body day. Choose more separated days for full sessions.']);
 if(mode!=='recovery'&&items.length<ids.length)notes.push(['Süre sınırı nedeniyle '+(ids.length-items.length)+' hareket sığmadı. Daha kapsamlı seans için süreyi artır.','The time budget omitted '+(ids.length-items.length)+' movements. Increase session time for broader coverage.']);
 if(p.trainingStyle==='ppl'&&ordered.length<3)notes.push(['Bu gün sayısında itiş/çekiş/bacak döngüsü haftalara yayılır. Daha sık tüm vücut çalışmak için Full Body seçebilirsin.','With this schedule the push/pull/legs cycle spans weeks. Full Body can provide more frequent whole-body work.']);
 if(p.trainingStyle==='bodypart'||p.trainingStyle==='upperlower'&&ordered.length<4||p.trainingStyle==='ppl'&&ordered.length<6)notes.push(['Bu dağılım her kas grubunu haftada iki kez çalıştırmayabilir. Sıklık hedefin için Full Body veya uygun gün sayısıyla üst/alt planını değerlendir.','This split may not train every major muscle group twice weekly. Consider Full Body or upper/lower with suitable training days.']);
 if(equipment==='home'&&['ppl','bodypart'].includes(p.trainingStyle))notes.push(['Ekipmansız çekiş ve biceps yüklemesi sınırlıdır. Ev planı salon hareketlerinin eşdeğeri değildir.','Equipment-free pulling and biceps loading are limited. This home plan is not equivalent to gym exercises.']);
 return {id:'plan-'+date,date,title:names[mode],style:p.trainingStyle,mode,planned:index>=0,minutes:used,warmup,cooldown,items,notes,recoveryAdjusted,omitted:mode==='recovery'?0:ids.length-items.length,short:minutes<30,progression:['Son sette 2–3 tekrar yedek bırakabileceğin kontrollü yük seç. Üst tekrar sınırına iki seansta rahat ulaşırsan en küçük yük artışını dene; teknik bozulursa artırma.','Choose a controlled load with 2–3 reps in reserve. After reaching the upper rep range comfortably in two sessions, try the smallest load increase; do not increase through technique loss.']};
}
