// Only the hosted web app registers a worker. Native apps use packaged assets.
(() => {
  if (!('serviceWorker' in navigator) || !/^https?:$/.test(location.protocol) || window.Capacitor?.isNativePlatform()) return;
  let reloadRequested = false;
  const english = () => document.documentElement.lang === 'en';
  navigator.serviceWorker.addEventListener('controllerchange', () => { if (reloadRequested) location.reload(); });
  function offerUpdate(reg) {
    if (!reg.waiting || document.getElementById('fitrota-update')) return;
    const panel = document.createElement('aside'); panel.id = 'fitrota-update'; panel.setAttribute('role', 'status');
    panel.style.cssText = 'position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:10000;background:#163d30;color:white;padding:14px;border-radius:16px;box-shadow:0 5px 25px #0004;max-width:calc(100% - 24px);width:360px;display:flex;gap:12px;align-items:center';
    const label = document.createElement('span'); label.textContent = english() ? 'A new version is ready. Finish your current action before updating.' : 'Yeni sürüm hazır. Açık işlemini tamamlayıp güncelleyebilirsin.';
    const button = document.createElement('button'); button.className = 'btn sm'; button.textContent = english() ? 'Update' : 'Güncelle';
    button.onclick = () => { if (reg.waiting) { reloadRequested = true; reg.waiting.postMessage({type:'ACTIVATE_UPDATE'}); } else location.reload(); };
    panel.append(label,button); document.body.append(panel);
  }
  window.addEventListener('load', async () => {
    try {
      const reg = await navigator.serviceWorker.register('/sw.js', {updateViaCache:'none'});
      offerUpdate(reg);
      reg.addEventListener('updatefound', () => {
        const worker = reg.installing;
        worker?.addEventListener('statechange', () => { if (worker.state === 'installed' && navigator.serviceWorker.controller) offerUpdate(reg); });
      });
      document.addEventListener('visibilitychange', () => { if (!document.hidden) reg.update().catch(() => {}); });
    } catch { /* A failed install must never block the ordinary web app. */ }
  });
})();
