import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const hash=x=>createHash('sha256').update(x).digest('hex');
const pkg=JSON.parse(await readFile('package.json','utf8'));
const root='android/app/src/main/assets/public/';
const meta=JSON.parse(await readFile(root+'release.json','utf8'));
if(meta.version!==pkg.version)throw Error('Packaged app version differs from source');
for(const [name,digest] of Object.entries(meta.files)){if(hash(await readFile(root+name))!==digest)throw Error('Packaged asset mismatch: '+name);}
const gradle=await readFile('android/app/build.gradle','utf8');
if(!Number.isInteger(pkg.androidVersionCode)||Number(gradle.match(/\bversionCode\s+(\d+)/)?.[1])!==pkg.androidVersionCode)throw Error('Android versionCode differs from release manifest');
if(!gradle.includes('versionName "'+pkg.version+'"'))throw Error('Android versionName differs from web source');
console.log('Verified packaged FitRota '+meta.version+' ('+meta.buildId+'): native AI, localized Premium and sign-in assets.');
