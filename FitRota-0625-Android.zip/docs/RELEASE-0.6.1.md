# FitRota 0.6.1 — besin havuzu ve görünür besin değerleri

## Değişiklikler

- Tek aramada 10.745 kaynaklı besin/tarif kaydı: 2.854 CoFID genel kayıt, 7.793 USDA SR Legacy kayıt, 6 Türk üretici etiketi ve 92 tarif. Sayı, farklı kaynak ve hazırlama durumlarına ait kayıt sayısıdır; 10.745 farklı marka iddiası değildir. Kaynak kodları korunur, porsiyon çoğaltılarak sayı artırılmaz.
- Pınar Klasik/Kangal Sucuk, Dana/Hindi Sosis, Sütaş Beyaz/Süzme Peynir üretici değerleriyle çevrimdışı bulunur. "peynir beyaz" ve "suzem peynir" gibi aramalar desteklenir. Paket formülü değişebilir; güncel ambalajı kontrol et.
- Karnıyarık, imambayıldı, İzmir köfte, kuru fasulye, etli nohut, menemen, mercimek çorbası, sebzeli türlü, kıymalı patates, bulgur pilavı, pirinç pilavı ve zeytinyağlı taze fasulye: açık gramajlı, orijinal örnek tarifler. Porsiyon değerleri listelenen çiğ/haşlanmış malzemelerden hesaplanır; tüm ev yapımı yemekler için tek doğru değer değildir. Listedeki yağ ve tuz dahil, eklenen malzeme ayrıca kaydedilir.
- Günlükte ve tarifte kolesterol, sodyum, demir, lif, şeker, doymuş yağ, potasyum ve kalsiyum açılır oka gerek kalmadan görünür. Eksik veri "bilinmiyor/—" olarak korunur, sıfıra çevrilmez.
- Kalıcı "AI bağlı/bağlantı açık" durum şeridi ve başarı mesajı kaldırıldı. Koç ayarları, veri paylaşım izni, hatalar, 30 mesaj kotası ve iki saat yenilenme düzeni korunur. AI istemcisi ve sunucusu çalışmaya devam eder.
- Gram hesabı ve kaynak bağlantısı günlükte saklanır; yedek/bulut aktarımı ve yeniden açılışta korunur. Kaynaklı üretici/USDA kayıtları yanlışlıkla kullanıcı etiketi olarak ortak havuza gönderilmez.

## Kaynaklar

USDA: FoodData Central SR Legacy, Nisan 2018 tarihsel veri seti. 7.793 kaydın tamamında temel dört enerji/makro alanı vardır; eksik mikro besinler null. İngilizce özgün ad korunur; Türkçe anahtar kelimeler kısmen çevrilmiştir. Tarihsel bazı marka adları, güncel Türkiye ambalajı olarak gösterilmez. Kaynak etiketinde "USDA SR 2018" görünür. USDA FoodData Central verileri public domain/CC0 olarak sağlanır; kaynak:
https://fdc.nal.usda.gov/download-datasets
https://fdc.nal.usda.gov/api-guide/
https://fdc.nal.usda.gov/fdc-datasets/FoodData_Central_sr_legacy_food_csv_2018-04.zip

CoFID 2021 / Open Government Licence v3.0: mevcut kaynak ve atıflar korunur. Ayrıntılar CONTENT-SOURCES.md dosyasında. Çevrimdışı geniş havuz yalnız elle günlük kaydı içindir; genel kaynak ve üretici kayıtları otomatik tarifin alerjen/diyet doğrulaması yerine kullanılmaz.

Üretici sayısal etiket bilgileri 3 Ekim 2026 tarihinde kontrol edildi; altı kesin ürün URL'si content/turkish-product-labels.json dosyasında ve ürün ekranında bulunur. Üretici fotoğrafı, logosu veya pazarlama metni alınmadı. Etiket yalnız tuz bildiriyorsa sodyum mg = tuz g / 2,5 × 1000, dönüşüm ekranda belirtilir. Üreticinin bildirmediği kolesterol/demir uydurulmaz.

Üretim betikleri: scripts/build-usda-foods.py ve scripts/build-turkish-foods.py. Kaynak CSV/XLSX araştırma dosyaları ZIP'e dahil değildir; yeniden üretim için belgelenen kaynaklar indirilir. Hazır src/usda-foods.js ve src/turkish-foods.js ZIP'tedir; dağıtım bunları tekrar indirmeden derler.

## Yükleme

Yeni SQL veya yeni ortam anahtarı gerekmiyor. Önceki Supabase kurulumu korunur.

FitRota-0.6.1.zip dosyasını ZIP olarak GitHub depo köküne yükle; çıkartman gerekmez. Render Build Command:

```bash
python3 -m zipfile -e FitRota-0.6.1.zip . && npm ci --include=dev && npm run build
```

Start Command: `npm run server`.

Android versionCode 18, iOS build 18; native proje kaynakları günceldir. ZIP imzalı mağaza paketi değildir. Bu teslim, GitHub/Render hesabında otomatik yayın yapıldığı anlamına gelmez.
