# FitRota 0.3.0 — erken erişim yayın paketi

Bu paket çalışan web uygulaması ve Android/iOS proje kaynaklarıdır. İmzalı APK, AAB veya IPA değildir. Herkese açık abonelik ürünü olarak mağazaya hazır olduğu iddia edilmez.

## Tamamlanan değişiklikler

- Robot simgeli, mobil alt menünün üzerinde duran koç düğmesi.
- Gerçek OpenAI yanıtları; anahtar yalnız sunucuda, oturum belirteci yalnız bellekte.
- Kişiye göre uyku rutini formu: yatış/kalkış, gerçek uyku süresi, vardiya, gündüz enerjisi, kafein ve ayrı paylaşım onayı. Gece yarısını aşan saatleri işler; yatakta geçirilen süreden fazla uyku girişini reddeder.
- Uyku süresi ile kalitesi ayrımı; yetersiz süreyi yeterliymiş gibi sunmama yönergesi.
- Kurulabilir web uygulaması manifesti, Android ve iOS ana ekran simgeleri.
- Çevrimdışı uygulama kabuğu; AI istekleri ve yetkilendirme bilgileri önbelleğe alınmaz.
- Yeni sürüm hazır olduğunda kullanıcı onaylı güncelleme. Kaydedilmiş yerel veriler korunur. Formdaki henüz kaydedilmemiş değişiklikler için önce işlemi tamamlayın.
- Web/Android/iOS sürüm etiketleri 0.3.0; mobil yapı numarası 3.
- Eski geliştirme araçlarının bağımlılık açıkları için kilitli bağımlılıklar yenilendi.

## Render'a güncel sürümü koyma

Mevcut Render komutu **FitRota-v0.1-Kaynak-Kod.zip** dosyasını açıyor. Bu dosya adı uyumluluk için korundu; paketin içindeki sürüm **0.3.0**. İndirirken adının sonuna `-1` veya `(1)` eklenirse GitHub'a yüklemeden önce asıl ada döndürün.

1. İndirilen ZIP'i açmadan GitHub deposunun köküne yükleyin ve aynı adlı eski dosyayı değiştirin.
2. Commit tamamlanınca Render'ın otomatik dağıtımını izleyin; başlamazsa **Manual Deploy → Deploy latest commit** kullanın.
3. Build Command:

   `python3 -m zipfile -e FitRota-v0.1-Kaynak-Kod.zip . && npm ci --include=dev && npm run build`

4. Start Command: `HOST=0.0.0.0 node server/index.mjs`
5. Var olan API anahtarını ve erişim kodunu koruyun. ZIP veya GitHub içine sır koymayın.
6. `https://fitrota.onrender.com/version.json` yanıtında `"version":"0.3.0"` görünmeli. Ardından Ayarlar'da 0.3.0, koç ekranında Uyku koçu kartını kontrol edin.
7. Bu yeni PWA sisteminden önce kurulan kısayolda uygulamayı kapatıp yeniden açın. Gerekirse tarayıcıdan aynı adresi açın. **Site verilerini silmeyin**: profil ve kayıtlar yerelde tutuluyor.

Render güncellemesi cihazlar arasında profil eşitlemez. Her cihazın kaydı ayrıdır. Sonraki web güncellemeleri bağlantı varken denetlenir. Native mağaza paketleri ayrı derleme ve dağıtım gerektirir.

## Yapılandırma

`NODE_VERSION=22`, `OPENAI_API_KEY`, hesabın erişebildiği `OPENAI_MODEL`, en az 32 karakterli rastgele `FITROTA_ACCESS_CODE`, `FITROTA_ALLOWED_ORIGINS=https://fitrota.onrender.com`, `FITROTA_DAILY_CALL_LIMIT=30`.

Günlük kota tek sunucuya aittir; kullanıcı başına değildir. Kalıcı disk yoksa kota dosyası yeniden dağıtımda kaybolabilir. Bu sınır kesin fatura tavanı değildir. Herkese açık erişim kodu paylaşmayın. Ücretsiz Render uykuya geçtiğinde ilk bağlantı zaman aşımına uğrayabilir; sunucu uyandıktan sonra tekrar deneyin.

## Mağaza yayını öncesinde kalan işler

| Konu | Mevcut durum / gereken |
|---|---|
| Kullanıcı kimliği | AI bağlantısı tek sahipli pilot kodu kullanır. Çok kullanıcılı yayında kişisel kimlik doğrulama, kurtarma, kalıcı kullanıcı başına kota ve kötüye kullanım denetimi gerekir. |
| Gizlilik / destek | İşletmeci adı, iletişim adresi, gerçek gizlilik metni, veri akışları ve mağaza beyanları tamamlanmalı. Yerel veriler ve sohbetler cihazda; onaylanan AI içeriği sunucu üzerinden OpenAI'ye gider. `store:false` sıfır sağlayıcı saklama garantisi değildir. |
| Abonelik ve ödül | Satın alma kapalı. Ödül ekranı önizleme; gerçek abonelik hakkı vermez. Mağaza satın alma doğrulaması ve sunucu tarafında hak takibi uygulanmadan ücretli ürün sunulmamalı. |
| Android | Proje kaynakları var. Play geliştirici hesabı, imzalama anahtarı, imzalı AAB ve gerçek cihaz testi eksik. |
| iPhone | Proje kaynakları var. macOS/Xcode derlemesi, Apple geliştirici hesabı, imzalama, TestFlight ve cihaz testleri eksik. |
| Bildirimler | Native bildirim kodu var; cihaz testleri tamamlanmadı. Web sürümünde kapalı uygulamaya arka plan alarmı garantisi yok. |
| Sağlık içeriği | Tıbbi ürün değildir. Otomatik programlar ve AI çıktıları için ürün kapsamına uygun uzman içerik incelemesi yapılmalı. |

## Kaynak proje ile çalışma

ZIP açılmış proje kökünde `npm ci`, `npm run check`, `npm run test:server`; Chromium kurulduktan sonra `npm run test:ui`, `npm run test:coach`, `npm run test:release`.

`npm run native:sync` platform dosyalarını eşler; derleme/imzalama yaptığı anlamına gelmez. Android debug iş akışı `.github/workflows/android.yml` içindedir. GitHub yalnız ZIP tutuyorsa bu gömülü iş akışı kendiliğinden etkinleşmez; kaynak dosyalar depo köküne çıkarılmalıdır.

## Geri alma

Dağıtımdan önce Ayarlar → Yedeği indir. Başarısız dağıtımda Render'da önceki çalışan dağıtıma dönün; ardından uygulamayı yeniden açıp sürümü doğrulayın. Yedek dosyaları kişisel bilgi içerir, herkese açık depoya koymayın. Bu sürüm yerel kayıt şemasını değiştirmez.
