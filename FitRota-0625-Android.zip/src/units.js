// Storage remains metric; conversions occur only at display/input boundaries.
export const US_UNITS={lb:0.45359237,inch:2.54,oz:28.349523125,flOz:29.5735295625};
export function toUS(value,kind){return Number(value)/US_UNITS[kind];}
export function fromUS(value,kind){return Number(value)*US_UNITS[kind];}
function imperialUnits(){return state.settings.units==='imperial';}
function displayWeight(kg){return imperialUnits()?toUS(kg,'lb'):kg;}
function inputWeight(value){return imperialUnits()?fromUS(value,'lb'):Number(value);}
function displayLength(cm){return imperialUnits()?toUS(cm,'inch'):cm;}
function inputLength(value){return imperialUnits()?fromUS(value,'inch'):Number(value);}
function weightUnit(){return imperialUnits()?'lb':'kg';}
function waterText(ml){return imperialUnits()?preciseNumber(toUS(ml,'flOz'))+' US fl oz':preciseNumber(ml)+' ml';}
function portionUnit(f){return f.unit==='serving'?'serving':imperialUnits()&&f.source!=='external'?(f.unit==='ml'?'US fl oz':'oz'):f.unit;}
function displayPortion(f,value){return imperialUnits()&&f.source!=='external'&&f.unit!=='serving'?toUS(value,f.unit==='ml'?'flOz':'oz'):value;}
function inputPortion(f,value){return imperialUnits()&&f.source!=='external'&&f.unit!=='serving'?fromUS(value,f.unit==='ml'?'flOz':'oz'):Number(value);}
function bodyMeasurementFields(p={},measurement=false){
 const us=imperialUnits(),lengthName=measurement?'waist':'height',length=p[lengthName];
 const heightField=field(measurement?t('Bel çevresi · isteğe bağlı','Waist · optional')+' ('+(us?'in':'cm')+')':t('Boy','Height')+' ('+(us?'in (e.g. 70 = 5 ft 10 in)':'cm')+')',lengthName,'number',length==null||length===''?'':Number(displayLength(length).toFixed(2)),`min="${us?measurement?11.8:47.2:measurement?30:120}" max="${us?measurement?98.5:90.6:measurement?250:230}" step="0.01" ${measurement?'':'required'}`);
 const weightField=field(t('Kilo','Weight')+' ('+weightUnit()+')','weight','number',p.weight==null||p.weight===''?'':Number(displayWeight(p.weight).toFixed(2)),`min="${us?77:35}" max="${us?662:300}" step="0.01" required`);
 return measurement?weightField+heightField:heightField+weightField;
}
function ingredientAmount(grams){return imperialUnits()?preciseNumber(toUS(grams,'oz'))+' oz':preciseNumber(grams)+' g';}
function shoppingAmount(item){const unit=item.unit,value=item.amount;if(!imperialUnits())return preciseNumber(value)+' '+(unit==='adet'?'pcs':unit);if(unit==='g'||unit==='kg')return ingredientAmount(value*(unit==='kg'?1000:1));if(unit==='ml'||unit==='l')return waterText(value*(unit==='l'?1000:1));return preciseNumber(value)+' '+(unit==='adet'?'pcs':unit);}
function usMealPrep(){const days=Array.from({length:3},(_,i)=>addDays(foodDate,i));modal('Three-day meal prep',`<p class="subtitle space">Batch shopping and simple meals from your current plan. Dietary exclusions and budget preferences still apply. No meals are logged until you choose Log eaten.</p>${days.map(d=>`<section class="space"><h3>${formatDate(d,{weekday:'long',month:'short',day:'numeric'})}</h3>${mealPlan(d).map(m=>mealSuggestion(m,false)).join('')}</section>`).join('')}`,btn('Three-day shopping list','us-prep-shopping','outline'));}
