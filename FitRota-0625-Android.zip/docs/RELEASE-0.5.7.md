# FitRota 0.5.7 — İngilizce hareket adları ve anlık haftalık program

Hareket adları uygulama dili Türkçe olsa da İngilizce gösterilir: kütüphane, hareket ayrıntısı, günlük/haftalık program, alternatifler, özel program, aktif set kaydı ve geçmiş kayıtlar. Açıklamalar ve diğer arayüz metinleri seçilen dilde kalır.

Antrenman → Programı ayarla ile düzen, gün, yer, süre ve deneyim güncellenir. Haftalık program anında yeni seçimi gösterir; tamamlanmış antrenmanların gerçek hareket/set/ağırlık kayıtları değişmez. Başlamış seansın planı, işaretli setleri ve dinlenme sayacı korunur. Yeni seçim o seansı yeniden yazmaz. Haftalık programda Kayıt var etiketi eski kayda bağlantıdır; gün ayrıntısından gerçek set kayıtları açılır. Güncel haftalık şablon ile gerçek eski kayıt ayrıdır.

Bugün/gelecek için tamamlanmamış günlük program uyarlamaları yeni seçimle yeniden oluşturulur; tamamlanmış kayıtlar korunur. Mevcut haftalık/aylık ödül hedefi dönem boyunca sabit kalır. Veri sıfırlamak veya kayıt silmek gerekmez.

## Yükle

Önce Ayarlar'dan yedek al. GitHub köküne FitRota-0.5.7.zip yükle, ZIP çıkartma.
Render Build Command:

```sh
python3 -m zipfile -e FitRota-0.5.7.zip . && npm ci --include=dev && npm run build
```

Start Command: HOST=0.0.0.0 node server/index.mjs
Manual Deploy → Deploy latest commit. Live sonrası uygulamayı güncelle, Ayarlar'da 0.5.7 görünür.

0.5.6 için 2 saatlik kota SQL'i çalıştırıldıysa yeni SQL gerekmez. Çalıştırılmadıysa database/003_ai_cooldown_2h.sql doğru Supabase projesinde New query → Run yapılır. Yeni anahtar gerekmiyor. AI kotası 30 mesaj + 2 saat olarak korunur.

## Kontrol

40 birim testi; haftalık plan değişimi, tamamlanan/aktif set ve dinlenme sayacı koruma, yeniden açılma, tüm hareket adlarının Türkçe arayüzde İngilizce gösterimi ve TR/EN mobil/tablet/masaüstü düzenleri doğrulandı. Önceki uygulama akışları/96 ekran düzeni de kontrol edildi. Chromium testidir; canlı API/Supabase değişikliği, gerçek cihaz testi veya imzalı mağaza derlemesi yapılmadı. Canlı GitHub/Render'a yüklenmedi.
