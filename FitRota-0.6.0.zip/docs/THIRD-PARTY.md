# Üçüncü taraflar

Capacitor 8.0.0 ve yerel bildirim eklentisi MIT lisanslıdır. Dağıtılan tek dosyalı önizleme Capacitor core runtime içerir; lisans `CAPACITOR-LICENSE.txt` içinde korunur. npm bağımlılıklarının kendi lisansları geçerlidir; paket kilidi `package-lock.json` içindedir.

Arayüz ikonları, yemek vektör çizimleri ve tasarım bu proje için kodla oluşturuldu. Kişi fotoğrafı veya üçüncü taraf egzersiz videosu kullanılmadı. Gıdaların besin değerleri tahmini başlangıç içerikleridir.
