-- FitRota shared nutrition labels. Run once in a NEW Supabase SQL query.
-- Rerunnable; does not alter personal snapshots or AI quotas.
begin;
create table if not exists public.fitrota_foods (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid references auth.users(id) on delete set null,
 name text not null check (length(name) between 2 and 80 and name !~ '[<>]'),
 brand text not null default '' check (length(brand)<=80 and brand !~ '[<>]'),
 barcode text not null default '' check (barcode='' or barcode ~ '^([0-9]{8}|[0-9]{12,14})$'),
 unit text not null check (unit in ('g','ml','serving')),
 nutrients jsonb not null,
 status text not null default 'published' check (status in ('published','hidden')),
 created_at timestamptz not null default now()
);
create unique index if not exists fitrota_food_identity on public.fitrota_foods
 ((case when barcode<>'' then 'barcode:'||barcode else 'name:'||lower(trim(name))||':'||lower(trim(brand)) end),unit);
create table if not exists public.fitrota_food_reports (
 food_id uuid not null references public.fitrota_foods(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 reason text not null check (reason in ('values','duplicate','inappropriate')),
 created_at timestamptz not null default now(), primary key(food_id,user_id)
);
alter table public.fitrota_foods enable row level security;
alter table public.fitrota_food_reports enable row level security;
-- Tables remain inaccessible directly; only the bounded RPCs below are exposed.
revoke all on public.fitrota_foods,public.fitrota_food_reports from anon,authenticated;
create or replace function public.fitrota_search_foods(query_text text default '',page_offset integer default 0)
returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(result),'[]'::jsonb) from (
 select jsonb_build_object('id',id,'name',name,'brand',brand,'barcode',barcode,'unit',unit,'nutrients',nutrients) result
 from public.fitrota_foods
 where status='published' and (query_text='' or strpos(lower(name||' '||brand||' '||barcode),lower(left(query_text,80)))>0)
 order by created_at desc,id limit 100 offset greatest(0,least(coalesce(page_offset,0),100000))
 ) entries;
$$;
create or replace function public.fitrota_submit_food(product jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); n text:=trim(product->>'name'); b text:=trim(coalesce(product->>'brand','')); c text:=trim(coalesce(product->>'barcode','')); measure text:=product->>'unit'; k text; v numeric; data jsonb:='{}'; f public.fitrota_foods; maxval numeric;
begin
 if u is null then raise exception 'signin_required'; end if;
 -- Serialize per account to enforce rate limits under concurrent submissions.
 perform pg_advisory_xact_lock(hashtextextended(u::text,42));
 if (select count(*) from public.fitrota_foods where owner_id=u and created_at>now()-interval '1 day')>=20
 or (select count(*) from public.fitrota_foods where owner_id=u and created_at>now()-interval '1 minute')>=5 then raise exception 'food_rate_limit'; end if;
 if jsonb_typeof(product)<>'object' or jsonb_typeof(product->'name') is distinct from 'string' or product->'brand' is not null and product->'brand'<>'null'::jsonb and jsonb_typeof(product->'brand')<>'string' or product->'barcode' is not null and product->'barcode'<>'null'::jsonb and jsonb_typeof(product->'barcode')<>'string' or n is null or length(n)<2 or length(n)>80 or n ~ '[<>[:cntrl:]]' or length(b)>80 or b ~ '[<>[:cntrl:]]' or measure is null or measure not in ('g','ml','serving') or c<>'' and c !~ '^([0-9]{8}|[0-9]{12,14})$' then raise exception 'invalid_product'; end if;
 foreach k in array array['kcal','protein','carbs','fat','fiber','sugar','saturatedFat','sodium','cholesterol','potassium','calcium','iron'] loop
  if product->k is null or product->k='null'::jsonb then
   if k in ('kcal','protein','carbs','fat') then raise exception 'invalid_product'; end if;
   data:=data||jsonb_build_object(k,null); continue;
  end if;
  if jsonb_typeof(product->k)<>'number' then raise exception 'invalid_product'; end if;
  v:=(product->>k)::numeric;
  maxval:=case when k='kcal' then case when measure='serving' then 3000 else 1000 end when k in ('protein','carbs','fat') then case when measure='serving' then 300 else 100 end when k in ('fiber','sugar','saturatedFat') then 300 when k='cholesterol' then 10000 when k='iron' then 1000 else 100000 end;
  if v<0 or v>maxval then raise exception 'invalid_product'; end if;
  data:=data||jsonb_build_object(k,v);
 end loop;
 if measure='g' and (data->>'protein')::numeric+(data->>'carbs')::numeric+(data->>'fat')::numeric>101
 or (data->>'sugar')::numeric>(data->>'carbs')::numeric+.5
 or (data->>'saturatedFat')::numeric>(data->>'fat')::numeric+.5 then raise exception 'invalid_product'; end if;
 -- Do not overwrite an existing product's values when another account submits it.
 begin
  insert into public.fitrota_foods(owner_id,name,brand,barcode,unit,nutrients) values(u,n,b,c,measure,data) returning * into f;
 exception when unique_violation then
  select * into f from public.fitrota_foods where unit=measure and (case when barcode<>'' then 'barcode:'||barcode else 'name:'||lower(trim(name))||':'||lower(trim(brand)) end)=(case when c<>'' then 'barcode:'||c else 'name:'||lower(n)||':'||lower(b) end);
  return jsonb_build_object('duplicate',true,'available',f.status='published','id',f.id);
 end;
 return jsonb_build_object('duplicate',false,'available',true,'id',f.id);
end;
$$;
create or replace function public.fitrota_report_food(product_id uuid,report_reason text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid();
begin
 if u is null then raise exception 'signin_required'; end if;
 if report_reason not in ('values','duplicate','inappropriate') then raise exception 'invalid_report'; end if;
 perform pg_advisory_xact_lock(hashtextextended(product_id::text,43));
 if not exists(select 1 from public.fitrota_foods where id=product_id and status='published') then raise exception 'food_not_found'; end if;
 if (select count(*) from public.fitrota_food_reports where user_id=u and created_at>now()-interval '1 day')>=20 then raise exception 'food_rate_limit'; end if;
 insert into public.fitrota_food_reports(food_id,user_id,reason) values(product_id,u,report_reason) on conflict do nothing;
 if (select count(*) from public.fitrota_food_reports where food_id=product_id)>=3 then update public.fitrota_foods set status='hidden' where id=product_id; end if;
 return jsonb_build_object('ok',true);
end;
$$;
revoke all on function public.fitrota_search_foods(text,integer),public.fitrota_submit_food(jsonb),public.fitrota_report_food(uuid,text) from public;
grant execute on function public.fitrota_search_foods(text,integer) to anon,authenticated;
grant execute on function public.fitrota_submit_food(jsonb),public.fitrota_report_food(uuid,text) to authenticated;
commit;
