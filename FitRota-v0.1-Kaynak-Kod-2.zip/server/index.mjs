// Single-owner pilot server. Provider credentials stay on the server.
// HTTPS reverse proxy required when exposing outside loopback.
import http from 'node:http';
import {timingSafeEqual,createHash,randomBytes} from 'node:crypto';
import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import {fileURLToPath,pathToFileURL} from 'node:url';
import path from 'node:path';
import {generateCoachReply,parseCoachPayload} from './ai.mjs';
const project=fileURLToPath(new URL('../',import.meta.url));
const digest=v=>createHash('sha256').update(v).digest();
const equal=(a,b)=>timingSafeEqual(digest(a),digest(b));
export function createCoachServer({accessCode,apiKey,model,allowedOrigins=[],dailyLimit=100,ledgerFile=path.join(project,'.data/ai-usage.json'),reply=generateCoachReply,now=()=>Date.now()}={}){
 if(typeof accessCode!=='string'||accessCode.length<32||accessCode.startsWith('sk-'))throw Error('FITROTA_ACCESS_CODE must be a random 32+ character code, not a provider key.');
 if(!Number.isInteger(dailyLimit)||dailyLimit<1||dailyLimit>10000)throw Error('Invalid daily limit');
 const sessions=new Map(),attempts=new Map();let active=0,quotaQueue=Promise.resolve();const minute=[];
 async function consumeBudget(){const task=quotaQueue.then(async()=>{const day=new Date(now()).toISOString().slice(0,10);let ledger={day,used:0};try{const saved=JSON.parse(await readFile(ledgerFile,'utf8'));if(saved.day===day){if(!Number.isInteger(saved.used)||saved.used<0)throw Error('ledger_invalid');ledger=saved;}}catch(e){if(e.code!=='ENOENT')throw e;}if(ledger.used>=dailyLimit)throw Error('usage_limit');ledger.used++;await mkdir(path.dirname(ledgerFile),{recursive:true});const temp=ledgerFile+'.tmp';await writeFile(temp,JSON.stringify(ledger),{mode:0o600});await rename(temp,ledgerFile);});quotaQueue=task.catch(()=>{});return task;}
 const send=(res,code,data)=>{if(res.destroyed||res.writableEnded)return;res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});res.end(JSON.stringify(data));};
 async function body(req){if(!(req.headers['content-type']||'').startsWith('application/json'))throw Error('json_required');let bytes=0,chunks=[];for await(const chunk of req){bytes+=chunk.length;if(bytes>32000)throw Error('body_too_large');chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw Error('invalid_json');}}
 const configured=()=>!!apiKey&&!!model;
 const server=http.createServer(async(req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
  const origin=req.headers.origin;
  // Exact allowlist, no wildcard or reflected Origin. Native origins must be explicitly listed.
  if(origin&&!allowedOrigins.includes(origin))return send(res,403,{error:'origin_not_allowed'});
  if(origin){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type');res.setHeader('Access-Control-Allow-Methods','POST, DELETE, GET, OPTIONS');}
  if(req.method==='OPTIONS'){res.writeHead(204);res.end();return;}
  const assets={'/manifest.webmanifest':'application/manifest+json','/pwa.js':'text/javascript','/sw.js':'text/javascript','/icon-192.png':'image/png','/icon-512.png':'image/png','/apple-touch-icon.png':'image/png','/icon.svg':'image/svg+xml','/version.json':'application/json'};
  if(req.method==='GET'&&Object.hasOwn(assets,req.url)){
   try{const data=await readFile(path.join(project,'dist',req.url.slice(1)));res.writeHead(200,{'Content-Type':assets[req.url],'Cache-Control':'no-cache','Service-Worker-Allowed':'/'});res.end(data);}catch{send(res,404,{error:'not_found'});}return;
  }
  if((req.url==='/'||req.url==='/index.html')&&req.method==='GET'){
   try{const html=await readFile(path.join(project,'dist/index.html'),'utf8');res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end(html);}catch{send(res,503,{error:'build_required'});}return;
  }
  try{
   if(req.url==='/session'&&req.method==='POST'){
    const ip=req.socket.remoteAddress||'unknown';for(const [key,v] of attempts)if(v.until<=now())attempts.delete(key);
    if(attempts.size>1000)return send(res,429,{error:'usage_limit'});
    const a=attempts.get(ip)||{count:0,until:now()+60000};if(a.count>=10)return send(res,429,{error:'usage_limit'});a.count++;attempts.set(ip,a);
    const data=await body(req);if(typeof data.accessCode!=='string'||data.accessCode.length>200||!equal(data.accessCode,accessCode))return send(res,401,{error:'unauthorized'});
    if(!configured())return send(res,503,{error:'ai_not_configured'});
    for(const [key,s] of sessions)if(s.expiry<=now())sessions.delete(key);
    if(sessions.size>=64)return send(res,429,{error:'usage_limit'});
    const token=randomBytes(32).toString('base64url'),expiry=now()+12*60*60*1000;sessions.set(digest(token).toString('hex'),{expiry});
    return send(res,200,{configured:true,sessionToken:token,expiresAt:new Date(expiry).toISOString()});
   }
   const raw=(req.headers.authorization||'').replace(/^Bearer /,'');const hash=digest(raw).toString('hex'),session=sessions.get(hash);
   if(!session||session.expiry<=now()){sessions.delete(hash);return send(res,401,{error:'session_expired'});}
   if(req.url==='/session'&&req.method==='DELETE'){sessions.delete(hash);return send(res,200,{ok:true});}
   if(req.url==='/health'&&req.method==='GET')return send(res,200,{ok:true,configured:configured(),mode:'single-owner-pilot'});
   if(req.url!=='/coach'||req.method!=='POST')return send(res,404,{error:'not_found'});
   if(!configured())return send(res,503,{error:'ai_not_configured'});
   while(minute.length&&minute[0]<now()-60000)minute.shift();
   if(minute.length>=10||active>=2)return send(res,429,{error:'usage_limit'});
   const payload=await body(req);parseCoachPayload(payload);
   // Re-check after awaiting request body, then reserve the concurrency slot synchronously.
   if(active>=2||minute.length>=10)return send(res,429,{error:'usage_limit'});active++;minute.push(now());
   const controller=new AbortController();const disconnect=()=>{if(!res.writableEnded)controller.abort();};res.on('close',disconnect);
   try{await consumeBudget();const result=await reply(payload,{apiKey,model,signal:controller.signal});send(res,200,result);}finally{active--;res.off('close',disconnect);}
  }catch(error){const message=error.message||'';const status=message==='body_too_large'?413:message==='json_required'?415:message==='usage_limit'||message==='provider_rate_limit'?429:/invalid_|last_message/.test(message)?400:error.name==='TimeoutError'?504:502;const safe=['body_too_large','json_required','usage_limit','provider_rate_limit','invalid_json','invalid_messages','invalid_message','last_message_must_be_user','provider_error'];send(res,status,{error:error.name==='TimeoutError'?'timeout':safe.includes(message)?message:'request_failed'});}
 });
 server.requestTimeout=35000;server.headersTimeout=10000;return server;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){
 const port=Number(process.env.PORT||8787),host=process.env.HOST||'127.0.0.1';
 const origins=(process.env.FITROTA_ALLOWED_ORIGINS||`http://127.0.0.1:${port},http://localhost:${port}`).split(',').map(x=>x.trim()).filter(Boolean);
 try{const server=createCoachServer({accessCode:process.env.FITROTA_ACCESS_CODE||process.env.FITROTA_DEV_TOKEN,apiKey:process.env.OPENAI_API_KEY,model:process.env.OPENAI_MODEL,allowedOrigins:origins,dailyLimit:Number(process.env.FITROTA_DAILY_CALL_LIMIT||100),ledgerFile:process.env.FITROTA_USAGE_FILE});server.listen(port,host,()=>console.log(`FitRota pilot server listening on ${host}:${port}. Provider credentials are never printed.`));}catch(e){console.error(e.message);process.exit(1);}
}
