import {emptyState,validateBackup} from './core.js';
const STORAGE_KEY='fitrota.v1';
export let storageWarning='';
export function loadState(){try{const data=localStorage.getItem(STORAGE_KEY);return data?validateBackup(JSON.parse(data)):emptyState();}catch{storageWarning='load';return emptyState();}}
export function saveState(state){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state));return true;}catch{storageWarning='save';return false;}}
export function clearState(){localStorage.removeItem(STORAGE_KEY);}
