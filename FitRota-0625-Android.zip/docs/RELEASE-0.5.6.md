# FitRota 0.5.6 — Haftalık antrenman seçimi ve 2 saat AI bekleme

## Yeni kullanım

Antrenman → Programı ayarla: Full Body, üst/alt split, bölgesel split veya itiş/çekiş/bacak seç. Mevcut otomatik başlangıç seçeneği de korunur. Ev/salon, başlangıç/düzenli deneyim, 15–60 dakika ve 1–6 gün seçilir.

Antrenman → Haftalık program: Pazartesi–Pazar için hareketler, set, tekrar ve dinlenme görünür. Hareket adına dokununca anlatımı açılır; gün ayrıntısından not/alternatif açılır. Salon düzenli planlarına bench press, cable row, incline bench, lat pulldown, leg press ve diğer mevcut hareketler yerleştirildi. Başlangıç planlarında bazı serbest ağırlık hareketleri makine seçeneklerine döner; ileri teknik hareketler otomatik seçilmez.

Döngüler seçilmiş günlere göre haftalar arasında devam eder. Beş gün PPL seçilince hep aynı seans atlanmaz. Full Body ardışık günlerinde toparlanma ayrılır; Pazar/Pazartesi geçişi de kontrol edilir. Kısa sürede sığmayan hareket sayısı ve düşük kas sıklığı ayrıca açıklanır. Evde ekipmansız çekişin sınırı belirtilir.

Kaydetmek bugünün ve geleceğin tamamlanmamış özel planlarını yeniden oluşturur; tamamlanmış kayıtlar korunur. Aktif seans önce tamamlanmalı/iptal edilmelidir. Mevcut haftalık/aylık ödül hedefleri değişmez; yeni program günleri ödül hedefinden farklı olabilir. Sonraki dönemin hedefleri yeni günlerden oluşturulur.

## AI kotası: 30 mesaj + 2 saat

30. hak ayrılınca **2 saat** bekleme başlar. Kullanıcının son talebi esas alındı. Veritabanındaki eski 1 saatlik bekleme başlamışsa o mevcut zamanlayıcı korunur; yeni dolan kota döngüsü 2 saat olur. Migration tekrar çalıştırılabilir; hesap/kota geçmişini silmez.

1. Supabase → doğru proje → SQL Editor → New query. database/003_ai_cooldown_2h.sql içeriğinin tamamını yapıştır ve Run. Success. No rows returned beklenir. 002 daha önce çalıştırıldıysa onu yeniden çalıştırma; 003 güncel işlevi 2 saate taşır.
2. GitHub deposunun köküne FitRota-0.5.6.zip yükle; telefonda çıkartma.
3. Render Build Command:

```sh
python3 -m zipfile -e FitRota-0.5.6.zip . && npm ci --include=dev && npm run build
```

Start Command: HOST=0.0.0.0 node server/index.mjs

4. Manual Deploy → Deploy latest commit. Live olunca uygulamayı güncelle. Ayarlar'da 0.5.6 görünmeli. Mevcut anahtarlar korunur, yeni ortam değişkeni gerekmez. Önce Ayarlar'dan yedek indir, site verilerini temizleme.

## Doğrulama ve sınırlar

40 birim testi; ayrıca 5 gerçek PostgreSQL kota/HTTP testi geçti. Yeni haftalık plan ekranında seçim, altı gün, bench/row anlatımı, yeniden açılma, geçersiz gün, aktif seans koruması ve TR/EN mobil/tablet/masaüstü düzenleri doğrulandı. Koç ekranında 2 saatlik geri sayım, yeniden açılma ve sunucu saatiyle yenilenme doğrulandı. Önceki akışlar ve 96 düzen kontrolü geçti.

Kaynak çerçevesi ACSM 2026: https://acsm.org/resistance-training-guidelines-update-2026/. Gün dağılımları FitRota ürün şablonudur; bireysel eğitmen onaylı reçete veya herkes için optimum program değildir. Haftada iki kas uyarımı karşılanmayan dağılımlarda ekranda bilgi verilir. Ağır 1RM/hedef yük reçetesi oluşturulmaz. Gerçek cihaz/Safari veya imzalı mağaza derlemesi bu testte yapılmadı. Canlı OpenAI harcaması/Supabase değişikliği ve GitHub/Render'a yükleme yapılmadı.
