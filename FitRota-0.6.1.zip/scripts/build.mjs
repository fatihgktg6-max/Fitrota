import {legalConfig,legalDocuments} from '../server/legal.mjs';
import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {createHash} from 'node:crypto';
const root=fileURLToPath(new URL('../',import.meta.url));
await mkdir(path.join(root,'dist'),{recursive:true});
const modules=['food-data','expanded-foods','usda-foods','turkish-foods','supplements','catalog','science','legacy-food','core','shared-food','features','store','native','icons','ai-client','app','upgrade','services','layout','weekly-ui','food-hub'];
let script='';for(const name of modules){const source=await readFile(path.join(root,`src/${name}.js`),'utf8');script+=`\n// ${name}\n`+source.replace(/^import .*?;\s*$/gm,'').replace(/^export /gm,'');}
let bridge='';try{bridge=await readFile(path.join(root,'node_modules/@capacitor/core/dist/capacitor.js'),'utf8');}catch{}
const css=((await readFile(path.join(root,'src/style.css'),'utf8'))+'\n'+(await readFile(path.join(root,'src/layout.css'),'utf8'))).replace("@import url('');",'');
const license=await readFile(path.join(root,'docs/CAPACITOR-LICENSE.txt'),'utf8');
const favicon=await readFile(path.join(root,'public/icon.svg'),'utf8');
const draftLegal={...legalConfig({}),documents:legalDocuments(legalConfig({}))};
const html=`<!doctype html><html lang="tr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#163d30"><meta name="description" content="FitRota: günlük hayatına uyum sağlayan spor ve beslenme yardımcın."><title>FitRota</title><link rel="manifest" href="/manifest.webmanifest"><link rel="apple-touch-icon" href="/apple-touch-icon.png"><meta name="apple-mobile-web-app-capable" content="yes"><link rel="icon" href="data:image/svg+xml,${encodeURIComponent(favicon)}"><style>${css}</style></head><body><div id="app"></div><div id="modal-root"></div><div id="toast" role="status" aria-live="polite"></div><script>/* ${license} */\n${bridge}</script><script>window.FITROTA_LEGAL_FALLBACK=${JSON.stringify(draftLegal).replace(/</g,'\\u003c')};</script><script>${script.replace(/<\/script/gi,'<\\/script')}</script></body></html>`;
const webHtml=html.replace('</body>','<script src="/pwa.js"></script></body>');
await writeFile(path.join(root,'dist/index.html'),webHtml);
await writeFile(path.join(root,'index.html'),html);
for (const asset of ['manifest.webmanifest','icon-192.png','icon-512.png','apple-touch-icon.png','pwa.js']) await copyFile(path.join(root,'public',asset),path.join(root,'dist',asset));
const worker=await readFile(path.join(root,'public/sw.template.js'),'utf8');
const hash=createHash('sha256').update(webHtml+worker);
for (const asset of ['manifest.webmanifest','icon-192.png','icon-512.png','apple-touch-icon.png','pwa.js']) hash.update(await readFile(path.join(root,'public',asset)));
const buildId=hash.digest('hex').slice(0,16);
await writeFile(path.join(root,'dist/sw.js'),worker.replace('__BUILD__',buildId));
await writeFile(path.join(root,'dist/version.json'),JSON.stringify({version:'0.6.1',build:buildId}));
await writeFile(path.join(root,'FitRota-Onizleme.html'),html);
await copyFile(path.join(root,'public/icon.svg'),path.join(root,'dist/icon.svg'));
console.log(`Built offline standalone preview (${Math.round(Buffer.byteLength(html)/1024)} KB). No external resources required.`);
