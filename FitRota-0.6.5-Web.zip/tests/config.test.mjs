import {test} from 'node:test';
import assert from 'node:assert/strict';
import {checkConfig} from '../scripts/check-config.mjs';

test('empty configuration reports missing fields without exposing values', () => {
  const secret = 'private-test-value-never-print';
  const report = checkConfig({OPENAI_API_KEY: secret});
  assert.equal(report.ok, false);
  assert.equal(JSON.stringify(report).includes(secret), false);
  assert.equal(report.results.find(x => x.id === 'OPENAI_API_KEY').ok, true);
});

test('complete pilot configuration passes; mismatched origin and missing Apple revoke fail', () => {
  const env = {FITROTA_PUBLIC_ORIGIN:'https://example.test',FITROTA_ALLOWED_ORIGINS:'https://example.test',SUPABASE_URL:'https://example.supabase.co',SUPABASE_PUBLISHABLE_KEY:'public',SUPABASE_SERVICE_ROLE_KEY:'private',FITROTA_SESSION_SECRET:'s'.repeat(40),FITROTA_ACCESS_CODE:'a'.repeat(40),FITROTA_AUTH_PROVIDERS:'google',FITROTA_LEGAL_OPERATOR:'Operator',FITROTA_PRIVACY_EMAIL:'privacy@example.test',FITROTA_LEGAL_ADDRESS:'Address',FITROTA_RETENTION_NOTICE:'Retention',FITROTA_LEGAL_REVIEWED:'true',OPENAI_API_KEY:'private',OPENAI_MODEL:'configured-model',FITROTA_DAILY_CALL_LIMIT:'100',FITROTA_USAGE_FILE:'/data/usage.json'};
  assert.equal(checkConfig(env).ok, true);
  assert.equal(checkConfig({...env,FITROTA_ALLOWED_ORIGINS:'*'}).ok, false);
  assert.equal(checkConfig({...env,FITROTA_AUTH_PROVIDERS:'apple'}).ok, false);
  assert.equal(checkConfig({...env,FITROTA_SESSION_SECRET:env.FITROTA_ACCESS_CODE}).ok, false);
});

test('private config gate accepts a valid Google allowlist without pretending legal review is complete',()=>{
 const env={FITROTA_ACCOUNT_TEST_MODE:'true',FITROTA_TEST_EMAILS:'a@example.test',FITROTA_AUTH_PROVIDERS:'google'};
 const report=checkConfig(env);assert.equal(report.results.find(x=>x.id==='private-test-access').ok,true);assert.equal(report.results.some(x=>x.id==='legal-details'),false);assert.equal(JSON.stringify(report).includes('a@example.test'),false);assert.equal(checkConfig({...env,FITROTA_TEST_EMAILS:'*'}).results.find(x=>x.id==='private-test-access').ok,false);assert.equal(checkConfig({...env,FITROTA_AUTH_PROVIDERS:'apple'}).results.find(x=>x.id==='private-test-provider').ok,false);
});
