import {test} from 'node:test';import assert from 'node:assert/strict';
import {minimizeCloudPayload} from '../src/privacy.js';
import {emptyState,normalizeProfile} from '../src/core.js';
import {parseCoachPayload,generateCoachReply} from '../server/ai.mjs';
const sensitiveContext={name:'Private Name',email:'private@example.test',weight:80,goal:'maintain',diet:'vegan',allergens:['milk'],healthRestriction:true,minutes:30,plan:[{name:'Squat',sets:3,reps:'10'}],days:[{date:'2026-10-05',entries:1,kcal:2000,protein:80,waterMl:1000}],pantry:'rice'};
test('profile and progress require independent choices at the provider boundary',()=>{
 const make=context=>parseCoachPayload({messages:[{role:'user',content:'Hello'}],context}).context;
 const none=make(sensitiveContext);for(const k of ['goal','diet','allergens','healthRestriction','minutes','plan','days','pantry','name','email','weight'])assert.equal(none[k],undefined,k);
 const profile=make({...sensitiveContext,shareProfile:true});assert.equal(profile.healthRestriction,true);assert.deepEqual(profile.allergens,['milk']);assert.equal(profile.days,undefined);
 const progress=make({...sensitiveContext,shareProgress:true});assert.equal(progress.days[0].kcal,2000);assert.equal(progress.allergens,undefined);
 const both=make({...sensitiveContext,shareProfile:true,shareProgress:true});for(const k of ['name','email','weight'])assert.equal(both[k],undefined);
});
test('default cloud snapshot excludes private notes/chats and never restores sharing opt-ins',()=>{
 const s=emptyState();s.profile=normalizeProfile({name:'Private',age:30,height:180,weight:80,days:[1,3,5]});s.dayNotes={'2026-10-05':'private health note'};s.chat=[{role:'user',text:'private diagnosis',source:'openai'}];Object.assign(s.settings,{autoCloud:true,accountAiConsent:true,coachProfileConsent:true,coachContextConsent:true});
 const p=minimizeCloudPayload(s);assert.deepEqual(p.chat,[]);assert.deepEqual(p.dayNotes,{});assert.equal(p.profile.weight,80);for(const k of ['autoCloud','accountAiConsent','coachProfileConsent','coachContextConsent'])assert.equal(p.settings[k],undefined);
 const opted=minimizeCloudPayload(s,true);assert.equal(opted.chat[0].text,'private diagnosis');assert.equal(opted.dayNotes['2026-10-05'],'private health note');assert.equal(s.chat.length,1);assert.equal(s.settings.autoCloud,true);
});
test('actual OpenAI request strips unapproved context and uses no response storage or redirects',async()=>{
 let seen;await generateCoachReply({messages:[{role:'user',content:'Hello'}],context:sensitiveContext},{apiKey:'mock',model:'mock',fetchImpl:async(url,init)=>{seen=init;return {ok:true,json:async()=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text:'Hi'}]}]})};}});
 const body=JSON.parse(seen.body);assert.equal(body.store,false);assert.equal(seen.redirect,'error');assert.equal(JSON.stringify(body).includes('private@example.test'),false);assert.equal(JSON.stringify(body.input).includes('allergens'),false);
});
