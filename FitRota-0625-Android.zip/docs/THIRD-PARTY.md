# Üçüncü taraflar

Capacitor 8.0.0 ve yerel bildirim eklentisi MIT lisanslıdır. Dağıtılan tek dosyalı önizleme Capacitor core runtime içerir; lisans `CAPACITOR-LICENSE.txt` içinde korunur. npm bağımlılıklarının kendi lisansları geçerlidir; paket kilidi `package-lock.json` içindedir.

Arayüz ikonları, yemek vektör çizimleri ve tasarım bu proje için kodla oluşturuldu. Kişi fotoğrafı veya üçüncü taraf egzersiz videosu kullanılmadı. Gıdaların besin değerleri tahmini başlangıç içerikleridir.

0.6.1: USDA FoodData Central SR Legacy 2018 besin verileri public domain/CC0; https://fdc.nal.usda.gov/api-guide/. CoFID OGL v3.0 atfı CONTENT-SOURCES.md içinde korunur. Altı Türk üretici kaydı yalnız sayısal etiket bilgisi ve kaynak URL'si içerir; görsel/marka metni kopyalanmadı. Yeni Türk yemeği örneklerinin tarif metinleri bu proje için yazıldı.
