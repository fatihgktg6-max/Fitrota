// Nutrition facts transcribed from the linked primary product pages, checked 2026-10-04.
// Restaurant portions below are individual products, not menus with fries/drinks.
const restaurantRows=[
 ['tr-mcd-bigmac',"McDonald's Big Mac (Türkiye)","McDonald's",'serving',525,26.1,51.5,25.2,'https://www.mcdonalds.com.tr/mcdonalds-lezzetleri/burgerler/big-mac',{sugar:8.6,saturatedFat:8.9,fiber:6.5,sodium:1080,sodiumFromSalt:true,aliases:'mc donalds mcdonalds mac donalds hamburger burger'}],
 ['tr-mcd-doublebigmac',"McDonald's Double Big Mac (Türkiye)","McDonald's",'serving',697,41.3,53.9,37,'https://www.mcdonalds.com.tr/mcdonalds-lezzetleri/burgerler/double-big-mac',{sugar:8.6,saturatedFat:15.2,fiber:8.9,sodium:1400,sodiumFromSalt:true,aliases:'mc donalds mcdonalds hamburger burger'}],
 ['tr-bk-chickenbigking','Burger King Chicken Big King (Türkiye)','Burger King','serving',671.35,28.46,55.36,37.15,'https://www.burgerking.com.tr/besin-degerleri',{sodium:1181.84,aliases:'burgerking tavuk hamburger'}],
 ['tr-popeyes-tavukburger','Popeyes Tavukburger (Türkiye)','Popeyes','serving',453.26,19.28,39.05,23.76,'https://www.popeyes.com.tr/urunler/sandvicler-ve-salatalar/tavukburger',{sodium:1528.27,aliases:'popayes popeyes tavuk burger'}],
 ['tr-popeyes-popchicken','Popeyes Popchicken (Türkiye)','Popeyes','serving',692.5,31.2,57.6,36.3,'https://www.popeyes.com.tr/urunler/sandvicler-ve-salatalar/popchicken',{sodium:1263.8,aliases:'popayes popeyes tavuk sandviç'}],
 ['tr-pinar-hindidoner','Pınar Hindi Döner','Pınar','g',310,20,3.5,24,'https://www.pinar.com.tr/urunler/detay/Hindi-Doner/682/231/0',{aliases:'döner doner hindi kebap'}],
 ['tr-simitsarayi-simit','Simit Sarayı Simit','Simit Sarayı','g',344.5,11.5,57.4,10,'https://www.migros.com.tr/simit-sarayi-simit-400-g-p-10bcb0d',{sugar:1.2,saturatedFat:.6,sodium:520,sodiumFromSalt:true,aliases:'simit susam kahvaltı gevrek',sourceLabel:'Tedarikçi etiketi · Migros'}]
];
export const restaurantFoods=restaurantRows.map(([id,name,brand,unit,kcal,protein,carbs,fat,sourceURL,extra])=>({id,name:[name,name],brand,unit,kcal,protein,carbs,fat,sourceURL,source:'manufacturer',checkedAt:'2026-10-04',market:'TR',fiber:null,sugar:null,saturatedFat:null,cholesterol:null,sodium:null,potassium:null,calcium:null,iron:null,...extra}));
