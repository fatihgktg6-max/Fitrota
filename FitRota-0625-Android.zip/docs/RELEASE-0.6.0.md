# FitRota 0.6.0 — haftalık özel program ve birleşik besin havuzu

## Kullanıcı akışı

- Antrenman → Haftam veya Keşfet → Kendi haftalık programın. Pazartesi–Pazar her gün OFF ya da antrenman. Hareket seçimi, sıralama, 1–5 set, tekrar metni ve 0–600 saniye dinlenme; bir günü başka güne kopyalama. Tüm haftayı tek kaydetme. Programı sonradan düzenlemek kayıt silmeyi gerektirmez. Aktif seans ve tamamlanmış antrenman reçeteleri korunur. Eski tek seanslık özel programlar kaybolmaz.
- Beslenme → Besin ekle veya Keşfet → Besin havuzu. Gıdalar, içecekler, atıştırmalıklar, tarifler ve protein tozu aynı aramada. Tümü / Son yediklerim / Ürünlerim / Topluluk kısayolları. İsteğe bağlı pişirme filtresi: çiğ-kuru, haşlanmış-buharda, tavada-yağda, fırın, ızgara. Pişirme filtresi yalnız kaynakta yöntemi belirtilen genel kayıtları gösterir; marka etiketlerine yöntem uydurulmaz.
- 177 mevcut + 2.677 ek CoFID kaydı = 2.854 genel kayıt; 80 özgün tarif ayrı. Bazı mevcut varyantlar aynı kaynak kodunu kullanır. Ham basmati, haşlanmış basmati, esmer basmati, cips, çikolata, bisküvi ve hazır yemek çeşitleri var. Yeni geniş kayıtlar otomatik diyet oluşturucusuna eklenmez; alerjenleri doğrulanmış sayılmaz.
- Marka veya barkod yazıp **Markalı ürünleri internette ara** seçilebilir. Open Food Facts sorgusu anahtar gerektirmez; internet, sağlayıcı erişimi ve hız sınırlarına bağlıdır. Her marka garanti edilmez. Ambalajdaki 100 g / 100 ml birimi kullanıcı tarafından onaylanır. Temel makroları eksik veya tutarsız etiketler alınmaz. Sonuçların doğruluğu ambalajla kontrol edilir.
- **Yeni ürün**: ad, marka, barkod, 100 g / 100 ml / porsiyon, kalori ve makrolar, isteğe bağlı mikro değerler. Ürün otomatik olarak kişisel listede saklanır; kullanıcı tekrar arayabilir. Bilinmeyen mikro değerler sıfır yapılmaz. Kendi etiketini tüm kullanıcılara paylaşma ayrı ve varsayılan olarak kapalı seçimdir.
- Günlük, kaydettiğin anda hesaplanan değerleri dondurur; ortak ürünün sonradan değişmesi geçmiş kaloriyi değiştirmez. Genel kayıtların miktarı g, marka etiketi g/ml ve kişisel etiket porsiyon olabilir. Günlükte tüketilen miktar görünür. Yağda kızarmış bir kaynak kaydı zaten kaynak yağını içerir; aynı yağı tekrar ekleme. Tarifine kaynaktakinden fazladan kattığın yağ ayrıca girilir.

## Ortak havuz kurulumu

Önceki hesap ve AI SQL kurulumu yerinde kalır. Supabase **SQL Editor → New query** aç, `database/004_shared_foods.sql` içeriğini yapıştır, **Run**. Mevcut sorgunun üzerine yazmak gerekmez. `Success. No rows returned` normaldir. Bu dosya yeniden çalıştırılabilir ve AI kotasını değiştirmez. Yeni ortam anahtarı gerekmez; hesabın mevcut Supabase sunucu ayarları kullanılır.

Başka hesapla giriş yapıp paylaşılan ürünün adı veya barkodunu ara. Yalnız ürün adı/marka/barkod/birim/besin değerleri ortaktır; öğün günlüğü, e-posta ve profil paylaşılmaz. Kişisel etiketler mevcut otomatik bulut izni açıksa hesabın yedeğine dahil edilir.

RLS açık; anon/authenticated doğrudan tabloya erişemez. Sabit `search_path` olan RPC aramayı yayımlanan ürünlerle sınırlar; yazma gerçek `auth.uid()` gerektirir. Sunucu Origin ve hesap sahibi kontrolü yapar. Kullanıcı başına en fazla 5 yeni ürün/dakika ve 20/gün; aynı ürün eski değerleri ezmez. En fazla 20 rapor/gün. Üç farklı hesap bildirimi ürünü inceleme için gizler; kullanıcı etiketi doğrulanmış besin olarak sunulmaz.

Yönetici Supabase Table Editor’da `fitrota_food_reports` ve `fitrota_foods` kayıtlarını incelemeli. Hatalı/kişisel/uygunsuz içerik için `status=hidden` kullanılır. Düzeltme sonrası raporları değerlendirip temizleyerek yeniden yayınla; aksi halde sonraki rapor tekrar gizler. Hesap silinince ürünün sahiplik bağı kaldırılır; kişisel olmayan paylaşılan etiket kalır. Yayın öncesi işletmeci bu saklama ve düzeltme düzenini kendi gizlilik belgesinde kesinleştirmeli.

## Kaynak ve lisans

Genel veriler: CoFID 2021, Open Government Licence v3.0; kaynak kodu ekranda. İlk Türkçe adlandırma geniş veri setinde kısmen çevrilmiştir; özgün İngilizce adlar korunur ve aramada kullanılabilir. Markalara tahmini değer atanmaz.

Markalı sorgu: https://world.openfoodfacts.org — ODbL 1.0 (https://opendatacommons.org/licenses/odbl/1-0/). Sonuçlar geçici sunucu/oturum önbelleğindedir; Open Food Facts kataloğu bizim ortak tabloya topluca kopyalanmaz. Seçilen ürün kişisel günlükte kaynak bağlantısıyla saklanır. Başka kullanıcıların kendi ambalajlarından girdikleri etiketler ayrı ortak havuzdadır. Marka görselleri kullanılmaz. Bu sürümde sağlayıcı testi taklit yanıtlarla yapılmıştır; canlı dış servis erişimi dağıtım ortamında ayrıca doğrulanmalıdır.

Sunucu `FITROTA_FOOD_LOOKUP=false` ile marka aramasını kapatabilir. Global sorgu bütçesi 8 metin araması/dakika veya 12 barkod okuma/dakika; 5 dakika geçici önbellek. Sağlayıcı hatasında yerel besin havuzu kullanılabilir. Aramaya yalnız sorgu gönderilir; kişisel sağlık/öğün bilgisi gönderilmez.

## Yükleme

`FitRota-0.6.0.zip` dosyasını ZIP olarak GitHub depo köküne yükle. Render Build Command:

```bash
python3 -m zipfile -e FitRota-0.6.0.zip . && npm ci --include=dev && npm run build
```

Start Command: `npm run server`.

Android sürüm kodu 17, iOS build 17; kaynaklar dahildir. Paket imzalı APK/AAB/IPA veya mağaza onayı değildir. Kod bu paketle teslim edilir; GitHub/Render hesabında otomatik yayın yapılmış sayılmaz.

## Kontroller

`npm run check`, hesap API / özel hesap / otomatik AI-bulut / kota / antrenman / düzen testleri; `npm run test:weekly-food` yeni program, geri yükleme, sayısal besin doğrulaması, gerçek PostgreSQL uyumlu PGlite RPC izinleri/tekrar çalıştırma/raporlar ve iki farklı tarayıcı hesabıyla ortak kayıt akışını doğrular. Marka servisi erişimi taklit sağlayıcı yanıtlarıyla test edilir. 320/390/768/1440 genişlik, Türkçe/İngilizce, açık/koyu temada taşma kontrolleri vardır.
