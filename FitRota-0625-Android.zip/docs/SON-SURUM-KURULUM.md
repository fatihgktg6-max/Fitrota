FITROTA 0.6.16 — FIYAT + IADE POLITIKASI

GitHub deposuna FitRota-0.6.16-Pricing-Refunds.zip yukle.
Render Build Command:
python3 -m zipfile -e FitRota-0.6.16-Pricing-Refunds.zip . && python3 scripts/prepare-us-release.py && npm ci --include=dev && npm run build:us
Manual Deploy > Deploy latest commit.
SQL, anahtarlar ve Cloudflare ayarlari degismeyecek.

Live olduktan sonra kontrol edip Paddle formuna yaz:
Pricing page: https://fitrota-us-gateway.fatihgktg6.workers.dev/legal/pricing
Terms: https://fitrota-us-gateway.fatihgktg6.workers.dev/legal/terms
Privacy: https://fitrota-us-gateway.fatihgktg6.workers.dev/legal/privacy
Refund policy: https://fitrota-us-gateway.fatihgktg6.workers.dev/legal/refunds

Fiyat 2.99 USD/ay planlanan canli fiyattir. Canli katalog da bu tutarda olmalidir.
Sandbox 3 USD test urunu ve abonelikleri degistirilmedi; canli odeme acilmadi.
Fiyat ve iade bilgi sayfalari herkese aciktir. Uygulama ABD siniri korunur.
0.6.14 su kaydi duzeltmeleri dahildir. 0.6.15'i ayrica yuklemeye gerek yoktur.

Iade metni Paddle'in asagidaki kaynaklarina gore hazirlandi (6 Ekim 2026):
https://www.paddle.com/legal/refund-policy
https://www.paddle.com/legal/buyer-terms
Kosulsuz para iadesi vaadi eklenmedi. Paddle'in takdire bagli iade basvuru suresi,
iptal ile iade farki, zorunlu tuketici haklari ve destek iletisimi aciklandi.
Bu sayfalar tek basina Paddle hesap onayini veya hukuki uygunluk garantisini saglamaz.

Dogrulama: US build ve 4 fiyat/iade/ulke erisimi testi basarili.
Render yayini ve mobil gorsel kontrol bu ortamdan yapilmadi.
