import test from 'node:test';
import assert from 'node:assert/strict';
import {createCoachServer} from '../server/index.mjs';
test('web UI closes while native APIs stay available',async()=>{
 const server=createCoachServer({accessCode:'x'.repeat(32),accountService:{enabled:true,handler:async(req,res)=>{if(req.url==='/account/config'){res.end('{"nativeReady":true}');return true;}return false;}},billingService:{},allowedOrigins:['https://localhost']});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;
 try{
 for(const p of ['/','/app','/index.html','/?old=1']){const r=await fetch(base+p);assert.equal(r.status,200);assert.match(await r.text(),/browser access is closed/);}
 assert.equal((await fetch(base+'/app-0123456789abcdef.js')).status,410);
 assert.match(await(await fetch(base+'/sw.js')).text(),/registration.unregister/);
 assert.equal((await(await fetch(base+'/account/config',{headers:{Origin:'https://localhost'}})).json()).nativeReady,true);
 assert.equal((await fetch(base+'/healthz')).status,200);
 }finally{await new Promise(r=>server.close(r));}
});
