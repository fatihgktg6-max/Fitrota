# İçerik kaynakları ve hesaplama sınırları — 0.5.5

İnceleme tarihi: 3 Ekim 2026. Bu dosya FitRota’nın ürün kararlarını, kaynakların önerilerinden ayırır. Bir uzmanın bireysel değerlendirmesi veya içerik onayı yapılmış değildir.

## Antrenman

- WHO: https://www.who.int/news-room/fact-sheets/detail/physical-activity — yetişkinler için genel aerobik hareket ve kas güçlendirme çerçevesi. Uygulamanın kısa seansları tek başına haftalık aerobik hedefin tamamını karşılamaz.
- ACSM 2026: https://acsm.org/resistance-training-guidelines-update-2026/ — düzenli katılım, ana kas grupları, kişiselleştirme ve amaca göre yük/hacim. Uygulama bu makalenin birebir reçetesi değildir; ağır 1RM denemesi yaptırmaz.
- Önceki ACSM pozisyon belgesi: https://pubmed.ncbi.nlm.nih.gov/19204579/ — başlangıç tekrar aralığı ve kademeli ilerleme için tarihsel bağlam. 2026 güncellemesi daha yenidir.

Ürün kararı: seçili günlere göre A/B tüm vücut veya üst/alt vücut, ardışık başlangıç günlerinde toparlanma; 2–3 çalışma seti, kontrollü tekrarlar, ana hareketlerde 90 saniye başlangıç dinlenmesi. Süre kısaysa hareket sayısı azalır; kapsam eksikliği ekranda belirtilir. Dinlenme artırılabilir. İleri seviye güç/yarışma planı, fizyoterapi veya her kullanıcı için optimum hipertrofi programı olarak sunulmaz. Ekipmansız yüzüstü W hareketi yüklü çekişin eşdeğeri sayılmaz.

## Enerji

- Mifflin–St Jeor orijinal araştırması: https://pubmed.ncbi.nlm.nih.gov/2305711/
- NIDDK yetişkin planlama sınırları: https://www.niddk.nih.gov/health-information/weight-management/body-weight-planner

Formül: 10 × kg + 6,25 × cm − 5 × yaş + katsayı (erkek +5, kadın −161). Dinlenme enerjisi tahminidir. Kullanıcı formül katsayısını seçmezse tahmin yapılmaz; kimliği hakkında çıkarım yapılmaz.

Aktivite çarpanları 1,20 / 1,375 / 1,55 / 1,725 uygulamanın yaklaşık başlangıç kategorileridir; bunlar orijinal Mifflin çalışmasınca doğrulanmış kişisel toplam harcama ölçümü değildir. Kilo yönetimi için en çok 300 kcal / %10 azaltma; kilo/kas alma için en çok 200 kcal / %7 ekleme muhafazakâr ürün varsayımlarıdır. Kilo değişimi garantisi değildir. Gösterilen ±%10 aralığı duyarlılık örneğidir, istatistiksel güven aralığı değildir. Egzersiz kalorisi tekrar eklenmez.

Özel sağlık durumu, gebelik/emzirme, yeme bozukluğu öyküsü, 79+ yaş, BMI <18,5 veya ≥40 için otomatik hedef devre dışı. Ayrıca 1500–4000 dışındaki otomatik sonuç gösterilmez; bu sınırlar herkes için güvenli alım sınırları değildir. Kullanıcı/uzman hedefi ayrı etiketlenir. Protein için kişisel klinik reçete üretilmez; kullanıcı hedefi ve kaydedilen miktar gösterilir.

## Beslenme verileri

Kaynak: Public Health England, **McCance and Widdowson’s Composition of Foods Integrated Dataset 2021**.
https://www.gov.uk/government/publications/composition-of-foods-integrated-dataset-cofid

Dosya: https://assets.publishing.service.gov.uk/media/60538b91e90e07527df82ae4/McCance_Widdowsons_Composition_of_Foods_Integrated_Dataset_2021..xlsx

Lisans: Contains public sector information licensed under the Open Government Licence v3.0. © Crown copyright.
https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/

`src/food-data.js` içindeki 160 temel besin, CoFID satır kodlarını ve 100 g değerlerini içerir. 80 tarif bu satırların gram ağırlıklı toplamından hesaplanır; enerji CoFID enerji sütunundan alınır, makrolardan yeniden türetilmez. Katalog yazımı `scripts/build-food-catalog.py` ile tekrar üretilebilir (Python openpyxl; kaynak Excel araştırma dizinine indirilir). Pişmiş/kuru tartım, yenebilir kısım ve alerjenler belirtilir. Tarifteki bulgur kuru tartılır, çoğu diğer tahıl/bakliyat pişmiş tartılır. Süt/içecek miktarları bu sürümde gramdır.

Miktarlar genel UK gıda örneklerine dayanır; Türkiye/ABD’deki markaların veya tek bir ürünün laboratuvar analizi değildir. Tarifler özgün basit birleştirme önerileridir. Mikro besin yeterliliği veya alerjen güvenliği garanti edilmez. Paketli üründe kendi etiketini kullan. Eski (≤0.4.1) öğün kayıtlarının tahmini değerleri geçişte korunur; yeni tarif değerleri geçmişi sessizce değiştirmez.

Porsiyonlar günlük enerjinin yaklaşık %25 / %30 / %30 / %15 paylarına göre çeyrek porsiyon adımlarıyla ayarlanır; bu oranlar ürün düzeni tercihidir, bilimsel zorunluluk değildir. 0,5–2,5 porsiyon aralığı kullanılır. Hedefe %15’ten fazla fark varsa açık uyarı gösterilir. Filtre nedeniyle öğün yoksa eksik olduğu belirtilir; istenmeyen alerjen/diyet otomatik eklenmez.

WHO sağlıklı beslenme genel çerçevesi: https://www.who.int/health-topics/healthy-diet

## Etkileşim ve medya

Beslenme günlüğünde tarih + öğün grubu + ekle + toplam düzeni; FatSecret yardım sayfasındaki günlük kayıt yaklaşımından esinlenildi: https://www.fatsecret.com/fatsecret-app-help/getting-started/food-add-options

Antrenmanda program ve kayıt araçlarının ayrılması, Hevy’nin rutin/sayaç anlatımlarıyla karşılaştırıldı: https://www.hevyapp.com/features/workout-rest-timer/ ve https://www.hevyapp.com/features/gym-routines/

Logo, marka görselleri, ekran tasarımı, tarifler, özel besin veritabanı veya üçüncü taraf animasyon kopyalanmadı. Hareket animasyonları kaldırılmıştır. 60 hareket için özgün yazılı adımlar, ekipman ve alternatifler bulunur. ACE Exercise Library (https://www.acefitness.org/resources/everyone/exercise-library/) ve NASM rehberleri (https://www.nasm.org/workout-exercise-guidance) teknik kaynak olarak incelendi. İleri seviye hareketler etiketlenir ve otomatik başlangıç planına/alternatiflerine eklenmez. Yazılı anlatımlar eğitmen tarafından bireysel olarak onaylanmış değildir. Müzik önerileri Spotify/YouTube arama bağlantısıdır; müzik dosyası barındırılmaz veya lisanssız yayın yapılmaz.


## 0.5.5 veri ayrıntıları

80 özgün tarif: 20 kahvaltı, 23 öğle, 23 akşam, 14 ara öğün. Ana yemek tarifleri alternatif öğle/akşam seçimine de uygundur. 160 temel besin ve 80 tarif günlük aramada ayrı filtrelenir; otomatik öğün planı yalnız tarifleri kullanır. Temel besinler 100 g kaynak değerleriyle, günlükte 1–2000 g miktarla hesaplanır.

Enerji, protein, karbonhidrat ve yağın yanında lif, şeker, doymuş yağ, sodyum, kolesterol, potasyum, kalsiyum ve demir saklanır. Sodyum CoFID mineral tablosundan alınır; tuz ile aynı miktar değildir. mg birimleri ekranda belirtilir. Kaynakta N/boş değer bilinmiyor; Tr iz miktarı kaynak hassasiyetinde 0 kabul edilir. Tarif bileşenlerinden biri bilinmiyorsa o tarifin ilgili besin değeri bilinmiyor kalır. Günlük toplam, bilinen ara toplamı ve eksik kayıt uyarısını gösterir; eksik mikro değerler sıfır diye sunulmaz. Kişisel sodyum/kolesterol tedavi hedefi üretilmez.

Her yeni günlük kaydında seçilen besinin değerleri dondurulur. Eski kayıtlarda bulunmayan mikro değerler sonradan uydurulmaz. Özel besin formunda mikro değerler isteğe bağlıdır. CoFID genel gıda örnekleri marka etiketlerinin yerine geçmez.

Tariflerde pişmiş/kuru tartım ve yenebilir kısım ayrı yazılır. Ek tuz/yağ ayrıca kaydedilmelidir. Güvenli minimum iç sıcaklık kaynağı: https://www.foodsafety.gov/food-safety-charts/safe-minimum-internal-temperatures. Tavuk/hindi 74°C, balık 63°C, kıyma 71°C, bütün kırmızı et 63°C ve 3 dakika dinlendirme. Ölçüm merkezde gıda termometresiyle yapılır.
