// Persistent, atomic PostgreSQL reservations. Identity comes from verified account sessions.
export function createQuotaService({env=process.env,fetcher=fetch}={}){
 const base=(env.SUPABASE_URL||'').replace(/\/$/,''),key=env.SUPABASE_SERVICE_ROLE_KEY;
 async function call(owner,action,requestId=null){
  try{
   const u=new URL(base);if(u.protocol!=='https:'||u.pathname!=='/'||u.search||u.hash||u.username||u.password||!key)throw Error();
   const res=await fetcher(base+'/rest/v1/rpc/fitrota_ai_quota',{method:'POST',headers:{apikey:key,Authorization:`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({p_user_id:owner,p_action:action,p_request_id:requestId}),signal:AbortSignal.timeout(10000)});
   if(!res.ok)throw Error();const data=await res.json(),q=data?.quota;
   if(typeof data.allowed!=='boolean'||!q||q.limit!==30||!Number.isInteger(q.used)||q.used<0||q.used>30||q.remaining!==30-q.used||q.blocked!==(q.used===30)||!Number.isFinite(Date.parse(q.serverNow))||(q.blocked?!Number.isFinite(Date.parse(q.resetAt)):q.resetAt!==null))throw Error();
   return data;
  }catch{throw Error('quota_unavailable');}
 }
 return {status:owner=>call(owner,'status'),reserve:(owner,id)=>call(owner,'reserve',id),refund:(owner,id)=>call(owner,'refund',id)};
}
