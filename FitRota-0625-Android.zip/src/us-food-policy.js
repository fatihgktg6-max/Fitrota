// Product choice for the US release, not a claim about the origin of rice or cuisines.
// Historical diary records are retained; this controls discovery and new plans.
export function isUSFoodVisible(food){
 if(!food||food.market==='TR'||['local','turkish'].includes(food.source)||/^tr-/.test(food.id||''))return false;
 const name=Array.isArray(food.name)?food.name[1]:food.name||'';
 const ingredients=(food.ingredients||[]).map(i=>Array.isArray(i)?i[1]:'').join(' ');
 const text=(name+' '+ingredients).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/ı/g,'i');
 if(/\b(basmati|sucuk\w*|sujuk\w*|soudjouk\w*|menemen|lahmacun|borek|burek|dolma\w*|sarma|manti|ayran|baklava|kofte|kebab\w*|kebap\w*|doner|bulgur|pilaf|pilav|turkish)\b/.test(text))return false;
 if(food.source==='recipe'||food.type&&food.type!=='ingredient')return /^us-recipe-/.test(food.id||'');
 return true;
}
