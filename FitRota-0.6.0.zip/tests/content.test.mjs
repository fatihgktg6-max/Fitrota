import {test} from 'node:test';import assert from 'node:assert/strict';
import {exercises,foods,recipeFoods,labels} from '../src/catalog.js';
import {nutrientIngredients as ingredients,basicFoods} from '../src/food-data.js';
import {emptyState,normalizeProfile,allowedFoods,allowedDiaryFoods,foodTotals,nutritionSnapshot,validateBackup} from '../src/core.js';
import {alternativesFor} from '../src/features.js';
const p=extra=>normalizeProfile({name:'Test',age:30,height:180,weight:80,days:[1,3,5],budget:3,...extra});
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);
test('60 distinct exercise guides and 80 distinct recipes; category counts and techniques are complete',()=>{
 assert.equal(exercises.length,60);assert.equal(new Set(exercises.map(e=>e.id)).size,60);
 for(const e of exercises){assert.ok(exercises.some(other=>other.id===e.alt),e.id);assert.ok(e.tips.every(t=>t.length>20));if(e.level){assert.equal(e.gear.length,2);assert.ok(e.tips.every(t=>t.split(/(?<=\.)\s+/).length>=4),e.id);}}
 assert.ok(exercises.filter(e=>e.level==='advanced').length>=3);assert.equal(recipeFoods.length,80);assert.equal(new Set(foods.map(f=>f.id)).size,257);
 assert.deepEqual(Object.fromEntries(Object.keys(labels.slots).map(slot=>[slot,recipeFoods.filter(f=>f.mealSlot===slot).length])),{breakfast:20,lunch:23,dinner:23,snack:14});
 for(const r of recipeFoods){assert.ok(r.methodSteps.length>=5,r.id);assert.ok(r.methodSteps.every(step=>step.length===2&&step.every(s=>s.length>20)));assert.equal(r.ingredients.length,r.sourceCodes.length);assert.ok(r.allergens.every(a=>labels.allergens[a]));}
 const options=alternativesFor({items:[exercises.find(e=>e.id==='legpress')]},0,'gym');assert.equal(options.some(e=>e.level==='advanced'),false);
});
test('177 basic foods include dry/cooked distinctions, known sodium/cholesterol, allergy and vegan filtering',()=>{
 assert.equal(basicFoods.length,177);assert.equal(new Set(basicFoods.map(f=>f.code)).size,175);
 assert.equal(ingredients.egg.sodium,150);assert.equal(ingredients.egg.cholesterol,360);assert.equal(ingredients.salt.sodium,39300);assert.equal(ingredients.bread.sodium,400);
 assert.equal(ingredients['rice-dry'].kcal,355);assert.equal(ingredients.rice.kcal,131);
 assert.ok(allowedFoods(p()).every(f=>f.type!=='ingredient'));assert.equal(allowedDiaryFoods(p()).length,257);
 const vegan=allowedDiaryFoods(p({diet:'vegan'}));assert.equal(vegan.some(f=>f.id==='basic-mayo'),false);assert.ok(vegan.every(f=>!f.allergens.includes('egg')&&!f.allergens.includes('milk')));
 for(const allergen of ['mustard','celery','sesame','shellfish'])assert.ok(allowedDiaryFoods(p({allergens:[allergen]})).every(f=>!f.allergens.includes(allergen)));
});
test('grams and servings sum nutrients correctly; missing label data stays unknown instead of zero',()=>{
 const sum=foodTotals([{foodId:'basic-egg',servings:1.5},{foodId:'basic-salt',servings:.02}]);close(sum.sodium,1011);close(sum.cholesterol,540);close(sum.kcal,214.5);assert.equal(sum.missing.sodium,0);
 const partial=foodTotals([{foodId:'basic-egg',servings:1},{foodId:'custom',servings:1,custom:{name:'Label',kcal:100,protein:5,carbs:10,fat:3}}]);assert.equal(partial.sodium,150);assert.equal(partial.missing.sodium,1);assert.equal(partial.entries,2);
 const unknown=foodTotals([{foodId:'custom',servings:2,custom:{name:'Label',kcal:100,protein:5,carbs:10,fat:3}}]);assert.equal(unknown.missing.cholesterol,1);
 const zero=foodTotals([{foodId:'basic-salt',servings:.01}]);assert.equal(zero.cholesterol,0);assert.equal(zero.missing.cholesterol,0);
});
test('new grams, label nutrients and snapshots survive backup; forged nutrient values are rejected; older labels preserved',()=>{
 const s=emptyState();s.profile=p();const f=foods.find(f=>f.id==='basic-salt');s.meals['2026-10-03']=[{id:'salt',foodId:f.id,slot:'lunch',servings:.01,nutrition:nutritionSnapshot(f)},{id:'custom',foodId:'custom',slot:'snack',servings:1,custom:{name:'Label',kcal:100,protein:5,carbs:10,fat:3,sodium:80,cholesterol:null}}];
 const restored=validateBackup(s);assert.equal(foodTotals(restored.meals['2026-10-03']).sodium,473);assert.equal(restored.meals['2026-10-03'][1].custom.cholesterol,null);
 const changed=structuredClone(s);changed.meals['2026-10-03'][0].nutrition.sodium=-1;assert.throws(()=>validateBackup(changed));changed.meals['2026-10-03'][0].nutrition.sodium=Infinity;assert.throws(()=>validateBackup(changed));
 const old=structuredClone(s);delete old.meals['2026-10-03'][1].custom.sodium;assert.equal(validateBackup(old).meals['2026-10-03'][1].custom.sodium,null);
 s.meals['2026-10-03'][0].servings=20;assert.doesNotThrow(()=>validateBackup(s));s.meals['2026-10-03'][0].servings=20.01;assert.throws(()=>validateBackup(s));
});
