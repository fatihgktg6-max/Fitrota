// Native-only controller. No health, meal, workout or profile data reaches AdMob.
export class NativeAds {
  constructor({plugin, platform, config, onHeight = () => {}}) {
    Object.assign(this, {plugin, platform, config, onHeight});
    this.state = {}; this.owner = null; this.visible = false;
    this.initialized = false; this.consent = null; this.attempted = false;
    this.tail = Promise.resolve(); this.error = null;
  }
  get available() { return this.platform() === 'android'; }
  get eligible() {
    const s = this.state;
    return this.available && this.config.enabled && !!s.owner && s.verified === true &&
      s.premium === false && s.optOut === false && s.foreground === true;
  }
  enqueue(fn) {
    const task = this.tail.then(fn).catch(error => { this.error = error.message; this.onHeight(0); });
    this.tail = task; return task;
  }
  update(state) {
    this.state = {...state};
    if (!this.eligible) this.onHeight(0);
    return this.enqueue(() => this.reconcile());
  }
  async remove() {
    if (this.visible) await this.plugin.removeBanner();
    this.visible = false; this.owner = null; this.onHeight(0);
  }
  async reconcile() {
    if (!this.eligible) { await this.remove(); return; }
    if (this.visible && this.owner !== this.state.owner) await this.remove();
    if (this.visible || this.error) return;
    const owner = this.state.owner;
    if (!this.attempted) {
      this.attempted = true;
      this.consent = await this.plugin.requestConsentInfo();
      if (this.consent.status === 'REQUIRED' && this.consent.isConsentFormAvailable)
        this.consent = await this.plugin.showConsentForm();
    }
    if (!this.eligible || owner !== this.state.owner || !this.consent?.canRequestAds) return;
    if (!this.initialized) { await this.plugin.initialize(); this.initialized = true; }
    if (!this.eligible || owner !== this.state.owner) return;
    // Mark before await so a failed or interrupted request is removed as well.
    this.visible = true; this.owner = owner;
    try {
      await this.plugin.showBanner({
        adId: this.config.testMode ? 'ca-app-pub-3940256099942544/6300978111' : this.config.androidBannerId,
        adSize: 'ADAPTIVE_BANNER', position: 'BOTTOM_CENTER', margin: 0,
        isTesting: this.config.testMode, npa: true,
      });
      if (!this.eligible || owner !== this.state.owner) await this.remove();
    } catch (error) { await this.remove(); throw error; }
  }
  privacyOptions() {
    return this.enqueue(async () => {
      await this.remove();
      this.error = null;
      this.consent = await this.plugin.requestConsentInfo();
      this.attempted = true;
      if (this.consent.privacyOptionsRequirementStatus === 'REQUIRED')
        this.consent = await this.plugin.showPrivacyOptionsForm();
      await this.reconcile();
    });
  }
  sizeChanged({height}) { this.onHeight(this.visible && this.eligible ? Math.max(0, Number(height) || 0) : 0); }
}
