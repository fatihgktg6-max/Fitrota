// HTTP integration fixture; database semantics are exercised separately against PostgreSQL.
export function mockQuotaService({now=()=>Date.now()}={}){
 const users=new Map();
 function get(owner){let s=users.get(owner);if(!s||s.resetAt&&s.resetAt<=now()){s={requests:new Set(),resetAt:null};users.set(owner,s);}return s;}
 function result(s,allowed=true){const used=s.requests.size;return {allowed,quota:{limit:30,used,remaining:30-used,blocked:used===30,resetAt:s.resetAt?new Date(s.resetAt).toISOString():null,serverNow:new Date(now()).toISOString()}};}
 return {status:async owner=>result(get(owner)),reserve:async(owner,id)=>{const s=get(owner);if(s.requests.has(id))return result(s);if(s.requests.size>=30)return result(s,false);s.requests.add(id);if(s.requests.size===30)s.resetAt=now()+7200000;return result(s);},refund:async(owner,id)=>{const s=get(owner);s.requests.delete(id);if(s.requests.size<30)s.resetAt=null;return result(s);}};
}
