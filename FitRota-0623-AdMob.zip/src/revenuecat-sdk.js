import './admob-sdk.js';
import {Capacitor} from '@capacitor/core';
import {Purchases} from '@revenuecat/purchases-capacitor';
import {RevenueCatUI} from '@revenuecat/purchases-capacitor-ui';
import {NativeBilling, billingError} from './revenuecat-client.js';
import {revenueCatConfig} from './revenuecat-config.js';
window.FitrotaBilling = new NativeBilling({
  purchases: Purchases, ui: RevenueCatUI, config: revenueCatConfig,
  platform: () => Capacitor.getPlatform(),
  onChange: () => window.dispatchEvent(new Event('fitrota-billing-update')),
});
window.fitrotaBillingError = billingError;
