const CACHE = 'fitrota-shell-f7207b998c32ce0b';
const SHELL = ['/','/manifest.webmanifest','/icon-192.png','/icon-512.png','/apple-touch-icon.png','/pwa.js'];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL))));
self.addEventListener('activate', event => event.waitUntil((async () => {
  for (const key of await caches.keys()) if (key.startsWith('fitrota-shell-') && key !== CACHE) await caches.delete(key);
  await self.clients.claim();
})()));
self.addEventListener('message', event => { if (event.data?.type === 'ACTIVATE_UPDATE') self.skipWaiting(); });
self.addEventListener('fetch', event => {
  const request = event.request, url = new URL(request.url);
  // No API calls, credentials, third-party requests or personal data enter this cache.
  if (request.method !== 'GET' || url.origin !== self.location.origin || request.headers.has('Authorization')) return;
  const key = url.pathname === '/index.html' ? '/' : url.pathname;
  if (!SHELL.includes(key) || url.search) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const cached = await cache.match(key);
    return cached || fetch(request);
  })());
});
