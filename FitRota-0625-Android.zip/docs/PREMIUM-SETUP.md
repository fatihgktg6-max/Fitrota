# FitRota 0.6.2 — hesaplar ve Premium kurulumu

Bu paket web/PWA içindir. Google, Apple ve gerçek ödeme sağlayıcısı hesaplarını oluşturmaz. Gerçek satın alma, OAuth ve iade akışları kendi hesaplarında ayrıca test edilmelidir. Mobil kaynaklar bulunur; imzalı Google Play/AAB veya App Store paketi değildir. Native OAuth ve uygulama içi ödeme bu sürümde bilinçli olarak kapalıdır.

## 1. Herkes kendi Google hesabıyla girsin

Render → Fitrota → Environment: `FITROTA_ACCOUNT_TEST_MODE=false`. Eski `FITROTA_TEST_EMAILS` değeri kamuya açık modda kullanılmaz; kaldırabilirsin. `FITROTA_AUTH_PROVIDERS=google`.

Gerçek işletmeci adı, adres, gizlilik iletişim adresi, saklama açıklaması ve güncellenmiş belgelerin incelemesi tamamlanmış olmalı. `FITROTA_LEGAL_REVIEWED=true` yalnız bu gerçekten tamamlandıysa yazılır. Bu paket hiçbir gerçek hukuk incelemesini tamamlanmış saymaz. Eksik yapılandırma kamuya açık girişi kapalı tutar.

Google Cloud → doğru Fitrota projesi → Google Auth Platform → Audience: External; genel yayın için Publish app / In production. Basic openid/email/profile akışının Google Testing istisnaları vardır; uygulamanın kendi özel test kısıtlaması ise yukarıdaki Render ayarıyla kalkar. Supabase → Authentication → Sign In / Providers → Google: Enabled, doğru Client ID ve Secret, Save. Google callback adresini Supabase ekranından aynen kopyala; uygulama adresi `https://fitrota.onrender.com`. Supabase URL Configuration → Site URL ve izin verilen redirect adreslerini bu adrese ayarla. FitRota girişte hesap seçme ekranını ister; geliştiricinin Gmail hesabı kullanıcı hesabı yerine kullanılmaz.

## 2. Apple ile giriş

Aktif Apple Developer hesabı ve Sign in with Apple yapılandırması gerekir. Apple hesabı/ücretli üyeliği bu ZIP tarafından oluşturulmaz.

1. Apple Developer → Certificates, Identifiers & Profiles: Sign in with Apple etkin App ID, ona bağlı web Services ID oluştur.
2. Web domain ve dönüş adresi için Supabase Apple sağlayıcısının gösterdiği domain/callback bilgisini kullan. Services ID web Client ID’dir.
3. Sign in with Apple anahtarı (.p8), Team ID ve Key ID ile client-secret JWT oluştur. Yardımcı betik: `APPLE_TEAM_ID=... APPLE_KEY_ID=... APPLE_CLIENT_ID=... APPLE_P8_PATH=/gizli/anahtar.p8 node scripts/apple-secret.mjs`. Çıktı `server/.apple-client-secret` dosyasındadır; terminale anahtarı yazdırmaz. Bu dosyayı veya .p8 dosyasını GitHub’a yükleme.
4. Supabase Apple sağlayıcısına Services ID ve oluşturulan client secret ekle; etkinleştirip kaydet.
5. Render’a `APPLE_CLIENT_ID`, `APPLE_CLIENT_SECRET` ve `FITROTA_AUTH_PROVIDERS=google,apple` ekle. Kimlik bilgileri hesap silme sırasında Apple token iptali için de gereklidir.
6. Yardımcı betik 150 gün geçerli secret üretir. Apple web secret en fazla 6 ay geçerlidir; bitmeden Supabase ve Render’da yenile.

Kimlik bilgisi eksikken Apple düğmesi kullanıma açılmaz. Gerçek iPhone/Safari girişi, hesap seçimi, callback ve Apple hesabı silme/izin iptali ayrıca test edilmelidir.

## 3. Yeni ödül SQL’i

Önceki hesap SQL’leri kurulmuş Supabase projesinde SQL Editor → New → `database/005_premium_rewards.sql` içeriğini yapıştır → Run. Var olan sorgunun üzerine yazmak gerekmez. SQL güvenli şekilde tekrar çalıştırılabilir. Önceki 001–004 dosyalarını değiştirme. 003 dosyası ücretsiz AI için iki saat beklemeyi korur.

Görev katılımı isteğe bağlıdır. Dönem katılma gününden başlayan iki takvim ayıdır; 60 gün sabiti değildir. Saat dilimi ve 1–6 antrenman günü ilk katılımda sabitlenir. Her gün en az bir öğün ve su kaydı, planlı günlerde tamamlanmış antrenman gerekir. Bunlar kullanıcı beyanıdır; gerçek fiziksel etkinlik doğrulanmaz. Aynı gün sunucuya ulaşan tamamlanma işaretleri sayılır; geçmiş günleri yedek içe aktarımıyla topluca doldurmak ödül vermez. Tüm görevler tamamlandıysa dönem sonunda bir takvim ayı Premium verilir; yeni dönemin sayaçları sıfırlanır. Hesapta tek ödül verilmesi SQL’de korunur. Geciken/offline günler geçmişe dönük eklenmez. Hediye, ücretli aboneliği başlatmaz veya mevcut aboneliğin yenilemesini iptal etmez.

## 4. Gerçek ödeme ve fiyatlandırma

Hedef aylık fiyatlar: Türkiye 49,99 TRY, ABD 2,99 USD, avro bölgesi 2,99 EUR. Arayüz bunları hedef fiyat olarak gösterir; gerçek yerel fiyat, vergi, para birimi ve yenileme şartları ödeme sağlayıcısında ayarlanıp satın alma öncesi gösterilir. Kullanıcının uygulama dili veya elle değiştirdiği bölge ücretli erişim oluşturmaz. Türkiye’de kuruluş/bireysel satıcı kabulünü seçtiğin ödeme sağlayıcısından doğrula; Stripe hesabı açılabileceğini varsayma. Web ve mağaza ödeme yollarının ülke uygunluğu ayrı ayrı kontrol edilir.

Bu sürüm, RevenueCat API v1 abonelik doğrulaması ve web Purchase Link akışına hazırlanmıştır. Önce hesabında uygun ve onaylanmış ödeme altyapısını kur, ürünü ve yerel fiyatları oluştur. RevenueCat entitlement: `premium`; ürün: `fitrota_premium_monthly`; monthly package: `$rc_monthly`. Birden fazla gerçek ürün ID’si varsa allowlist’e virgülle ekle.

Render Environment:

```dotenv
FITROTA_BILLING_ENABLED=true
REVENUECAT_SECRET_KEY=SUNUCUDA_KALAN_REVENUECAT_SECRET_API_KEY
REVENUECAT_ENTITLEMENT=premium
FITROTA_PREMIUM_PRODUCTS=fitrota_premium_monthly
REVENUECAT_MONTHLY_PACKAGE=$rc_monthly
FITROTA_WEB_PURCHASE_LINK=https://pay.rev.cat/GERCEK_CANLI_LINK_TOKEN
```

Bunlar örnektir; sahte değerleri ortamına koyma. `SUPABASE_URL` ve `SUPABASE_SERVICE_ROLE_KEY` önceki sunucu kurulumundan gereklidir. Satın alma açmak için kamuya açık hesap modu ve tamamlanmış legal yapılandırma da gerekir. Yalnız doğrulanmış, süresi dolmamış, iade edilmemiş **canlı** abonelik veya SQL’in verdiği görev hediyesi Premium açar. Sandbox abonelik üretimde Premium vermez. Purchase Link’in canlı ortam bağlantısı olduğunu RevenueCat panelinden doğrula; kod token metninden bunu saptayamaz.

Ödeme linkine doğrulanmış hesabın ID’si sunucuda eklenir. Kart verisi FitRota’ya gelmez. Ödeme sonrası uygulamaya dönüp Premium → Üyeliğimi kontrol et seçilir. Provider API her AI isteğinde tekrar doğrulanır. İptal, süre sonu ve iade doğrulamalarını gerçek ödeme sağlayıcısıyla test et. RevenueCat’ın döndürdüğü desteklenen yönetim bağlantısı Premium ekranında gösterilir; sağlayıcının URL’si desteklenmiyorsa docs ve destek yolunu yapılandırmadan ücretli yayına çıkma.

Ödeme anahtarları eksikse satın alma kapalı kalır; bu paket kendi başına ödeme almaz. Premium görev hizmeti de billing etkinleştirilene kadar kapalıdır.

## 5. Premium davranışı

Ana ekranın üstünde `✦ Premium`. Ücretsiz kullanıcı `Premium’a geç` görür. Ücretsiz AI 30 mesajdan sonra iki saat bekler. Premium’da bu kota/bekleme ve ücretsiz sunucu günlük mesaj bütçesi uygulanmaz; kısa hız, eşzamanlılık ve güvenlik sınırları korunur. Abonelik doğrulaması yapılamazsa ücretli yetki verilmez; doğrulanmış aktif görev hediyesi sağlayıcı geçici kesintisinde kullanılabilir.

Koç → Uyku & koç tercihleri → Tatlı sert · Premium: isteğe bağlı, hafif esprili/takılan koç; kişi görünüşü, kilosu, sağlığı veya kimliği üzerinden aşağılanmaz. İstediğinde Destekleyici moda geçilir. Ücretsiz hesabın veya içe aktarılan yedeğin Premium bayrağı bu modu açamaz.

Reklam SDK’sı bu sürümde bağlı değildir; ücretsiz sürümde de henüz reklam yoktur. Premium `adFree` yetkisi ve reklam gösterim kontrolü hazırdır. Sonraki reklam entegrasyonu `canShowAds()` kontrolüne uymalı; abonelik doğrulaması bilinmiyorken reklam göstermemeli.

## Resmî kaynaklar

- Google Audience: https://support.google.com/cloud/answer/15549945
- Supabase Apple: https://supabase.com/docs/guides/auth/social-login/auth-apple
- RevenueCat API v1: https://www.revenuecat.com/docs/api-v1
- Web purchase links: https://www.revenuecat.com/docs/web/web-billing/web-purchase-links

## Yükleme

GitHub depo köküne ZIP’i çıkarmadan `FitRota-0.6.2.zip` adıyla yükle. Render Build Command:

```bash
python3 -m zipfile -e FitRota-0.6.2.zip . && npm ci --include=dev && npm run build
```

Start Command: `npm run server`.
