-- Separate production records: sandbox data is never promoted.
begin;
create table if not exists public.fitrota_paddle_live_checkouts (
 transaction_id text primary key check(transaction_id ~ '^txn_[a-z0-9]{26}$'),
 user_id uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table if not exists public.fitrota_paddle_live_subscriptions (
 subscription_id text primary key check(subscription_id ~ '^sub_[a-z0-9]{26}$'),
 user_id uuid not null references auth.users(id) on delete cascade,
 transaction_id text not null check(transaction_id ~ '^txn_[a-z0-9]{26}$'),
 occurred_at timestamptz not null
);
create index if not exists fitrota_paddle_live_subscription_owner on public.fitrota_paddle_live_subscriptions(user_id);
create table if not exists public.fitrota_paddle_live_refunds (
 transaction_id text primary key check(transaction_id ~ '^txn_[a-z0-9]{26}$'),
 created_at timestamptz not null default now()
);
create table if not exists public.fitrota_paddle_live_checkout_limits (
 user_id uuid primary key references auth.users(id) on delete cascade,
 claimed_at timestamptz not null
);
alter table public.fitrota_paddle_live_checkouts enable row level security;
alter table public.fitrota_paddle_live_subscriptions enable row level security;
alter table public.fitrota_paddle_live_refunds enable row level security;
alter table public.fitrota_paddle_live_checkout_limits enable row level security;
revoke all on public.fitrota_paddle_live_checkouts,public.fitrota_paddle_live_subscriptions,public.fitrota_paddle_live_refunds,public.fitrota_paddle_live_checkout_limits from public,anon,authenticated;
grant select,insert,update,delete on public.fitrota_paddle_live_checkouts,public.fitrota_paddle_live_subscriptions,public.fitrota_paddle_live_refunds,public.fitrota_paddle_live_checkout_limits to service_role;
create or replace function public.fitrota_paddle_live_claim_checkout(p_user_id uuid)
returns boolean language plpgsql security invoker set search_path='' as $$
declare changed integer;
begin
 insert into public.fitrota_paddle_live_checkout_limits(user_id,claimed_at) values(p_user_id,clock_timestamp())
 on conflict(user_id) do update set claimed_at=excluded.claimed_at
 where public.fitrota_paddle_live_checkout_limits.claimed_at < clock_timestamp()-interval '60 seconds';
 get diagnostics changed=row_count;
 return changed=1;
end $$;
create or replace function public.fitrota_paddle_live_record_payment(p_user_id uuid,p_subscription_id text,p_transaction_id text,p_occurred_at timestamptz)
returns void language plpgsql security invoker set search_path='' as $$
begin
 -- Transactional monotonic update makes duplicate and out-of-order deliveries safe.
 insert into public.fitrota_paddle_live_subscriptions(subscription_id,user_id,transaction_id,occurred_at)
 values(p_subscription_id,p_user_id,p_transaction_id,p_occurred_at)
 on conflict(subscription_id) do update set transaction_id=excluded.transaction_id,occurred_at=excluded.occurred_at
 where public.fitrota_paddle_live_subscriptions.user_id=excluded.user_id
 and public.fitrota_paddle_live_subscriptions.occurred_at<excluded.occurred_at;
end $$;
revoke all on function public.fitrota_paddle_live_claim_checkout(uuid),public.fitrota_paddle_live_record_payment(uuid,text,text,timestamptz) from public,anon,authenticated;
grant execute on function public.fitrota_paddle_live_claim_checkout(uuid),public.fitrota_paddle_live_record_payment(uuid,text,text,timestamptz) to service_role;
commit;
