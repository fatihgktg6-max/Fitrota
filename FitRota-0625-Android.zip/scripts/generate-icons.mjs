// Render the project's own vector mark to native icon assets.
import {chromium} from '@playwright/test';import {writeFile,readFile} from 'node:fs/promises';
const browser=await chromium.launch({args:['--no-sandbox']});const page=await browser.newPage();
const source=await readFile('public/icon.svg','utf8');const mark=source.replace(/<svg[^>]*>/,'').replace('</svg>','');
async function render(file,size,foreground=false){await page.setViewportSize({width:size,height:size});const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 128 128">${foreground?'':'<rect width="128" height="128" fill="#192139"/>'}<g transform="translate(16 10) scale(.76)">${mark}</g></svg>`;await page.setContent(`<style>body{margin:0;background:transparent}</style>${svg}`);await page.screenshot({path:file,omitBackground:foreground});}
for(const [dpi,n] of [['mdpi',48],['hdpi',72],['xhdpi',96],['xxhdpi',144],['xxxhdpi',192]]){for(const suffix of ['', '_round'])await render(`android/app/src/main/res/mipmap-${dpi}/ic_launcher${suffix}.png`,n);await render(`android/app/src/main/res/mipmap-${dpi}/ic_launcher_foreground.png`,Math.round(n*2.25),true);}
await render('ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png',1024);
await writeFile('android/app/src/main/res/values/ic_launcher_background.xml','<?xml version="1.0" encoding="utf-8"?><resources><color name="ic_launcher_background">#192139</color></resources>');
await browser.close();console.log('Native launcher icons generated.');
