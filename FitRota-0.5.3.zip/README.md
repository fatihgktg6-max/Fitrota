# FitRota 0.5.3

Günlük spor ve beslenme düzeni için web/PWA test sürümü. Android/iOS kaynakları dahildir; imzalı mağaza paketi değildir. Canlı siteye otomatik gönderilmez.

Yeni akış: **Bugün → Antrenman → Beslenme → Takvim → Diğer/Profil**. Robot koç düğmesi ayrıca erişilebilir. Antrenmanda Programım / Sayaç & müzik / Hareketler; beslenmede Günlüğüm / Haftalık plan / Tarifler bulunur.

- Günlere göre antrenman ve toparlanma; süreye uygun başlangıç planları.
- 32 tarif, CoFID 2021 kaynak kodlarıyla hesaplanan değerler; günlük enerji tahmini, öğün/porsiyon kaydı, kendi etiketinden besin ekleme.
- Kronometre, tur kaydı, set arası sayaç, dış müzik önerileri ve 21 hareketin yazılı adım adım anlatımı.
- Google/Apple web OAuth, ayrı kullanıcı alanları, isteğe bağlı bulut yedeği ve hesap silme altyapısı. Kendi sağlayıcı ve veritabanı ayarları olmadan devre dışıdır.
- Uygulama içi ve herkese açık kullanıcı belgesi taslakları. Gerçek işletmeci bilgisi ve hukuki inceleme beklenir.

Ayrıntılar: [Sürüm raporu](docs/RELEASE-0.5.0.md), [bilimsel kaynaklar](docs/CONTENT-SOURCES.md), [hesap kurulumu](docs/ACCOUNT-SETUP.md), [yayın belgeleri](docs/PUBLICATION-LEGAL.md).

## Yerel geliştirme

Node.js 22+: `npm ci`, `npm run check`, `npm run dev`. Son komut derlenmiş uygulamayı ve kullanıcı belgelerini `http://127.0.0.1:4173` üzerinden sunar; ücretli AI çağrısı yapmaz.

Üretim sunucusu: `server/.env.example` alanlarını kendi sunucu ortamında yapılandırıp `npm run server`. Gerçek API ve service-role anahtarları yalnız sunucuda tutulur; kaynak depoya veya HTML’e eklenmez.

Derleyici, mevcut sıfır-CDN çevrimdışı yaklaşımı koruyarak modül kaynaklarını sıralı tek HTML paketine toplar. `src/app.js` ve `src/upgrade.js` arayüz kapsamını paylaşır; doğrudan tarayıcıya modül dosyası olarak bağlanmaz. `index.html`, `FitRota-Onizleme.html`, `dist/` derlenmiş çıktılardır.

## Sınırlar

AI hâlâ tek sahipli pilot erişim sistemi kullanır. Kullanıcı bazlı AI kotası, mağaza ödeme/ödül doğrulaması ve reklam etkin değildir. Google/Apple gerçek sağlayıcı testi, gerçek veritabanı RLS testi ve Android/iOS yerel giriş entegrasyonu beklenir. İçerikler bireysel uzman onaylı diyet/antrenman reçetesi değildir. Bu paket “tüm ülkelerde yayına hazır” iddiası taşımaz.

0.5.1: geçici hesap hizmeti hatasında oturum korunur. Apple girişinde iptal ayarları aranır. `npm run check:config` gizli değerleri göstermeden sunucu ayarlarını kontrol eder. Ayrıntılar: docs/RELEASE-0.5.1.md.

0.5.3: hareket animasyonları kaldırıldı, antrenman görünümü sadeleştirildi. Yapılandırılmış web/PWA hesabıyla AI kod girmeden açılır; özel pilot test bağlantısı ayrı açılır bölümdedir. Ayrıntılar: docs/RELEASE-0.5.3.md.
