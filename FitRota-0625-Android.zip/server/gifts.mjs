import {createHash} from 'node:crypto';

// Codes and grants live only in the database; requests use the authenticated owner.
export function createGiftService({env=process.env,fetcher=fetch}={}){
 const base=(env.SUPABASE_URL||'').replace(/\/$/,''),key=env.SUPABASE_SERVICE_ROLE_KEY;
 const enabled=env.FITROTA_GIFT_CODES_ENABLED==='true'&&!!base&&!!key;
 async function rpc(name,body){
  const r=await fetcher(base+'/rest/v1/rpc/'+name,{method:'POST',headers:{apikey:key,Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify(body),redirect:'error',signal:AbortSignal.timeout(10000)});
  if(!r.ok)throw Error('gift_unavailable');
  const data=await r.json();
  if(data.error){if(['gift_invalid','gift_already_used','gift_rate_limit'].includes(data.error))throw Error(data.error);throw Error('gift_unavailable');}
  if(!Object.hasOwn(data,'premiumUntil')||(data.premiumUntil!==null&&!Number.isFinite(Date.parse(data.premiumUntil))))throw Error('gift_unavailable');
  return data;
 }
 return {enabled,
  status:owner=>enabled?rpc('fitrota_gift_status',{p_user_id:owner}):Promise.resolve({premiumUntil:null}),
  redeem:async(owner,code)=>{
   if(!enabled)throw Error('gift_disabled');
   // Invalid formats also reach the persistent attempt limiter, without sending raw codes.
   const normalized=typeof code==='string'&&code.length<=80?code.trim().replace(/[\s-]/g,'').toUpperCase():'';
   const hash=/^FR[A-F0-9]{32}$/.test(normalized)?createHash('sha256').update(normalized).digest('hex'):null;
   return rpc('fitrota_redeem_gift',{p_user_id:owner,p_code_hash:hash});
  }
 };
}
