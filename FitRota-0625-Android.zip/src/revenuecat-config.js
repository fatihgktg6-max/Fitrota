// Public SDK keys only. Secret RevenueCat keys belong exclusively on the server.
export const revenueCatConfig = {
  testMode: false,
  testApiKey: '',
  androidApiKey: 'goog_VBWxlztyWOJaqSZawQyDDGDXRNA',
  iosApiKey: '',
  entitlement: 'fitrota_pro',
};
