import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
const context=await browser.newContext({viewport:{width:1440,height:1000},locale:'tr-TR'});
const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
const url=pathToFileURL(path.resolve('FitRota-Onizleme.html')).href;
const open=async()=>{await page.goto(url);await page.waitForSelector('[data-action="onboard"]');};
await open();await page.screenshot({path:'qa/welcome-desktop.png',fullPage:true});
await page.locator('[data-action="onboard"]').click();
await page.locator('[name="name"]').fill('Deneme');await page.locator('[name="age"]').fill('24');await page.locator('[name="height"]').fill('180');await page.locator('[name="weight"]').fill('80');
await page.locator('#onboard-form button[type="submit"]').click();await page.locator('#onboard-form button[type="submit"]').click();await page.locator('[name="consent"]').check();await page.locator('#onboard-form button[type="submit"]').click();
await page.waitForSelector('.dashboard');assert.match(await page.locator('h1').textContent(),/Deneme/);
await page.locator('[data-action="water-plus"]').click();assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('fitrota.v1')).water[new Date().toLocaleDateString('en-CA')]),1);
await page.locator('.sidebar [data-nav="workout"]').click();await page.locator('[data-action="adapt"]').click();await page.selectOption('#adapt-form [name="minutes"]','15');await page.locator('#adapt-form button[type="submit"]').click();await page.locator('[data-action="approve-plan"]').click();await page.locator('[data-action="start-workout"]').click();
await page.locator('[data-set-field="weight"]').first().fill('12.5');await page.locator('[data-set-field="reps"]').first().fill('10');await page.locator('[data-action="toggle-set"]').first().click();await page.locator('[data-action="close"]').first().click();await page.reload();await page.locator('.sidebar [data-nav="workout"]').click();await page.locator('[data-action="start-workout"]').click();assert.equal(await page.locator('[data-set-field="weight"]').first().inputValue(),'12.5');
while(await page.locator('[data-action="toggle-set"][aria-pressed="false"]').count()){await page.locator('[data-action="toggle-set"][aria-pressed="false"]').first().click();}
await page.locator('[data-action="finish-workout"]').click();await page.waitForSelector('[data-action="workout-log"]');
await page.locator('.sidebar [data-nav="food"]').click();await page.locator('[data-action="log-meal"]').first().click();await page.locator('#meal-form [name="servings"]').fill('1.5');await page.locator('#meal-form button[type="submit"]').click();await page.locator('[data-action="food-tab"][data-id="log"]').click();assert.equal(await page.locator('[data-action="delete-meal"]').count(),1);
await page.locator('.sidebar [data-nav="calendar"]').click();await page.locator('[data-action="add-event"]').click();await page.locator('#event-form [name="title"]').fill('Akşam yürüyüşü');await page.locator('#event-form button[type="submit"]').click();assert.equal(await page.locator('[data-action="toggle-event"]').count(),1);
await page.locator('.sidebar [data-nav="coach"]').click();await page.locator('#chat-input').fill('Bugün 15 dakikam var');await page.locator('#chat-form button').click();await page.waitForSelector('#coach-connect-form');await page.locator('[data-action="close"]').first().click();assert.equal(await page.locator('.message').count(),0);
await page.locator('.sidebar [data-nav="settings"]').click();await page.selectOption('#setting-lang','en');assert.equal(await page.locator('h1').textContent(),'Make it yours.');await page.selectOption('#setting-lang','tr');
await page.locator('.sidebar [data-nav="home"]').click();await page.waitForTimeout(4400);await page.screenshot({path:'qa/dashboard-desktop.png',fullPage:true});
for(const width of [390,768,1440]){await page.setViewportSize({width,height:844});for(const route of ['home','workout','food','coach','calendar','progress','rewards','settings']){await page.evaluate(r=>navigate(r),route);await page.waitForTimeout(50);const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth+1);assert.equal(overflow,false,`overflow ${route} ${width}`);}await page.evaluate(()=>navigate('home'));await page.screenshot({path:`qa/dashboard-${width}.png`,fullPage:true});}
await page.setViewportSize({width:390,height:844});await page.locator('[data-action="more"]').click();await page.locator('#modal-root [data-nav="rewards"]').click();assert.equal(await page.locator('.rewardcard').count(),2);await page.screenshot({path:'qa/rewards-mobile.png',fullPage:true});
assert.deepEqual(errors,[]);console.log('PASS: onboarding, water, adaptation, persisted sets, workout completion, food, calendar, coach, language, all 8 routes at 3 sizes; zero runtime errors.');
await browser.close();
