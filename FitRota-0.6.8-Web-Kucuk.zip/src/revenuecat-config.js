// Public SDK keys only. Secret RevenueCat keys belong exclusively on the server.
export const revenueCatConfig = {
  testMode: true,
  testApiKey: 'test_cEwgcQXtLdaksjmDfqtJwDKyBRY',
  androidApiKey: '',
  iosApiKey: '',
  entitlement: 'fitrota_pro',
};
