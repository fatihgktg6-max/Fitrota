# Doğrulama — 2 Ekim 2026

## Başarılı

- JavaScript sözdizimi kontrolü.
- 16 çekirdek mantık testi: yetişkin profil doğrulaması, süre/ekipman planı, sağlık kısıtı, alerjen/diyet/malzeme filtreleri, porsiyon hesabı, alışveriş toplama, sabit haftalık hedef, geçmiş gün muafiyeti, sıfır hedef/mükerrer ödül engeli, demo ödülü engeli, aylık hedef, tamamlama önkoşulları, aktif seansın korunması, bozuk yedek reddi, yerel koç yanıtı, tarih sınırları.
- 3 AI adaptör testi: rol/alan doğrulaması, reasoning çıktılarını atlayıp metin bulma, `store:false`/çıktı sınırı ve hata durumları. **Sahte sağlayıcı ile; gerçek API çağrısı değil.**
- Chromium 134 / Playwright 1.51.1 üzerinde UI akışları: yeni profil, su kaydı, 15 dakikalık uyarlama, set verisi, sayfa yenilendikten sonra devam, antrenman bitirme, porsiyonlu öğün, takvim, koç, Türkçe/İngilizce.
- 8 ekran × 390, 768, 1440 px: yatay taşma bulunmadı. Bulunan mobil takvim taşması düzeltildi.
- Ek UI akışları: özel program, HTML enjeksiyon denemesinde metin kaçışlama, ölçüm güncelleme, beslenme hedefleri, JSON yedek gidiş-dönüş, malzemeden tarif bulma, tüm verileri silme.
- Testlerde yakalanmış JavaScript çalışma zamanı hatası kalmadı.
- Android ve iOS native projeleri oluşturuldu; `npx cap sync` her iki platformda başarılı.
- Tarayıcı ekran görüntüleri `qa/` klasöründe. Bazı ekran görüntülerinde test kayıtları/örnek veriler vardır.

## Yapılmayan / doğrulanmayan

- APK/AAB derlemesi: bu ortamda Android SDK ve Java 21 yok. APK verilmedi. GitHub Actions iş akışı hazır ama uzakta çalıştırılmadı.
- iOS simulator / fiziksel iPhone / TestFlight: Xcode ve imzalama hesabı yok.
- Android/iOS fiziksel cihaz bildirimi, alarm zamanlaması ve WebView dosya dışa aktarımı.
- Gerçek OpenAI API yanıtları: kullanıcı API anahtarı/model tercihi sağlanmadı.
- Mağaza satın alma, abonelik, sunucu hesabı, bulut veri kaydı ve gerçek hediye aktivasyonu uygulanmadı.
- Klinik/uzman içerik doğrulaması, gerçek besin veri tabanı ve tam erişilebilirlik denetimi.

Bu sonuçlar üretim/mağaza yayını onayı değildir; çalışan ilk sürümün kapsamlı yerel doğrulamasıdır.

## v0.2 AI güncelleme doğrulaması

19 mevcut mantık/adaptör testi, 4 yeni HTTP sunucu testi başarılı. Yeni koç UI testi gerçek yerel HTTP sunucusuyla bağlantı, yanlış kod, bağlam paylaşımı, yeniden deneme, iptal, sohbet temizliği ve bellekte tutulan oturumu doğruladı. Sağlayıcı bu testte mock olarak değiştirildi; ücretli OpenAI çağrısı yapılmadı. Önceki 8 ekran ve mevcut UI akışları yeniden geçti. v0.2 koç mobil ekran görüntüsü `qa/coach-v02-mobile.png`.
