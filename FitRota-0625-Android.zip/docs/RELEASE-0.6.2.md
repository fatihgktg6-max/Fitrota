# FitRota 0.6.2

Premium üst rozeti, Premium’a geç ekranı, üç aylık fiyat hedefi ve isteğe bağlı Tatlı sert koç. Google kamuya açık modda e-posta allowlist’i kullanmaz ve hesap seçimini ister. Apple web OAuth mevcut hesap yapısına bağlıdır; gerçek Apple Developer kimlik bilgileri olmadan kapalıdır.

Yeni sunucu abonelik doğrulaması RevenueCat’ın canlı entitlements/subscriptions durumunu kontrol eder. İade edilmiş, sandbox, süresi bitmiş veya izinli ürün dışında kayıtlar Premium açmaz. UI/backup verisi ücretli yetki oluşturmaz. Premium 30 mesaj/2 saat kotasını aşar; standart hesaplar mevcut kota hizmetini kullanır. Rozet hesap değişiminde temizlenir. Satın alma ve ücretlendirme gerçek dış yapılandırma tamamlanmadan açılmaz.

005_premium_rewards.sql: isteğe bağlı iki takvim aylık sabit görev dönemi; tüm günlük öğün/su ve planlı antrenman kayıtları tamamlanınca bir takvim ayı Premium. Yalnız aynı gün sunucuya ulaşan işaretler sayılır. Dönem atomik olarak kapanır, tek ödül verilir ve sayaç sıfırlanır. Hesap silme ödül tablolarını da siler.

Testler: ödeme doğrulama redleri, sunucu güven sınırı, gerçek PostgreSQL motorunda SQL idempotency/erişim hakları/ödül/reset, Google bağımsız e-posta, tarayıcıda 35 Premium mesaj ve dolu ücretsiz kota, Premium’dan düşme, hesap izolasyonu ve 320–1280 px rozeti. AI ve ödeme servisleri testlerde taklittir; gerçek ödeme/OAuth testi yapıldığını ifade etmez.

Yeni SQL dosyasını kur. Google, Apple ve ödeme için adımlar docs/PREMIUM-SETUP.md. Hukuk metinlerine abonelik, görev kayıtları, yenileme/iptal ve provider verileri eklendi; gerçek işletmeci ve hukuk incelemesi hâlâ zorunludur. Reklam SDK’sı henüz yoktur. Native ödeme/OAuth henüz açık değildir. Android versionCode 19, iOS build 19.
