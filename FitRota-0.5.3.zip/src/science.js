// Calculation choices are documented separately from source recommendations.
export const evidenceSources=[
 ['WHO · Physical activity','https://www.who.int/news-room/fact-sheets/detail/physical-activity'],
 ['ACSM · Resistance training 2026','https://acsm.org/resistance-training-guidelines-update-2026/'],
 ['Mifflin–St Jeor · Energy equation','https://pubmed.ncbi.nlm.nih.gov/2305711/'],
 ['WHO · Healthy diet','https://www.who.int/health-topics/healthy-diet'],
 ['CoFID 2021 · Food composition','https://www.gov.uk/government/publications/composition-of-foods-integrated-dataset-cofid'],
 ['NIDDK · Adult weight planning','https://www.niddk.nih.gov/health-information/weight-management/body-weight-planner']
];
export function energyEstimate(p){
 if(!p||p.age<18||p.age>78||p.health||p.nutritionRisk||!['female','male'].includes(p.sex)||!['low','light','moderate','high'].includes(p.activity))return {available:false,reason:'profile'};
 const bmi=p.weight/(p.height/100)**2;
 if(bmi<18.5||bmi>=40)return {available:false,reason:'individual'};
 const factor={low:1.2,light:1.375,moderate:1.55,high:1.725}[p.activity];
 const resting=10*p.weight+6.25*p.height-5*p.age+(p.sex==='male'?5:-161);
 const maintenance=Math.round(resting*factor);
 // Conservative product starting offsets, not a validated weight-loss prediction.
 const adjustment=p.goal==='lose'?-Math.min(300,maintenance*.1):['gain','muscle'].includes(p.goal)?Math.min(200,maintenance*.07):0;
 const kcal=Math.round((maintenance+adjustment)/10)*10;
 if(kcal<1500||kcal>4000)return {available:false,reason:'individual'};
 return {available:true,kcal,maintenance,resting:Math.round(resting),factor,adjustment:Math.round(adjustment),range:[Math.round(kcal*.9/10)*10,Math.round(kcal*1.1/10)*10]};
}
export function nutritionTarget(p){const e=energyEstimate(p);return {kcal:p?.calories|| (e.available?e.kcal:null),protein:p?.protein||null,source:p?.calories?'manual':e.available?'estimate':'none',estimate:e};}
export function balancedMealPlan(p,date,pool){
 const target=nutritionTarget(p).kcal,offset=Math.floor(Date.parse(date+'T12:00:00Z')/86400000),used=new Set();
 return ['breakfast','lunch','dinner','snack'].map((slot,i)=>{
  let list=pool.filter(f=>f.type===({lunch:'main',dinner:'main'}[slot]||slot));const fresh=list.filter(f=>!used.has(f.id));if(fresh.length)list=fresh;
  const f=list[((offset*3+i*5)%list.length+list.length)%list.length];if(!f)return {slot,foodId:null,servings:1};used.add(f.id);
  const share=[.25,.3,.3,.15][i],servings=target?Math.max(.5,Math.min(2.5,Math.round(target*share/f.kcal*4)/4)):1;
  return {slot,foodId:f.id,servings};
 });
}
export function trainingPrescription(p,{minutes=p.minutes,equipment=p.equipment,date,gentle=false}={},catalog){
 const day=new Date(date+'T12:00:00'),weekday=day.getDay(),ordered=[1,2,3,4,5,6,0].filter(d=>p.days.includes(d)),index=Math.max(0,ordered.indexOf(weekday)),seed=Math.floor(Date.parse(date+'T12:00:00Z')/604800000);
 const restricted=p.health&&!gentle;
 if(restricted)return {id:'plan-'+date,date,title:['Uzman onaylı plan gerekli','Professional plan needed'],minutes:0,warmup:0,cooldown:0,items:[],restricted:true};
 const planned=p.days.includes(weekday),consecutive=p.days.includes((weekday+6)%7),split=ordered.length>=4;
 let mode=gentle||!planned?'recovery':split?(index===4?'conditioning':index%2?'lower':'upper'):consecutive&&index>0?'recovery':(seed+index)%2?'fullB':'fullA';
 const gym={fullA:['legpress','row','chestpress','legcurl','deadbug','calf'],fullB:['hipthrust','pulldown','chestpress','legpress','shoulderpress','birddog'],upper:['chestpress','row','pulldown','shoulderpress','curl','triceps'],lower:['legpress','hipthrust','legcurl','calf','deadbug','birddog']};
 const home={fullA:['squat','pushup','hinge','pronew','deadbug','calf'],fullB:['lunge','pushup','bridge','pronew','birddog','wallslide'],upper:['pushup','pronew','wallslide','deadbug'],lower:['squat','hinge','bridge','calf','birddog']};
 const names={fullA:['Tüm vücut A','Full body A'],fullB:['Tüm vücut B','Full body B'],upper:['Üst vücut','Upper body'],lower:['Alt vücut','Lower body'],recovery:['Toparlanma & hareketlilik','Recovery & mobility'],conditioning:['Yürüyüş & merkez','Walking & core']};
 const ids=['recovery','conditioning'].includes(mode)?['walk','mobility']:(equipment==='gym'?gym:home)[mode];
 const warmup=mode==='recovery'?0:minutes>=30?5:3,cooldown=mode==='recovery'?0:2;let used=warmup+cooldown;
 const items=[];
 for(const id of ids){const base=catalog.find(e=>e.id===id);if(!base)continue;const movement=['walk','mobility'].includes(id);const sets=movement?1:p.level==='beginner'?2:3,rest=movement?0:['deadbug','birddog','calf','wallslide','pronew'].includes(id)?60:90;
  let cost=movement?(id==='walk'?Math.max(5,minutes-5):5):Math.ceil(sets*.6+(sets-1)*rest/60+1);
  if(used+cost>minutes)continue;
  const e={...base,sets,rest,minutes:cost};if(id==='walk')e.reps=cost+' dk / min';items.push(e);used+=cost;
 }
 return {id:'plan-'+date,date,title:names[mode],minutes:used,warmup,cooldown,items,mode,planned,short:minutes<30,consecutive:planned&&consecutive,progression:['recovery','conditioning'].includes(mode)?['Rahat konuşabildiğin tempoda yürü; gerekirse süreyi azalt. Bu toparlanma gününde ağırlık artırma hedefi yok.','Walk at an easy conversational pace; shorten as needed. This recovery session has no load-increase target.']:['Son sette 2–3 tekrar daha yapabilecek kontrollü yük seç. Tüm setlerde üst tekrar sınırına iki antrenmanda rahatça ulaşırsan en küçük yük artışını dene. Ağrı veya teknik bozulmada artırma.','Choose a controlled load leaving about 2–3 repetitions in reserve. After reaching the top of the rep range comfortably in two sessions, try the smallest load increase. Do not increase through pain or poor form.']};
}
export function stopwatchElapsed(timer,now=Date.now()){return Math.max(0,(timer?.elapsed||0)+(timer?.running?Math.max(0,now-timer.startedAt):0));}
