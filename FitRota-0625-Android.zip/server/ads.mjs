// Public AdSense identifiers only. No provider keys or user data are returned.
export function adConfig(env=process.env){
 const publisher=env.FITROTA_ADSENSE_CLIENT||'',slot=env.FITROTA_ADSENSE_SLOT||'';
 let cmpURL='';try{const u=new URL(env.FITROTA_CMP_SCRIPT_URL);if(u.protocol==='https:'&&u.hostname==='fundingchoicesmessages.google.com'&&!u.username&&!u.password)cmpURL=u.href;}catch{}
 const validCMP=!env.FITROTA_CMP_SCRIPT_URL||!!cmpURL;
 const enabled=validCMP&&env.FITROTA_ADS_ENABLED==='true'&&env.FITROTA_ADS_SITE_APPROVED==='true'&&/^ca-pub-\d{16}$/.test(publisher)&&/^\d{10}$/.test(slot);
 return enabled?{enabled,publisher,slot,cmpURL:cmpURL||'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client='+publisher}:{enabled:false};
}
export function adsTxt(env=process.env){const publisher=env.FITROTA_ADSENSE_CLIENT||'';return /^ca-pub-\d{16}$/.test(publisher)?`google.com, ${publisher.slice(3)}, DIRECT, f08c47fec0942fa0\n`:'';}
