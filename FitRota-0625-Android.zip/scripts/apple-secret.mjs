// Run locally with --env-file. Writes the client secret to a private file, never stdout.
import {createPrivateKey,sign} from 'node:crypto';import {readFile,writeFile} from 'node:fs/promises';
const {APPLE_TEAM_ID,APPLE_KEY_ID,APPLE_CLIENT_ID,APPLE_P8_PATH}=process.env;
if(!/^[A-Z0-9]{10}$/.test(APPLE_TEAM_ID||'')||!/^[A-Z0-9]{10}$/.test(APPLE_KEY_ID||'')||!/^[a-zA-Z0-9.-]{3,200}$/.test(APPLE_CLIENT_ID||'')||!APPLE_P8_PATH)throw Error('Provide APPLE_TEAM_ID, APPLE_KEY_ID, APPLE_CLIENT_ID and APPLE_P8_PATH privately.');
const key=createPrivateKey(await readFile(APPLE_P8_PATH));if(key.asymmetricKeyType!=='ec'||key.asymmetricKeyDetails.namedCurve!=='prime256v1')throw Error('Apple requires an ES256 P-256 private key.');
const iat=Math.floor(Date.now()/1000),exp=iat+150*86400,encode=v=>Buffer.from(JSON.stringify(v)).toString('base64url');const input=encode({alg:'ES256',kid:APPLE_KEY_ID})+'.'+encode({iss:APPLE_TEAM_ID,iat,exp,aud:'https://appleid.apple.com',sub:APPLE_CLIENT_ID});
const secret=input+'.'+sign('sha256',Buffer.from(input),{key,dsaEncoding:'ieee-p1363'}).toString('base64url');await writeFile('server/.apple-client-secret',secret,{mode:0o600,flag:'wx'});console.log('Client secret saved privately; expires '+new Date(exp*1000).toISOString()+'. Configure Supabase and Render; do not commit this file.');
