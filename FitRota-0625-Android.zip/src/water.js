// Historical backups store water in 250 ml units. Keep that representation.
function waterAmount(){const value=state.water[today()];return Number.isFinite(value)?Math.max(0,Math.min(6000,value*250)):0;}
function waterStep(){return imperialUnits()?fromUS(8,'flOz'):250;}
function waterCard(){const amount=waterAmount(),step=waterStep(),label=waterText(step),date=today();return `<section class="card daily-water" data-date="${date}"><div class="cardhead"><h2>${t('Su kaydın','Water log')}</h2>${icon('water',22)}</div><div class="water-inline"><strong aria-live="polite" aria-atomic="true">${waterText(amount)}</strong><div class="water-controls">${btn('− '+label,'water-minus','outline sm',`data-date="${date}" aria-label="${t('Azalt: ','Remove ')+label}" ${amount===0?'disabled':''}`)}${btn('+ '+label,'water-plus','soft sm',`data-date="${date}" aria-label="${t('Ekle: ','Add ')+label}" ${amount+step>6000.000001?'disabled':''}`)}</div></div><p class="subtitle">${amount+step>6000.000001?t('Günlük kayıt sınırına ulaştın. Bu sınır bir tüketim önerisi değildir.','Daily logging limit reached. This limit is not an intake recommendation.'):t('Bugün içtiğin su. Değişiklikler bu cihazda kaydedilir.','Water logged today. Changes are saved on this device.')}</p></section>`;}
function refreshWaterCard(){const card=document.querySelector('.daily-water');if(card)card.outerHTML=waterCard();}
function updateWater(action,el){
 const date=today();
 if(el.dataset.date&&el.dataset.date!==date){refreshWaterCard();toast(t('Gün değişti. Bugünün kaydını güncelleyebilirsin.','A new day has started. You can now update today’s log.'));return;}
 const previous=state.water[date],had=Object.hasOwn(state.water,date),amount=waterAmount(),step=waterStep();
 let next=action==='water'?Number(el.dataset.value)*250:amount+(action==='water-plus'?step:-step);
 if(!Number.isFinite(next)||next>6000.000001)return;
 next=Math.max(0,Math.min(6000,Math.round(next*1e6)/1e6));
 state.water[date]=next/250;
 if(!saveState(state)){if(had)state.water[date]=previous;else delete state.water[date];toast(t('Su kaydı kaydedilemedi. Cihaz depolama alanını kontrol edip tekrar dene.','Water could not be saved. Check device storage and try again.'));return;}
 queueRewardSync();queueCloudSave();refreshWaterCard();
 document.querySelector(`[data-action="${action}"]:not(:disabled)`)?.focus({preventScroll:true});
}
// Update an open water card across midnight without replacing forms or dialogs.
setInterval(()=>{const card=document.querySelector('.daily-water');if(!document.hidden&&card&&card.dataset.date!==today())refreshWaterCard();},1000);
