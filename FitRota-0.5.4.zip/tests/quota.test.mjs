import {test} from 'node:test';
import assert from 'node:assert/strict';
import {PGlite} from '@electric-sql/pglite';
import {readFile,mkdtemp,rm} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {createQuotaService} from '../server/quota.mjs';
import {createCoachServer} from '../server/index.mjs';
const owner='10000000-0000-0000-0000-000000000001',other='10000000-0000-0000-0000-000000000002';
const sql=await readFile(new URL('../database/002_ai_quota.sql',import.meta.url),'utf8');
async function database(location){const db=new PGlite(location);await db.exec(`create role anon; create role authenticated; create role service_role bypassrls; create schema auth; create table auth.users(id uuid primary key); insert into auth.users values('${owner}'),('${other}');`);await db.exec(sql);await db.exec(sql);return db;}
async function rpc(db,user,action='status',id=null){return (await db.query('select public.fitrota_ai_quota($1::uuid,$2::text,$3::uuid) as result',[user,action,id])).rows[0].result;}
function service(db){return createQuotaService({env:{SUPABASE_URL:'https://quota.example.test',SUPABASE_SERVICE_ROLE_KEY:'server-only-test-key'},fetcher:async(url,init)=>{assert.equal(url,'https://quota.example.test/rest/v1/rpc/fitrota_ai_quota');const p=JSON.parse(init.body);try{const data=await rpc(db,p.p_user_id,p.p_action,p.p_request_id);return {ok:true,json:async()=>data};}catch{return {ok:false};}}});}

test('PostgreSQL migration: 30 atomic reservations, one-hour cooldown, idempotency, refund, ownership and expired cycles',async()=>{
 const db=await database();try{
  let result=await rpc(db,owner);assert.equal(result.quota.remaining,30);
  const ids=Array.from({length:32},()=>randomUUID());const results=await Promise.all(ids.map(id=>rpc(db,owner,'reserve',id)));
  assert.equal(results.filter(r=>r.allowed).length,30);result=await rpc(db,owner);assert.equal(result.quota.remaining,0);assert.equal(result.quota.blocked,true);
  assert.ok(Math.abs(Date.parse(result.quota.resetAt)-Date.parse(result.quota.serverNow)-3600000)<5000);
  assert.equal((await rpc(db,owner,'reserve',ids[0])).allowed,true);assert.equal((await rpc(db,other)).quota.remaining,30);
  result=await rpc(db,owner,'refund',ids[29]);assert.equal(result.quota.remaining,1);assert.equal(result.quota.resetAt,null);
  assert.equal((await rpc(db,owner,'refund',ids[29])).quota.remaining,1);
  assert.equal((await rpc(db,other,'refund',ids[0])).quota.remaining,30);assert.equal((await rpc(db,owner)).quota.remaining,1);
  await rpc(db,owner,'reserve',randomUUID());await db.query("update public.fitrota_ai_quotas set reset_at=clock_timestamp()-interval '1 second' where user_id=$1",[owner]);
  result=await rpc(db,owner);assert.equal(result.quota.remaining,30);assert.equal(result.quota.blocked,false);
  await rpc(db,owner,'reserve',randomUUID());assert.equal((await rpc(db,owner,'refund',ids[0])).quota.remaining,29);
  await assert.rejects(rpc(db,'10000000-0000-0000-0000-000000000099','reserve',randomUUID()));
  for(const role of ['anon','authenticated']){await db.exec('set role '+role);await assert.rejects(rpc(db,owner));await assert.rejects(db.query('select * from public.fitrota_ai_quotas'));await db.exec('reset role');}
  await db.exec('set role service_role');assert.equal((await rpc(db,owner)).quota.remaining,29);await db.exec('reset role');
 }finally{await db.close();}
});

test('quota survives database close/reopen',async()=>{const dir=await mkdtemp(path.join(os.tmpdir(),'fitrota-quota-db-'));let db;try{db=await database(dir);await rpc(db,owner,'reserve',randomUUID());await db.close();db=new PGlite(dir);assert.equal((await rpc(db,owner)).quota.remaining,29);}finally{await db?.close();await rm(dir,{recursive:true,force:true});}});

test('server enforces account quota, rejects forged identity, refunds provider failure, persists across server restart',async()=>{
 const db=await database(),dir=await mkdtemp(path.join(os.tmpdir(),'fitrota-quota-http-'));let server,base,calls=0,fail=false;
 const quotaService=service(db),origins=[];const accountService={enabled:true,handler:async()=>false,session:async req=>req.headers.cookie==='owner=a'?{user:{id:owner}}:req.headers.cookie==='owner=b'?{user:{id:other}}:null};
 async function start(){server=createCoachServer({accessCode:'test-code-with-more-than-32-characters',apiKey:'test',model:'test',dailyLimit:1000,ledgerFile:path.join(dir,'ledger.json'),allowedOrigins:origins,accountService,quotaService,reply:async()=>{calls++;if(fail)throw Error('provider_error');return {text:'Mock reply',source:'openai'};}});await new Promise(r=>server.listen(0,'127.0.0.1',r));base='http://127.0.0.1:'+server.address().port;origins.push(base);}
 const call=(cookie='owner=a',header=owner)=>fetch(base+'/account/coach',{method:'POST',headers:{Origin:base,Cookie:cookie,'X-Fitrota-Owner':header,'Content-Type':'application/json'},body:JSON.stringify({messages:[{role:'user',content:'hello'}],consent:true,user_id:other,premium:true})});
 try{
  await start();for(let i=0;i<29;i++)await quotaService.reserve(owner,randomUUID());
  assert.equal((await call('',owner)).status,401);assert.equal((await call('owner=a',other)).status,409);assert.equal(calls,0);
  fail=true;let res=await call();assert.equal(res.status,502);assert.equal((await res.json()).quota.remaining,1);
  fail=false;res=await call();assert.equal(res.status,200);assert.equal((await res.json()).quota.remaining,0);
  res=await call();assert.equal(res.status,429);assert.equal((await res.json()).error,'account_quota_exhausted');assert.ok(Number(res.headers.get('retry-after'))>3500);assert.equal(calls,2);
  res=await call('owner=b',other);assert.equal(res.status,200);assert.equal((await res.json()).quota.remaining,29);
  await new Promise(r=>server.close(r));await start();res=await call();assert.equal(res.status,429);assert.equal(calls,3);
  await db.query("update public.fitrota_ai_quotas set reset_at=clock_timestamp()-interval '1 second' where user_id=$1",[owner]);res=await call();assert.equal(res.status,200);assert.equal((await res.json()).quota.remaining,29);
 }finally{if(server?.listening)await new Promise(r=>server.close(r));await db.close();await rm(dir,{recursive:true,force:true});}
});

test('quota RPC failure fails closed and never exposes credentials',async()=>{const svc=createQuotaService({env:{SUPABASE_URL:'https://quota.example.test',SUPABASE_SERVICE_ROLE_KEY:'secret'},fetcher:async()=>({ok:false})});await assert.rejects(svc.reserve(owner,randomUUID()),{message:'quota_unavailable'});const bad=createQuotaService({env:{SUPABASE_URL:'https://quota.example.test/path',SUPABASE_SERVICE_ROLE_KEY:'secret'},fetcher:async()=>{throw Error('must not call');}});await assert.rejects(bad.status(owner),{message:'quota_unavailable'});});

test('HTTP fails closed on missing quota migration before any AI provider call',async()=>{
 let calls=0;const origins=[],dir=await mkdtemp(path.join(os.tmpdir(),'fitrota-quota-outage-'));
 const quotaService=createQuotaService({env:{SUPABASE_URL:'https://quota.example.test',SUPABASE_SERVICE_ROLE_KEY:'server-secret'},fetcher:async()=>({ok:false})});
 const server=createCoachServer({accessCode:'test-code-with-more-than-32-characters',apiKey:'mock',model:'mock',allowedOrigins:origins,ledgerFile:path.join(dir,'ledger.json'),quotaService,accountService:{enabled:true,handler:async()=>false,session:async()=>({user:{id:owner}})},reply:async()=>{calls++;return {source:'openai',text:'must not call'};}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;origins.push(base);
 try{for(const [endpoint,method] of [['/account/ai-session','GET'],['/account/coach','POST']]){const res=await fetch(base+endpoint,{method,headers:{Origin:base,'Content-Type':'application/json','X-Fitrota-Owner':owner},...(method==='POST'?{body:JSON.stringify({consent:true,messages:[{role:'user',content:'hi'}]})}:{})});assert.equal(res.status,503);assert.deepEqual(await res.json(),{error:'quota_unavailable'});}assert.equal(calls,0);}finally{await new Promise(r=>server.close(r));await rm(dir,{recursive:true,force:true});}
});
