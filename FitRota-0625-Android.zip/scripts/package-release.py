"""Create the fixed-name Render upload without secrets or build caches."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json
from io import BytesIO

root = Path(__file__).resolve().parent.parent
output = root.parent / 'release-output' / 'FitRota-0.6.2.zip'
output.parent.mkdir(exist_ok=True)
excluded = {'node_modules', '.git', '.data', '.gradle', 'build', '.idea', 'DerivedData', 'research'}
buffer = BytesIO()
with ZipFile(buffer, 'w', ZIP_DEFLATED) as archive:
    for item in sorted(root.rglob('*')):
        rel = item.relative_to(root)
        if not item.is_file() or item.is_symlink() or any(part in excluded for part in rel.parts):
            continue
        if (item.name.startswith('.env') and item.name != '.env.example') or item.suffix in {'.jks', '.keystore', '.p12', '.mobileprovision', '.zip'} or item.name in {'local.properties','.apple-client-secret'} or item.suffix=='.p8':
            continue
        archive.write(item, rel.as_posix())
output.write_bytes(buffer.getvalue())
with ZipFile(output) as archive:
    assert archive.testzip() is None
    assert json.loads(archive.read('package.json'))['version'] == '0.6.2'
    assert json.loads(archive.read('dist/version.json'))['version'] == '0.6.2'
    assert 'dist/sw.js' in archive.namelist()
print(output)
