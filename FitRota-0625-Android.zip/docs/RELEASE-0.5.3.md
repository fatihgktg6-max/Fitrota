# FitRota 0.5.3 — özel Google giriş testi

Sözleşme incelemesi beklenirken genel hesap girişini açmadan izinli Google hesaplarıyla web/PWA testi yapılabilir. Render'da iki yeni değişken gerekir: `FITROTA_ACCOUNT_TEST_MODE=true`, `FITROTA_TEST_EMAILS` tam test e-postası. Hiçbir kişisel e-posta pakete sabitlenmedi.

Sunucu PKCE, çerez, origin ve kullanıcı başına veri sahipliği kontrollerini korur. Doğrulanmış Google kimliği, OAuth callback ve her korunan istekte izin listesiyle eşleşmelidir. Hatalı/boş liste, sahte metadata, doğrulanmamış kimlik ve farklı e-posta erişimi reddedilir. Özel testin ayrı onayı gerekir; taslak hukuki durum değişmez. AI hesabı doğrulayan aynı oturumu kullanır.

0.5.2 arayüz ve animasyon kaldırma değişiklikleri korunur. Native kaynaklardaki web varlıkları güncellenir; native OAuth etkin değildir. 30 mesaj/1 saat kotası, ödeme ve reklamlar hâlâ bu sürümde yoktur. Canlı GitHub/Render'a otomatik gönderilmez. Gerçek Google/Supabase/OpenAI uçtan uca testi kullanıcı ortamında beklenir.

Doğrulama: 50 birim/sunucu/yapılandırma testi ve iki tarayıcı akışı geçti. Tarayıcı akışları özel test onayını, Google-only girişini, reddedilen hesaba mesajı, kodsuz AI bağlantısını, yeniden yükleme ve oturum iptalini sahte sağlayıcılarla doğrular. Derleme başarılı. Native web varlıkları dosya kopyasıyla güncellendi; imzalı paket veya cihaz testi yapılmadı.
