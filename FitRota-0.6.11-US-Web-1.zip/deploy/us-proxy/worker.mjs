// Optional country-aware gateway. Deploy only after updating the public origin,
// provider disclosures and OAuth redirect configuration. No request-body logging.
export function createCountryGateway(fetcher=fetch){return async function(request,env){
 const fail=(status,error)=>Response.json({error},{status,headers:{'Cache-Control':'no-store','Referrer-Policy':'no-referrer'}});
 let origin;try{origin=new URL(env.FITROTA_ORIGIN);}catch{return fail(503,'origin_not_configured');}
 if(origin.protocol!=='https:'||origin.hostname!=='fitrota.onrender.com'||origin.pathname!=='/'||origin.username||origin.password||origin.search||origin.hash)return fail(503,'invalid_origin');
 if(typeof env.FITROTA_COUNTRY_PROXY_SECRET!=='string'||env.FITROTA_COUNTRY_PROXY_SECRET.length<32)return fail(503,'proxy_secret_not_configured');
 const incoming=new URL(request.url),publicInfo=incoming.pathname.startsWith('/legal/')||incoming.pathname==='/healthz';
 // request.cf is supplied by the Cloudflare runtime, not a visitor HTTP header.
 const country=request.cf?.country;
 if(!publicInfo&&country!=='US')return fail(403,'market_not_available');
 const target=new URL(origin);target.pathname=incoming.pathname;target.search=incoming.search;
 const headers=new Headers(request.headers);
 headers.delete('x-fitrota-country');headers.delete('x-fitrota-proxy-token');headers.delete('cf-ipcountry');
 headers.set('x-fitrota-country',country==='US'?'US':'UNKNOWN');headers.set('x-fitrota-proxy-token',env.FITROTA_COUNTRY_PROXY_SECRET);
 headers.delete('host');
 const forwarded=new Request(target,{method:request.method,headers,body:['GET','HEAD'].includes(request.method)?undefined:request.body,redirect:'manual',duplex:'half'});
 try{const result=await fetcher(forwarded,{redirect:'manual',cf:{cacheEverything:false,cacheTtl:0}});
  const responseHeaders=new Headers(result.headers);responseHeaders.delete('x-fitrota-proxy-token');
  // Health/account responses are never cached by this gateway.
  if(!/^\/app-[a-f0-9]{16}\.js$|^\/catalog\/[a-f0-9]{16}\.json$/.test(incoming.pathname))responseHeaders.set('Cache-Control','no-store');
  return new Response(result.body,{status:result.status,headers:responseHeaders});
 }catch{return fail(502,'origin_unavailable');}
};}
export default {fetch:(request,env)=>createCountryGateway()(request,env)};
