"""Build 139,250 barcode-distinct records from USDA's April 2026 public dataset.
Download https://fdc.nal.usda.gov/fdc-datasets/FoodData_Central_branded_food_json_2026-04-30.zip
as research/branded.zip. Uses gram-labelled products with energy and all macros.
Original descriptions, FDC IDs, source dates and serving weights are preserved.
"""
from pathlib import Path
from zipfile import ZipFile
import json, math, re, ast, hashlib
root=Path(__file__).resolve().parent.parent
source=root/'research/branded.zip'
tree=ast.parse((root/'scripts/build-usda-foods.py').read_text())
words=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='words' for t in n.targets))
fields={1008:('kcal','kcal'),1003:('protein','g'),1005:('carbs','g'),1004:('fat','g'),1079:('fiber','g'),2000:('sugar','g'),1258:('saturatedFat','g'),1253:('cholesterol','mg'),1093:('sodium','mg'),1092:('potassium','mg'),1087:('calcium','mg'),1089:('iron','mg')}
limits={'kcal':900,'protein':100,'carbs':100,'fat':100,'fiber':100,'sugar':100,'saturatedFat':100,'cholesterol':3000,'sodium':40000,'potassium':20000,'calcium':20000,'iron':500}
seen=set();names=set();out=[]
with ZipFile(source) as z:
 with z.open(z.namelist()[0]) as stream:
  for line in stream:
   line=line.strip().rstrip(b',')
   if not line.startswith(b'{"foodClass"'):continue
   p=json.JSONDecoder().raw_decode(line.decode())[0]
   barcode=str(p.get('gtinUpc',''));description=p.get('description','').strip();brand=p.get('brandName') or p.get('brandOwner','')
   date=p.get('publicationDate','');year=int(date.split('/')[-1]) if '/' in date else 0
   # Select published records from 2020 onward, omit liquid volumes rather than guess density.
   if year<2020 or p.get('servingSizeUnit','').lower()!='g' or not re.fullmatch(r'\d{8}|\d{12,14}',barcode) or barcode.lstrip('0') in seen or not description:continue
   n={v[0]:None for v in fields.values()}
   for r in p.get('foodNutrients',[]):
    nu=r.get('nutrient',{});spec=fields.get(nu.get('id'));v=r.get('amount')
    if spec and nu.get('unitName','').lower()==spec[1] and isinstance(v,(float,int)) and math.isfinite(v) and 0<=v<=limits[spec[0]]:n[spec[0]]=v
   if any(n[k] is None for k in ['kcal','protein','carbs','fat']):continue
   key=(description.casefold(),brand.casefold(),tuple(n[k] for k in ['kcal','protein','carbs','fat']))
   if key in names:continue
   tr=description.lower()
   for word,translation in words:tr=re.sub(r'\b'+re.escape(word)+r'\b',translation,tr)
   f={'id':'branded-'+str(p['fdcId']),'code':str(p['fdcId']),'name':[description.title(),description],'aliases':tr,'brand':brand,'barcode':barcode,'unit':'g','source':'branded','sourceURL':'https://fdc.nal.usda.gov/food-details/'+str(p['fdcId'])+'/nutrients','publishedAt':date,**n}
   size=p.get('servingSize')
   if isinstance(size,(float,int)) and 0<size<=2000:f['portionGrams']=size;f['portionLabel']=p.get('householdServingFullText','')
   seen.add(barcode.lstrip('0'));names.add(key);out.append(f)
   if len(out)==139250:break
assert len(out)==139250,len(out)
(root/'src/branded-foods.js').write_text('// USDA FoodData Central Branded, April 2026 download. Public-domain data. 139,250 distinct barcodes; original descriptions retained.\nexport const brandedFoods='+json.dumps(out,ensure_ascii=False,separators=(',',':'))+';\n')
(root/'docs/BRANDED-DATA.json').write_text(json.dumps({'source':'https://fdc.nal.usda.gov/fdc-datasets/FoodData_Central_branded_food_json_2026-04-30.zip','sha256':hashlib.file_digest(source.open('rb'),'sha256').hexdigest(),'records':len(out),'selection':'First 139250 gram-based records published 2020 or later with complete macros; unique normalized barcode and unique name+brand+macros; dataset order. Not a Turkish-market catalogue. Check current package label.','attribution':'USDA FoodData Central; public-domain/CC0 data.'},indent=2))
print('Generated',len(out),'distinct branded records')
