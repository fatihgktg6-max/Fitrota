# FitRota 0.6.9 — veri akışı ve güvenlik incelemesi

Tarih: 5 Ekim 2026. İncelenen temel paket: FitRota-Giris-Duzeltme.zip (0.6.8). Bu dosya, düzenlenmiş 0.6.9 kodunun teknik bulgularını ve işletmecinin tamamlaması gereken işleri açıklar. Hukuki uygunluk belgesi veya sağlayıcılarla imzalanmış sözleşme değildir. Canlı hizmetin ortam değişkenleri, bölgesi, günlükleri ve veritabanı politikaları bu çalışmada yetkili panelden denetlenmedi. Testlerde sahte sağlayıcılar kullanıldı; gerçek kullanıcı kayıtları dış servislere gönderilmedi.

## Sağlayıcıya göre veri envanteri

| Alıcı | Gönderilen/işlenen bilgiler | Ne zaman? | Kod kanıtı |
| --- | --- | --- | --- |
| Render / FitRota sunucusu | Sayfa/API bağlantısı, IP ve teknik bağlantı bilgileri; OAuth dönüş kodu ve state; Supabase oturum belirteçleri; girişte hesap kimliği/e-posta; etkin hizmete göre AI mesajları, bulut kaydı, ürün araması, üyelik ve görev istekleri | Siteyi açmak bile sunucu bağlantısı kurar. Diğer içerikler yalnız ilgili hizmet kullanıldığında | server/index.mjs, server/accounts.mjs |
| Supabase Auth | Google kimliği, e-posta, doğrulama durumu; sağlayıcının temel profil kapsamından ad/fotoğraf gibi kimlik metadatası gelebilir; oturumlar ve kimlik doğrulama teknik kayıtları | Google ile giriş ve oturum yenileme/doğrulama | accounts.mjs: authorize, token, user; yönetilen Google sağlayıcısının gerçek kapsamı ayrıca kontrol edilmeli |
| Supabase veritabanı | Hesap UUID'sine bağlı profil (takma ad, yaş, boy, kilo, cinsiyet/formül seçimi, hedefler, ekipman, beslenme/alerjen/sağlık tercihleri), öğün ve su kayıtları, antrenmanlar, ölçümler, takvim, planlar, alışveriş ve mutfak tercihleri | Manuel bulut kaydı veya ayrı otomatik yedek seçimi | accounts.mjs /account/data; src/privacy.js; database/001_accounts.sql |
| Supabase veritabanı — ek özel içerik | AI sohbet geçmişi ve özel günlük notları | Yalnız ek sohbet/not yedeği seçimi. Varsayılan kapalı | includePrivateDetails isteği, cloudPrivateDetails ayarı |
| Supabase — diğer kayıtlar | AI kota kullanım sayısı/istek rezervasyonu ve zamanları; hediye kodu özeti ve hesap bağlantısı; görev kayıtlarında tarih, saat dilimi, sabit antrenman günleri ve tamamlanma işaretleri; ortak ürün katkısı/bildiriminde hesap kimliği | AI kotası, hediye kullanımı, isteğe bağlı görevler, ortak besin paylaşımı | quota.mjs, gifts.mjs, billing.mjs, database SQL dosyaları |
| OpenAI | Yazılan son kullanıcı mesajı ve sınırlı sohbet geçmişi (istemcide son 12 mesaj), dil ve koç modu, uygulamanın genel özellik bilgisi | Kullanıcı AI mesajı gönderdiğinde | app.js sendChat; ai-client.js; server/ai.mjs |
| OpenAI — ayrı profil izni | Hedef, ekipman, diyet, alerjenler, sağlık kısıtı işareti, süre ve en fazla 10 hareketlik kısa plan | coachProfileConsent / shareProfile açık olduğunda | experience.js; server/ai.mjs allowlist |
| OpenAI — ayrı gelişim izni | Son 7 günlük kalori/protein/su/antrenman özeti, günlük kalori hedefi, bütçe, mutfak serbest metni, bugünkü öğün planı | coachContextConsent / shareProgress açık olduğunda | experience.js; server/ai.mjs |
| OpenAI — uyku formu | Kullanıcının seçtiği yatış/kalkış saatleri, uyuduğunu bildirdiği süre, günlük düzen, uykululuk, kafein ve profil yaşından üretilen yaş grubu | Uyku formundaki ayrı onay ve gönderim | app.js sleepRequest / showSleepCoach |
| Google giriş | OAuth istemcisi ve yönlendirme bilgisi, giriş/hesap seçimi, IP/cihaz bağlantısı; temel kimlik kapsamı | Kullanıcının Google'a yönlendirildiği giriş | accounts.mjs; Supabase Google Auth |
| Google AdSense / CMP | Reklam veya tercih hizmeti yüklenirse IP, cihaz/tarayıcı, sayfa ve çerez/onay bilgileri; yayıncı ve reklam alanı kimlikleri | Reklamlar sunucuda etkin ve onaylıysa, kullanıcı reklam tercihini açar; reklam isteği ayrıca izin kontrolünden sonra | src/ads.js, server/ads.mjs |
| RevenueCat / ödeme sağlayıcısı | Hesap UUID'si, ürün/paket ve abonelik durumu. Web ödeme URL'si hesabı içerir. Kart ve mali bilgiler harici ödeme ekranında sağlayıcı tarafından işlenir | Üyelik hizmeti etkinse doğrulama/satın alma | server/billing.mjs; revenuecat-client.js; native SDK |
| Open Food Facts | Besin/marka/barkod arama metni ve FitRota sunucusunun bağlantı bilgileri | Kullanıcı çevrimiçi ürün aramasını seçince | server/food-lookup.mjs |
| Spotify / YouTube / kaynak siteleri | Dış bağlantıya gidildiğinde ilgili arama sorgusu ve kullanıcı bağlantısı; ilgili site hesabı açıksa o hizmetin kendi kayıtları | Kullanıcı dış bağlantıyı açınca | upgrade.js musicCard; kaynak bağlantıları |

Google şifresi FitRota'ya ulaşmaz. FitRota tarayıcı arayüzüne hesap UUID'si, e-posta ve sağlayıcı adı döndürülür; Google temel profil metadatasının Supabase tarafında bulunmadığı sonucuna varılamaz. Uygulama Google Drive, Gmail veya Google Calendar içeriği istemiyor; gerçek Google Cloud/Supabase kapsam listesi panelde ayrıca doğrulanmalı.

OpenAI'ye hesap UUID'si/e-posta/ad/ham ölçüm geçmişi uygulama tarafından otomatik eklenmez. Buna rağmen serbest mesaj ve mutfak alanı kişisel veri içerebilir. Diyet, alerjenler ve gelişim özetleri sağlıkla ilgili çıkarımlara elverişlidir. Bu akış anonim sayılmaz.

## Bu sürümde yapılan düzenlemeler

1. AI profil paylaşımı artık gelişim paylaşımından ayrı, varsayılan kapalı bir seçim. Sunucu, shareProfile açık değilse sağlık/alerjen/diyet/plan alanlarını sağlayıcı isteminden çıkarıyor. Genel uygulama bilgisi kişisel kayıt gerektirmeden koça ulaşmaya devam ediyor.
2. Bulut sohbetleri ve özel günlük notları varsayılan olarak dışarıda. Ek seçim istekte açıkça belirtilmediğinde sunucu, istemci ayarına güvenmeden bunları temizliyor. Otomatik ve manuel kayıt aynı azaltma işlevini kullanıyor. Diğer profil/sağlık kayıtları bulut yedeğine dahil; bu yedek anonim veya sağlayıcının okuyamayacağı uçtan uca şifreli bir yedek değildir.
3. Bulut kopyasından AI/bulut paylaşım tercihleri yüklenmiyor. Geri yükleme kullanıcının bu cihazdaki güncel seçimlerini koruyor. Sohbet/notları içermeyen kopya geri yüklenince yerel sohbet/notlar korunuyor.
4. Buluta dahil edilen sohbetlerde tanımlı alan listesi kullanılıyor; içe aktarılmış bilinmeyen sohbet alanları aktarılmıyor.
5. Google için gereksiz provider_refresh_token oturum çerezinde tutulmuyor. Supabase erişim/yenileme belirteçleri oturumun sürmesi için HttpOnly, AES-GCM ile şifrelenmiş çerezde kalıyor. Bu, bulut içeriği için uçtan uca şifreleme değildir.
6. Sunucu Referer başlığını no-referrer yapıyor; OAuth dönüş URL'si dış sayfalara Referer olarak taşınmıyor. Çerçeve içine gömme yasaklandı; kamera/mikrofon/konum izinleri kapatıldı.
7. OpenAI ve Supabase kota isteklerinde HTTP yönlendirme izlenmiyor. Diğer sağlayıcı isteklerinde mevcut redirect:error kontrolü korundu.
8. Açıkça girilmiş hatalı CMP adresi varsa reklam yapılandırması kapalı kalıyor; sessizce başka adrese geçmiyor. İlk sayfa yüklenişinde reklam dış kodu yüklenmemesi, onaydan önce reklam istenmemesi ve Premium'da reklam kaldırılması test edildi.
9. Yeni aktarımları durdurmak için ayrı sunucu anahtarları eklendi: FITROTA_ACCOUNT_ENABLED=false ve FITROTA_AI_ENABLED=false. Eski verileri silmezler; oturum/giriş veya AI hizmetini durdururlar. Mevcut anahtarlar FITROTA_ADS_ENABLED=false, FITROTA_BILLING_ENABLED=false, FITROTA_FOOD_LOOKUP=false.
10. Aydınlatma sürümü 2026-10-05. AI sağlık bağlamı, serbest metin, bulut ek seçimleri, şifreleme sınırı ve OpenAI güvenlik kaydı ayrımı açıklandı.

## Saklama, silme ve onay sınırları

- Yerel kayıtlar localStorage içindedir; cihaz hesabı veya aynı origin'deki kod erişimini ayrı bir işletim sistemi kasası gibi engellemez. Sağlık profili için cihazın güvenliği önemlidir.
- Sohbet/not yedeğini kapatmak eski Supabase kopyasını o anda silmez. Yeni azaltılmış yedek kaydet veya bulut yedeğini sil. Yeni sürüme geçince eski bulut içeriği kendiliğinden tüm sağlayıcı yedeklerinden silinmiş olmaz.
- AI profil/gelişim seçimlerini kapatmak sonraki bağlamı durdurur ve arayüzde yürüyen isteği iptal eder; sağlayıcıya ulaşmış isteği veya son sohbet metninde zaten bulunan bilgiyi geri almaz. Önceki metnin yeniden gönderilmesini istemiyorsan sohbeti de temizle.
- OpenAI istekleri /v1/responses ve store:false kullanıyor. Bu, Responses uygulama durumunu saklamama talebidir; varsayılan kötüye kullanım kayıtlarını sıfırlamaz. API içerikleri varsayılan eğitim için kullanılmaz; kötüye kullanım kayıtları varsayılan olarak 30 güne kadar tutulabilir, hukuki istisnalar olabilir. Bu kuruluşta ZDR/MAM etkinliği doğrulanmadı.
- Supabase hesabı silme auth kullanıcısını siler; SQL'deki ON DELETE CASCADE ilişkilerinin canlıda çalışması, ortak katkı bağlantısının ayrılması, sağlayıcı yedek saklama ve ödeme kayıtlarının durumu ayrıca gerçek test ister.
- Uygulama kendi çalışma günlüğüne mesaj/profil/anahtar yazmıyor. Render/Supabase/Google'ın altyapı ve güvenlik günlükleri bundan bağımsızdır. IP ve callback sorgu dizelerinin platform kayıtlarında bulunma ihtimali incelenmeli; doğrulanmamış bir günlük saklama süresi verilmedi.
- NPA (kişiselleştirilmemiş reklam) çerezsiz veya verisiz demek değildir. Üçüncü taraf reklam kodu uygulama origin'inde çalışır; hedefleme alanına sağlık kaydı eklememek tek başına script erişim izolasyonu sağlamaz. Kamuya açılışta reklamı kapalı tutmak veya sağlık kayıtlarının bulunmadığı ayrı origin/sayfaya taşımak değerlendirilmelidir. Google Auto Ads açılmamalı: uygulamanın Premium'da reklam kaldırma kuralını aşabilir.

## Hukuki olarak açık kalan işler ve uygulanabilir yollar

Düzenli Google/Supabase girişleri, yedekler, OpenAI çağrıları ve dış ülkedeki sunucu bağlantıları için her alıcı ve veri türüne göre KVKK 5/6 işleme şartı ile 9. madde aktarım mekanizması belirlenmeli. Kullanıcının tek bir 'yurt dışı paylaşımını kabul ediyorum' kutusu, tekrarlanan aktarımı kendiliğinden hukuka uygun yapmaz. Özel test modu da otomatik hukuki istisna değildir.

A. Mevcut sağlayıcılarla devam: gerçek bölgeler/alt işleyenler, veri sorumlusu–veri işleyen rolleri ve özel nitelikli veri tedbirleri doğrulanır; uygulanabilir uygun güvence kurulup belgelenir. Türk standart sözleşmesi kullanılacaksa doğru modül, yetkili imzalar ve beş iş günü bildirim gerekir. Genel GDPR DPA veya AB SCC tek başına Türk standardının imzalandığını göstermez. OpenAI desteğinin imzalayamayacağını söylemesi tüm hukuk mekanizmalarını tükettiğimizi göstermez; fakat mevcut imza varmış gibi de yayınlanamaz.

B. Aktarımı gerçekten azaltacak mimari: Türkiye'de sunucu ve veritabanı, yerel hesap sistemi, cihazda çalışan planlayıcı/AI; Google girişi, OpenAI, reklam ve uluslararası ödeme/veri hizmetleri ilgili dayanak tamamlanana kadar kapalı. Yalnız OpenAI'yi kapatıp yabancı Render/Supabase'i bırakmak Türkiye dışına aktarımı kaldırmaz. Türkiye'deki barındırmanın yedek/alt işleyen/uzaktan destek akışları da kontrol edilmeli. Bu alternatifin taşıma işlemi bu paketle tamamlanmış değildir; yeni sağlayıcı, bölge ve işletmeci bilgileri gerekir.

C. Irreversible anonymization: kimlik/ad silmek veya UUID ile değiştirmek yeterli değil. Serbest metin ve küçük sağlık özetleri yeniden tanımlama ihtimali taşır. Mevcut sohbet akışı için 'anonimleştirdik, sözleşme gerekmez' iddiası kullanılmamalı.

İşletmecinin tamamlaması gerekenler: tam veri sorumlusu adı/unvanı ve adresi, başvuru iletişimi, gerçek bölgeler/alt işleyenler, işleme/aktarım dayanakları, saklama ve yedek silme süreleri, başvuru/ihlal prosedürü, özel nitelikli veri değerlendirmesi, ödeme/abonelik işletmeci koşulları ve gerçek hizmet testi. FITROTA_LEGAL_REVIEWED=true bu işlerin yerine geçen bir belge değil; yalnız tamamlandıktan sonra kullanılan yazılım anahtarıdır.

## Dağıtım

GitHub'a FitRota-0.6.9-Veri-Guvenligi.zip yükle. Render Build Command:

```sh
python3 -m zipfile -e FitRota-0.6.9-Veri-Guvenligi.zip . && npm ci --include=dev && npm run build
```

Start Command: npm run server. FITROTA_SESSION_SECRET değerini değiştirme; değiştirmek mevcut oturumları geçersiz kılar. Yeni SQL gerekmez; mevcut SQL/RLS kurulumunun gerçekten uygulanmış olması gerekir. Eski kaynak ZIP'lerindeki dosyaların dağıtımda yanlışlıkla çalışmadığını version.json ve yeni hash ile doğrula. Bu paketin hazırlanması canlı sitenin güncellendiği anlamına gelmez.

## Kaynaklar

- KVKK güncel aktarım rejimi: https://www.kvkk.gov.tr/Icerik/2053/Yurtdisina-Aktarim
- Standart sözleşme imza/bildirim koşulları: https://www.kvkk.gov.tr/Icerik/8170/Yurt-Disina-Kisisel-Veri-Aktariminda-Kullanilacak-Standart-Sozlesmelerde-Dikkat-Edilmesi-Gereken-Hususlara-Iliskin-Kamuoyu-Duyurusu
- OpenAI veri kontrolleri: https://developers.openai.com/api/docs/guides/your-data
- Supabase Google kapsamları: https://supabase.com/docs/guides/auth/social-login/auth-google
- Render günlükler: https://render.com/docs/logging

Bu kaynaklar 5 Ekim 2026'da kontrol edildi. Sağlayıcı genel belgeleri, FitRota kuruluşunun canlı yapılandırmasının kanıtı değildir.

## Doğrulama sonucu

- 43 odaklı sunucu/hesap/AI/kota/yapılandırma/gizlilik testi geçti.
- npm test temel uygulama, beslenme, içerik ve antrenman test zinciri geçti.
- Tarayıcıda yeni profil paylaşımı açma/kapama, gerçek istek gövdesinde izin verilmeyen bağlamın bulunmaması, varsayılan sohbet/not yedeği azaltması ve geri yükleme tercihlerinin korunması geçti.
- Özel Google test girişi arayüzü, reklam onay/red/Premium kaldırma ve otomatik bulut kayıt/offline tekrar/çatışma/geri yükleme testleri geçti. Sağlayıcılar sahteydi; gerçek Google/OpenAI/ödeme entegrasyonu için canlı testin yerini tutmaz.
- 0.6.9 üretim derlemesi başarılı. ZIP bütünlük kontrolü başarılı; node_modules, dist, çalışma günlükleri ve gerçek .env dosyaları pakete alınmaz.

## İşletmeci bilgileri güncellemesi

Kullanıcının verdiği kamuya açık işletmeci adı Fatih Göktuğ Pamukçu, gizlilik e-postası fitrotaaa@gmail.com ve konum Türkiye, Adana/Çukurova olarak eklendi. Konum tam posta teslim adresi değildir; FITROTA_LEGAL_ADDRESS doldurulmadı ve genel yayın uygunluk anahtarı açılmadı. Mevcut Render ortam değişkenleri kod varsayılanlarının önüne geçer.

## Dağıtım bölgesi bilgisi

5 Ekim 2026: İşletmeci Render panelindeki bölgeyi Frankfurt (EU Central), Almanya olarak bildirdi. Bu bilgi kullanıcı tarafından sağlanmıştır; panel tarafımızdan incelenmemiştir. Supabase veritabanı bölgesi henüz sağlanmadı. Render bölgesi, Google/OpenAI işleme konumunu veya alt işleyenlerin tüm konumlarını belirlemez.

5 Ekim 2026 ek bilgi: İşletmeci Supabase birincil veritabanı bölgesini Tokyo, Japonya olarak bildirdi. Render Almanya / Supabase Japonya bilgisi aydınlatmanın bölge bölümüne ve .env.example dosyasına işlendi. Canlı panel ayarları tarafımızdan değiştirilmedi; bölge bilgisi aktarım sözleşmesi veya yeterlilik kararı yerine geçmez.
