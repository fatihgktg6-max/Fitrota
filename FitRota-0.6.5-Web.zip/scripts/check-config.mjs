import {pathToFileURL} from 'node:url';
import {legalConfig} from '../server/legal.mjs';
import {accountTestConfig} from '../server/accounts.mjs';

// Offline configuration checks only. Never prints environment values or contacts providers.
export function checkConfig(env = process.env) {
  const results = [];
  const add = (id, ok, action) => results.push({id, ok: Boolean(ok), action});
  const present = key => Boolean(env[key]?.trim());
  const origin = value => {
    try { const u = new URL(value); return u.protocol === 'https:' && u.origin === value; }
    catch { return false; }
  };
  add('public-origin', origin(env.FITROTA_PUBLIC_ORIGIN), 'FITROTA_PUBLIC_ORIGIN: HTTPS site adresi, sonunda / olmadan.');
  add('allowed-origin', origin(env.FITROTA_PUBLIC_ORIGIN) && (env.FITROTA_ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).includes(env.FITROTA_PUBLIC_ORIGIN), 'FITROTA_ALLOWED_ORIGINS listesine sitenin tam adresini ekle.');
  add('supabase-url', origin(env.SUPABASE_URL), 'SUPABASE_URL: projenin HTTPS adresini gir.');
  for (const key of ['SUPABASE_PUBLISHABLE_KEY', 'SUPABASE_SERVICE_ROLE_KEY']) add(key, present(key), `${key}: yalnız sunucu ortamında tanımla.`);
  add('session-secret', (env.FITROTA_SESSION_SECRET || '').trim().length >= 32 && env.FITROTA_SESSION_SECRET !== env.FITROTA_ACCESS_CODE, 'FITROTA_SESSION_SECRET: erişim kodundan farklı, rastgele en az 32 karakter.');
  const providers = (env.FITROTA_AUTH_PROVIDERS || 'google').split(',').map(x => x.trim());
  add('providers', providers.length > 0 && providers.every(x => ['google', 'apple'].includes(x)), 'FITROTA_AUTH_PROVIDERS: google, apple veya google,apple.');
  if (providers.includes('apple')) for (const key of ['APPLE_CLIENT_ID', 'APPLE_CLIENT_SECRET']) add(key, present(key), `${key}: Apple hesap silme/bağlantı iptali için gerekli.`);
  if(env.FITROTA_ACCOUNT_TEST_MODE==='true'){
    add('private-test-access', accountTestConfig(env).enabled, 'FITROTA_TEST_EMAILS: en fazla 10 tam e-posta; yalnız doğrulanmış Google kimlikleri kabul edilir.');
    add('private-test-provider', providers.every(x=>x==='google'), 'Özel testte FITROTA_AUTH_PROVIDERS=google kullan. Bu mod genel yayın için değildir.');
  }else add('legal-details', legalConfig(env).ready, 'İşletmeci, adres, e-posta, saklama metni ve gerçek hukuki inceleme tamamlanmalı.');
  for (const key of ['OPENAI_API_KEY', 'OPENAI_MODEL']) add(key, present(key), `${key}: AI pilotu için sunucuda tanımla.`);
  add('pilot-code', (env.FITROTA_ACCESS_CODE || '').trim().length >= 32, 'FITROTA_ACCESS_CODE: rastgele en az 32 karakter.');
  add('daily-limit', /^[1-9]\d*$/.test(env.FITROTA_DAILY_CALL_LIMIT || ''), 'FITROTA_DAILY_CALL_LIMIT: pozitif tam sayı gir.');
  add('persistent-usage', present('FITROTA_USAGE_FILE'), 'FITROTA_USAGE_FILE: kalıcı özel diskteki sayaç dosyasını belirt; disk bağlantısını ayrıca doğrula.');
  return {ok: results.every(x => x.ok), results};
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const report = checkConfig();
  console.log('FitRota — yerel sunucu ayar kontrolü (gizli değerler gösterilmez)');
  for (const row of report.results) console.log(`${row.ok ? 'TAMAM' : 'EKSİK'}  ${row.id}${row.ok ? '' : ': ' + row.action}`);
  console.log('\nBu kontrol anahtarların geçerliliğini, sağlayıcı ayarlarını, SQL/RLS çalışmasını veya hukuki uygunluğu doğrulamaz.');
  console.log('Google/Apple gerçek hesap ve silme testi, yerel mobil giriş, kullanıcı bazlı AI/ödeme doğrulaması ayrıca tamamlanmalıdır.');
  process.exitCode = report.ok ? 0 : 1;
}
