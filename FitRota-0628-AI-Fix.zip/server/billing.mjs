import {createPaddleService} from './paddle.mjs';
import {adConfig} from './ads.mjs';
// Only server-verified provider subscriptions or server-awarded gifts grant Premium.
import {createGiftService} from './gifts.mjs';
import {legalConfig} from './legal.mjs';
export const MONTHLY_PRICES=[{country:'TR',currency:'TRY',amount:49.99},{country:'US',currency:'USD',amount:2.99},{country:'EU',currency:'EUR',amount:2.99}];
export function createBillingService({env=process.env,fetcher=fetch,now=()=>Date.now()}={}){
 const gifts=createGiftService({env,fetcher});
 const paddle=createPaddleService({env,fetcher,now});
 const paddleEnabled=paddle.configured&&legalConfig(env).ready&&env.FITROTA_ACCOUNT_TEST_MODE!=='true';
 const enabled=env.FITROTA_BILLING_ENABLED==='true'&&legalConfig(env).ready&&env.FITROTA_ACCOUNT_TEST_MODE!=='true'&&!!env.REVENUECAT_SECRET_KEY;
 const entitlement=env.REVENUECAT_ENTITLEMENT||'fitrota_pro',products=(env.FITROTA_PREMIUM_PRODUCTS||'fitrota_premium_monthly,fitrota_premium_monthly:monthly,monthly,yearly,lifetime').split(',').map(x=>x.trim()).filter(Boolean),base=(env.SUPABASE_URL||'').replace(/\/$/,''),admin=env.SUPABASE_SERVICE_ROLE_KEY;
 const paymentURL=()=>{try{const u=new URL(env.FITROTA_WEB_PURCHASE_LINK);return u.protocol==='https:'&&u.hostname==='pay.rev.cat'&&/^\/[a-zA-Z0-9_-]+\/?$/.test(u.pathname)&&!u.search&&!u.hash&&!u.username&&!u.password?u:null;}catch{return null;}};
 const api=async(owner)=>{const r=await fetcher('https://api.revenuecat.com/v1/subscribers/'+encodeURIComponent(owner),{headers:{Authorization:'Bearer '+env.REVENUECAT_SECRET_KEY},redirect:'error',signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error('billing_unavailable');const d=await r.json();if(!d.subscriber||!d.subscriber.entitlements||!d.subscriber.subscriptions)throw Error('billing_unavailable');return d.subscriber;};
 async function rewards(owner,action='status',options={}){
  if(!base||!admin)throw Error('reward_database_not_ready');
  const r=await fetcher(base+'/rest/v1/rpc/fitrota_reward_cycle',{method:'POST',headers:{apikey:admin,Authorization:'Bearer '+admin,'Content-Type':'application/json'},body:JSON.stringify({p_user_id:owner,p_action:action,p_days:options.days||null,p_timezone:options.timezone||null,p_day:options.date||null,p_workout:options.workout===true,p_meal:options.meal===true,p_water:options.water===true}),redirect:'error',signal:AbortSignal.timeout(10000)});
  if(!r.ok)throw Error(r.status===404?'reward_database_not_ready':'reward_unavailable');const data=await r.json();if(!data||typeof data.enrolled!=='boolean')throw Error('reward_unavailable');return data;
 }
 async function purchaseStatus(owner){
  const free={owner,premium:false,adFree:false,unlimitedAI:false,source:null,expiresAt:null,managementURL:null};if(!enabled)return free;
  let gift,rewardError;try{gift=await rewards(owner);}catch(e){if(e.message!=='reward_database_not_ready')rewardError=e;}
  const giftExpiry=gift?.premiumUntil,validGift=Number.isFinite(Date.parse(giftExpiry))&&Date.parse(giftExpiry)>now();
  let sub;try{sub=await api(owner);}catch(e){if(validGift)return {...free,premium:true,adFree:true,unlimitedAI:true,source:'reward',expiresAt:giftExpiry};throw e;}
  const e=sub.entitlements[entitlement],record=e&&(sub.subscriptions[e.product_identifier]||Object.entries(sub.subscriptions).find(([id])=>id.startsWith(e.product_identifier+':')&&products.includes(id))?.[1]);
  const allowSandbox=env.FITROTA_REVENUECAT_SANDBOX==='true';
  const allowedRecord=r=>!!r&&(r.is_sandbox===false||allowSandbox&&r.is_sandbox===true)&&!r.refunded_at;
  const lifetimeProducts=(env.FITROTA_LIFETIME_PRODUCTS||'lifetime').split(',').map(x=>x.trim());
  const lifetime=!!e&&products.includes(e.product_identifier)&&lifetimeProducts.includes(e.product_identifier)&&e.expires_date===null&&Number.isFinite(Date.parse(e.purchase_date))&&Date.parse(e.purchase_date)<=now()&&
    (sub.non_subscriptions?.[e.product_identifier]||[]).some(r=>allowedRecord(r)&&r.purchase_date===e.purchase_date);
  const expiry=e&&[e.expires_date,e.grace_period_expires_date].map(v=>Date.parse(v)).filter(Number.isFinite).sort((a,b)=>b-a)[0];
  const active=lifetime||allowedRecord(record)&&products.includes(e.product_identifier)&&Number.isFinite(expiry)&&expiry>now();
  let managementURL=null;try{const u=new URL(sub.management_url);if(u.protocol==='https:'&&!u.username&&!u.password&&(u.hostname==='apps.apple.com'||u.hostname==='play.google.com'||u.hostname==='billing.stripe.com'||u.hostname==='customer-portal.paddle.com'||u.hostname.endsWith('.revenuecat.com')||u.hostname==='pay.rev.cat'))managementURL=u.href;}catch{}
  if(!active&&!validGift){if(rewardError)throw rewardError;return free;}const paidExpiry=active?expiry:0,until=Math.max(paidExpiry,validGift?Date.parse(giftExpiry):0);
  return {...free,premium:true,adFree:true,unlimitedAI:true,source:active?'purchase':'reward',expiresAt:lifetime?null:new Date(until).toISOString(),lifetime,managementURL:active?managementURL:null};
 }
 async function legacyStatus(owner){
  const [paid,gift]=await Promise.allSettled([purchaseStatus(owner),gifts.status(owner)]);
  const current=paid.status==='fulfilled'?paid.value:null;
  const until=gift.status==='fulfilled'?gift.value.premiumUntil:null;
  const valid=Number.isFinite(Date.parse(until))&&Date.parse(until)>now();
  if(current?.premium&&(current.lifetime||!valid||Date.parse(current.expiresAt)>=Date.parse(until)))return current;
  if(valid)return {owner,premium:true,adFree:true,unlimitedAI:true,source:'gift_code',expiresAt:until,lifetime:false,managementURL:current?.managementURL||null};
  if(paid.status==='rejected')throw paid.reason;
  if(gift.status==='rejected')throw gift.reason;
  return current;
 }
 async function status(owner){
  if(!paddleEnabled)return legacyStatus(owner);
  const results=await Promise.allSettled([legacyStatus(owner),paddle.status(owner)]);
  const active=results.filter(x=>x.status==='fulfilled'&&x.value?.premium).map(x=>x.value).sort((a,b)=>(b.lifetime?Infinity:Date.parse(b.expiresAt))-(a.lifetime?Infinity:Date.parse(a.expiresAt)));
  if(active.length)return active[0];
  const failed=results.find(x=>x.status==='rejected');if(failed)throw failed.reason;
  return {...results[0].value,hasSubscription:results[1].value.hasSubscription===true,managementURL:results[1].value.managementURL||results[0].value.managementURL};
 }
 return {enabled:enabled||paddleEnabled,paddle,config:(user)=>({enabled:enabled||paddleEnabled,giftCodesEnabled:gifts.enabled,webCheckout:paddleEnabled?paddle.allowed(user):enabled&&!!paymentURL(),...(paddleEnabled?{provider:'paddle',environment:paddle.environment}:{}),prices:paddleEnabled?paddle.publicConfig().prices:MONTHLY_PRICES,period:'month',features:['ad_free','unlimited_ai'],nativeCheckout:false,rewardMonths:2,giftMonths:1,adsEnabled:adConfig(env).enabled,ads:adConfig(env)}),status,rewards,redeemGift:gifts.redeem,
  checkout:(owner,user)=>{if(paddleEnabled)return paddle.checkout(user);if(!enabled||!paymentURL())throw Error('billing_not_configured');const u=paymentURL();u.pathname=u.pathname.replace(/\/$/,'')+'/'+encodeURIComponent(owner);u.searchParams.set('package_id',env.REVENUECAT_MONTHLY_PACKAGE||'$rc_monthly');return u.href;},
  premiumQuota:status=>({plan:'premium',unlimited:true,limit:null,used:0,remaining:null,blocked:false,resetAt:null,serverNow:new Date(now()).toISOString(),expiresAt:status.expiresAt,lifetime:status.lifetime===true})};
}
