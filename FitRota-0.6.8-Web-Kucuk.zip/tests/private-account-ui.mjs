import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {createCoachServer} from '../server/index.mjs';
let testConsent=null;
const service={enabled:true,session:async()=>null,handler:async(req,res)=>{
 if(!req.url.startsWith('/account/'))return false;
 const send=(data,status=200)=>{res.writeHead(status,{'Content-Type':'application/json'});res.end(JSON.stringify(data));};
 if(req.url==='/account/config')send({configured:true,testMode:true,legalReady:false,providers:['google']});
 else if(req.url==='/account/me')send({error:'signin_required'},401);
 else if(req.url==='/account/login'){let body='';for await(const chunk of req)body+=chunk;testConsent=JSON.parse(body).testConsent;send({error:'test_access_denied'},403);}
 else send({},404);
 return true;
}};
const origins=[];
const server=createCoachServer({allowedOrigins:origins,accountService:service,accessCode:'private-test-code-at-least-32-characters',apiKey:'mock',model:'mock'});
await new Promise(r=>server.listen(0,'127.0.0.1',r));origins.push('http://127.0.0.1:'+server.address().port);
const browser=await chromium.launch({args:['--no-sandbox']});
try{
 const p=await browser.newPage({viewport:{width:390,height:844}}),errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.goto('http://127.0.0.1:'+server.address().port);await p.locator('[data-action="demo"]').click();await p.evaluate(()=>showAccount());
 await p.waitForSelector('#account-terms');assert.match(await p.locator('#modal-root').textContent(),/Özel test/);assert.match(await p.locator('#account-terms').locator('..').textContent(),/Test taslaklarını/);
 assert.equal(await p.locator('[data-provider="apple"]').isDisabled(),true);assert.equal(await p.locator('[data-provider="google"]').isDisabled(),false);
 await p.locator('[data-provider="google"]').click();assert.equal(testConsent,null);
 await p.locator('#account-terms').check();await p.locator('[data-provider="google"]').click();await p.waitForFunction(()=>document.getElementById('toast').textContent.includes('izinli değil'));
 assert.equal(testConsent,true);assert.deepEqual(errors,[]);console.log('PASS: private-test notice, explicit consent, Google-only button and denied-access message. Mock provider.');
}finally{await browser.close();await new Promise(r=>server.close(r));}
