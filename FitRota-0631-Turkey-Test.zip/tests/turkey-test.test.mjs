import test from 'node:test';
import assert from 'node:assert/strict';
import {createCountryGateway} from '../deploy/us-proxy/worker.mjs';
import {createCoachServer} from '../server/index.mjs';
test('Turkey switch preserves US, excludes other countries, and requires trusted proxy',async()=>{
 const secret='test-secret-'.repeat(4);
 for(const enabled of [false,true]){
  const server=createCoachServer({accessCode:secret,launchMarket:'US',countryProxySecret:secret,turkeyTestEnabled:enabled,billingService:{},accountService:{handler:async(req,res)=>{if(req.url!=='/account/config')return false;res.end('{}');return true;}}});
  await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;
  try{
   const gateway=createCountryGateway(req=>fetch(base+new URL(req.url).pathname,{headers:req.headers}));
   for(const country of ['US','TR','DE',undefined]){
    const req=new Request('https://gateway.test/account/config',{headers:{'x-fitrota-country':'US'}});Object.defineProperty(req,'cf',{value:{country}});
    const result=await gateway(req,{FITROTA_ORIGIN:'https://fitrota.onrender.com',FITROTA_COUNTRY_PROXY_SECRET:secret,FITROTA_TURKEY_TEST_ENABLED:String(enabled)});
    assert.equal(result.status,country==='US'||enabled&&country==='TR'?200:403);
   }
   assert.equal((await fetch(base+'/account/config',{headers:{'x-fitrota-country':'TR'}})).status,403);
  }finally{await new Promise(r=>server.close(r));}
 }
});
