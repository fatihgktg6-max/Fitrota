import {mockQuotaService} from './quota-fixture.mjs';
import {test} from 'node:test';import assert from 'node:assert/strict';import {mkdtemp,rm} from 'node:fs/promises';import os from 'node:os';import path from 'node:path';import {createCoachServer} from '../server/index.mjs';
const code='fitrota-test-owner-code-at-least-32-chars';
async function setup(options={}){const dir=await mkdtemp(path.join(os.tmpdir(),'fitrota-api-')),origins=[];const server=createCoachServer({accessCode:code,apiKey:'test-placeholder-never-used',model:'mock-test',allowedOrigins:origins,ledgerFile:path.join(dir,'usage.json'),reply:async()=>({text:'Test provider reply',source:'openai'}),...options});await new Promise(r=>server.listen(0,'127.0.0.1',r));const base=`http://127.0.0.1:${server.address().port}`;origins.push(base);return {base,server,close:async()=>{await new Promise(r=>server.close(r));await rm(dir,{recursive:true,force:true});}};}
const post=(base,endpoint,data,token)=>fetch(base+endpoint,{method:'POST',headers:{'Content-Type':'application/json',Origin:base,...(token?{Authorization:`Bearer ${token}`}:{})},body:JSON.stringify(data)});
test('auth, session lifecycle, origin and request roles are enforced',async()=>{const app=await setup();try{let res=await post(app.base,'/session',{accessCode:'wrong'});assert.equal(res.status,401);res=await post(app.base,'/session',{accessCode:code});const s=await res.json();assert.ok(s.sessionToken);assert.equal(JSON.stringify(s).includes('test-placeholder'),false);res=await post(app.base,'/coach',{messages:[{role:'system',content:'bad'}]},s.sessionToken);assert.equal(res.status,400);res=await post(app.base,'/coach',{messages:[{role:'user',content:'hello'}]},s.sessionToken);assert.equal(res.status,200);assert.equal((await res.json()).text,'Test provider reply');res=await fetch(app.base+'/health',{headers:{Origin:'https://evil.example',Authorization:`Bearer ${s.sessionToken}`}});assert.equal(res.status,403);await fetch(app.base+'/session',{method:'DELETE',headers:{Authorization:`Bearer ${s.sessionToken}`}});res=await post(app.base,'/coach',{messages:[{role:'user',content:'hello'}]},s.sessionToken);assert.equal(res.status,401);}finally{await app.close();}});
test('missing provider configuration cannot claim connected',async()=>{const app=await setup({apiKey:''});try{const res=await post(app.base,'/session',{accessCode:code});assert.equal(res.status,503);assert.equal((await res.json()).error,'ai_not_configured');}finally{await app.close();}});
test('daily quota persists across new sessions',async()=>{const app=await setup({dailyLimit:1});try{for(let i=0;i<2;i++){const s=await (await post(app.base,'/session',{accessCode:code})).json();const res=await post(app.base,'/coach',{messages:[{role:'user',content:'hello'}]},s.sessionToken);assert.equal(res.status,i===0?200:429);}}finally{await app.close();}});
test('expired session is rejected',async()=>{let time=Date.now();const app=await setup({now:()=>time});try{const s=await (await post(app.base,'/session',{accessCode:code})).json();time+=13*3600000;const res=await post(app.base,'/coach',{messages:[{role:'user',content:'hello'}]},s.sessionToken);assert.equal(res.status,401);}finally{await app.close();}});
test('remember cookie survives server restart, expires, rejects tampering and clears on logout',async()=>{
 let time=Date.now();let app=await setup({now:()=>time});let cookie;
 try{const res=await post(app.base,'/session',{accessCode:code,remember:true});cookie=res.headers.get('set-cookie');assert.match(cookie,/HttpOnly/);assert.match(cookie,/SameSite=Strict/);assert.equal(cookie.includes(code),false);cookie=cookie.split(';')[0];}finally{await app.close();}
 app=await setup({now:()=>time});
 try{let res=await fetch(app.base+'/session',{headers:{Cookie:cookie}});assert.equal(res.status,200);const token=(await res.json()).sessionToken;res=await fetch(app.base+'/session',{headers:{Cookie:cookie+'x'}});assert.equal(res.status,401);res=await fetch(app.base+'/session',{method:'DELETE',headers:{Cookie:cookie,Authorization:`Bearer ${token}`}});assert.match(res.headers.get('set-cookie'),/Max-Age=0/);res=await post(app.base,'/coach',{messages:[{role:'user',content:'hello'}]},token);assert.equal(res.status,401);time+=8*86400000;res=await fetch(app.base+'/session',{headers:{Cookie:cookie}});assert.equal(res.status,401);}finally{await app.close();}
});

test('account coach uses verified cookie identity, explicit consent and owner; no pilot code',async()=>{
 let signedIn=true,seen=0;const service={enabled:true,handler:async()=>false,session:async req=>signedIn&&req.headers.cookie==='fitrota_account=test'?{user:{id:'owner-one'}}:null};
 const app=await setup({accountService:service,quotaService:mockQuotaService(),reply:async()=>{seen++;return {text:'Account reply',source:'openai'};}});
 const call=async(extra={},payload={messages:[{role:'user',content:'hello'}],consent:true})=>fetch(app.base+'/account/coach',{method:'POST',headers:{Origin:app.base,'Content-Type':'application/json',Cookie:'fitrota_account=test','X-Fitrota-Owner':'owner-one',...extra},body:JSON.stringify(payload)});
 try{
  assert.equal((await (await fetch(app.base+'/coach-config')).json()).mode,'account');
  assert.equal((await fetch(app.base+'/account/ai-session',{headers:{Cookie:'fitrota_account=test'}})).status,200);
  assert.equal((await call({Cookie:''})).status,401);
  assert.equal((await call({'X-Fitrota-Owner':'other-owner'})).status,409);
  assert.equal((await call({Origin:'https://evil.test'})).status,403);
  assert.equal((await call({}, {messages:[{role:'user',content:'hello'}]})).status,400);
  assert.equal(seen,0);
  assert.equal((await call()).status,200);assert.equal(seen,1);
  signedIn=false;assert.equal((await call()).status,401);assert.equal(seen,1);
 }finally{await app.close();}
});
test('account coach does not bypass missing account setup or provider outage',async()=>{
 for(const [service,status] of [[{enabled:false,handler:async()=>false},503],[{enabled:true,handler:async()=>false,session:async()=>{throw Error('account_temporarily_unavailable');}},503]]){
  const app=await setup({accountService:service});try{assert.equal((await fetch(app.base+'/account/ai-session')).status,status);}finally{await app.close();}
 }
});

test('AI kill switch prevents external calls despite valid provider credentials',async()=>{
 let called=0;const app=await setup({aiEnabled:false,reply:async()=>{called++;return {text:'blocked',source:'openai'};}});try{const res=await post(app.base,'/session',{accessCode:code});assert.equal(res.status,503);assert.equal(called,0);assert.equal((await(await fetch(app.base+'/coach-config')).json()).configured,false);}finally{await app.close();}
});
