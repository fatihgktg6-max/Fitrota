import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {JSDOM,VirtualConsole} from 'jsdom';
test('production minified app boots with logo/phone and loads USDA search data on demand',async()=>{
 const root=new URL('../dist/',import.meta.url);let html=readFileSync(new URL('index.html',root),'utf8');
 html=html.replace(/<script src="(\/app-[a-f0-9]+\.js)" defer><\/script>/,(_,p)=>'<script>'+readFileSync(new URL(p.slice(1),root),'utf8').replace(/<\/script/gi,'<\\/script')+'</script>').replace('<script src="/pwa.js" defer></script>','');
 const errors=[],vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
 const dom=new JSDOM(html,{url:'https://app.fitrota.example/',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){w.structuredClone=structuredClone;w.scrollTo=()=>{};w.HTMLElement.prototype.scrollTo=()=>{};w.matchMedia=()=>({matches:false,addEventListener(){},removeEventListener(){}});w.ResizeObserver=class{observe(){}disconnect(){}};w.fetch=async url=>({ok:true,json:async()=>String(url).startsWith('/catalog/')?JSON.parse(readFileSync(new URL(String(url).slice(1),root),'utf8')):String(url)==='/account/config'?{configured:false}:{} });}});
 try{await new Promise(r=>setTimeout(r,40));const w=dom.window;assert.ok(w.document.querySelector('.login-phone'));assert.ok(w.document.querySelector('.fitrota-brand-logo'));assert.equal(w.eval('usdaFoods.length'),1);await w.eval('ensureFoodCatalog()');assert.ok(w.eval("foodHubPool().some(f=>f.source==='usda'&&f.id!=='usda-167715')"));assert.equal(w.eval('catalogState().status'),'ready');assert.deepEqual(errors,[]);}finally{dom.window.close();}
});
