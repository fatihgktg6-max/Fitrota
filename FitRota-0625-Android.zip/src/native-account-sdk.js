import {Capacitor,CapacitorHttp} from '@capacitor/core';
import {SocialLogin} from '@capgo/capacitor-social-login';
import {createNativeAccount} from './native-account.js';
if(Capacitor.getPlatform()==='android') {
  const client=createNativeAccount({http:CapacitorHttp,social:SocialLogin});
  window.FitrotaNativeAccount=client;
  const original=window.fetch.bind(window);
  window.fetch=async (input,options={})=>{
    if(typeof input!=='string')return original(input,options);
    const url=new URL(input,location.href);
    if(url.origin!==location.origin||!/^\/(account(?:\/|$)|catalog\/search|legal\/)/.test(url.pathname))return original(input,options);
    if(options.signal?.aborted)throw options.signal.reason;
    const pending=client.request(url.pathname+url.search,options);
    if(!options.signal)return pending;
    let cancel;
    const aborted=new Promise((_,reject)=>{cancel=()=>reject(options.signal.reason||new DOMException('Aborted','AbortError'));options.signal.addEventListener('abort',cancel,{once:true});});
    try{return await Promise.race([pending,aborted]);}finally{options.signal.removeEventListener('abort',cancel);}
  };
}
