# FitRota 0.6.17 — release candidate

Date: 2026-10-06. Prepared source package, not deployed in this session.

## Scope and status

| Request | Result |
|---|---|
| Premium refresh flicker | Membership and config fetch concurrently; pending/unavailable states replace incorrect upsells; verified membership renders immediately. No local flags grant Premium. Network verification still takes time. |
| New account starts journey | Setup opens after identity/cloud restoration if there is no profile. Guest sessions, existing profiles and account changes are covered. |
| Professional entry flow | English landing/sign-in, provider buttons, optional service consent in a collapsible section, legal links. Demo is only offered while signed out. |
| FitRota Google branding | Frontend brand is FitRota. Google consent branding/custom domain still requires account-owner setup below. |
| Public Apple login | Public server flow, PKCE and revocation support available; default provider discovery includes Apple only with required server credentials. Actual Apple/Supabase configuration and real-account validation remain outstanding. |
| US foods/900,000 | 16 sourced ingredient-based US recipes added. Turkish market records excluded from new searches/plans. 453,397 verified USDA US branded records; target of 900,000 and all-brand coverage NOT met. |
| US-only experience | US build forces English, hides language selection, migrates previous settings, keeps chosen units after initial US migration, English legal-page language and exercise repetitions. Historical personal records are retained. |
| Final audit | 113 automated checks passed. No guarantee of zero bugs. Visual/browser, real OAuth and deployed production verification remain outstanding. |

## Apple setup (owner action)

1. In Apple Developer, configure an App ID with Sign in with Apple, an associated Services ID for the web, and a Sign in with Apple signing key. Keep the `.p8` private.
2. Use the actual public app domain `fitrota-us-gateway.fatihgktg6.workers.dev` in the web configuration as appropriate. The return URL must be the **exact callback shown by Supabase's Apple provider**, normally `https://<project-ref>.supabase.co/auth/v1/callback`. Do not use the FitRota app URL as that provider callback.
3. Create the client-secret JWT with the Services ID, Team ID, Key ID and `.p8`. Existing `scripts/apple-secret.mjs` writes a 150-day secret to `server/.apple-client-secret` without printing it. Its input environment fields are `APPLE_TEAM_ID`, `APPLE_KEY_ID`, `APPLE_CLIENT_ID`, `APPLE_P8_PATH`. Never upload the private key or generated secret to GitHub or chat.
4. Enable Apple in Supabase Authentication providers and enter the Services ID and generated secret there.
5. In Render set `APPLE_CLIENT_ID`, `APPLE_CLIENT_SECRET`, and `FITROTA_AUTH_PROVIDERS=google,apple`. The public account flow must be configured; private Google-only test mode does not enable Apple. Do not claim legal review is complete just to open the public gate.
6. Leave FitRota's existing public origin and Supabase redirect allowlist aligned with the gateway. Verify real sign-in with a separate Apple account, Hide My Email, sign-out, refresh and account deletion/revocation.
7. Rotate the Apple web OAuth secret before expiry (Apple maximum six months). This release does not schedule automatic rotation.

No Apple Developer account, private key or provider-console credentials were available in this session, so public Apple sign-in has NOT been activated remotely.

## Google FitRota branding

In the Google Cloud project containing the OAuth client, open Google Auth Platform > Branding. Set the app name to **FitRota**, provide the actual support/developer email, logo and owned/approved homepage, privacy and terms URLs, and complete Google's applicable verification/publication requirements.

A random `project-ref.supabase.co` hostname can remain even after the displayed app name changes. Replacing that hostname requires a Supabase custom domain using a domain the operator owns, DNS and callback configuration; it cannot be renamed by changing frontend text. Do not simply replace `SUPABASE_URL` with an unconfigured domain. No domain purchase or paid plan change was made here.

Sources checked:
- https://supabase.com/docs/guides/auth/social-login/auth-google
- https://supabase.com/docs/guides/auth/social-login/auth-apple
- https://supabase.com/docs/guides/platform/custom-domains

## Food catalog and provenance

`docs/US-CATALOG.json` retains the verified record count and `targetMet:false`. The source is USDA FoodData Central's April 2026 branded-food export. Brand, barcode, source IDs and unknown nutrient values are preserved. Record counts do not promise current store availability or complete brand coverage. The 1,500-item browser seed is not the full catalog: the full SQLite catalog is prepared on Render and searched on the server.

US recipes in `src/us-recipes.js` sum recorded edible ingredient weights from CoFID 2021. The cereal example uses USDA SR Legacy FDC 167715; it explicitly names that reference and advises choosing the actual package for a brand label. Recipes are estimates. No synthetic brand variants or portion-duplicate inflation were added.

US market filtering keeps original recipe IDs available for existing diary entries and backups. Newly generated plans and recipe search exclude Turkish market recipes, including eggs with sucuk. Existing current/future automatic plans containing those recipes are regenerated when opened; past logged meals remain intact.

Open Food Facts bulk-source availability was researched; the count request returned HTTP 503. Existing explicit online lookup retains ODbL attribution and US filtering. This source was not imported into the counted catalog.

## Validation

- `npm test`: 44 tests across profiles, plans, diet/allergen filters, nutrition, history/backup, training, content and local AI behavior.
- 62 backend/US tests: accounts/config, Paddle signatures and SQL entitlements, billing/rewards/gifts, native billing adapter, shared-food lookup, public pricing/refunds, US gateway, catalog, water persistence and day rollover.
- `node --test tests/release617-dom.test.mjs`: 7 full-application DOM scenarios (guest, new-account setup, delayed Premium, English/market migration and screens, stale account responses/outage, cloud-profile restore, meal/water/measurement persistence).
- `npm run build:us`: success; displayed version comes from package.json.
- Real browser launch was blocked by the execution environment; jsdom does not establish pixel layout, iOS/Safari behavior or genuine OAuth success.

`npm run test:release617` rebuilds the US app and reruns the focused release gate. The full SQLite test additionally needs `python3 scripts/prepare-us-release.py`.

Paddle remains sandbox-only. Existing $3 sandbox subscriptions were not converted to the planned $2.99 live price. Real-money launch is a separate, uncompleted integration step.
