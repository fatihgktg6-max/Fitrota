import {build} from 'esbuild';
import {gzipSync} from 'node:zlib';
import {brandedFoods} from '../src/branded-foods.js';
import {legalConfig,legalDocuments} from '../server/legal.mjs';
import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {createHash} from 'node:crypto';
const root=fileURLToPath(new URL('../',import.meta.url));
await mkdir(path.join(root,'dist'),{recursive:true});
const modules=['food-data','expanded-foods','usda-foods','branded-foods','turkish-foods','snack-foods','restaurant-foods','supplements','catalog','science','legacy-food','core','shared-food','privacy','features','store','native','icons','ai-client','units','app','upgrade','services','layout','weekly-ui','food-hub','catalog-loader','food-fast','nutrition-plan','experience','ads','membership'];
const rcBundle=await build({entryPoints:[path.join(root,'src/revenuecat-sdk.js')],bundle:true,format:'iife',platform:'browser',target:'es2022',write:false,minify:true});
const sdkScript=rcBundle.outputFiles[0].text;
let script='';let webScript='';for(const name of modules){const source=await readFile(path.join(root,`src/${name}.js`),'utf8');const clean=source.replace(/^import .*?;\s*$/gm,'').replace(/^export /gm,'');script+=`\n// ${name}\n`+clean;webScript+=name==='branded-foods'?'\nconst brandedFoods=[];':`\n// ${name}\n`+clean;}
let bridge='';try{bridge=await readFile(path.join(root,'node_modules/@capacitor/core/dist/capacitor.js'),'utf8');}catch{}
const css=((await readFile(path.join(root,'src/style.css'),'utf8'))+'\n'+(await readFile(path.join(root,'src/layout.css'),'utf8'))).replace("@import url('');",'');
const license=await readFile(path.join(root,'docs/CAPACITOR-LICENSE.txt'),'utf8');
const favicon=await readFile(path.join(root,'public/icon.svg'),'utf8');
const catalogMetadata=JSON.parse(await readFile(path.join(root,'docs/US-CATALOG.json'),'utf8').catch(()=>'{}'));
const draftLegal={...legalConfig({FITROTA_LAUNCH_MARKET:process.env.FITROTA_LAUNCH_MARKET}),documents:legalDocuments(legalConfig({FITROTA_LAUNCH_MARKET:process.env.FITROTA_LAUNCH_MARKET}))};
const html=`<!doctype html><html lang="${process.env.FITROTA_LAUNCH_MARKET==='US'?'en-US':'tr'}"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#5267c9"><meta name="description" content="${process.env.FITROTA_LAUNCH_MARKET==='US'?'FitRota: fitness, nutrition and a routine that fits your life.':'FitRota: günlük hayatına uyum sağlayan spor ve beslenme yardımcın.'}"><title>FitRota</title><link rel="manifest" href="/manifest.webmanifest"><link rel="apple-touch-icon" href="/apple-touch-icon.png"><meta name="apple-mobile-web-app-capable" content="yes"><link rel="icon" href="data:image/svg+xml,${encodeURIComponent(favicon)}"><style>${css}</style></head><body><div id="app"></div><div id="modal-root"></div><div id="toast" role="status" aria-live="polite"></div><footer style="padding:16px;text-align:center;font-size:13px"><a href="/legal/privacy">Privacy</a> · <a href="/legal/health">Consumer Health Data Privacy Policy</a> · <a href="/legal/terms">Terms</a> · <a href="/legal/deletion">Delete data</a> · <button class="linkbtn" data-action="privacy-ad-settings">Do Not Sell or Share</button> · <a href="mailto:fitrotaaa@gmail.com">Contact</a></footer><script>/* ${license} */\n${bridge}</script><script>window.FITROTA_RELEASE=${JSON.stringify({market:process.env.FITROTA_LAUNCH_MARKET==='US'?'US':null})};window.FITROTA_LEGAL_FALLBACK=${JSON.stringify(draftLegal).replace(/</g,'\\u003c')};</script><script>${(sdkScript+script).replace(/<\/script/gi,'<\\/script')}</script></body></html>`;
const catalogFiles=[];await mkdir(path.join(root,'dist/catalog'),{recursive:true});
for(let i=0;i<brandedFoods.length;i+=5000){const json=JSON.stringify(brandedFoods.slice(i,i+5000)),id=createHash('sha256').update(json).digest('hex').slice(0,16),name=`/catalog/${id}.json`;catalogFiles.push(name);await writeFile(path.join(root,'dist',name),json);await writeFile(path.join(root,'dist',name+'.gz'),gzipSync(json));}
const webCode=sdkScript+webScript;
const appId=createHash('sha256').update(webCode).digest('hex').slice(0,16),appFile=`/app-${appId}.js`;
await writeFile(path.join(root,'dist',appFile),webCode);await writeFile(path.join(root,'dist',appFile+'.gz'),gzipSync(webCode));
const inline=`<script>${(sdkScript+script).replace(/<\/script/gi,'<\\/script')}</script>`;
const webHtml=html.replace(inline,`<script>window.FITROTA_CATALOG=${JSON.stringify({files:catalogFiles,count:catalogMetadata.records||brandedFoods.length,serverSearch:true,seedCount:brandedFoods.length})};</script><script src="${appFile}" defer></script>`).replace('</body>','<script src="/pwa.js" defer></script></body>');
await writeFile(path.join(root,'dist/index.html'),webHtml);
await writeFile(path.join(root,'index.html'),html);
for (const asset of ['manifest.webmanifest','icon-192.png','icon-512.png','apple-touch-icon.png','pwa.js']) await copyFile(path.join(root,'public',asset),path.join(root,'dist',asset));
const worker=await readFile(path.join(root,'public/sw.template.js'),'utf8');
const hash=createHash('sha256').update(webHtml+worker);
for (const asset of ['manifest.webmanifest','icon-192.png','icon-512.png','apple-touch-icon.png','pwa.js']) hash.update(await readFile(path.join(root,'public',asset)));
hash.update(webCode);const buildId=hash.digest('hex').slice(0,16);
await writeFile(path.join(root,'dist/sw.js'),worker.replace('__BUILD__',buildId).replace('__APP_FILE__',appFile));
await writeFile(path.join(root,'dist/version.json'),JSON.stringify({version:'0.6.11',build:buildId}));
await writeFile(path.join(root,'FitRota-Onizleme.html'),html);
if(process.env.FITROTA_LAUNCH_MARKET==='US'){const manifest=JSON.parse(await readFile(path.join(root,'dist/manifest.webmanifest'),'utf8'));manifest.lang='en-US';manifest.description='Fitness, nutrition and your daily routine, together.';await writeFile(path.join(root,'dist/manifest.webmanifest'),JSON.stringify(manifest));}
await copyFile(path.join(root,'public/icon.svg'),path.join(root,'dist/icon.svg'));
console.log(`Built offline standalone preview (${Math.round(Buffer.byteLength(html)/1024)} KB). No external resources required.`);
