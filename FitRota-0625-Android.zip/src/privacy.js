import {validateBackup} from './core.js';
// Shared client/server minimization. Opt-ins are never restored from a backup.
export function minimizeCloudPayload(value,includePrivateDetails=false){
 const payload=validateBackup(structuredClone(value));
 payload.chat=payload.chat.map(m=>Object.fromEntries(['id','role','text','displayText','at','source','delivery','incomplete'].filter(k=>Object.hasOwn(m,k)).map(k=>[k,m[k]])));
 if(!includePrivateDetails){payload.chat=[];payload.dayNotes={};}
 for(const key of ['autoCloud','accountAiConsent','servicesPrompted','coachPosition','coachContextConsent','coachProfileConsent'])delete payload.settings[key];
 payload.settings.cloudPrivateDetails=includePrivateDetails===true;
 return payload;
}
