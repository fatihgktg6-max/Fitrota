import {readdir,unlink,access} from 'node:fs/promises';
import path from 'node:path';
const root='android/app/src/main/assets/public';
await access(path.join(root,'index.html'));
async function clean(dir){for(const entry of await readdir(dir,{withFileTypes:true})){const full=path.join(dir,entry.name);if(entry.isDirectory())await clean(full);else if(/\.(gz|br)$/.test(entry.name))await unlink(full);}}
await clean(root);
console.log('Android web assets ready; compressed server copies removed.');
