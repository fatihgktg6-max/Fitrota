// Provider keys never enter this module. Only short-lived FitRota sessions do.
export function coachBaseUrl(value){
 const u=new URL(value);
 const loopback=['localhost','127.0.0.1','[::1]'].includes(u.hostname);
 if(u.protocol!=='https:'&&!(u.protocol==='http:'&&loopback))throw Error('https_required');
 if(u.username||u.password||u.search||u.hash||u.pathname!=='/')throw Error('invalid_server');
 return u.origin;
}
async function coachFetch(baseUrl,path,{token,owner,body,signal,method='POST'}={}){
 const combined=signal?AbortSignal.any([signal,AbortSignal.timeout(35000)]):AbortSignal.timeout(35000);
 let res;try{res=await fetch(coachBaseUrl(baseUrl)+path,{method,headers:{...(owner?{'X-Fitrota-Owner':owner}:{}),...(body?{'Content-Type':'application/json'}:{}),...(token?{Authorization:`Bearer ${token}`}:{})},...(body?{body:JSON.stringify(body)}:{}),signal:combined,credentials:'same-origin',cache:'no-store'});}catch(e){if(e.name==='TimeoutError')throw Error('timeout');if(e.name==='AbortError')throw e;throw Error('network_error');}
 let data;try{data=await res.json();}catch{throw Error('invalid_response');}
 if(!res.ok){const allowed=['signin_required','account_changed','account_temporarily_unavailable','account_not_configured','consent_required','unauthorized','session_expired','ai_not_configured','usage_limit','origin_not_allowed','provider_rate_limit','provider_error','timeout'];throw Error(allowed.includes(data.error)?data.error:'ai_unavailable');}return data;
}
export async function connectLiveCoach({baseUrl,accessCode,consent=false,remember=false}){
 if(!consent)throw Error('consent_required');
 if(!accessCode||accessCode.startsWith('sk-'))throw Error('access_code_required');
 const data=await coachFetch(baseUrl,'/session',{body:{accessCode,remember}});
 if(typeof data.sessionToken!=='string'||!Number.isFinite(Date.parse(data.expiresAt))||!data.configured)throw Error('invalid_response');
 return {baseUrl:coachBaseUrl(baseUrl),token:data.sessionToken,expiresAt:data.expiresAt};
}
export async function disconnectLiveCoach(connection){if(connection&&connection.mode!=='account')await coachFetch(connection.baseUrl,'/session',{token:connection.token,method:'DELETE'});}
export async function requestLiveCoach({baseUrl,sessionToken,owner,mode,messages,context,consent=false,signal}){
 if(!consent)throw Error('consent_required');if(mode==='account'){const result=await coachFetch(baseUrl,'/account/coach',{owner,body:{messages,context,consent:true},signal});if(typeof result.text!=='string'||!result.text.trim()||result.source!=='openai')throw Error('invalid_response');return result;}if(!sessionToken)throw Error('session_expired');
 let result,renewedSession;try{result=await coachFetch(baseUrl,'/coach',{token:sessionToken,body:{messages,context},signal});}catch(error){if(error.message!=='session_expired')throw error;const restored=await restoreLiveCoach(baseUrl);renewedSession=restored;result=await coachFetch(baseUrl,'/coach',{token:restored.token,body:{messages,context},signal});}
 if(typeof result.text!=='string'||!result.text.trim()||result.source!=='openai')throw Error('invalid_response');return {...result,...(renewedSession?{renewedSession}:{})};
}

export async function restoreLiveCoach(baseUrl){
 const data=await coachFetch(baseUrl,'/session',{method:'GET'});
 if(typeof data.sessionToken!=='string'||!Number.isFinite(Date.parse(data.expiresAt))||!data.configured)throw Error('invalid_response');
 return {baseUrl:coachBaseUrl(baseUrl),token:data.sessionToken,expiresAt:data.expiresAt};
}

export async function connectAccountCoach(baseUrl,consent=false){
 if(!consent)throw Error('consent_required');
 const data=await coachFetch(baseUrl,'/account/ai-session',{method:'GET'});
 if(!data.configured||data.mode!=='account'||typeof data.owner!=='string')throw Error('invalid_response');
 return {baseUrl:coachBaseUrl(baseUrl),mode:'account',owner:data.owner,expiresAt:new Date(Date.now()+3600000).toISOString()};
}
export async function coachServiceConfig(baseUrl){return coachFetch(baseUrl,'/coach-config',{method:'GET'});}
