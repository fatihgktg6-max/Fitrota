# FitRota 0.6.11 — ABD web sürümü

## Dosya ve Render komutları

GitHub'a **FitRota-0.6.11-US-Web.zip** yükle. ZIP kaynak kodunu içerir; 344 MB kamuya açık besin arama indeksi build sırasında hazırlanır. Eski ZIP dosyalarını build komutuna dahil etme.

Build Command:

```sh
python3 -m zipfile -e FitRota-0.6.11-US-Web.zip . && python3 scripts/prepare-us-release.py && npm ci --include=dev && npm run build:us
```

Start Command:

```sh
npm run server
```

Node sürümü 22.23.3 veya daha yeni olmalı (node:sqlite kullanılıyor). İlk build USDA'nın yaklaşık 195 MB arşivini indirir, SHA-256 doğrular ve ABD indeksini kurar. Build sırasında 3.3 GB JSON diske açılmaz, akışla işlenir. İndeks yaklaşık 344 MB disktir; tüm besinler telefon belleğine alınmaz. Başarılı build için çıkış interneti ve yeterli geçici disk gereklidir. İlk build önceki paketten uzun sürebilir. Yeniden oluşturulan indeksin SHA-256 değeri sürümle eşleşmezse yayın durur; kaynak değişikliği sessizce kabul edilmez.

## Yapılanlar

- İngilizce/ABD içerik, pound, inç, yiyecekte ons ve suda US fl oz. Makro besinler gram, enerji kcal olarak kalır: ABD besin etiketleri de bunları kullanır. Cihaz kayıtları ve hesaplamalar metrik tabanda kalır; eski kayıtların değerleri değişmez. İlk ABD geçişinde görüntüleme tercihleri değiştirilir; kullanıcı sonraki seçimlerini korur.
- Profil, ölçüm, antrenman yükü, besin miktarı, tarif malzemeleri ve alışveriş miktarları dönüştürülür. İnç alanında örneğin 70 in = 5 ft 10 in açıklaması vardır. Bilinmeyen yoğunluktan sıvı ons/gram veya cup hesabı yapılmaz.
- **453.397 ABD markalı USDA kaydı**; 1.500 kayıt küçük çevrimdışı başlangıç katalogunda, tam katalog sunucuda indeksli aramada. Marka/UPC/kaynak korunur. Sayı 900 bin değildir; güncel kaynağın sağlamadığı kayıtlar uydurulmadı. Her marka veya güncel mağaza bulunurluğu vaat edilmez. 953 eksik isim/markalı kayıt dışarıda bırakıldı; 5.448 kayıtta enerji bilinmiyor. Kaynak: docs/US-CATALOG.json.
- Etiket porsiyonları korunur. USDA sıvılardaki 100 g verileri 100 ml varsayılmaz; güvenilir üretici etiketinde porsiyon verisi varsa porsiyon üzerinden kaydedilir. Etiketin bildirmediği mikro değerler bilinmiyor kalır.
- Türkiye'ye özel üretici/restoran kayıtları ABD aramasından çıkarılır. İngilizce genel tarifler, kişisel etiketler ve kaynakları açık genel besinler kullanılabilir. Open Food Facts ABD filtreli isteğe bağlı ek arama sağlar; kullanıcı ürünü doğrulamalıdır.
- Üç günlük yemek hazırlığı, alışveriş listesi, evdeki malzemeler ve bütçe tercihleri pratik erişimle sunulur; mevcut diyet/alerjen kısıtları korunur. Bu bir sağlık veya alerjen uygunluk garantisi değildir.
- Google/Apple giriş altyapısı; Apple aşağıdaki gerçek panel ayarları olmadan etkinleşmez. Özel Google test modu Apple'ı açmaz.
- Hesap yapılandırması ve kimlik isteği eşzamanlıdır. Premium, bulut ve AI ek işlemleri ekranı engellemez. Premium tarayıcı verisinden verilmez; sunucu doğrulaması gerekir. Kimlik hatasında veri ve oturum ayrımı korunur.
- ABD İngilizce Privacy, Consumer Health Data Privacy Policy, Terms ve Deletion belgeleri. Sağlık verileri, kaynakları, sağlayıcılar, ayrı tercihler, geri çekme/silme/itiraz, yenileme/iptal ve veri ihlali bildirim yolları açıklandı. GPC ve reklamdan vazgeçme korunur.

## Gerçek yayın için panel işlemleri

1. Tam **posta adresi** gir: FITROTA_LEGAL_ADDRESS. Şu ana kadar sadece Türkiye, Adana/Çukurova verilmiştir; mahalle/sokak/bina/daire/posta kodu yerine uydurma adres konmadı. İşletmeci Fatih Göktuğ Pamukçu; iletişim fitrotaaa@gmail.com.
2. Render ortamında FITROTA_CONTENT_MARKET=US kullan. Bu içerik ve metin seçimi içindir, ülke engeli değildir. Sadece ABD erişimi için deploy/us-proxy içindeki gateway'i gerçekten kur; paylaşılan özel anahtarı iki sunucuda tanımla; **ondan sonra** FITROTA_LAUNCH_MARKET=US etkinleştir. Tek başına açılırsa erişim güvenli şekilde kapanır. Proxy eklenirse sağlayıcıyı ve gerçek konumlarını bölge/aktarım metinlerine ekle.
3. Açık site adresi değişirse Render public/allowed origin, Supabase site/redirect URL'leri ve Google marka URL'lerini birlikte güncelle. Direkt eski origin, sahte country header, ABD/dış-ABD/unknown konumlarını test et. VPN veya mevcut çevrimdışı PWA kopyalarının kusursuz engellendiği söylenmez.
4. Supabase 001–006 SQL dosyaları ve RLS gerçek projede uygulanmış olmalı. Hesap, yedek ve silme testini gerçek hesabınla yap. Bu çalışma sağlayıcı panellerini değiştirmedi.
5. Google'ın üretim durumunda bağımsız bir kullanıcıyla giriş/çıkış/geri dönüşü doğrula. Branding onayı ile OAuth yayın durumunu birbirine karıştırma.
6. Apple Developer hesabında Sign in with Apple ana App ID, web Services ID ve özel anahtarını oluştur. Supabase'de Apple provider'ı Services ID/client secret ile yapılandır. Supabase Apple callback URL'sini Apple return URL olarak kaydet. Render'da APPLE_CLIENT_ID, APPLE_CLIENT_SECRET ve FITROTA_AUTH_PROVIDERS=google,apple tanımla. .p8 ve secret dosyasını GitHub'a koyma. scripts/apple-secret.mjs yerel özel dosya üretebilir. JWT'nin geçerliliği sona ermeden yenile; Apple web OAuth secrets en fazla altı aylık geçerliliğe tabidir. Gizli/relay e-posta ve Apple hesap silme/authorization revoke testleri yapılmalı. Native iOS/Android girişleri bu web paketinin cihaz testi değildir.
7. AdSense **Ready** ve site/slot onayı gerekli. GPC, red ve Premium'da reklam yüklenmediğini gerçek ağ istekleriyle doğrula. Sağlık kayıtları içeren uygulama ile aynı origin'deki üçüncü taraf scriptleri ayrıca değerlendirilmelidir; reklamdan ayrı rıza almak tek başına script erişimini teknik olarak izole etmez. Ayrı origin reklam alanı veya yalnız sağlık kaydı içermeyen yayın alanı gerekebilir. NPA, sıfır veri aktarımı değildir.
8. Premium için gerçek RevenueCat/ödeme sağlayıcısı merchant hesabı, uygun işletmeci ülkesi, kesin fiyat, vergi, açık yenileme kabulü, kolay iptal ve iade desteği gerekir. ABD müşterisine satış, Türkiye'deki işletmeciyi ABD merchant'ı yapmaz. Ülke/adres yanlış yazılmaz. Satın alma → entitlement → iptal → dönem sonu testi yap. Gerçek ödeme testi yapılmadı.
9. Kullanılan sağlayıcıların geçerli hizmet/DPA koşullarını kabul et, gerçek saklama ve işlem konumlarını belirle. FITROTA_RETENTION_NOTICE, FITROTA_REGION_NOTICE, FITROTA_PROCESSING_BASIS_NOTICE, FITROTA_TRANSFER_NOTICE doldur. OpenAI desteğinin gönderdiği genel yanıt bir imzalı aktarım sözleşmesi değildir. ABD pazarı seçimi provider depolamasını ABD'ye taşımaz.
10. FITROTA_LEGAL_REVIEWED yalnız bu gerçek bilgiler ve uygulanabilir yükümlülükler tamamlandığında true olur. Kod bu bayrağı kendiliğinden açmaz. Açık kullanıcı erişiminden önce özel test modunu kapat ve tam uçtan uca doğrulama yap.

## Gizlilik talepleri ve olay yönetimi — işletmeci süreci

fitrotaaa@gmail.com adresini takip et. Talep tarihi, asgari kimlik doğrulama, istek türü, yanıt tarihi, sağlayıcıya yönlendirme ve tamamlama kaydını tut; bu kayıtta tüm sağlık günlüğünü kopyalama. Hak talebini ücretli üyelik koşuluna bağlama. Başvuruyu reddedersen gerekçe ve itiraz yolunu ilet. Washington sağlık verisi başvurularında 45 günlük yanıt; izin verilen ek 45 günlük uzatmada ilk süre içinde gerekçeli bildirim; itirazlarda 45 günlük yazılı yanıt süreci uygulanır. Nevada ve diğer eyaletlerin uygulanabilir süre/istisnaları ayrıca takip edilir. Kullanıcının cihaz kopyası, aktif Supabase verisi, yedekler ve daha önce seçerek AI'ya gönderdiği veriler ayrı ele alınır.

Olay tespitinde erişimi sınırla, delilleri koru, etkilenen veri/kullanıcıları belirle ve sağlayıcılarla temas kur. FTC Health Breach Notification Rule kapsamını değerlendir; uygulanıyorsa tüketici/FTC/medya bildirimleri ve süreleri izlenir. FTC rehberinde en geç 60 gün genel üst sınırdır, gereksiz gecikme yapılamaz; 500 ve üzeri kişi olayları FTC'ye eşzamanlı, daha küçük olaylar ilgili yıl sonundan sonraki 60 gün içinde bildirilir. Eyalet süreleri daha kısa olabilir. E-posta ve gereken ilave uygulama/web bildirimleri ile posta tercihi süreci hazırlanır. Bu belge olayın olmadığı veya HIPAA sertifikası alındığı anlamına gelmez.

## Resmî kaynaklar

- USDA: https://fdc.nal.usda.gov/download-datasets/ ve https://fdc.nal.usda.gov/GBFPD_Documentation/
- Apple: https://developer.apple.com/help/account/capabilities/configure-sign-in-with-apple-for-the-web
- Supabase: https://supabase.com/docs/guides/auth/social-login/auth-apple
- Washington: https://app.leg.wa.gov/RCW/default.aspx?cite=19.373.020 ; .030 ; .040 ; .050
- Nevada: https://www.leg.state.nv.us/NRS/NRS-603A.html
- FTC: https://www.ftc.gov/business-guidance/resources/complying-ftcs-health-breach-notification-rule-0
- CCPA/GPC: https://oag.ca.gov/privacy/ccpa

CCPA eşikleri ve diğer eyalet yasalarının kapsamları aynı değildir; Washington/Nevada sağlık verisi kuralları sırf küçük işletme olduğumuz için görmezden gelinmez. ABD'nin tamamına yönelik kullanımda eyalet bazlı kapsam, tüketici/abonelik, vergi ve olay süreçleri işletmecinin gerçek satış/veri durumuna göre uygulanır. Sitedeki metinleri düzenlemek sağlayıcı sözleşmesi imzalama veya resmi onay yerine geçmez.

## Doğrulama

Yerel sunucu/birim testleri: hesap/PKCE/Apple provider, geçici hatada oturum koruma, owner isolation, backup minimizasyonu, GPC, ülke gateway, ödeme yetkileri, birim dönüşümleri, USDA marka/UPC/kaynak araması. Tarayıcı: ABD onboarding, ölçüler, gerçek yerel indeks araması, onsla yemek kaydı, ölçüm, üç günlük meal prep ve gecikmiş Premium isteğinin hesap açılışını engellememesi. Gerçek sağlayıcı OAuth/ödeme/AdSense ve mobil native akışları test edilmiş sayılmaz.
