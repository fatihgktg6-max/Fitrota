// UI language is independent of the release market, store country and currency.
export const supportedLanguages=['en','tr','es','de','fr','pt'];
export const languageNames={en:'English',tr:'Türkçe',es:'Español',de:'Deutsch',fr:'Français',pt:'Português'};
const uiRows=`Today|Hoy|Heute|Aujourd’hui|Hoje
Workout|Entrenamiento|Training|Entraînement|Treino
Nutrition|Nutrición|Ernährung|Nutrition|Nutrição
Coach|Entrenador|Coach|Coach|Treinador
Calendar|Calendario|Kalender|Calendrier|Calendário
Progress|Progreso|Fortschritt|Progrès|Progresso
Rewards|Recompensas|Belohnungen|Récompenses|Recompensas
Settings|Ajustes|Einstellungen|Paramètres|Configurações
Profile|Perfil|Profil|Profil|Perfil
Overview|Resumen|Übersicht|Vue d’ensemble|Visão geral
Close|Cerrar|Schließen|Fermer|Fechar
Cancel|Cancelar|Abbrechen|Annuler|Cancelar
Save|Guardar|Speichern|Enregistrer|Salvar
Edit|Editar|Bearbeiten|Modifier|Editar
Add|Añadir|Hinzufügen|Ajouter|Adicionar
Delete|Eliminar|Löschen|Supprimer|Excluir
Continue|Continuar|Weiter|Continuer|Continuar
Back|Atrás|Zurück|Retour|Voltar
Retry|Reintentar|Erneut versuchen|Réessayer|Tentar novamente
Search|Buscar|Suchen|Rechercher|Pesquisar
Name|Nombre|Name|Nom|Nome
Goal|Objetivo|Ziel|Objectif|Objetivo
Training|Entrenamiento|Training|Entraînement|Treino
Training style|Tipo de entrenamiento|Trainingsstil|Type d’entraînement|Tipo de treino
Place|Lugar|Ort|Lieu|Local
Gym|Gimnasio|Fitnessstudio|Salle de sport|Academia
Home|Casa|Zu Hause|Maison|Casa
days|días|Tage|jours|dias
days/week|días/semana|Tage/Woche|jours/semaine|dias/semana
exercises|ejercicios|Übungen|exercices|exercícios
min|min|Min.|min|min
sec|s|Sek.|s|s
side|lado|Seite|côté|lado
Theme|Tema|Design|Thème|Tema
Light|Claro|Hell|Clair|Claro
Dark|Oscuro|Dunkel|Sombre|Escuro
Follow device|Según el dispositivo|Geräteeinstellung|Selon l’appareil|Seguir dispositivo
Language|Idioma|Sprache|Langue|Idioma
Appearance & experience|Aspecto y experiencia|Darstellung und Bedienung|Apparence et expérience|Aparência e experiência
My preferences|Mis preferencias|Meine Einstellungen|Mes préférences|Minhas preferências
My profile|Mi perfil|Mein Profil|Mon profil|Meu perfil
My account|Mi cuenta|Mein Konto|Mon compte|Minha conta
Sign in|Iniciar sesión|Anmelden|Se connecter|Entrar
Sign out|Cerrar sesión|Abmelden|Se déconnecter|Sair
Continue with Google|Continuar con Google|Mit Google fortfahren|Continuer avec Google|Continuar com Google
Welcome to FitRota|Bienvenido a FitRota|Willkommen bei FitRota|Bienvenue sur FitRota|Bem-vindo ao FitRota
Your routine.|Tu rutina.|Deine Routine.|Votre routine.|Sua rotina.
Your progress.|Tu progreso.|Dein Fortschritt.|Vos progrès.|Seu progresso.
Start your routine|Empieza tu rutina|Starte deine Routine|Commencez votre routine|Comece sua rotina
Explore a preview|Explorar una vista previa|Vorschau ansehen|Explorer un aperçu|Explorar uma prévia
Build a fitness routine that fits your day. Track workouts, meals and water, and see how far you’ve come.|Crea una rutina que se adapte a tu día. Registra entrenamientos, comidas y agua, y descubre tu progreso.|Gestalte eine Routine für deinen Alltag. Erfasse Training, Mahlzeiten und Wasser und entdecke deinen Fortschritt.|Créez une routine adaptée à votre journée. Suivez entraînements, repas et eau, et découvrez vos progrès.|Crie uma rotina para o seu dia. Registre treinos, refeições e água e acompanhe seu progresso.
Fitness|Fitness|Fitness|Fitness|Fitness
Meals|Comidas|Mahlzeiten|Repas|Refeições
Water|Agua|Wasser|Eau|Água
Protein|Proteína|Protein|Protéines|Proteína
Carbs|Carbohidratos|Kohlenhydrate|Glucides|Carboidratos
Fat|Grasa|Fett|Lipides|Gordura
Calories|Calorías|Kalorien|Calories|Calorias
Breakfast|Desayuno|Frühstück|Petit-déjeuner|Café da manhã
Lunch|Almuerzo|Mittagessen|Déjeuner|Almoço
Dinner|Cena|Abendessen|Dîner|Jantar
Snack|Aperitivo|Snack|Collation|Lanche
Budget|Presupuesto|Budget|Budget|Orçamento
Daily targets|Objetivos diarios|Tagesziele|Objectifs quotidiens|Metas diárias
Complete|Completado|Abgeschlossen|Terminé|Concluído
Today’s workout|Entrenamiento de hoy|Heutiges Training|Entraînement du jour|Treino de hoje
Your weekly review|Tu resumen semanal|Dein Wochenrückblick|Votre bilan hebdomadaire|Seu resumo semanal
Ad-free. Unlimited AI.|Sin anuncios. IA ilimitada.|Werbefrei. Unbegrenzte KI.|Sans publicité. IA illimitée.|Sem anúncios. IA ilimitada.
Ad-free experience|Sin anuncios|Werbefreie Nutzung|Sans publicité|Sem anúncios
Unlimited AI|IA ilimitada|Unbegrenzte KI|IA illimitée|IA ilimitada
Weekly review|Resumen semanal|Wochenrückblick|Bilan hebdomadaire|Resumo semanal
Your Premium membership|Tu suscripción Premium|Deine Premium-Mitgliedschaft|Votre abonnement Premium|Sua assinatura Premium
Get Premium|Obtener Premium|Premium holen|Passer à Premium|Obter Premium
Explore Premium|Descubrir Premium|Premium entdecken|Découvrir Premium|Explorar Premium
See Premium options|Ver opciones Premium|Premium-Optionen ansehen|Voir les options Premium|Ver opções Premium
Premium options|Opciones Premium|Premium-Optionen|Options Premium|Opções Premium
Manage membership|Gestionar suscripción|Mitgliedschaft verwalten|Gérer l’abonnement|Gerenciar assinatura
Manage subscription|Gestionar suscripción|Abonnement verwalten|Gérer l’abonnement|Gerenciar assinatura
Restore purchases|Restaurar compras|Käufe wiederherstellen|Restaurer les achats|Restaurar compras
Check membership|Comprobar suscripción|Mitgliedschaft prüfen|Vérifier l’abonnement|Verificar assinatura
Monthly|Mensual|Monatlich|Mensuel|Mensal
Yearly|Anual|Jährlich|Annuel|Anual
Lifetime|De por vida|Lebenslang|À vie|Vitalício
Renews monthly|Se renueva cada mes|Verlängert sich monatlich|Renouvellement mensuel|Renovação mensal
Renews yearly|Se renueva cada año|Verlängert sich jährlich|Renouvellement annuel|Renovação anual
One-time purchase|Pago único|Einmaliger Kauf|Achat unique|Compra única
Purchase|Comprar|Kaufen|Acheter|Comprar
Continue to Google Play|Continuar a Google Play|Weiter zu Google Play|Continuer vers Google Play|Continuar para o Google Play
Premium is active.|Premium está activo.|Premium ist aktiv.|Premium est actif.|Premium está ativo.
Purchase cancelled.|Compra cancelada.|Kauf abgebrochen.|Achat annulé.|Compra cancelada.
No active Premium purchase found.|No se encontró una compra Premium activa.|Kein aktiver Premium-Kauf gefunden.|Aucun achat Premium actif trouvé.|Nenhuma compra Premium ativa encontrada.
Your price comes from Google Play. Currency and regional pricing follow your Play account, not your app language.|El precio viene de Google Play. La moneda y el precio regional dependen de tu cuenta de Play, no del idioma de la aplicación.|Der Preis kommt von Google Play. Währung und regionale Preise richten sich nach deinem Play-Konto, nicht nach der App-Sprache.|Le prix vient de Google Play. La devise et le tarif régional dépendent de votre compte Play, pas de la langue de l’application.|O preço vem do Google Play. A moeda e o preço regional dependem da sua conta Play, não do idioma do aplicativo.
Subscriptions renew automatically until cancelled. Review the final price and renewal terms in Google Play before confirming.|Las suscripciones se renuevan automáticamente hasta su cancelación. Revisa el precio final y las condiciones en Google Play antes de confirmar.|Abonnements verlängern sich automatisch bis zur Kündigung. Prüfe Preis und Bedingungen in Google Play vor der Bestätigung.|Les abonnements se renouvellent automatiquement jusqu’à résiliation. Vérifiez le prix et les conditions dans Google Play avant de confirmer.|As assinaturas são renovadas automaticamente até o cancelamento. Confira o preço final e as condições no Google Play antes de confirmar.
Terms|Condiciones|Nutzungsbedingungen|Conditions|Termos
Privacy|Privacidad|Datenschutz|Confidentialité|Privacidade
AI coach|Entrenador IA|KI-Coach|Coach IA|Treinador IA
Open coach|Abrir entrenador|Coach öffnen|Ouvrir le coach|Abrir treinador
The coach uses your account; no access code is needed.|El entrenador usa tu cuenta; no necesitas un código.|Der Coach nutzt dein Konto; kein Zugangscode erforderlich.|Le coach utilise votre compte ; aucun code requis.|O treinador usa sua conta; nenhum código é necessário.
I agree to share messages and the listed plan/preferences with OpenAI for AI replies.|Acepto compartir mensajes y las preferencias indicadas con OpenAI para obtener respuestas de IA.|Ich stimme zu, Nachrichten und die angegebenen Planinformationen mit OpenAI für KI-Antworten zu teilen.|J’accepte de partager mes messages et les préférences indiquées avec OpenAI pour les réponses IA.|Concordo em compartilhar mensagens e as preferências indicadas com a OpenAI para respostas de IA.
Could not connect to the coach. Check your connection and try again.|No se pudo conectar al entrenador. Revisa la conexión e inténtalo de nuevo.|Verbindung zum Coach fehlgeschlagen. Prüfe die Verbindung und versuche es erneut.|Connexion au coach impossible. Vérifiez la connexion et réessayez.|Não foi possível conectar ao treinador. Verifique a conexão e tente novamente.
Signing you in…|Iniciando sesión…|Anmeldung läuft…|Connexion en cours…|Entrando…
Checking account…|Comprobando cuenta…|Konto wird geprüft…|Vérification du compte…|Verificando conta…
Checking your plan…|Comprobando tu plan…|Dein Plan wird geprüft…|Vérification de votre abonnement…|Verificando seu plano…
Secure sign-in|Inicio de sesión seguro|Sichere Anmeldung|Connexion sécurisée|Login seguro
Your routine, together.|Tu rutina, en un solo lugar.|Deine Routine, an einem Ort.|Votre routine, ensemble.|Sua rotina, em um só lugar.
Keep your workouts, nutrition and progress in one place.|Tus entrenamientos, nutrición y progreso en un solo lugar.|Training, Ernährung und Fortschritt an einem Ort.|Entraînements, nutrition et progrès au même endroit.|Seus treinos, nutrição e progresso em um só lugar.
You control what you share.|Tú controlas lo que compartes.|Du bestimmst, was du teilst.|Vous contrôlez ce que vous partagez.|Você controla o que compartilha.
Optional AI and cloud services|Servicios opcionales de IA y nube|Optionale KI- und Cloud-Dienste|Services IA et cloud facultatifs|Serviços opcionais de IA e nuvem
Redeem gift code|Canjear código de regalo|Geschenkcode einlösen|Utiliser un code cadeau|Resgatar código de presente
Gift code|Código de regalo|Geschenkcode|Code cadeau|Código de presente
Local price at checkout|Precio local al pagar|Lokaler Preis beim Bezahlen|Prix local au paiement|Preço local no pagamento
Language changes display text, not your market or payment currency.|El idioma cambia los textos, no el mercado ni la moneda.|Die Sprache ändert Texte, nicht Markt oder Zahlungswährung.|La langue change les textes, pas le marché ni la devise.|O idioma muda os textos, não o mercado ou a moeda.
Additional languages cover the main interface. Some detailed content and legal documents remain in English.|Los idiomas adicionales cubren la interfaz principal. Algunos contenidos detallados y documentos legales siguen en inglés.|Zusätzliche Sprachen decken die Hauptoberfläche ab. Einige ausführliche Inhalte und Rechtsdokumente bleiben auf Englisch.|Les langues supplémentaires couvrent l’interface principale. Certains contenus détaillés et documents juridiques restent en anglais.|Os idiomas adicionais cobrem a interface principal. Alguns conteúdos detalhados e documentos legais permanecem em inglês.`;
const uiTranslations=Object.fromEntries(uiRows.split('\n').map(row=>{const [key,...values]=row.split('|');return [key,Object.fromEntries(['es','de','fr','pt'].map((lang,i)=>[lang,values[i]]))];}));
export function uiText(tr,en,language='en') {
  if(language==='tr')return tr;
  return uiTranslations[en]?.[language]||en;
}
