// Public IDs. Test ads remain enabled until physical-device release checks pass.
export const admobConfig = {
  enabled: true,
  testMode: true,
  androidAppId: 'ca-app-pub-9835164875546157~4451494203',
  androidBannerId: 'ca-app-pub-9835164875546157/6782888938',
};
