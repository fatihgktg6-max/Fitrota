import {chromium} from '@playwright/test';
import {createServer} from 'node:http';
import {readFile,mkdir} from 'node:fs/promises';
import path from 'node:path';
const outputDir=process.env.FITROTA_QA_OUTPUT_DIR||path.resolve('qa/release629');await mkdir(outputDir,{recursive:true});
import assert from 'node:assert/strict';
import {emptyState,normalizeProfile} from '../src/core.js';
let signedIn=false;
const user={id:'visual-user',email:'test@example.test'};
const server=createServer(async(req,res)=>{try{if(req.url.startsWith('/account/')){const route=req.url.slice(9);const d=route==='config'?{configured:true,providers:['google']}:route==='me'?{user:signedIn?user:null}:route==='membership'?{owner:user.id,premium:false}:route==='billing-config'?{enabled:true,adsEnabled:false}:{snapshot:null};res.setHeader('Content-Type','application/json');res.end(JSON.stringify(d));return;}const name=req.url==='/'?'index.html':'public'+req.url;res.end(await readFile(new URL('../'+name,import.meta.url)));}catch{res.writeHead(404);res.end();}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;
let browser;try{browser=await chromium.launch({headless:true});const page=await browser.newPage({viewport:{width:390,height:844}});await page.goto(origin);await page.waitForTimeout(800);
for(const lang of ['en','tr','es','de','fr','pt']){await page.evaluate(lang=>{state.settings.lang=lang;render();},lang);assert.equal(await page.locator('html').getAttribute('lang'),lang);assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));}
await page.screenshot({path:path.join(outputDir,'welcome629.png'),fullPage:true});
await page.evaluate(()=>{state.settings.lang='tr';render();});await page.evaluate(()=>showAccount());assert.equal(await page.locator('.permission-option').count(),3);await page.locator('.login-services summary').click();await page.screenshot({path:path.join(outputDir,'permissions629.png'),fullPage:true});
signedIn=true;const state=emptyState();state.profile=normalizeProfile({name:'Test',age:30,height:180,weight:80,days:[1,3,5]});state.settings.lang='tr';state.settings.market='US';state.settings.usReleaseRevision=1;await page.evaluate(s=>{localStorage.setItem('fitrota.account.visual-user',JSON.stringify(s));},state);await page.reload();await page.waitForTimeout(800);
await page.evaluate(()=>{window.FitrotaBilling={available:true,owner:'visual-user',active:false,entitlement:null,refresh:async()=>{},offerings:async()=>({availablePackages:[{identifier:'$rc_monthly',product:{priceString:'₺174,99',title:'Monthly'}}]})};return showNativeMembership();});assert.equal(await page.locator('[data-action="native-purchase"]').count(),1);await page.screenshot({path:path.join(outputDir,'premium629.png'),fullPage:true});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
await page.setViewportSize({width:768,height:1024});await page.evaluate(()=>{state.settings.theme='dark';render();return showNativeMembership();});await page.screenshot({path:path.join(outputDir,'premium-tablet629.png'),fullPage:true});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));console.log('Visual QA: six welcome languages; grouped permissions; single localized checkout; mobile/tablet no overflow.');
}finally{await browser?.close();await new Promise(r=>server.close(r));}
