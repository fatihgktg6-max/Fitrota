# FitRota 0.3.0 — erken erişim

Robot koç, uyku önerileri, kurulabilir web uygulaması ve kontrollü güncelleme içeren son paket.

**Güncel dağıtım, test ve kalan mağaza işleri:** [RELEASE-0.3.0](docs/RELEASE-0.3.0.md).

Bu paket web yayını içindir; imzalı mağaza paketi değildir. AI erişimi tek sahipli pilot kodu kullanır, satın alma ve gerçek ödül aboneliği etkin değildir.

## Geliştirme

Node.js 22 veya sonrası ile `npm ci` ve `npm run check`. `npm run dev` kaynak önizlemesini açar. Yayındaki PWA davranışı `npm run server` ile derlenmiş dist üzerinde çalışır. Sunucu değişkenleri `server/.env.example` içinde.

`npm run test:server`, `npm run test:ui`, `npm run test:coach`, `npm run test:release`. Tarayıcı testleri için önce `npx playwright install chromium`.

Mobil kaynaklar için `npm run native:sync`. Android/iOS imzalama ayrıca gerekir.
