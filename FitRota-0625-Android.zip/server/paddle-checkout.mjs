// This public payment-link page contains only the publishable client token.
// Access to the application remains behind the existing US country gate.
export function paddleCheckoutHTML(token,environment='sandbox'){
 const live=environment==='live';
 if(!['sandbox','live'].includes(environment)||!(live?/^live_[a-zA-Z0-9]{27}$/:/^test_[a-zA-Z0-9]{27}$/).test(token||''))throw Error('billing_not_configured');
 return `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>FitRota checkout</title><body><h1>FitRota ${live?'secure':'sandbox'} checkout</h1><p>${live?'Paid subscriptions renew monthly until canceled. Review the price and taxes before paying.':'No real payment is collected. Use a Paddle test card only.'}</p><p id="status">Loading secure checkout…</p><a href="/app">Return to FitRota</a><script src="https://cdn.paddle.com/paddle/v2/paddle.js"></script><script>
if(window.Paddle){${live?'':"Paddle.Environment.set('sandbox');"}Paddle.Initialize({token:${JSON.stringify(token)},eventCallback:function(event){if(event.name==='checkout.completed'){document.getElementById('status').textContent='Payment received. Return to FitRota and select Check membership. Premium is activated only after server verification.';}}});document.getElementById('status').textContent='Review the checkout below. If no checkout appears, start from Premium in FitRota.';}else{document.getElementById('status').textContent='Checkout could not load. Return to FitRota and try again.';}
</script></body></html>`;
}
