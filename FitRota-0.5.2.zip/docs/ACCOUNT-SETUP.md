# Hesap altyapısı — yapılandırma ve kalan işler

Bu sürümde **web/PWA** için gerçek OAuth PKCE kod akışı hazırlanmıştır. Şu an proje/sağlayıcı anahtarları olmadığı için Google/Apple düğmeleri devre dışıdır; sahte giriş yapılmaz. Gerçek Google/Apple hesabıyla uçtan uca test yapılmamıştır. Android/iOS yerel SDK girişleri bu pakette etkin değildir; mağaza paketi için ayrı entegrasyon, bundle/package kimliği, yönlendirme ve cihaz testi gerekir.

## İşletmecinin yapacağı dış yapılandırma

1. Kendi Supabase projesini oluştur; veri bölgesini ve sözleşmelerini hedef ülkeler için değerlendir. `database/001_accounts.sql` betiğini SQL editöründe uygula. Kullanıcılar sadece kendi satırına erişir; hesabı silince satır cascade ile silinir.
2. Google Cloud OAuth uygulamasında gerekli temel kimlik/e-posta izinlerini, izin ekranını ve Supabase callback adresini tanımla; Google sağlayıcısını Supabase’de etkinleştir.
3. Apple Developer’da Services ID, web domain/return URL, anahtar ve istemci sırrını oluştur; Supabase Apple sağlayıcısını yapılandır. Apple client secret sürelidir, yenileme sorumluluğu işletmecidedir. Silme akışı Apple token revoke endpoint’ini çağırır; sağlayıcı tokenı verilmezse kullanıcıya yeniden giriş/destek ihtiyacı gösterilir, silinmiş gibi davranılmaz. Bu akışı gerçek hesapla doğrulamadan Apple’ı etkinleştirme.
4. Supabase redirect allowlist: `https://fitrota.onrender.com/account/callback**` (yalnız tam sahip olduğun site; wildcard domain verme). Site URL aynı origin olmalı. Callback query’sinde rastgele state bulunur. `FITROTA_PUBLIC_ORIGIN` sonunda slash olmadan tam origin olmalıdır.
5. Render sunucusuna `.env.example` içindeki hesap alanlarını gir: Supabase URL, publishable key, yalnız sunucuda service-role key, ayrı en az 32 karakterli rastgele session secret. Apple için client ID/secret. Bunları GitHub’a, HTML’e veya uygulama paketine koyma.
6. Gerçek işletmeci/adres/iletişim ve saklama metnini tamamla; hukuki inceleme gerçekten tamamlandıktan sonra `FITROTA_LEGAL_REVIEWED=true` yap. Bu değişken hukuki uygunluk sağlamaz; yalnız eksik taslakla hesap açılmasını engelleyen yayın kapısıdır.
7. İki ayrı kullanıcıyla giriş, yanlış callback, oturum yenileme, ayrı cihaz yedeği, çakışan kayıt, çıkış ve kalıcı silmeyi gerçek ortamda doğrula. Google ve Apple marka/mağaza gereksinimlerini son kez kontrol et.

## Davranış

- Şifre uygulamadan istenmez. Provider tokenları AES-256-GCM ile şifrelenmiş HttpOnly, SameSite=Lax, üretimde Secure çerezde tutulur. JavaScript/localStorage’a yazılmaz. Oturum her korumalı işlemde Supabase `/user` ile doğrulanır; gerekli olduğunda refresh yapılır.
- Google/Apple girişi mevcut misafir verilerini kendiliğinden yüklemez. Her hesabın bu cihazdaki kayıt alanı ayrıdır. Misafir verisini taşımak isteyen kullanıcı JSON dışa/içe aktarımıyla açıkça seçebilir.
- Bulut yedekleme otomatik değildir; kullanıcı ayrı paylaşım kutusunu onaylar. Profil, öğün, antrenman, ölçüm, takvim, not ve sohbetleri içerir. Yükleme mevcut bulut kopyasını değiştirir; sürüm kontrolü eşzamanlı güncellemeyi reddeder. Kullanıcı eski yerel kopyayı bilinçli yükleyebilir; otomatik birleştirme yoktur.
- Hesap silme, son 10 dakika içinde giriş ister. Supabase hesabı ve bağlı snapshot silinir; Apple kullanılmışsa önce token iptali denenir. Farklı cihazdaki çevrimdışı kayıtların uzaktan silindiği iddia edilmez.
- Hesap değişiminin başka sekmede olması durumunda mutation isteğindeki hesap kimliği kontrol edilir; eski sekmenin verisi yeni hesaba yazılmaz.
- 0.5.2’de web/PWA AI erişimi doğrulanmış hesap oturumuna bağlanmıştır: kullanıcı ayrıca pilot kodu girmez. `/account/coach` her istekte hesabı doğrular; AI paylaşımı ayrıca onaylanır. Özel pilot test bağlantısı ve genel günlük bütçe korunur. Kullanıcı başına 30 mesaj/1 saat kotası ve ödeme yetkilendirmesi henüz yoktur; ücretli yayına hazır değildir.

## Doğrulanmış kaynaklar

https://supabase.com/docs/guides/auth/social-login/auth-google
https://supabase.com/docs/guides/auth/social-login/auth-apple
https://supabase.com/docs/guides/auth/sessions/pkce-flow
https://supabase.com/docs/guides/database/postgres/row-level-security
https://supabase.com/docs/reference/javascript/auth-admin-deleteuser
https://developer.apple.com/documentation/signinwithapplerestapi/revoke-tokens

## Test sınırları

Yerel sahte sağlayıcı testleri gerçek Google/Apple onayını, Supabase SQL çalışma davranışını veya mağaza incelemesini doğrulamaz. SQL şeması hazırlanmıştır; gerçek veritabanına uygulanmamıştır. Native Google/Apple girişinin tamamlandığı veya tüm hesap sisteminin yayında olduğu iddia edilmez.

## 0.5.1 kurulum kontrolü

Render ortamında `npm run check:config` çalıştırılabilir. Yerel özel ortam dosyası kullanılıyorsa `node --env-file=server/.env scripts/check-config.mjs`. Eksikler için çıkış kodu 1, tüm yerel kontroller geçerse 0 döner. Bu yalnız biçim/varlık kontrolüdür; dış servise bağlanmaz, gizli değerleri yazdırmaz ve canlıya hazır sertifikası değildir. Apple giriş düğmesi, client ID/secret eksikse kapalı kalır. Geçici kimlik sağlayıcı kesintisinde mevcut oturum korunur; korumalı işlemler tamamlanmış sayılmaz.
