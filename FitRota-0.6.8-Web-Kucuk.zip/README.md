# FitRota Web 0.6.8

Web yayın adayı. Kurulum ve dış hizmetlerde kalan işlemler: [Son sürüm kurulum rehberi](docs/SON-SURUM-KURULUM.md).

```
npm ci --include=dev
npm run build
npm run server
```

- Google giriş; Apple giriş düğmesi kaldırılmıştır.
- 150.007 kaynaklı besin/ürün; büyük katalog gerektiğinde yüklenir.
- Aydınlık/koyu tema; Profil içinde Premium ve hediye kodu.
- Sunucudan doğrulanan üyelik, RevenueCat web ödeme entegrasyonu, izin kontrollü manuel AdSense alanı.
- Her dış hizmet canlı hesap yapılandırması ve gerekli onayları ister; bu paket kendiliğinden onay sağlamaz.

`npm test` temel testleri, `node tests/release068-ui.mjs` web sürüm testlerini çalıştırır. Playwright Chromium gerektirir.
