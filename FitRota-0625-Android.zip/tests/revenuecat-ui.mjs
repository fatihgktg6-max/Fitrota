import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import {createCoachServer} from '../server/index.mjs';
import {randomBytes} from 'node:crypto';
const server=createCoachServer({accessCode:randomBytes(32).toString('hex'),allowedOrigins:[]});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await chromium.launch({args:['--no-sandbox']});
const page=await browser.newPage({viewport:{width:390,height:844}}),errors=[];
page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto('http://127.0.0.1:'+server.address().port);
 await page.evaluate(()=>{
  let info={entitlements:{active:{}}};
  const pro={entitlements:{active:{fitrota_pro:{isActive:true,expirationDate:null}}}};
  const offerings={current:{identifier:'default',availablePackages:[
   {identifier:'$rc_monthly',product:{priceString:'₺49,99'}},
   {identifier:'$rc_annual',product:{priceString:'₺499,99'}},
   {identifier:'$rc_lifetime',product:{priceString:'₺999,99'}}]}};
  const purchases={configure:async()=>{},getCustomerInfo:async()=>({customerInfo:info}),addCustomerInfoUpdateListener:async()=> '1',getOfferings:async()=>offerings,purchasePackage:async()=>{info=pro;return {customerInfo:info};},restorePurchases:async()=>{info=pro;return {customerInfo:info};}};
  const ui={presentPaywallIfNeeded:async()=>{info=pro;return {result:'PURCHASED'};},presentCustomerCenter:async()=>{info={entitlements:{active:{}}};}};
  const Constructor=window.FitrotaBilling.constructor;
  window.FitrotaBilling=new Constructor({purchases,ui,platform:()=> 'android',config:{testMode:true,testApiKey:'test_example',entitlement:'fitrota_pro'},onChange:()=>window.dispatchEvent(new Event('fitrota-billing-update'))});
 });
 await page.evaluate(()=>showMembership());
 assert.match(await page.locator('#modal-root').innerText(),/₺49,99/);
 assert.match(await page.locator('#modal-root').innerText(),/Ömür boyu/);
 await page.locator('[data-action="native-purchase"][data-id="$rc_lifetime"]').click();
 await page.waitForFunction(()=>nativePremium());
 await page.waitForFunction(()=>!!document.querySelector('[data-action="native-manage"]'));
 assert.match(await page.locator('#modal-root').innerText(),/Ömür boyu/);
 await page.locator('[data-action="native-manage"]').click();
 await page.waitForFunction(()=>!nativePremium());
 await page.waitForFunction(()=>!!document.querySelector('[data-action="native-paywall"]'));
 await page.locator('[data-action="native-paywall"]').click();await page.waitForFunction(()=>nativePremium());
 await page.waitForFunction(()=>!!document.querySelector('[data-action="native-restore"]'));
 await page.locator('[data-action="native-restore"]').click();
 await page.evaluate(()=>{accountInfo.user={id:'other'};});assert.equal(await page.evaluate(()=>nativePremium()),false);
 assert.deepEqual(errors,[]);console.log('PASS RevenueCat UI: localized prices, lifetime purchase, paywall, restore, Customer Center, account isolation. Mock SDK only.');
}finally{await browser.close();await new Promise(r=>server.close(r));}
