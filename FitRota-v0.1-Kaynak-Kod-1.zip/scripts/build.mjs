import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=fileURLToPath(new URL('../',import.meta.url));
await mkdir(path.join(root,'dist'),{recursive:true});
const modules=['catalog','core','store','native','icons','ai-client','app'];
let script='';for(const name of modules){const source=await readFile(path.join(root,`src/${name}.js`),'utf8');script+=`\n// ${name}\n`+source.replace(/^import .*?;\s*$/gm,'').replace(/^export /gm,'');}
let bridge='';try{bridge=await readFile(path.join(root,'node_modules/@capacitor/core/dist/capacitor.js'),'utf8');}catch{}
const css=(await readFile(path.join(root,'src/style.css'),'utf8')).replace("@import url('');",'');
const license=await readFile(path.join(root,'docs/CAPACITOR-LICENSE.txt'),'utf8');
const favicon=await readFile(path.join(root,'public/icon.svg'),'utf8');
const html=`<!doctype html><html lang="tr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#163d30"><meta name="description" content="FitRota: günlük hayatına uyum sağlayan spor ve beslenme yardımcın."><title>FitRota</title><link rel="icon" href="data:image/svg+xml,${encodeURIComponent(favicon)}"><style>${css}</style></head><body><div id="app"></div><div id="modal-root"></div><div id="toast" role="status" aria-live="polite"></div><script>/* ${license} */\n${bridge}</script><script>${script.replace(/<\/script/gi,'<\\/script')}</script></body></html>`;
await writeFile(path.join(root,'dist/index.html'),html);
await writeFile(path.join(root,'FitRota-Onizleme.html'),html);
await copyFile(path.join(root,'public/icon.svg'),path.join(root,'dist/icon.svg'));
console.log(`Built offline standalone preview (${Math.round(Buffer.byteLength(html)/1024)} KB). No external resources required.`);
