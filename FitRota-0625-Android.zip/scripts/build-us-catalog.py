"""Create a US-only, source-labelled searchable catalog. Never synthesize brand records.
Source: USDA FoodData Central April 2026 Branded JSON download (CC0/public domain).
All values remain per 100 g unless reliable per-serving label values exist for liquids.
"""
from pathlib import Path
from zipfile import ZipFile
import json,sqlite3,math,hashlib
root=Path(__file__).resolve().parent.parent
source=root/'research/usda-branded.zip'
output=root/'content/us-foods.build.sqlite'
output.unlink(missing_ok=True)
db=sqlite3.connect(output)
db.execute('PRAGMA journal_mode=OFF')
db.execute('PRAGMA synchronous=OFF')
db.executescript('CREATE TABLE foods (id TEXT PRIMARY KEY, barcode TEXT UNIQUE, search TEXT, data TEXT); CREATE VIRTUAL TABLE food_search USING fts5(search, content=foods, content_rowid=rowid);')
fields={1008:('kcal','kcal'),1003:('protein','g'),1004:('fat','g'),1005:('carbs','g'),1079:('fiber','g'),2000:('sugar','g'),1258:('saturatedFat','g'),1253:('cholesterol','mg'),1093:('sodium','mg'),1092:('potassium','mg'),1087:('calcium','mg'),1089:('iron','mg')}
limits={'kcal':900,'protein':100,'carbs':100,'fat':100,'fiber':100,'sugar':100,'saturatedFat':100,'cholesterol':3000,'sodium':40000,'potassium':20000,'calcium':20000,'iron':500}
count=0;unknown=0;bad=0;seed=[]
with ZipFile(source) as z:
 with z.open(z.namelist()[0]) as stream:
  for line in stream:
   if not line.startswith(b'{"foodClass"'):continue
   p=json.JSONDecoder().raw_decode(line.decode())[0]
   if p.get('marketCountry') not in ['United States','US']:continue
   code=str(p['fdcId']);barcode=str(p.get('gtinUpc',''));name=p.get('description','').strip();brand=p.get('brandName') or p.get('brandOwner','')
   if not name or not brand:bad+=1;continue
   n={v[0]:None for v in fields.values()}
   for row in p.get('foodNutrients',[]):
    nutrient=row.get('nutrient',{});spec=fields.get(nutrient.get('id'));v=row.get('amount')
    if spec and nutrient.get('unitName','').lower()==spec[1] and isinstance(v,(int,float)) and math.isfinite(v) and 0<=v<=limits[spec[0]]:n[spec[0]]=v
   f={'id':'branded-'+code,'code':code,'name':[name,name],'brand':brand,'barcode':barcode,'unit':'g','source':'branded','market':'US','sourceURL':'https://fdc.nal.usda.gov/food-details/'+code+'/nutrients','publishedAt':p.get('publicationDate',''),**n}
   size=p.get('servingSize');unit=p.get('servingSizeUnit','').lower()
   if unit=='g' and isinstance(size,(int,float)) and 0<size<=2000:f['portionGrams']=size;f['portionLabel']=p.get('householdServingFullText','')
   elif unit=='ml':
    # USDA normalized nutrients are per 100g, not per 100ml. Use manufacturer label per serving.
    label=p.get('labelNutrients',{});keys={'kcal':'calories','protein':'protein','fat':'fat','carbs':'carbohydrates','fiber':'fiber','sugar':'sugars','sodium':'sodium','saturatedFat':'saturatedFat','cholesterol':'cholesterol'}
    f.update({k:None for k in n});f['unit']='serving';f['portionLabel']=p.get('householdServingFullText','')
    if isinstance(size,(int,float)) and 0<size<=2000:f['portionMl']=size
    for k,labelkey in keys.items():
     v=label.get(labelkey,{}).get('value')
     if isinstance(v,(int,float)) and math.isfinite(v) and 0<=v<=limits[k]*max(1,(size or 100)/100):f[k]=v
   if f['kcal'] is None:unknown+=1
   search=' '.join([name,brand,barcode]).lower()
   db.execute('INSERT OR IGNORE INTO foods VALUES (?,?,?,?)',(f['id'],barcode or code,search,json.dumps(f,separators=(',',':'),ensure_ascii=False)))
   count+=1
   if f['unit']=='g' and all(f[k] is not None for k in ['kcal','protein','carbs','fat']) and len(seed)<1500:seed.append(f)
   if count%20000==0:db.commit()
db.execute("INSERT INTO food_search(food_search) VALUES ('rebuild')");db.commit()
actual=db.execute('SELECT count(*) FROM foods').fetchone()[0]
assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
db.close()
output.replace(root/'content/us-foods.sqlite')
output=root/'content/us-foods.sqlite'
import importlib.util
spec=importlib.util.spec_from_file_location('catalog_integrity',root/'scripts/catalog-integrity.py')
verifier=importlib.util.module_from_spec(spec);spec.loader.exec_module(verifier)
verified_count,content_hash=verifier.catalog_digest(output)
assert verified_count==actual
(root/'src/branded-foods.js').write_text('// Small offline US seed; full USDA catalogue uses server-side search.\nexport const brandedFoods='+json.dumps(seed,separators=(',',':'),ensure_ascii=False)+';\n')
(root/'docs/US-CATALOG.json').write_text(json.dumps({'source':'https://fdc.nal.usda.gov/fdc-datasets/FoodData_Central_branded_food_json_2026-04-30.zip','sha256':hashlib.file_digest(source.open('rb'),'sha256').hexdigest(),'contentSHA256':content_hash,'databaseSHA256':hashlib.file_digest(output.open('rb'),'sha256').hexdigest(),'records':actual,'seedRecords':len(seed),'market':'US','requestedTarget':900000,'targetMet':actual>=900000,'missingEnergyRecords':unknown,'skippedInvalidIdentity':bad,'note':'Source records, not a guarantee of all brands/current availability. Missing nutrients stay unknown. Liquids use per-serving manufacturer labels; no inferred density. No fabricated duplicates. USDA public domain/CC0.'},indent=2))
print(actual,output.stat().st_size,flush=True)
