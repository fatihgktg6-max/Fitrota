// Membership is verified online per owner. Never use backup/localStorage to grant paid access.
function membershipState(){return window.__membership??={owner:null,premium:false,adFree:false,unlimitedAI:false,config:null,rewards:null,sequence:0};}
function nativePremium(){const b=window.FitrotaBilling;const e=b?.entitlement;return b?.available&&b.owner===(accountInfo.user?.id||null)&&e?.isActive===true;}
function isPremium(){if(nativePremium())return true;const m=membershipState();return !!accountInfo.user&&m.owner===accountInfo.user.id&&m.premium===true&&(m.lifetime===true||Date.parse(m.expiresAt)>Date.now());}
function brandTitle(){return `<span class="brand-title">FitRota${isPremium()?'<span class="brand-premium">Premium</span>':''}</span>`;}
function premiumBadge(){return `<button class="premium-badge ${isPremium()?'active':''}" data-action="membership" aria-label="${t('Premium üyeliği','Premium membership')}">${isPremium()?'FitRota Premium':membershipState().status==='unavailable'?t('Üyelik kontrolü','Membership check'):t('Premium’a geç','Get Premium')}</button>`;}
function resetMembership(){window.FitrotaBilling?.clear();const old=membershipState();clearTimeout(window.__rewardTimer);window.__membership={owner:null,premium:false,adFree:false,unlimitedAI:false,config:null,rewards:null,sequence:old.sequence+1};}
async function refreshMembership(){const owner=accountInfo.user?.id||null,existing=window.__membershipRefresh;if(existing?.owner===owner)return existing.promise;const entry={owner};window.__membershipRefresh=entry;entry.promise=refreshMembershipOnce().finally(()=>{if(window.__membershipRefresh===entry)window.__membershipRefresh=null;});return entry.promise;}
async function refreshMembershipOnce(){if(window.FitrotaBilling?.available){await window.FitrotaBilling.refresh(accountInfo.user?.id).catch(()=>{});}await membershipConfig();const m=membershipState(),owner=accountInfo.user?.id;if(!owner)return;const sequence=++m.sequence;try{const found=await accountRequest('membership');if(membershipState()!==m||accountInfo.user?.id!==owner||m.sequence!==sequence)return;if(found.owner!==owner)throw Error('account_changed');Object.assign(m,found,{verifiedAt:Date.now(),status:'ready'});if(liveCoach?.mode==='account'&&state.settings.accountAiConsent){try{const connection=await connectAccountCoach(location.origin,true);if(membershipState()===m&&accountInfo.user?.id===owner&&m.sequence===sequence)liveCoach=connection;}catch{liveCoach=null;}}if(!isPremium()&&['roast','analyst','planner'].includes(state.settings.coach)){state.settings.coach='warm';saveState(state);}if(found.premium||m.config?.enabled){accountRequest('rewards').then(rewards=>{if(membershipState()===m&&accountInfo.user?.id===owner&&m.sequence===sequence){m.rewards=rewards;if(page==='rewards')render();}}).catch(()=>{});}}catch(e){if(membershipState()===m&&m.sequence===sequence){m.status='unavailable';if(['signin_required','account_changed'].includes(e.message)){resetMembership();}else if(m.owner!==owner){m.owner=owner;m.premium=false;m.adFree=false;m.unlimitedAI=false;}}}}
async function membershipConfig(){const m=membershipState();if(!m.config||m.configStale){try{m.config=await accountRequest('billing-config');m.configStale=false;}catch{m.configStale=true;m.config={enabled:false,webCheckout:false,prices:[{country:'TR',currency:'TRY',amount:49.99},{country:'US',currency:'USD',amount:3},{country:'EU',currency:'EUR',amount:2.99}],adsEnabled:false};}}return m.config;}
function canShowAds(){const m=membershipState();return !adPrivacyOptOut()&&m.status==='ready'&&!!m.config?.adsEnabled&&!!accountInfo.user&&m.owner===accountInfo.user.id&&!isPremium();}
function premiumCard(){return `<section class="card premium-card space"><div class="cardhead"><div><div class="eyebrow">FITROTA PREMIUM</div><h2>${t('Reklamsız. Sınırsız AI.','Ad-free. Unlimited AI.')}</h2></div>${icon('gift',28)}</div><p class="subtitle">${t('Haftalık analiz, Pratik mutfak, Tatlı sert koç ve haftalık rapor dahil.','Includes weekly analysis, practical meals, playful roast and weekly review.')}</p>${btn(t('Hediye kodu kullan','Redeem gift code'),'gift-open','outline full space')}${btn(t(isPremium()?'Üyeliğimi yönet':'Premium seçenekleri',isPremium()?'Manage membership':'Premium options'),'membership','full space')}</section>`;}
async function showMembership(){if(window.FitrotaBilling?.available)return showNativeMembership();await membershipConfig();if(membershipState().status!=='ready'||Date.now()-(membershipState().verifiedAt||0)>60000)await refreshMembership();const m=membershipState(),native=window.Capacitor?.isNativePlatform?.();modal('FitRota Premium',`<h2>${t('Reklamsız + sınırsız AI','Ad-free + unlimited AI')}</h2><ul class="guide-list"><li>${t('30 mesaj kotası ve 2 saat bekleme uygulanmaz.','No 30-message quota or two-hour waiting period.')}</li><li>${t('Gelişmiş yanıtlar: daha ayrıntılı analiz ve planlama','Advanced replies: more detailed analysis and planning')}</li><li>${t('Haftalık analiz ve Pratik mutfak AI modları','Weekly analyst and Practical meals AI modes')}</li><li>${t('7 günlük özet ve CSV dışa aktarma','Seven-day review and CSV export')}</li><li>${t('Premium’a özel Tatlı sert koç modu','Premium-exclusive playful roast coach')}</li></ul>${isPremium()?`<p class="notice">✦ Premium · ${t('Geçerlilik','Valid until')}: ${(m.lifetime?t('Ömür boyu','Lifetime'):esc(new Date(m.expiresAt).toLocaleDateString(state.settings.lang)))}${m.source==='reward'?' · '+t('Görev hediyesi','Task reward'):m.source==='gift_code'?' · '+t('Hediye kodu','Gift code'):''}</p>`:`<div class="premium-prices"><b>${premiumPriceLabel()}</b></div><p class="subtitle space">${t('Aylık fiyat hedefleri. Kesin yerel fiyat, vergi ve yenileme koşulları ödeme ekranında gösterilir; dilin fiyatı değiştirmez.','Monthly target prices. Final local price, taxes and renewal terms appear at checkout; language does not change the price.')}</p>`}<p class="subtitle space">${t('Ücretsiz: 30 AI mesajı, ardından 2 saat bekleme. Premium’da hizmetin kısa süreli hız ve güvenlik sınırları korunur.','Free: 30 AI messages, then a two-hour wait. Short service rate and security limits remain on Premium.')}</p>${!m.config.enabled||!m.config.webCheckout||native?`<p class="notice space">${t('Satın alma henüz açılmadı. Bu ekranda ücret alınmaz.','Purchases are not open yet. No charge is collected on this screen.')}</p>`:''}<p class="subtitle space">${t('Ücretli abonelik iptal edilene kadar aylık yenilenir. Görev hediyesi ücretli abonelik başlatmaz; mevcut ücretli aboneliğin yenilemesini de iptal etmez.','Paid subscriptions renew monthly until cancelled. A task gift does not start a paid subscription or cancel an existing renewal.')}</p>${m.config.environment==='sandbox'?'<p class="notice">SANDBOX TEST — No real payment. Test access only.</p>':''}${giftCodeSection()}<div id="membership-error" class="formerror" role="alert"></div>`,(!accountInfo.user?btn(t('Hesabımla giriş','Sign in'),'account',''):!isPremium()&&!m.hasSubscription&&m.config.webCheckout&&!native?btn(t('Ödeme koşullarını gör','Review checkout terms'),'premium-checkout',''):m.managementURL?`<a class="btn" href="${esc(m.managementURL)}" target="_blank" rel="noopener">${t('Aboneliği yönet / iptal','Manage / cancel subscription')}</a>`:'')+btn(t('Üyeliğimi kontrol et','Check membership'),'membership-refresh','outline'));}
function rewardsView(){const r=membershipState().rewards;return `${premiumCard()}<section class="card space"><div class="cardhead"><h2>${t('2 aylık görev ödülü','Two-month task reward')}</h2>${tag(t('1 ay Premium','1 month Premium'),'orange')}</div><p>${t('Her iki takvim aylık dönemde günlük öğün ve su kaydını, planlı günlerde antrenmanını tamamla. Dönem bitince tüm görevler tamamlandıysa 1 ay Premium kazanırsın. Yeni dönemde sayaç sıfırdan başlar.','In each two-calendar-month period, log a meal and water daily and finish workouts on planned days. Complete all tasks to earn one month of Premium when the period ends. Each new period resets progress.')}</p>${r?.enrolled?`<p class="subtitle space">${esc(r.start)} → ${esc(r.end)} · ${t('Antrenman günlerin dönem boyunca sabit.','Workout days stay fixed throughout this period.')}</p><div class="progresslegend"><b>${r.done} / ${r.target}</b><span>${Math.round(r.done/r.target*100)}%</span></div><div class="bar"><i style="width:${Math.min(100,r.done/r.target*100)}%"></i></div><p class="subtitle space">${t('Görevler cihazdaki kayıtlarına dayanır; yalnız sunucuya zamanında ulaşan günler sayılır. Geçmiş günler topluca eklenmez.','Tasks are based on self-reported logs; only days received by the server on time count. Past days cannot be batch-added.')}</p>${btn(t('Görevleri eşitle','Sync tasks'),'reward-sync','outline full space')}`:`<p class="subtitle space">${t('Katılınca tarih ve antrenman günleri hesabında sabitlenir. Yalnız tarih ve tamamlanma işaretleri paylaşılır; öğün içeriği veya ölçümlerin paylaşılmaz.','Joining freezes dates and workout days for your account. Only dates and completion flags are shared, not meal contents or measurements.')}</p>${btn(t('Görev ödülüne katıl','Join task rewards'),'reward-enroll','full space')}`}<p id="reward-status" class="subtitle space"></p></section>`;}
async function syncRewardTasks(){const m=membershipState(),owner=accountInfo.user?.id;if(!owner||!m.rewards?.enrolled||state.demo)return;const date=new Intl.DateTimeFormat('sv-SE',{timeZone:m.rewards.timezone,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());const body={action:'record',date,workout:state.workouts[date]?.completed===true,meal:(state.meals[date]||[]).length>0,water:(state.water[date]||0)>0};const response=await accountRequest('rewards',body);if(membershipState()!==m||accountInfo.user?.id!==owner)return;m.rewards=response;const el=document.getElementById('reward-status');if(el)el.textContent=t('Bugünün görevleri hesabına kaydedildi.','Today’s tasks saved to your account.');if(response.earned){await refreshMembership();render();toast(t('1 ay Premium kazandın!','You earned one month of Premium!'));}}
function queueRewardSync(){if(!membershipState().rewards?.enrolled||!accountInfo.user||state.demo)return;clearTimeout(window.__rewardTimer);window.__rewardTimer=setTimeout(()=>syncRewardTasks().catch(()=>{const el=document.getElementById('reward-status');if(el)el.textContent=t('Görevler çevrimiçi olduğunda tekrar eşitlenmeli.','Sync tasks again when online.');}),900);}
async function membershipAction(a,el){if(!['gift-open','membership','membership-refresh','premium-checkout','reward-enroll','reward-sync'].includes(a))return;el.disabled=true;try{if(a==='gift-open'){await membershipConfig();modal(t('Hediye kodu','Gift code'),giftCodeSection());document.getElementById('gift-code')?.focus();}if(a==='membership'||a==='membership-refresh'){if(a==='membership-refresh')await refreshMembership();await showMembership();render();}
 if(a==='premium-checkout'){if(window.Capacitor?.isNativePlatform?.())throw Error('native_purchase_not_ready');const data=await accountRequest('checkout',{confirm:true,platform:'web'});if(data.provider==='paddle'){await openPaddleCheckout(data);return;}const u=new URL(data.url);if(u.protocol!=='https:'||u.hostname!=='pay.rev.cat')throw Error('invalid_checkout');location.assign(u.href);}
 if(a==='reward-enroll'){if(!accountInfo.user){await showAccount();return;}if(state.demo||!state.profile?.days?.length){toast(t('Önce gerçek profilini ve antrenman günlerini oluştur.','Create your real profile and workout days first.'));return;}const m=membershipState(),owner=accountInfo.user.id;const r=await accountRequest('rewards',{action:'enroll',days:state.profile.days,timezone:Intl.DateTimeFormat().resolvedOptions().timeZone});if(membershipState()!==m||accountInfo.user?.id!==owner)return;m.rewards=r;await syncRewardTasks();render();}
 if(a==='reward-sync'){await syncRewardTasks();render();}
 }catch(e){const out=document.getElementById('membership-error')||document.getElementById('reward-status');const text=e.message==='paddle_test_only'?t('Sandbox ödemesi yalnızca tanımlı test hesabına açık.','Sandbox checkout is limited to the configured test account.'):e.message==='checkout_rate_limit'?t('Yeni ödeme denemesi için bir dakika bekle.','Wait one minute before starting another checkout.'):e.message==='already_premium'?t('Zaten aktif aboneliğin var. Üyeliğini yenile.','You already have an active subscription. Refresh membership.'):e.message==='billing_not_configured'?t('Üyelik ve ödül hizmeti henüz açılmadı.','Membership and reward service is not enabled yet.'):e.message==='reward_database_not_ready'?t('Görev ödülü hizmeti henüz hazır değil.','Task reward service is not ready yet.'):t('İşlem tamamlanamadı. Bağlantını kontrol edip yeniden dene.','Could not complete. Check connection and retry.');if(out)out.textContent=text;else toast(text);}finally{if(el.isConnected)el.disabled=false;}}
app.addEventListener('click',e=>{const el=e.target.closest('[data-action]');if(el)membershipAction(el.dataset.action,el);});modalRoot.addEventListener('click',e=>{const el=e.target.closest('[data-action]');if(el)membershipAction(el.dataset.action,el);});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')initializeAccount().then(()=>{render();queueRewardSync();});});

// Native checkout uses localized store prices and the dashboard's current offering.
async function showNativeMembership(){
 const b=window.FitrotaBilling,owner=accountInfo.user?.id||null;
 try{
  await b.refresh(owner);
  let offering=null;try{offering=await b.offerings(owner);}catch(e){if(!b.active)throw e;}
  if((accountInfo.user?.id||null)!==owner)return;
  const e=b.entitlement;
  const plans=(offering?.availablePackages||[]).map(p=>{
   const label={'$rc_monthly':t('Aylık','Monthly'),'$rc_annual':t('Yıllık','Yearly'),'$rc_lifetime':t('Ömür boyu','Lifetime')}[p.identifier]||p.product.title;
   const period=p.identifier==='$rc_lifetime'?t('Tek seferlik ödeme','One-time purchase'):p.identifier==='$rc_annual'?t('Her yıl yenilenir','Renews yearly'):p.identifier==='$rc_monthly'?t('Her ay yenilenir','Renews monthly'):p.product.description;
   return `<div class="card space"><b>${esc(label)} · ${esc(p.product.priceString)}</b><p class="subtitle">${esc(period)}</p>${btn(t('Satın al','Purchase'),'native-purchase','outline full',`data-id="${esc(p.identifier)}"`)}</div>`;
  }).join('');
  modal('FitRota Premium',`${b.config.testMode?`<p class="notice">${t('Test mağazası: gerçek ücret alınmaz.','Test Store: no real charge.')}</p>`:''}${b.active?`<p class="notice space">✦ Premium · ${e.expirationDate?esc(new Date(e.expirationDate).toLocaleDateString(state.settings.lang)):t('Ömür boyu','Lifetime')}</p>`:plans}<div id="membership-error" class="formerror" role="alert"></div>`,
   (b.active?btn(t('Aboneliğimi yönet','Manage subscription'),'native-manage',''):btn(t('Premium ödeme ekranını aç','Open Premium paywall'),'native-paywall',''))+
   btn(t('Satın alımları geri yükle','Restore purchases'),'native-restore','outline')+
   btn(t('Üyeliğimi kontrol et','Check membership'),'membership-refresh','outline'));
 }catch(e){modal('FitRota Premium',`<p>${esc(nativeBillingErrorText(e))}</p><div id="membership-error" role="alert"></div>`,btn(t('Tekrar dene','Retry'),'membership-refresh','outline'));}
}
function nativeBillingErrorText(error){
 const key=window.fitrotaBillingError(error);
 const messages={cancelled:['Satın alma iptal edildi.','Purchase cancelled.'],pending:['Ödeme onay bekliyor. Onaydan sonra Premium erişimi güncellenir.','Payment is pending. Premium updates after approval.'],offering_missing:['RevenueCat’in güncel offering ayarını ve mağaza ürünlerini kontrol et.','Check the current RevenueCat offering and store products.'],store_key_missing:['Bu sürüm için mağaza bağlantısı henüz tamamlanmadı.','Store setup is not complete for this build.'],purchase_busy:['Önce mevcut işlemin bitmesini bekle.','Wait for the current operation to finish.']};
 return messages[key]?t(...messages[key]):t('İşlem tamamlanamadı. Bağlantını kontrol edip tekrar dene.','Could not complete. Check your connection and retry.');
}
async function nativeBillingAction(a,el){
 if(!['native-purchase','native-paywall','native-restore','native-manage'].includes(a))return;
 const b=window.FitrotaBilling,owner=accountInfo.user?.id||null;
 el.disabled=true;
 try{
  if(a==='native-purchase')await b.purchase(owner,el.dataset.id);
  if(a==='native-paywall'){closeModal();await b.paywall(owner);}
  if(a==='native-restore')await b.restore(owner);
  if(a==='native-manage'){closeModal();await b.manage(owner);}
  if((accountInfo.user?.id||null)!==owner)return;
  await refreshMembership();render();await showNativeMembership();
  if(a==='native-purchase'||a==='native-restore')toast(b.active?t('Premium erişimin aktif.','Premium is active.'):t('Aktif Premium satın alımı bulunamadı.','No active Premium purchase found.'));
 }catch(e){const text=nativeBillingErrorText(e),out=document.getElementById('membership-error');if(out)out.textContent=text;else toast(text);}finally{if(el.isConnected)el.disabled=false;}
}
modalRoot.addEventListener('click',e=>{const el=e.target.closest('[data-action]');if(el)nativeBillingAction(el.dataset.action,el);});
window.addEventListener('fitrota-billing-update',()=>{render();});
if(window.FitrotaBilling?.available)window.FitrotaBilling.refresh(accountInfo.user?.id).catch(()=>{});

function giftCodeSection(){
 const ready=membershipState().config?.giftCodesEnabled===true;
 return `<section class="gift-code-section space" aria-labelledby="gift-code-title"><div class="cardhead"><h3 id="gift-code-title">${t('Hediye kodun var mı?','Have a gift code?')}</h3>${icon('gift',22)}</div><p class="subtitle">${t('FitRota hediye kodunu kullan, Premium hesabına tanımlansın.','Redeem a FitRota gift code to add Premium to your account.')}</p>${!accountInfo.user?`<p class="space">${t('Kodunu kullanmak için hesabınla giriş yap.','Sign in to redeem your code.')}</p>${btn(t('Hesabımla giriş','Sign in'),'account','outline full')}`:!ready?`<p class="subtitle space">${t('Hediye kodları yakında kullanıma açılacak.','Gift codes will be available soon.')}</p>`:`<label class="field space" for="gift-code"><span>${t('Hediye kodu','Gift code')}</span><input id="gift-code" type="text" maxlength="80" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="FR…" aria-describedby="gift-code-result"></label>${btn(t('Kodu kullan','Redeem code'),'gift-redeem','full')}<p class="subtitle space">${t('Hediye süresi kod kullanıldığında başlar. Diğer hediye kodlarından kalan sürene eklenir. Ücretli aboneliğinin yenilemesini değiştirmez.','The gift starts when redeemed and extends any remaining code credit. It does not change paid subscription renewals.')}</p>`}<p id="gift-code-result" class="space" role="status" aria-live="polite"></p></section>`;
}
let giftRedemptionBusy=false;
async function redeemGiftCode(el){
 if(giftRedemptionBusy)return;
 const input=document.getElementById('gift-code'),out=document.getElementById('gift-code-result'),owner=accountInfo.user?.id;
 if(!input||!out||!owner)return;
 if(!input.value.trim()){out.textContent=t('Önce hediye kodunu yaz.','Enter your gift code first.');input.focus();return;}
 giftRedemptionBusy=true;el.disabled=true;input.disabled=true;out.textContent=t('Kod kontrol ediliyor…','Checking code…');
 try{
  const result=await accountRequest('redeem-gift',{code:input.value});
  if(accountInfo.user?.id!==owner)return;
  input.value='';await refreshMembership();
  if(accountInfo.user?.id!==owner)return;
  render();out.textContent=t('Hediye kodun kullanıldı. Premium bitiş tarihi: ','Gift redeemed. Premium expires: ')+new Date(result.premiumUntil).toLocaleDateString(state.settings.lang);
  if(!isPremium())out.textContent+=' '+t('Üyelik durumunu yenilemek için Üyeliğimi kontrol et seçeneğine dokun.','Tap Check membership to refresh your status.');
 }catch(e){
  if(accountInfo.user?.id!==owner)return;
  const messages={gift_invalid:['Kod geçersiz, süresi dolmuş veya kullanım hakkı bitmiş.','Code is invalid, expired or fully redeemed.'],gift_already_used:['Bu kodu hesabında zaten kullandın.','You have already redeemed this code.'],gift_rate_limit:['Çok fazla deneme yaptın. 15 dakika sonra tekrar dene.','Too many attempts. Try again in 15 minutes.'],gift_disabled:['Hediye kodları henüz kullanıma açılmadı.','Gift codes are not available yet.'],gift_unavailable:['Kod şu anda kontrol edilemiyor. Biraz sonra tekrar dene.','Cannot check your code right now. Please try again later.']};
  out.textContent=messages[e.message]?t(...messages[e.message]):t('Bağlantı kesildi. Üyeliğini kontrol et; gerekirse aynı kodla tekrar dene.','Connection interrupted. Check your membership, then retry the same code if needed.');
 }finally{giftRedemptionBusy=false;if(el.isConnected)el.disabled=false;if(input.isConnected)input.disabled=false;}
}
modalRoot.addEventListener('click',e=>{const el=e.target.closest('[data-action="gift-redeem"]');if(el)redeemGiftCode(el);});
modalRoot.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.id==='gift-code'){e.preventDefault();const el=modalRoot.querySelector('[data-action="gift-redeem"]');if(el)redeemGiftCode(el);}});

function localPremiumPrice(){
 const prices=membershipState().config?.prices||[{country:'TR',currency:'TRY',amount:49.99},{country:'US',currency:'USD',amount:3},{country:'EU',currency:'EUR',amount:2.99}];
 const zone=Intl.DateTimeFormat().resolvedOptions().timeZone||'', region=window.FITROTA_RELEASE?.market==='US'?'US':zone==='Europe/Istanbul'?'TR':zone.startsWith('America/')?'US':zone.startsWith('Europe/')?'EU':null;
 return prices.find(p=>p.country===region)||null;
}
function premiumPriceLabel(){const p=localPremiumPrice();return p?new Intl.NumberFormat(state.settings.lang,{style:'currency',currency:p.currency}).format(p.amount)+' / '+t('ay','month'):t('Yerel fiyat ödeme ekranında','Local price at checkout');}
function premiumSettingsCard(){return `<section class="card premium-settings premium-card"><div class="eyebrow">FITROTA PREMIUM</div><h2>${isPremium()?t('Premium üyeliğin','Your Premium membership'):t('Daha fazlası seninle','More for your routine')}</h2><p class="premium-price">${premiumPriceLabel()}</p><p class="subtitle">${t('Planlanan aylık fiyat. Kesin tutar ve vergiler ödeme onayından önce gösterilir.','Planned monthly price. Final price and taxes are shown before payment approval.')}</p><ul><li>${t('Reklamsız kullanım','Ad-free experience')}</li><li>${t('30 mesaj kotası olmadan gelişmiş AI','Advanced AI without the 30-message quota')}</li><li>${t('Haftalık analiz, Pratik mutfak ve Tatlı sert koç','Weekly analyst, Practical meals and Playful roast')}</li><li>${t('7 günlük gelişim raporu ve CSV','Seven-day progress report and CSV')}</li></ul>${btn(t(isPremium()?'Üyeliği yönet':'Premium seçeneklerini gör',isPremium()?'Manage membership':'See Premium options'),'membership','full space')}${btn(t('Hediye kodu kullan','Redeem gift code'),'gift-open','outline full space')}</section>`;}

let paddleScriptPromise;
function loadPaddle(){
 if(window.Paddle)return Promise.resolve(window.Paddle);
 if(paddleScriptPromise)return paddleScriptPromise;
 paddleScriptPromise=new Promise((resolve,reject)=>{
  const script=document.createElement('script');script.src='https://cdn.paddle.com/paddle/v2/paddle.js';script.async=true;
  const timer=setTimeout(()=>{script.remove();paddleScriptPromise=null;reject(Error('paddle_load_failed'));},15000);
  script.onload=()=>{clearTimeout(timer);if(window.Paddle)resolve(window.Paddle);else{paddleScriptPromise=null;reject(Error('paddle_load_failed'));}};
  script.onerror=()=>{clearTimeout(timer);script.remove();paddleScriptPromise=null;reject(Error('paddle_load_failed'));};document.head.append(script);
 });return paddleScriptPromise;
}
async function openPaddleCheckout(data){
 if(data.environment!=='sandbox'||!/^test_[a-zA-Z0-9]{27}$/.test(data.token||'')||!/^txn_[a-z0-9]{26}$/.test(data.transactionId||''))throw Error('invalid_checkout');
 const owner=accountInfo.user?.id;
 const paddle=await loadPaddle();if(accountInfo.user?.id!==owner)throw Error('account_changed');
 if(!window.__fitrotaPaddleInitialized){
  paddle.Environment.set('sandbox');
  paddle.Initialize({token:data.token,eventCallback:event=>{
   if(event.name==='checkout.completed'){
    const owner=window.__fitrotaPaddleOwner;
    // Never grant an entitlement from browser events. Wait for server confirmation.
    toast(t('Test ödemesi alındı. Üyeliğin sunucuda doğrulanıyor.','Test payment received. Verifying your membership.'));
    void (async()=>{for(let attempt=0;attempt<6;attempt++){await new Promise(r=>setTimeout(r,2000));if(accountInfo.user?.id!==owner)return;await refreshMembership();if(isPremium()){render();await showMembership();return;}}toast(t('Doğrulama bekleniyor. Biraz sonra Üyeliğimi kontrol et düğmesine bas.','Verification is pending. Tap Check membership shortly.'));})().catch(()=>{});
   }
  }});window.__fitrotaPaddleInitialized=true;
 }
 window.__fitrotaPaddleOwner=owner;
 paddle.Checkout.open({transactionId:data.transactionId,settings:{displayMode:'overlay',allowLogout:false}});
}
