// Native transport keeps the existing HttpOnly server session in Android's cookie jar.
export const nativeAccountConfig = Object.freeze({
  apiOrigin: 'https://fitrota-us-gateway.fatihgktg6.workers.dev',
  googleWebClientId: '897717716631-0n0vgvahfnjvoe9bhmtpo5chgud5sm9q.apps.googleusercontent.com',
});
export function createNativeAccount({http, social, config=nativeAccountConfig, cryptoImpl=globalThis.crypto}) {
  let publicOrigin=null, initialization=null, busy=false;
  async function request(path, options={}) {
    if (!/^\/(account(?:\/|$)|catalog\/search|legal\/)/.test(path)) throw Error('native_path_not_allowed');
    const headers=Object.fromEntries(new Headers(options.headers||{}));
    if(publicOrigin) headers.Origin=publicOrigin;
    const result=await http.request({url:config.apiOrigin+path,method:options.method||'GET',headers,
      ...(options.body?{data:JSON.parse(options.body)}:{}),responseType:'json',connectTimeout:15000,readTimeout:65000,disableRedirects:true});
    const body=result.data;
    if(path==='/account/config' && result.status===200) {
      const origin=new URL(body.publicOrigin||'');
      if(origin.protocol!=='https:') throw Error('native_backend_not_ready');
      publicOrigin=origin.origin;
    }
    return new Response(typeof body==='string'?body:JSON.stringify(body),{status:result.status,headers:result.headers});
  }
  async function login(preferences) {
    if(busy) throw Error('login_in_progress');
    busy=true;
    try {
      const cfg=await (await request('/account/config')).json();
      if(!cfg.nativeReady) throw Error('native_backend_not_ready');
      initialization??=social.initialize({google:{webClientId:config.googleWebClientId,mode:'online'}}).catch(e=>{initialization=null;throw e;});
      await initialization;
      const nonce=Array.from(cryptoImpl.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,'0')).join('');
      const hash=Array.from(new Uint8Array(await cryptoImpl.subtle.digest('SHA-256',new TextEncoder().encode(nonce))),b=>b.toString(16).padStart(2,'0')).join('');
      const result=await social.login({provider:'google',options:{nonce:hash,scopes:['openid','email','profile']}});
      if(!result.result?.idToken) throw Error('google_token_missing');
      const response=await request('/account/native-login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...preferences,provider:'google',idToken:result.result.idToken,nonce})});
      const data=await response.json();
      if(!response.ok) throw Error(data.error||'native_login_failed');
      return data;
    } finally {busy=false;}
  }
  return {request,login,logout:()=>social.logout({provider:'google'})};
}
