-- Existing 001_accounts.sql must already be installed. Safe to re-run.
-- Records self-reported daily tasks, frozen two-calendar-month periods and one-month gifts.
begin;
create table if not exists public.fitrota_reward_cycles (
 user_id uuid primary key references auth.users(id) on delete cascade,
 timezone text not null,
 training_days integer[] not null,
 cycle_start date not null,
 cycle_end date not null,
 premium_until timestamptz,
 check(cycle_end>cycle_start)
);
create table if not exists public.fitrota_reward_tasks (
 user_id uuid not null references public.fitrota_reward_cycles(user_id) on delete cascade,
 day date not null,workout boolean not null default false,meal boolean not null default false,water boolean not null default false,
 primary key(user_id,day)
);
create table if not exists public.fitrota_reward_awards (
 user_id uuid not null references public.fitrota_reward_cycles(user_id) on delete cascade,
 cycle_start date not null,cycle_end date not null,earned_at timestamptz not null default clock_timestamp(),premium_until timestamptz not null,
 primary key(user_id,cycle_start)
);
alter table public.fitrota_reward_cycles enable row level security;
alter table public.fitrota_reward_tasks enable row level security;
alter table public.fitrota_reward_awards enable row level security;
revoke all on public.fitrota_reward_cycles,public.fitrota_reward_tasks,public.fitrota_reward_awards from public,anon,authenticated;
grant select,insert,update,delete on public.fitrota_reward_cycles,public.fitrota_reward_tasks,public.fitrota_reward_awards to service_role;
create or replace function public.fitrota_reward_cycle(p_user_id uuid,p_action text default 'status',p_days integer[] default null,p_timezone text default null,p_workout boolean default false,p_meal boolean default false,p_water boolean default false,p_day date default null)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare r public.fitrota_reward_cycles%rowtype; today date; actual bigint; target bigint; earned boolean:=false; ending timestamptz;
begin
 if p_user_id is null or p_action is null or p_action not in ('status','enroll','record') then raise exception 'invalid_request'; end if;
 if p_action='enroll' then
  if p_days is null or cardinality(p_days) not between 1 and 6 or exists(select 1 from unnest(p_days) d where d is null or d not between 0 and 6) or cardinality(p_days)<>(select count(distinct d) from unnest(p_days) d) or p_timezone is null or not exists(select 1 from pg_timezone_names where name=p_timezone) then raise exception 'invalid_schedule'; end if;
  today:=(clock_timestamp() at time zone p_timezone)::date;
  insert into public.fitrota_reward_cycles(user_id,timezone,training_days,cycle_start,cycle_end) values(p_user_id,p_timezone,p_days,today,(today+interval '2 months')::date) on conflict do nothing;
 end if;
 select * into r from public.fitrota_reward_cycles where user_id=p_user_id for update;
 if not found then return jsonb_build_object('enrolled',false,'premiumUntil',null); end if;
 today:=(clock_timestamp() at time zone r.timezone)::date;
 -- Close each elapsed period once. No client date, uploaded backup or client Premium flag is accepted.
 while today>=r.cycle_end loop
  select count(*)*2+count(*) filter(where extract(dow from d)::integer=any(r.training_days)) into target from generate_series(r.cycle_start::timestamp,(r.cycle_end-1)::timestamp,interval '1 day') d;
  select coalesce(sum((t.meal::int)+(t.water::int)+case when extract(dow from t.day)::integer=any(r.training_days) then t.workout::int else 0 end),0) into actual from public.fitrota_reward_tasks t where t.user_id=p_user_id and t.day>=r.cycle_start and t.day<r.cycle_end;
  if actual=target and target>0 then
   ending:=(greatest(clock_timestamp(),coalesce(r.premium_until,clock_timestamp()))+interval '1 month');
   insert into public.fitrota_reward_awards(user_id,cycle_start,cycle_end,premium_until) values(p_user_id,r.cycle_start,r.cycle_end,ending) on conflict do nothing;
   if found then r.premium_until:=ending;earned:=true;end if;
  end if;
  delete from public.fitrota_reward_tasks where user_id=p_user_id and day<r.cycle_end;
  r.cycle_start:=r.cycle_end;r.cycle_end:=(r.cycle_end+interval '2 months')::date;
 end loop;
 if p_action='record' then
  if p_day is null or p_day<>today then raise exception 'invalid_day'; end if;
  insert into public.fitrota_reward_tasks(user_id,day,workout,meal,water) values(p_user_id,today,coalesce(p_workout,false),coalesce(p_meal,false),coalesce(p_water,false)) on conflict(user_id,day) do update set workout=public.fitrota_reward_tasks.workout or excluded.workout,meal=public.fitrota_reward_tasks.meal or excluded.meal,water=public.fitrota_reward_tasks.water or excluded.water;
 end if;
 update public.fitrota_reward_cycles set cycle_start=r.cycle_start,cycle_end=r.cycle_end,premium_until=r.premium_until where user_id=p_user_id;
 select count(*)*2+count(*) filter(where extract(dow from d)::integer=any(r.training_days)) into target from generate_series(r.cycle_start::timestamp,(r.cycle_end-1)::timestamp,interval '1 day') d;
 select coalesce(sum((t.meal::int)+(t.water::int)+case when extract(dow from t.day)::integer=any(r.training_days) then t.workout::int else 0 end),0) into actual from public.fitrota_reward_tasks t where t.user_id=p_user_id and t.day>=r.cycle_start and t.day<r.cycle_end;
 return jsonb_build_object('enrolled',true,'start',r.cycle_start,'end',r.cycle_end,'today',today,'days',r.training_days,'timezone',r.timezone,'done',actual,'target',target,'premiumUntil',r.premium_until,'earned',earned);
end;
$$;
revoke all on function public.fitrota_reward_cycle(uuid,text,integer[],text,boolean,boolean,boolean,date) from public,anon,authenticated;
grant execute on function public.fitrota_reward_cycle(uuid,text,integer[],text,boolean,boolean,boolean,date) to service_role;
commit;
