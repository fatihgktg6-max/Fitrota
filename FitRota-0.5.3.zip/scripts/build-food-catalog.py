"""Reproducible subset of CoFID 2021. Input: research/cofid.xlsx from GOV.UK."""
import openpyxl,json
from pathlib import Path
root=Path(__file__).resolve().parent.parent
rows={r[0]:r for r in openpyxl.load_workbook(root/'research/cofid.xlsx',read_only=True,data_only=True)['1.3 Proximates'].values if r[0]}
# Every amount is edible grams; cooked/dry state appears in the ingredient label.
spec={
'oat':('11-788','Yulaf (kuru)',['gluten'],1),'banana':('14-318','Muz (kabuksuz)',[],1),'yog':('12-379','Az yağlı sade yoğurt',['milk'],1),'egg':('12-940','Haşlanmış yumurta (kabuksuz)',['egg'],1),'bread':('11-981','Tam buğday ekmeği',['gluten'],1),'tomato':('13-517','Domates (çiğ)',[],1),'chicken':('18-323','Tavuk göğsü (pişmiş, derisiz)',[],2),'bulgur':('11-904','Bulgur (kuru tartılmış)',['gluten'],1),'lentil':('13-661','Mercimek (haşlanmış)',[],1),'rice':('11-862','Pirinç (pişmiş)',[],1),'oil':('17-038','Zeytinyağı',[],1),'potato':('13-491','Patates (fırınlanmış, kabuklu)',[],1),'chickpea':('13-662','Nohut (haşlanmış)',[],1),'salmon':('16-359','Somon (fırınlanmış)',['fish'],3),'broccoli':('13-504','Brokoli (buharda pişmiş)',[],1),'pasta':('11-723','Tam buğday makarna (haşlanmış)',['gluten'],1),'tofu':('13-570','Tofu (buharda pişmiş)',['soy'],2),'apple':('14-319','Elma (çekirdeksiz, kabuklu)',[],1),'seed':('14-842','Kabak çekirdeği içi',[],1),'almond':('14-896','Badem içi',['nuts'],2),'milk':('12-313','Yarım yağlı süt',['milk'],1),'soy':('12-524','Şekersiz güçlendirilmiş soya içeceği',['soy'],2),'bean':('13-659','Kırmızı fasulye (haşlanmış)',[],1),'cottage':('12-550','Az yağlı cottage peynir',['milk'],2),'carrot':('13-497','Havuç (haşlanmış)',[],1),'turkey':('18-359','Hindi göğsü (pişmiş)',[],2)}
ing={}
for k,(code,tr,a,cost) in spec.items():
 r=rows[code]
 def num(i):
  try:return float(r[i])
  except:return 0 if r[i]=='Tr' else None
 ing[k]={'code':code,'name':[tr,r[1]],'kcal':num(12),'protein':num(9),'carbs':num(11),'fat':num(10),'fiber':num(25),'allergens':a,'cost':cost}
# Original recipes; no third-party recipe text or images.
specs=[
('oats','Yoğurtlu yulaf kasesi','Yogurt oat bowl','breakfast','oat:60 yog:200 banana:100 seed:10'),
('eggs','Yumurtalı kahvaltı tabağı','Egg breakfast plate','breakfast','egg:100 bread:80 tomato:150 oil:5'),
('fruitoat','Meyveli yulaf','Fruit oats','breakfast','oat:70 banana:100 seed:20'),
('soy-oats','Soyalı yulaf kasesi','Soy oat bowl','breakfast','oat:60 soy:250 apple:150 seed:15'),
('cottage-toast','Peynirli tam tahıl tabağı','Cottage cheese toast','breakfast','cottage:150 bread:80 tomato:150 oil:5'),
('tofu-toast','Tofulu kahvaltı','Tofu breakfast','breakfast','tofu:200 bread:80 tomato:150 oil:5'),
('egg-potato','Yumurta ve patates','Egg and potato','breakfast','egg:100 potato:220 tomato:150 oil:5'),
('apple-oats','Elmalı sütlü yulaf','Apple milk oats','breakfast','oat:60 milk:250 apple:150 seed:10'),
('chicken','Tavuklu bulgur kasesi','Chicken bulgur bowl','main','chicken:140 bulgur:70 broccoli:200 oil:10'),
('lentil','Mercimek ve pirinç kasesi','Lentil rice bowl','main','lentil:250 rice:150 tomato:150 oil:10'),
('potato','Nohutlu fırın patates','Chickpea potato bowl','main','potato:250 chickpea:180 tomato:150 oil:10'),
('fish','Somon ve pirinç','Salmon and rice','main','salmon:130 rice:170 broccoli:200'),
('pasta','Mercimekli makarna','Lentil pasta','main','pasta:200 lentil:200 tomato:200 oil:10'),
('tofu','Sebzeli tofu','Tofu vegetables','main','tofu:250 rice:200 broccoli:200 oil:10'),
('turkey-rice','Hindili pirinç tabağı','Turkey rice plate','main','turkey:140 rice:200 carrot:150 oil:10'),
('bean-bulgur','Fasulyeli bulgur','Bean bulgur bowl','main','bean:220 bulgur:70 tomato:150 oil:10'),
('chickpea-bulgur','Nohutlu bulgur','Chickpea bulgur bowl','main','chickpea:200 bulgur:60 carrot:150 oil:5'),
('chicken-potato','Tavuk ve patates','Chicken and potato','main','chicken:140 potato:280 broccoli:200 oil:10'),
('lentil-egg','Yumurtalı mercimek tabağı','Lentil egg plate','main','lentil:220 egg:100 bread:60 tomato:150 oil:5'),
('bean-rice','Fasulye ve pirinç','Beans and rice','main','bean:250 rice:180 broccoli:200 oil:10'),
('tofu-pasta','Tofulu makarna','Tofu pasta','main','tofu:250 pasta:200 tomato:200 oil:10'),
('salmon-potato','Somon ve fırın patates','Salmon potato plate','main','salmon:130 potato:250 broccoli:200 oil:5'),
('chicken-pasta','Tavuklu makarna','Chicken pasta','main','chicken:140 pasta:200 tomato:200 oil:10'),
('lentil-potato','Mercimekli patates','Lentil potato bowl','main','lentil:250 potato:250 carrot:150 oil:10'),
('yogurt','Yoğurt ve meyve','Yogurt and fruit','snack','yog:250 apple:150 seed:10'),
('apple','Elma ve kabak çekirdeği','Apple and pumpkin seeds','snack','apple:150 seed:30'),
('nuts','Muz ve badem','Banana and almonds','snack','banana:150 almond:25'),
('cottage-fruit','Peynir ve meyve','Cottage cheese and fruit','snack','cottage:180 apple:150'),
('soy-banana','Soya içeceği ve muz','Soy drink and banana','snack','soy:250 banana:150 seed:15'),
('chickpea-snack','Nohutlu küçük kase','Small chickpea bowl','snack','chickpea:150 tomato:150 oil:5'),
('milk-oat','Sütlü küçük yulaf','Small milk oat bowl','snack','milk:200 oat:35 banana:70'),
('egg-bread','Yumurta ve ekmek','Egg and bread','snack','egg:50 bread:50 tomato:100')]
foods=[]
for id,tr,en,typ,parts in specs:
 parts=[(k,float(q)) for k,q in (p.split(':') for p in parts.split())]
 alls=sorted({a for k,q in parts for a in ing[k]['allergens']})
 meat=any(k in ['chicken','turkey','salmon'] for k,q in parts)
 dairy=any(k in ['egg','yog','milk','cottage'] for k,q in parts)
 totals={n:round(sum((ing[k][n] or 0)*q/100 for k,q in parts),1) for n in ['kcal','protein','carbs','fat','fiber']}
 foods.append({'id':id,'name':[tr,en],'type':typ,'emoji':'🥣' if typ=='breakfast' else '🥗','minutes':10 if typ!='main' else 30,'cost':max(ing[k]['cost'] for k,q in parts),'diet':'omnivore' if meat else 'vegetarian' if dairy else 'vegan','allergens':alls,**totals,'ingredients':[[*ing[k]['name'],q,'g'] for k,q in parts],'sourceCodes':[ing[k]['code'] for k,q in parts],'steps':['Malzemeleri listede belirtilen pişmiş/kuru durumuna göre tart. Kuru bulguru paket talimatına göre pişir; yulafı suyla yumuşatabilirsin. Et, balık ve yumurtayı tamamen pişir; sebze ve meyveyi yıka. Malzemeleri birleştir, listede varsa zeytinyağını ekle. Eklediğin başka yağ ve sosları ayrıca günlüğe kaydet.','Weigh ingredients in their listed cooked/dry state. Cook dry bulgur as directed on its packet; soften oats with water if preferred. Cook meat, fish and eggs thoroughly; wash produce. Combine and add the listed oil. Log any extra oils or sauces separately.']})
(root/'src/food-data.js').write_text('// CoFID 2021 subset; Crown copyright, Open Government Licence v3.0. See docs/CONTENT-SOURCES.md.\nexport const nutrientIngredients='+json.dumps(ing,ensure_ascii=False)+';\nexport const curatedFoods='+json.dumps(foods,ensure_ascii=False)+';\n')
s=root/'src/catalog.js';text=s.read_text();start=text.index('export const foods = [');end=text.index('export const labels',start);text="import {curatedFoods} from './food-data.js';\n"+text[:start]+'export const foods = curatedFoods;\n'+text[end:];s.write_text(text)
print(len(foods),'recipes;',len(ing),'traced ingredients')
