import {createHmac,timingSafeEqual} from 'node:crypto';

export const PADDLE_WEBHOOK_PATH='/webhooks/paddle/sandbox';
const id=(value,prefix)=>typeof value==='string'&&new RegExp('^'+prefix+'_[a-z0-9]{26}$').test(value);
const uuid=value=>typeof value==='string'&&/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(value);
const fail=()=>{throw Error('billing_unavailable');};

export function verifyPaddleSignature(raw,header,secret,now=Date.now()){
 if(!secret||typeof header!=='string'||header.length>1024)return false;
 const fields=header.split(';').map(x=>x.trim().split('='));
 const timestamps=fields.filter(([key])=>key==='ts');
 if(timestamps.length!==1||!/^\d{10}$/.test(timestamps[0][1]||''))return false;
 const timestamp=timestamps[0][1];
 if(Math.abs(now/1000-Number(timestamp))>5)return false;
 const expected=createHmac('sha256',secret).update(timestamp+':').update(raw).digest();
 return fields.some(([key,value])=>key==='h1'&&/^[a-f0-9]{64}$/i.test(value||'')&&timingSafeEqual(expected,Buffer.from(value,'hex')));
}

// This release intentionally supports sandbox only. Live payments require a separate rollout.
export function createPaddleService({env=process.env,fetcher=fetch,now=()=>Date.now()}={}){
 const base=(env.SUPABASE_URL||'').replace(/\/$/,''),admin=env.SUPABASE_SERVICE_ROLE_KEY;
 const price=env.PADDLE_PRICE_ID,token=env.PADDLE_CLIENT_TOKEN;
 let origin;try{const u=new URL(env.FITROTA_PUBLIC_ORIGIN);if(u.protocol==='https:'&&u.origin===env.FITROTA_PUBLIC_ORIGIN)origin=u.origin;}catch{}
 const testers=new Set((env.FITROTA_PADDLE_TEST_EMAILS||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean));
 const configured=env.FITROTA_PADDLE_ENABLED==='true'&&env.PADDLE_ENVIRONMENT==='sandbox'&&!!env.PADDLE_API_KEY&&!!env.PADDLE_WEBHOOK_SECRET&&!!base&&!!admin&&!!origin&&id(price,'pri')&&/^test_[a-zA-Z0-9]{27}$/.test(token||'')&&testers.size>0&&testers.size<=10;
 const allowed=user=>configured&&uuid(user?.id)&&!!user?.email_confirmed_at&&testers.has((user.email||'').toLowerCase());
 async function paddle(path,body){
  const r=await fetcher('https://sandbox-api.paddle.com'+path,{method:body?'POST':'GET',headers:{Authorization:'Bearer '+env.PADDLE_API_KEY,'Content-Type':'application/json','Paddle-Version':'1'},...(body?{body:JSON.stringify(body)}:{}),redirect:'error',signal:AbortSignal.timeout(10000)});
  if(!r.ok){
   let code='';try{code=(await r.json()).error?.code||'';}catch{}
   if(['transaction_default_checkout_url_not_set','transaction_checkout_url_not_approved','transaction_checkout_url_invalid'].includes(code))throw Error('paddle_payment_link_required');
   if(r.status===401||r.status===403)throw Error('paddle_api_access_error');
   if(r.status===404)throw Error('paddle_resource_not_found');
   throw Error('paddle_request_failed');
  }
  const d=await r.json();if(!d.data)fail();return d.data;
 }
 async function db(path,{method='GET',body,prefer}={}){
  const r=await fetcher(base+'/rest/v1/'+path,{method,headers:{apikey:admin,Authorization:'Bearer '+admin,'Content-Type':'application/json',...(prefer?{Prefer:prefer}:{})},...(body?{body:JSON.stringify(body)}:{}),redirect:'error',signal:AbortSignal.timeout(8000)});
  if(!r.ok)throw Error('paddle_database_unavailable');
  // PostgREST returns 201 with an EMPTY body for INSERT + return=minimal.
  // Only read JSON for operations that actually request a representation.
  if(r.status===204||prefer?.split(',').includes('return=minimal'))return null;
  return r.json();
 }
 const eligibleItems=items=>Array.isArray(items)&&items.length===1&&items[0].price?.id===price&&items[0].quantity===1&&items[0].price?.billing_cycle?.interval==='month'&&items[0].price?.billing_cycle?.frequency===1;
 async function checkout(user){
  if(!allowed(user))throw Error('paddle_test_only');
  // A database reservation also prevents duplicate checkout creation across server instances.
  const claim=await db('rpc/fitrota_paddle_claim_checkout',{method:'POST',body:{p_user_id:user.id}});
  if(!claim)throw Error('checkout_rate_limit');
  const existing=await status(user.id);
  if(existing.premium||existing.hasSubscription)throw Error('already_premium');
  const transaction=await paddle('/transactions',{items:[{price_id:price,quantity:1}],collection_mode:'automatic',currency_code:'USD',custom_data:{fitrota_user_id:user.id},checkout:{url:origin+'/paddle-checkout'}});
  if(!id(transaction.id,'txn'))fail();
  await db('fitrota_paddle_checkouts',{method:'POST',body:{transaction_id:transaction.id,user_id:user.id},prefer:'return=minimal'});
  // The browser never chooses the price or entitlement owner.
  return {provider:'paddle',environment:'sandbox',token,transactionId:transaction.id};
 }
 async function recordCompleted(transactionId,occurredAt){
  if(!id(transactionId,'txn')||!Number.isFinite(Date.parse(occurredAt)))throw Error('invalid_paddle_event');
  const transaction=await paddle('/transactions/'+transactionId);
  if(transaction.id!==transactionId||transaction.status!=='completed'||transaction.origin==='subscription_payment_method_change'||!id(transaction.subscription_id,'sub')||!eligibleItems(transaction.items)||transaction.currency_code!=='USD')return;
  const known=await db('fitrota_paddle_subscriptions?subscription_id=eq.'+transaction.subscription_id+'&select=user_id');
  const pending=await db('fitrota_paddle_checkouts?transaction_id=eq.'+transactionId+'&select=user_id');
  const owner=pending[0]?.user_id||known[0]?.user_id;
  if(!uuid(owner)||transaction.custom_data?.fitrota_user_id!==owner||known[0]&&known[0].user_id!==owner)return;
  await db('rpc/fitrota_paddle_record_payment',{method:'POST',body:{p_user_id:owner,p_subscription_id:transaction.subscription_id,p_transaction_id:transaction.id,p_occurred_at:occurredAt}});
 }
 async function status(owner){
  const free={owner,premium:false,adFree:false,unlimitedAI:false,source:null,expiresAt:null,managementURL:null};
  if(!configured||!uuid(owner))return free;
  // Resolve against the provider on every entitlement check, not a browser callback.
  const rows=await db('fitrota_paddle_subscriptions?user_id=eq.'+encodeURIComponent(owner)+'&select=subscription_id,transaction_id');
  let best=null,managementURL=null,hasSubscription=false;
  for(const row of rows){
   if(!id(row.subscription_id,'sub')||!id(row.transaction_id,'txn'))fail();
   const [subscription,transaction,revoked]=await Promise.all([paddle('/subscriptions/'+row.subscription_id),paddle('/transactions/'+row.transaction_id),db('fitrota_paddle_refunds?transaction_id=eq.'+row.transaction_id+'&select=transaction_id')]);
   if(subscription.id!==row.subscription_id||subscription.custom_data?.fitrota_user_id!==owner)continue;
   if(['active','trialing','past_due','paused'].includes(subscription.status))hasSubscription=true;
   const management=subscription.management_urls?.cancel;
   try{const u=new URL(management);if(u.protocol==='https:'&&u.hostname==='sandbox-customer-portal.paddle.com'&&!u.username&&!u.password)managementURL=u.href;}catch{}
   const expiry=Date.parse(subscription.current_billing_period?.ends_at);
   if(subscription.status!=='active'||!Number.isFinite(expiry)||expiry<=now()||!eligibleItems(subscription.items))continue;
   const paidUntil=Date.parse(transaction.billing_period?.ends_at);
   if(transaction.status!=='completed'||transaction.origin==='subscription_payment_method_change'||transaction.subscription_id!==row.subscription_id||transaction.custom_data?.fitrota_user_id!==owner||transaction.currency_code!=='USD'||!eligibleItems(transaction.items)||!Number.isFinite(paidUntil)||paidUntil<=now())continue;
   if(revoked.length)continue;
   const until=Math.min(expiry,paidUntil);
   if(!best||until>best.until)best={until,managementURL};
  }
  if(!best)return {...free,managementURL,hasSubscription};
  return {...free,premium:true,adFree:true,unlimitedAI:true,source:'paddle_sandbox',hasSubscription:true,expiresAt:new Date(best.until).toISOString(),managementURL:best.managementURL,lifetime:false};
 }
 async function webhook(raw,signature){
  if(!configured)throw Error('billing_not_configured');
  if(!verifyPaddleSignature(raw,signature,env.PADDLE_WEBHOOK_SECRET,now()))throw Error('invalid_paddle_signature');
  let event;try{event=JSON.parse(raw.toString('utf8'));}catch{throw Error('invalid_paddle_event');}
  if(!id(event.event_id,'evt')||!Number.isFinite(Date.parse(event.occurred_at))||!event.data)throw Error('invalid_paddle_event');
  if(event.event_type==='transaction.completed')await recordCompleted(event.data.id,event.occurred_at);
  if(['adjustment.created','adjustment.updated'].includes(event.event_type)&&['refund','chargeback'].includes(event.data.action)&&event.data.status==='approved'){
   if(!id(event.data.transaction_id,'txn'))throw Error('invalid_paddle_event');
   // Conservative sandbox policy: any approved refund removes access for that paid transaction.
   // Upsert is idempotent and records refunds even when they arrive before payment events.
   await db('fitrota_paddle_refunds',{method:'POST',body:{transaction_id:event.data.transaction_id},prefer:'resolution=ignore-duplicates,return=minimal'});
  }
  // Subscription events are acknowledged; status always re-reads the current provider state.
  return {received:true};
 }
 return {configured,allowed,checkout,status,webhook,publicConfig:()=>({provider:'paddle',environment:'sandbox',token,prices:[{country:'US',currency:'USD',amount:3}]})};
}
