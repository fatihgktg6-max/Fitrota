# Yayın öncesi kullanıcı belgeleri ve işlem listesi

3 Ekim 2026 — teknik hazırlık; hukuki danışmanlık veya uygunluk sertifikası değildir.

## Hazırlananlar

- Kullanım koşulları: `/legal/terms`
- Gizlilik/KVKK aydınlatma taslağı: `/legal/privacy`
- Hesap ve veri silme açıklaması: `/legal/deletion` (herkese açık URL olarak kullanılabilir; henüz canlıya gönderilmedi)
- Aynı metinler Profil → Hesap & gizlilik ekranından açılır.
- Yerel sağlıkla ilişkili tercihler için ayrı seçim, koşul kabulü, AI için mevcut ayrı onay ve bulut aktarımı için ayrıca kutu.
- İndirilebilir JSON yedeği; yerel profil silme; hesap açılmışsa bulut yedeği ve hesap silme.
- Veri envanteri ve akışlar gizlilik metninde açıklanır. Ödeme/reklam SDK’sı eklenmedi.

## İşletmeci bilgisi gerektiren tamamlanmamış noktalar

Gerçek kişi/şirket adı, adres, gizlilik iletişimi, sorumlu kişi; hukukî işleme dayanakları; sağlayıcı bölgeleri/alt işleyenleri; uluslararası aktarım mekanizmaları; güvenlik logları ve yedekler dahil somut saklama/silme süreleri. Bunlar bilinmediği için sahte bilgi yazılmadı. Sunucu env alanları tamamlanmadan belgeler açıkça TEST TASLAĞI olarak görünür ve OAuth kapalı kalır.

AB için GDPR özel veri dayanakları ve aktarım, Türkiye için KVKK aydınlatma/özel nitelikli veri/aktarım, ABD için uygulanabilir eyalet tüketici sağlık verisi kuralları ve FTC Health Breach Notification Rule kapsamı uzman tarafından değerlendirilmelidir. Genel metin tek başına üç bölgenin tamamında uygunluk sağlamaz. Açık rıza gereklilikleri ile aydınlatma birbirine karıştırılmamalıdır. Tıbbi cihaz iddiası yapılmadığından özellikler genel sağlık/kayıt aracı olarak tanımlanır; tıbbi amaç değişirse ayrıca değerlendirme gerekir.

## Mağaza ve canlı operasyon

Apple: gizlilik politikası/App Privacy yanıtları, üçüncü taraf giriş varsa login services kuralı, uygulama içinden hesap silme, Apple erişim iptali, inceleme hesabı/demo erişimi. Yerel giriş henüz entegre değil.

Google Play: gizlilik URL’si, Data Safety, Health apps declaration, hesap varsa uygulama içi ve dışı silme yolu, geliştirici kimlik bilgileri ve gerekli test kanalları. Sağlık iddiaları ve tıbbi olmayan işlev açıklaması gerçek davranışla aynı olmalı.

Abonelik açılmadan önce ürün/fiyat/otomatik yenileme, deneme, iptal/iade, satın alma geri yükleme ve ülkeye uygun ön bilgilendirme/dijital hizmet şartları hazırlanmalı. Reklam eklenirse gerçek SDK veri akışına göre gizlilik/izin ekranları yeniden düzenlenmeli; bu pakette bunlar etkin değil.

Üretim güvenliği: gerçek RLS iki-kullanıcı testleri, dış hata/saldırı incelemesi, güvenli loglar, yedek/geri yükleme testi, olay/ihlal prosedürü, bağımlılık ve gerçek cihaz testleri, erişilebilirlik incelemesi, hareket içeriklerinin eğitmen/diyetisyen kontrolü. Kullanıcı sağlık verilerini test hesaplarında izinsiz kullanma.

## Kaynaklar

- Apple Review Guidelines: https://developer.apple.com/app-store/review/guidelines/
- Apple hesap silme: https://developer.apple.com/support/offering-account-deletion-in-your-app
- Google Health Content and Services: https://support.google.com/googleplay/android-developer/answer/16679511?hl=en
- Google Data Safety: https://support.google.com/googleplay/android-developer/answer/10787469?hl=en
- Google account deletion: https://support.google.com/googleplay/android-developer/answer/13327111?hl=en
- KVKK aydınlatma: https://www.kvkk.gov.tr/Icerik/2033/Aydinlatma-Yukumlulugu-
- KVKK aydınlatma usulleri: https://www.kvkk.gov.tr/Icerik/4132/aydinlatma-yukumlulugunun-yerine-getirilmesinde-uyulacak-usul-ve-esaslar-hakkinda-teblig
- European Commission processing grounds: https://commission.europa.eu/law/law-topic/data-protection/information-business-and-organisations/legal-grounds-processing-data_en
- FTC HBNR: https://www.ftc.gov/legal-library/browse/rules/health-breach-notification-rule
- FTC app guidance: https://www.ftc.gov/business-guidance/resources/complying-ftcs-health-breach-notification-rule-0
