import {test} from 'node:test';
import assert from 'node:assert/strict';
import {NativeBilling,billingError} from '../src/revenuecat-client.js';
const free={entitlements:{active:{}}};
const pro={entitlements:{active:{fitrota_pro:{isActive:true,expirationDate:null}}}};
const offering={identifier:'default',availablePackages:[{identifier:'$rc_lifetime',product:{priceString:'₺999,99'}}]};
function fixture(){
 let current=free,listener;const calls=[];
 const purchases={configure:async v=>calls.push(['configure',v]),logIn:async v=>{calls.push(['login',v]);current=free;return {customerInfo:current};},logOut:async()=>{calls.push(['logout']);current=free;return {customerInfo:current};},getCustomerInfo:async()=>({customerInfo:current}),getOfferings:async()=>({current:offering}),addCustomerInfoUpdateListener:async f=>{listener=f;return 'listener';},removeCustomerInfoUpdateListener:async v=>calls.push(['remove',v]),purchasePackage:async v=>{calls.push(['purchase',v]);current=pro;return {customerInfo:current};},restorePurchases:async()=>{current=pro;return {customerInfo:current};}};
 const ui={presentPaywallIfNeeded:async v=>{calls.push(['paywall',v]);current=pro;return {result:'PURCHASED'};},presentCustomerCenter:async()=>{calls.push(['center']);current=free;}};
 const b=new NativeBilling({purchases,ui,config:{testMode:true,testApiKey:'test_example',entitlement:'fitrota_pro'},platform:()=> 'android'});
 return {b,purchases,calls,update:v=>{current=v;listener(v);}};
}
test('configure once, purchase offering package, retrieve current info, switch identities without carrying access',async()=>{
 const {b,calls}=fixture();await b.refresh('alice');await b.refresh('alice');assert.equal(calls.filter(c=>c[0]==='configure').length,1);
 await b.purchase('alice','$rc_lifetime');assert.equal(b.active,true);assert.equal(b.entitlement.expirationDate,null);assert.equal(calls.find(c=>c[0]==='purchase')[1].aPackage,offering.availablePackages[0]);
 await b.refresh('bob');assert.equal(b.active,false);assert.equal(b.owner,'bob');await b.refresh(null);assert.equal(b.active,false);assert.ok(calls.some(c=>c[0]==='logout'));
 await b.dispose();assert.deepEqual(calls.at(-1),['remove',{listenerToRemove:'listener'}]);
});
test('paywall checks fitrota_pro and current offering; restore, listener, Customer Center refresh access',async()=>{
 const {b,calls,update}=fixture();await b.paywall(null);assert.equal(b.active,true);assert.equal(calls.find(c=>c[0]==='paywall')[1].requiredEntitlementIdentifier,'fitrota_pro');
 await b.manage(null);assert.equal(b.active,false);await b.restore(null);assert.equal(b.active,true);update(free);await b.tail;assert.equal(b.active,false);
});
test('duplicate purchase is rejected; cancellation/pending cannot grant access; retry initialization after failure',async()=>{
 const {b,purchases}=fixture();let release;purchases.purchasePackage=()=>new Promise(r=>release=r);const pending=b.purchase(null,'$rc_lifetime');await assert.rejects(b.restore(null),/purchase_busy/);await new Promise(r=>setImmediate(r));release({customerInfo:free});await pending;assert.equal(b.active,false);
 purchases.purchasePackage=async()=>{throw {code:'20'};};await assert.rejects(b.purchase(null,'$rc_lifetime'));assert.equal(b.active,false);assert.equal(b.busy,false);
 assert.equal(billingError({code:'20'}),'pending');assert.equal(billingError({userCancelled:true}),'cancelled');
 const other=fixture();let attempts=0;other.purchases.configure=async()=>{if(!attempts++)throw Error('offline');};await assert.rejects(other.b.refresh(null));await other.b.refresh(null);assert.equal(other.b.configured,true);
});
test('web and missing production keys never invoke checkout',async()=>{
 const {b,calls}=fixture();b.platform=()=> 'web';await assert.rejects(b.paywall(null),/native_only/);assert.equal(calls.length,0);
 b.platform=()=> 'android';b.config.testMode=false;b.config.androidApiKey='test_bad';await assert.rejects(b.refresh(null),/store_key_missing/);assert.equal(calls.length,0);
});
