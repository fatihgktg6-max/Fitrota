# FitRota — spor, beslenme ve günlük düzen

**Sürüm 0.2.0 — çalışan yerel ilk sürüm. Mağaza yayınına hazır nihai ürün değildir.**

Geçici ürün adı FitRota. Android, iPhone ve tablet hedefiyle aynı arayüzü kullanan Capacitor projesi. Türkçe ve İngilizce desteklenir. ABD/Avrupa/Türkiye için mağaza yayını yapılmadı; çok bölgeli ödeme ve diğer Avrupa dilleri henüz eklenmedi.

## Hemen dene

`FitRota-Onizleme.html` dosyasını JavaScript çalıştırabilen bir tarayıcıda aç. İnternet, hesap veya kurulum gerektirmeyen tek dosyalı önizlemedir. “Örnek uygulamayı gez” ile örnek verileri görebilir veya kendi profilini oluşturabilirsin.

Bu dosya APK değildir. Bazı tablet dosya görüntüleyicileri JavaScript çalıştırmaz; dosyayı tarayıcıda açmak veya aşağıdaki Android derlemesini kullanmak gerekir. Dosya üzerinden yerel depolama davranışı tarayıcıya göre değişebilir. Verilerin önemliyse Ayarlar → Yedeği indir.

## Bu sürümde gerçekten çalışanlar

- 3 adımlı profil: yaş, boy, kilo, hedef, seviye, ev/salon, süre, günler, beslenme tercihi, alerjenler, bütçe.
- 8 ana ekran: Bugün, Antrenman, Beslenme, Koç, Takvim, Gelişim, Ödüller, Ayarlar.
- 17 hareketlik başlangıç kütüphanesi, açıklamalar ve alternatifler.
- Süre/ekipman/seviyeye göre yerel antrenman önerisi; önizleme ve kullanıcı onayıyla günlük uyarlama.
- Set, tekrar ve kg kaydı; dinlenme sayacı; kapanıp açılan antrenmana devam.
- Kendi programını oluşturma/kaydetme/kullanma.
- 12 tarif, porsiyonlu öğün kaydı, yaklaşık besin değerleri, tarif alternatifleri.
- Diyet/alerjen/istenmeyen malzeme/bütçe filtreleri ve eldeki malzemeyle tarif eşleşmesi.
- Seçili günlük tariflerden birleştirilmiş alışveriş listesi, işaretleme ve metin dışa aktarımı.
- Kullanıcının belirlediği enerji ve protein hedefi. Otomatik tıbbi diyet reçetesi üretilmez.
- Su günlüğü, kilo/bel kaydı ve grafik; kg/cm veya lb/in gösterimi.
- Takvim etkinlikleri ve `.ics` dışa aktarma. Android/iOS bildirim köprüsü var, gerçek cihazda henüz test edilmedi.
- Destekleyici/doğrudan/enerjik gerçek AI koç bağlantısı; sunucu ve API hesabı yapılandırıldığında OpenAI yanıtlarını gösterir. Bağlantısızken sahte yanıt vermez.
- Haftalık/aylık hedef ve mükerrer kazanımı engelleyen ödül önizlemesi.
- JSON yedek dışa/içe aktarımı, yedek doğrulama, tüm verileri silme.
- Mobil/tablet/masaüstü düzeni, klavye odağı, diyalog odağı, azaltılmış hareket desteği.

## AI ve abonelik durumu

Koç arayüzü, istemci ve sunucu artık uçtan uca bağlıdır. **Bu teslimde sunucu/sağlayıcı hesabı yapılandırılmadığından canlı AI aktif değildir.** API anahtarı yalnızca sunucuda kalır. Bağlantı formu, veri paylaşımı onayı, kısa ömürlü oturum, hata/iptal/yeniden deneme ve kullanım sınırları eklenmiştir.

Kurulum ve pilot barındırma ayrıntıları: `docs/LIVE-AI.md`. Anahtarı asla HTML, mobil paket, kaynak kod veya yerel yedek içine koyma. Bu dosyayı açmak tek başına AI hizmetini açmaz.

Abonelik satın alma, reklam, App Store/Google Play makbuz doğrulaması, kullanıcı hesabı ve bulut eşitleme yoktur. Ödül alma **gerçek ücretli AI hakkı açmaz**, yalnızca “önizleme” kaydı oluşturur. Ürün kuralı önerisi: haftalık hedef 1 gün, aynı ayda başlayan 4 başarılı hafta 3 gün hediye. Süreler değiştirilebilir. Abonelere ek kullanım hakkı için sunucu entegrasyonu gerekir. Ücret alınmaz.

## Bilgisayarda geliştirme

Node.js 22 veya üzeri:

```bash
npm ci
npm run dev
```

Yerel adres: `http://127.0.0.1:4173`.

```bash
npm run check
npm run build
```

`dist/index.html` native uygulamanın web içeriğidir. `FitRota-Onizleme.html` aynı içeriğin taşınabilir kopyasıdır. Core uygulama derlemesi harici bundler kullanmaz; modülleri açık bir sırayla birleştirir. Yeni modül eklenirse `scripts/build.mjs` listesini güncelle. Native köprü, kurulu `@capacitor/core` dosyasından dahil edilir.

## Android

`android/` projesi oluşturulup Capacitor ile eşitlendi. Bu ortamda Android SDK ve Java 21 olmadığı için **APK derlenmedi**.

Bilgisayarda Android Studio/SDK 36 ve Java 21 ile:

```bash
npm ci
npm run native:android
npx cap open android
```

Komut satırından:

```bash
cd android
./gradlew assembleDebug
```

APK: `android/app/build/outputs/apk/debug/app-debug.apk`.

### Yalnızca tablet kullanıyorsan

Projenin dosyalarını yeni bir GitHub reposunun köküne koyduktan sonra `.github/workflows/android.yml` iş akışı kullanılabilir. Paket bir repo içine **FitRota adlı fazladan üst klasör olmadan**, `package.json` kökte olacak şekilde yüklenmelidir. GitHub → Actions → Android APK → Run workflow. Başarılı olursa `FitRota-Android-Debug` artifact ZIP’i içinden APK alınır. Bu iş akışı burada GitHub üzerinde çalıştırılmadı. Debug APK mağaza yüklemesi değildir; mağaza için imzalı release AAB gerekir.

## iPhone / iPad

`ios/` Xcode projesi oluşturulup eşitlendi. Mac/Xcode ortamı ve Apple imzalama hesabı gerekir:

```bash
npm ci
npm run native:ios
npx cap open ios
```

Signing & Capabilities bölümünde kendi Team değerini seç. Geliştirme paket kimliği `com.fitrota.app`; yayın öncesinde marka/kimlik kontrolü gerekir. Bu sürümde iOS binary/TestFlight çıktısı üretilmedi.

## Testler

```bash
npm test
npx playwright install chromium
npm run test:ui
node tests/extended-ui.mjs
```

19 mantık/adaptör testi ve 4 HTTP sunucu testi; onboarding, su, uyarlama, yarım antrenmanın korunması, tamamlama, öğün, takvim, koç, dil değiştirme, özel program, HTML enjeksiyonu, ölçüm, yedek geri yükleme ve silme tarayıcı testleri vardır. Ana 8 ekran 390 / 768 / 1440 px genişlikte yatay taşma açısından kontrol edilir. Son doğrulama ayrıntıları `docs/TEST-RESULTS.md`.

## Yapı

| Yol | Sorumluluk |
|---|---|
| `src/app.js` | Ekranlar, formlar, olaylar, kullanıcı akışları |
| `src/core.js` | Planlama, beslenme toplamları, hedef/ödül ve yedek doğrulama |
| `src/catalog.js` | İki dilli hareket ve tarif başlangıç kataloğu |
| `src/store.js` | Cihaz içi saklama |
| `src/native.js` | Yerel bildirim köprüsü |
| `src/icons.js`, `src/style.css` | Vektör görseller ve duyarlı görünüm |
| `src/ai-client.js` | Oturum açma ve gerçek AI istemci istekleri |
| `server/` | Tek sahipli pilot AI sunucusu |
| `tests/` | Mantık ve uçtan uca testler |
| `android/`, `ios/` | Oluşturulmuş native projeler |
| `.github/workflows/` | APK ve kontrol iş akışları |
| `docs/` | Ürün kapsamı, sınırlar, sonraki işler |

## Kaynaklar

- Capacitor: https://capacitorjs.com/docs
- Ortam gereksinimleri: https://capacitorjs.com/docs/getting-started/environment-setup
- Bildirimler: https://capacitorjs.com/docs/apis/local-notifications
- AI metin API biçimi: https://developers.openai.com/api/docs/guides/text

Tarif besin değerleri başlangıç tahminleridir; doğrulanmış gıda veri tabanından alınmadı. Egzersiz içeriği ve beslenme hesabı yayın öncesinde yetkin uzmanlarca incelenmeli. Hareket simgesi teknik video değildir. Fotoğrafla kalori ölçme, hareket analizi, ilaç/takviye dozlama bu sürümün kapsamına dahil değildir.
