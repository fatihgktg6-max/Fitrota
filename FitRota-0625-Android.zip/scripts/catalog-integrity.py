"""Portable catalog verification independent of SQLite's binary file layout."""
import hashlib,sqlite3

def catalog_digest(path):
 db=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True)
 try:
  if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('Catalog integrity check failed')
  digest=hashlib.sha256();count=0
  for row in db.execute('SELECT id,barcode,search,data FROM foods ORDER BY id'):
   for value in row:
    raw=value.encode('utf-8');digest.update(len(raw).to_bytes(8,'big'));digest.update(raw)
   count+=1
  if db.execute('SELECT count(*) FROM food_search').fetchone()[0]!=count:raise RuntimeError('Catalog search index count mismatch')
  db.execute("SELECT rowid FROM food_search WHERE food_search MATCH 'milk' LIMIT 1").fetchall()
  return count,digest.hexdigest()
 finally:db.close()
