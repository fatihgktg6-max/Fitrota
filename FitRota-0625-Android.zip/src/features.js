import {exercises} from './catalog.js';
import {uid,dayKey,dateOf,addDays,weekStart,workoutPlan,claimReward,scheduledWeekdays} from './core.js';

export function ensureMonth(state,date=dayKey()){
 const month=date.slice(0,7);state.monthGoals??={};if(state.monthGoals[month])return state.monthGoals[month];
 const first=month+'-01',created=dayKey(new Date(state.createdAt)),days=[];
 for(let d=first;d.slice(0,7)===month;d=addDays(d,1))if(d>=created&&scheduledWeekdays(state).includes(dateOf(d).getDay()))days.push(d);
 return state.monthGoals[month]={month,planned:days,createdAt:new Date().toISOString()};
}
export function monthProgress(state,month=dayKey().slice(0,7),today=dayKey()){
 const goal=state.monthGoals?.[month],dates=goal?.planned||[];
 const done=dates.filter(d=>d<=today&&state.workouts[d]?.completed).length;
 return {done,total:dates.length,percent:dates.length?Math.round(done/dates.length*100):0,complete:dates.length>0&&done===dates.length&&dates.at(-1)<=today};
}
export function awardMonthlyPreviews(state,today=dayKey()){
 if(state.demo)return [];
 const receipts=[];for(const month of Object.keys(state.monthGoals||{})){
  if(month>today.slice(0,7)||!monthProgress(state,month,today).complete||state.claims.some(c=>c.key===`month:${month}`))continue;
  const receipt=claimReward(state,'monthly',month+'-01',dateOf(today).getTime());receipts.push(receipt);
 }return receipts;
}
export function datePlan(state,date){
 if(state.workouts[date]?.completed)return state.workouts[date].plan;
 if(state.activeWorkout?.date===date)return state.activeWorkout.plan;
 const frozen=state.weeks[weekStart(date)];const profile=frozen&&(!state.profile.trainingStyle||state.profile.trainingStyle==='auto')?{...state.profile,days:frozen.planned.map(d=>dateOf(d).getDay())}:state.profile;
 return state.workoutPlans?.[date]||customWeeklyPlan(state,date)||workoutPlan(profile,{date});
}
export function alternativesFor(plan,index,equipment){
 const current=plan.items[index];if(!current)return [];
 return exercises.filter(e=>e.id!==current.id&&e.group[1]===current.group[1]&&(equipment==='gym'||e.equipment==='home')&&e.level!=='advanced'&&!plan.items.some(x=>x.id===e.id));
}
export function swapExercise(state,date,index,id){
 if(state.workouts[date]?.completed)throw Error('completed');
 const plan=structuredClone(datePlan(state,date)),old=plan.items[index];
 if(!old||!alternativesFor(plan,index,state.profile.equipment).some(x=>x.id===id))throw Error('alternative');
 plan.items[index]={...exercises.find(e=>e.id===id),sets:old.sets};
 plan.minutes=(plan.warmup||0)+(plan.cooldown||0)+plan.items.reduce((a,e)=>a+e.minutes,0);
 state.workoutPlans??={};state.workoutPlans[date]=plan;
 if(state.activeWorkout?.date===date){state.activeWorkout.plan=structuredClone(plan);for(const key of Object.keys(state.activeWorkout.sets))if(key.startsWith(index+':'))delete state.activeWorkout.sets[key];state.restTimer=null;}
 return plan;
}
export function restSeconds(timer,now=Date.now()){
 if(!timer)return 0;return timer.paused?Math.max(0,timer.remaining):Math.max(0,Math.ceil((timer.endAt-now)/1000));
}
export function startRest(state,seconds=60,now=Date.now()){
 if(!Number.isInteger(seconds)||seconds<15||seconds>600)throw Error('rest');
 state.restTimer={endAt:now+seconds*1000,remaining:seconds,total:seconds,paused:false};return state.restTimer;
}
export function toggleRest(state,now=Date.now()){
 const r=state.restTimer;if(!r)return;
 if(r.paused){r.endAt=now+r.remaining*1000;r.paused=false;}else{r.remaining=restSeconds(r,now);r.paused=true;}
}
export function ingredientCategory(name){
 const n=name.toLocaleLowerCase('tr');
 if(n==='su'||/tuz|baharat|limon suyu/.test(n))return 'other';
 if(/tavuk|ton bal|somon|hindi|et |kıyma/.test(n))return 'protein';
 if(/yoğurt|süt|peynir|yumurta/.test(n))return 'dairy';
 if(/pirinç|bulgur|yulaf|ekmek|makarna|mercimek|nohut|fasulye/.test(n))return 'pantry';
 if(/yağ|badem|ceviz|fındık|fıstık|tahin/.test(n))return 'other';
 return 'produce';
}
export const shoppingCategories={produce:['Meyve & sebze','Fruit & vegetables'],protein:['Et & balık','Meat & fish'],dairy:['Süt ürünleri & yumurta','Dairy & eggs'],pantry:['Tahıl & bakliyat','Grains & legumes'],other:['Diğer','Other']};
export const musicMoods=[
 {id:'focus',title:['Odaklan','Focus'],description:['Sözsüz elektronik ve lo-fi; setlerine odaklan.','Instrumental electronic and lo-fi for focus.'],query:'instrumental workout focus'},
 {id:'energy',title:['Enerjini yükselt','More energy'],description:['Sevdiğin hareketli pop, rock veya elektronik parçalar.','Upbeat pop, rock or electronic tracks you enjoy.'],query:'workout motivation upbeat'},
 {id:'calm',title:['Sakinleş','Wind down'],description:['Antrenman sonunda yumuşak akustik ve ambient.','Gentle acoustic and ambient after your session.'],query:'relaxing ambient cool down'}
];

export function customWeeklyPlan(state,date){if(!state.weeklyPlan||state.profile.health)return null;const p=state.weeklyPlan.days[dateOf(date).getDay()];return {...structuredClone(p),date,mode:p.off?'recovery':'custom',title:p.off?['Dinlenme · OFF','Rest · OFF']:p.title};}
