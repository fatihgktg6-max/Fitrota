// Provider keys never enter this module. Only short-lived FitRota sessions do.
export function coachBaseUrl(value){
 const u=new URL(value);
 const loopback=['localhost','127.0.0.1','[::1]'].includes(u.hostname);
 if(u.protocol!=='https:'&&!(u.protocol==='http:'&&loopback))throw Error('https_required');
 if(u.username||u.password||u.search||u.hash||u.pathname!=='/')throw Error('invalid_server');
 return u.origin;
}
async function coachFetch(baseUrl,path,{token,body,signal,method='POST'}={}){
 const combined=signal?AbortSignal.any([signal,AbortSignal.timeout(35000)]):AbortSignal.timeout(35000);
 let res;try{res=await fetch(coachBaseUrl(baseUrl)+path,{method,headers:{...(body?{'Content-Type':'application/json'}:{}),...(token?{Authorization:`Bearer ${token}`}:{})},...(body?{body:JSON.stringify(body)}:{}),signal:combined,credentials:'omit',cache:'no-store'});}catch(e){if(e.name==='TimeoutError')throw Error('timeout');if(e.name==='AbortError')throw e;throw Error('network_error');}
 let data;try{data=await res.json();}catch{throw Error('invalid_response');}
 if(!res.ok){const allowed=['unauthorized','session_expired','ai_not_configured','usage_limit','origin_not_allowed','provider_rate_limit','provider_error','timeout'];throw Error(allowed.includes(data.error)?data.error:'ai_unavailable');}return data;
}
export async function connectLiveCoach({baseUrl,accessCode,consent=false}){
 if(!consent)throw Error('consent_required');
 if(!accessCode||accessCode.startsWith('sk-'))throw Error('access_code_required');
 const data=await coachFetch(baseUrl,'/session',{body:{accessCode}});
 if(typeof data.sessionToken!=='string'||!Number.isFinite(Date.parse(data.expiresAt))||!data.configured)throw Error('invalid_response');
 return {baseUrl:coachBaseUrl(baseUrl),token:data.sessionToken,expiresAt:data.expiresAt};
}
export async function disconnectLiveCoach(connection){if(connection)await coachFetch(connection.baseUrl,'/session',{token:connection.token,method:'DELETE'});}
export async function requestLiveCoach({baseUrl,sessionToken,messages,context,consent=false,signal}){
 if(!consent)throw Error('consent_required');if(!sessionToken)throw Error('session_expired');
 const result=await coachFetch(baseUrl,'/coach',{token:sessionToken,body:{messages,context},signal});
 if(typeof result.text!=='string'||!result.text.trim()||result.source!=='openai')throw Error('invalid_response');return result;
}
