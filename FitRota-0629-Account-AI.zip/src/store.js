import {emptyState,validateBackup} from './core.js';
let STORAGE_KEY='fitrota.v1';
export function setStorageOwner(id){if(id!==null&&!/^[a-zA-Z0-9-]{1,100}$/.test(id))throw Error('invalid_owner');STORAGE_KEY=id?'fitrota.account.'+id:'fitrota.v1';}
export let storageWarning='';
export function loadState(){try{const data=localStorage.getItem(STORAGE_KEY);const state=data?validateBackup(JSON.parse(data)):emptyState();if(typeof window!=='undefined'&&window.FITROTA_RELEASE?.market==='US'&&(state.settings.usReleaseRevision!==1||state.settings.market!=='US')){Object.assign(state.settings,{market:'US',...(state.settings.usReleaseRevision!==1?{lang:'en'}:{}),units:state.settings.usReleaseRevision===1?state.settings.units:'imperial',usReleaseRevision:1});localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}const language=localStorage.getItem('fitrota.language');if(['en','tr','es','de','fr','pt'].includes(language))state.settings.lang=language;return state;}catch{storageWarning='load';return emptyState();}}
export function saveState(state){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state));return true;}catch{storageWarning='save';return false;}}
export function clearState(){localStorage.removeItem(STORAGE_KEY);}
