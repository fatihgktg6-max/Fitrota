// Public catalogue is fetched only when food search is opened. No personal data is sent.
function catalogState(){return window.__catalogState??={status:'idle',loaded:0,pending:null};}
function catalogNotice(){const c=catalogState();if(state.settings.market==='TR'||!window.FITROTA_CATALOG||c.status==='ready')return '';return `<p class="catalog-progress" role="status">${c.status==='error'?t('Ek ürünler yüklenemedi. Mevcut besinlerle devam edebilir veya tekrar deneyebilirsin.','Extra products unavailable. Use loaded foods or retry.'):t('Uluslararası ürün kataloğu yükleniyor…','Loading international products…')} ${brandedFoods.length.toLocaleString()} / ${window.FITROTA_CATALOG.count.toLocaleString()} ${c.status==='error'?btn(t('Tekrar dene','Retry'),'catalog-retry','outline sm'):''}</p>`;}
async function ensureFoodCatalog(){
 const cfg=window.FITROTA_CATALOG,c=catalogState();if(state.settings.market==='TR'||!cfg||c.status==='ready')return;if(c.pending)return c.pending;
 c.status='loading';c.pending=(async()=>{try{for(let i=c.loaded;i<cfg.files.length;i++){
  const response=await fetch(cfg.files[i],{credentials:'omit',signal:AbortSignal.timeout(30000)});if(!response.ok)throw Error('catalog_unavailable');
  const chunk=await response.json();if(!Array.isArray(chunk)||chunk.some(f=>!f.id||!Array.isArray(f.name)))throw Error('catalog_invalid');
  for(const food of chunk){food.key=food.id;brandedFoods.push(food);}c.loaded=i+1;baseFoodPool=undefined;
  if(document.getElementById('unified-food-results'))paintFoodResults();
  await new Promise(resolve=>setTimeout(resolve,0));
 }c.status='ready';}catch{c.status='error';}finally{c.pending=null;if(document.getElementById('unified-food-results'))paintFoodResults();}})();return c.pending;
}
function startFoodCatalog(){if(catalogState().status==='idle')queueMicrotask(()=>ensureFoodCatalog());}
