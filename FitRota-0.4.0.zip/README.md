# FitRota 0.4.0

Spor, beslenme, günlük planlama ve isteğe bağlı AI koç için erken erişim web/PWA uygulaması; Android/iOS proje kaynakları dahil.

**Güncel kullanım, özellikler, yayın komutu ve sınırlar:** [RELEASE-0.4.0](docs/RELEASE-0.4.0.md).

Yeni: koyu tema, haftalık program, güne özel notlar, alternatif hareketler, set arası sayaç, müzik aramaları, gelişmiş alışveriş listesi, bölgesel Premium fiyat önizlemesi ve otomatik aylık ödül kaydı.

Gerçek satın alma veya Premium hakkı verilmez. AI tek sahipli erişim kodu ile çalışır. Anahtarları GitHub'a koymayın. Kalıcı kullanıcı hesabı/cihaz eşitleme ve imzalı mağaza paketleri henüz yoktur.

## Yerel çalışma

Node.js 22+: `npm ci`, `npm run check`, `npm run dev`.

Derlenmiş PWA: sunucu ortamını `server/.env.example` üzerinden ayarlayıp `npm run server`. Sağlayıcı anahtarı sadece sunucuda olmalıdır. Chromium testleri ve yayın ayrıntıları sürüm belgesinde.
