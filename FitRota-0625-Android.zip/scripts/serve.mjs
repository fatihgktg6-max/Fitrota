// Serve the same compiled application and public legal routes as production.
// No provider credentials are required for an offline-feature development session.
import {randomBytes} from 'node:crypto';
import {createCoachServer} from '../server/index.mjs';
const port=Number(process.env.PORT||4173),host='127.0.0.1';
createCoachServer({accessCode:randomBytes(32).toString('base64url'),allowedOrigins:[`http://${host}:${port}`,`http://localhost:${port}`]}).listen(port,host,()=>console.log(`FitRota development: http://${host}:${port}`));
