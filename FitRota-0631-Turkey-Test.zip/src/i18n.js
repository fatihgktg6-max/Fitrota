// UI language is independent of the release market, store country and currency.
export const supportedLanguages=['en','tr','es','de','fr','pt'];
export const languageNames={en:'English',tr:'Türkçe',es:'Español',de:'Deutsch',fr:'Français',pt:'Português'};
const uiRows=`Today|Hoy|Heute|Aujourd’hui|Hoje
Workout|Entrenamiento|Training|Entraînement|Treino
Nutrition|Nutrición|Ernährung|Nutrition|Nutrição
Coach|Entrenador|Coach|Coach|Treinador
Calendar|Calendario|Kalender|Calendrier|Calendário
Progress|Progreso|Fortschritt|Progrès|Progresso
Rewards|Recompensas|Belohnungen|Récompenses|Recompensas
Settings|Ajustes|Einstellungen|Paramètres|Configurações
Profile|Perfil|Profil|Profil|Perfil
Overview|Resumen|Übersicht|Vue d’ensemble|Visão geral
Close|Cerrar|Schließen|Fermer|Fechar
Cancel|Cancelar|Abbrechen|Annuler|Cancelar
Save|Guardar|Speichern|Enregistrer|Salvar
Edit|Editar|Bearbeiten|Modifier|Editar
Add|Añadir|Hinzufügen|Ajouter|Adicionar
Delete|Eliminar|Löschen|Supprimer|Excluir
Continue|Continuar|Weiter|Continuer|Continuar
Back|Atrás|Zurück|Retour|Voltar
Retry|Reintentar|Erneut versuchen|Réessayer|Tentar novamente
Search|Buscar|Suchen|Rechercher|Pesquisar
Name|Nombre|Name|Nom|Nome
Goal|Objetivo|Ziel|Objectif|Objetivo
Training|Entrenamiento|Training|Entraînement|Treino
Training style|Tipo de entrenamiento|Trainingsstil|Type d’entraînement|Tipo de treino
Place|Lugar|Ort|Lieu|Local
Gym|Gimnasio|Fitnessstudio|Salle de sport|Academia
Home|Casa|Zu Hause|Maison|Casa
days|días|Tage|jours|dias
days/week|días/semana|Tage/Woche|jours/semaine|dias/semana
exercises|ejercicios|Übungen|exercices|exercícios
min|min|Min.|min|min
sec|s|Sek.|s|s
side|lado|Seite|côté|lado
Theme|Tema|Design|Thème|Tema
Light|Claro|Hell|Clair|Claro
Dark|Oscuro|Dunkel|Sombre|Escuro
Follow device|Según el dispositivo|Geräteeinstellung|Selon l’appareil|Seguir dispositivo
Language|Idioma|Sprache|Langue|Idioma
Appearance & experience|Aspecto y experiencia|Darstellung und Bedienung|Apparence et expérience|Aparência e experiência
My preferences|Mis preferencias|Meine Einstellungen|Mes préférences|Minhas preferências
My profile|Mi perfil|Mein Profil|Mon profil|Meu perfil
My account|Mi cuenta|Mein Konto|Mon compte|Minha conta
Sign in|Iniciar sesión|Anmelden|Se connecter|Entrar
Sign out|Cerrar sesión|Abmelden|Se déconnecter|Sair
Continue with Google|Continuar con Google|Mit Google fortfahren|Continuer avec Google|Continuar com Google
Welcome to FitRota|Bienvenido a FitRota|Willkommen bei FitRota|Bienvenue sur FitRota|Bem-vindo ao FitRota
Your routine.|Tu rutina.|Deine Routine.|Votre routine.|Sua rotina.
Your progress.|Tu progreso.|Dein Fortschritt.|Vos progrès.|Seu progresso.
Start your routine|Empieza tu rutina|Starte deine Routine|Commencez votre routine|Comece sua rotina
Explore a preview|Explorar una vista previa|Vorschau ansehen|Explorer un aperçu|Explorar uma prévia
Build a fitness routine that fits your day. Track workouts, meals and water, and see how far you’ve come.|Crea una rutina que se adapte a tu día. Registra entrenamientos, comidas y agua, y descubre tu progreso.|Gestalte eine Routine für deinen Alltag. Erfasse Training, Mahlzeiten und Wasser und entdecke deinen Fortschritt.|Créez une routine adaptée à votre journée. Suivez entraînements, repas et eau, et découvrez vos progrès.|Crie uma rotina para o seu dia. Registre treinos, refeições e água e acompanhe seu progresso.
Fitness|Fitness|Fitness|Fitness|Fitness
Meals|Comidas|Mahlzeiten|Repas|Refeições
Water|Agua|Wasser|Eau|Água
Protein|Proteína|Protein|Protéines|Proteína
Carbs|Carbohidratos|Kohlenhydrate|Glucides|Carboidratos
Fat|Grasa|Fett|Lipides|Gordura
Calories|Calorías|Kalorien|Calories|Calorias
Breakfast|Desayuno|Frühstück|Petit-déjeuner|Café da manhã
Lunch|Almuerzo|Mittagessen|Déjeuner|Almoço
Dinner|Cena|Abendessen|Dîner|Jantar
Snack|Aperitivo|Snack|Collation|Lanche
Budget|Presupuesto|Budget|Budget|Orçamento
Daily targets|Objetivos diarios|Tagesziele|Objectifs quotidiens|Metas diárias
Complete|Completado|Abgeschlossen|Terminé|Concluído
Today’s workout|Entrenamiento de hoy|Heutiges Training|Entraînement du jour|Treino de hoje
Your weekly review|Tu resumen semanal|Dein Wochenrückblick|Votre bilan hebdomadaire|Seu resumo semanal
Ad-free. Unlimited AI.|Sin anuncios. IA ilimitada.|Werbefrei. Unbegrenzte KI.|Sans publicité. IA illimitée.|Sem anúncios. IA ilimitada.
Ad-free experience|Sin anuncios|Werbefreie Nutzung|Sans publicité|Sem anúncios
Unlimited AI|IA ilimitada|Unbegrenzte KI|IA illimitée|IA ilimitada
Weekly review|Resumen semanal|Wochenrückblick|Bilan hebdomadaire|Resumo semanal
Your Premium membership|Tu suscripción Premium|Deine Premium-Mitgliedschaft|Votre abonnement Premium|Sua assinatura Premium
Get Premium|Obtener Premium|Premium holen|Passer à Premium|Obter Premium
Explore Premium|Descubrir Premium|Premium entdecken|Découvrir Premium|Explorar Premium
See Premium options|Ver opciones Premium|Premium-Optionen ansehen|Voir les options Premium|Ver opções Premium
Premium options|Opciones Premium|Premium-Optionen|Options Premium|Opções Premium
Manage membership|Gestionar suscripción|Mitgliedschaft verwalten|Gérer l’abonnement|Gerenciar assinatura
Manage subscription|Gestionar suscripción|Abonnement verwalten|Gérer l’abonnement|Gerenciar assinatura
Restore purchases|Restaurar compras|Käufe wiederherstellen|Restaurer les achats|Restaurar compras
Check membership|Comprobar suscripción|Mitgliedschaft prüfen|Vérifier l’abonnement|Verificar assinatura
Monthly|Mensual|Monatlich|Mensuel|Mensal
Yearly|Anual|Jährlich|Annuel|Anual
Lifetime|De por vida|Lebenslang|À vie|Vitalício
Renews monthly|Se renueva cada mes|Verlängert sich monatlich|Renouvellement mensuel|Renovação mensal
Renews yearly|Se renueva cada año|Verlängert sich jährlich|Renouvellement annuel|Renovação anual
One-time purchase|Pago único|Einmaliger Kauf|Achat unique|Compra única
Purchase|Comprar|Kaufen|Acheter|Comprar
Continue to Google Play|Continuar a Google Play|Weiter zu Google Play|Continuer vers Google Play|Continuar para o Google Play
Premium is active.|Premium está activo.|Premium ist aktiv.|Premium est actif.|Premium está ativo.
Purchase cancelled.|Compra cancelada.|Kauf abgebrochen.|Achat annulé.|Compra cancelada.
No active Premium purchase found.|No se encontró una compra Premium activa.|Kein aktiver Premium-Kauf gefunden.|Aucun achat Premium actif trouvé.|Nenhuma compra Premium ativa encontrada.
Your price comes from Google Play. Currency and regional pricing follow your Play account, not your app language.|El precio viene de Google Play. La moneda y el precio regional dependen de tu cuenta de Play, no del idioma de la aplicación.|Der Preis kommt von Google Play. Währung und regionale Preise richten sich nach deinem Play-Konto, nicht nach der App-Sprache.|Le prix vient de Google Play. La devise et le tarif régional dépendent de votre compte Play, pas de la langue de l’application.|O preço vem do Google Play. A moeda e o preço regional dependem da sua conta Play, não do idioma do aplicativo.
Subscriptions renew automatically until cancelled. Review the final price and renewal terms in Google Play before confirming.|Las suscripciones se renuevan automáticamente hasta su cancelación. Revisa el precio final y las condiciones en Google Play antes de confirmar.|Abonnements verlängern sich automatisch bis zur Kündigung. Prüfe Preis und Bedingungen in Google Play vor der Bestätigung.|Les abonnements se renouvellent automatiquement jusqu’à résiliation. Vérifiez le prix et les conditions dans Google Play avant de confirmer.|As assinaturas são renovadas automaticamente até o cancelamento. Confira o preço final e as condições no Google Play antes de confirmar.
Terms|Condiciones|Nutzungsbedingungen|Conditions|Termos
Privacy|Privacidad|Datenschutz|Confidentialité|Privacidade
AI coach|Entrenador IA|KI-Coach|Coach IA|Treinador IA
Open coach|Abrir entrenador|Coach öffnen|Ouvrir le coach|Abrir treinador
The coach uses your account; no access code is needed.|El entrenador usa tu cuenta; no necesitas un código.|Der Coach nutzt dein Konto; kein Zugangscode erforderlich.|Le coach utilise votre compte ; aucun code requis.|O treinador usa sua conta; nenhum código é necessário.
I agree to share messages and the listed plan/preferences with OpenAI for AI replies.|Acepto compartir mensajes y las preferencias indicadas con OpenAI para obtener respuestas de IA.|Ich stimme zu, Nachrichten und die angegebenen Planinformationen mit OpenAI für KI-Antworten zu teilen.|J’accepte de partager mes messages et les préférences indiquées avec OpenAI pour les réponses IA.|Concordo em compartilhar mensagens e as preferências indicadas com a OpenAI para respostas de IA.
Could not connect to the coach. Check your connection and try again.|No se pudo conectar al entrenador. Revisa la conexión e inténtalo de nuevo.|Verbindung zum Coach fehlgeschlagen. Prüfe die Verbindung und versuche es erneut.|Connexion au coach impossible. Vérifiez la connexion et réessayez.|Não foi possível conectar ao treinador. Verifique a conexão e tente novamente.
Signing you in…|Iniciando sesión…|Anmeldung läuft…|Connexion en cours…|Entrando…
Checking account…|Comprobando cuenta…|Konto wird geprüft…|Vérification du compte…|Verificando conta…
Checking your plan…|Comprobando tu plan…|Dein Plan wird geprüft…|Vérification de votre abonnement…|Verificando seu plano…
Secure sign-in|Inicio de sesión seguro|Sichere Anmeldung|Connexion sécurisée|Login seguro
Your routine, together.|Tu rutina, en un solo lugar.|Deine Routine, an einem Ort.|Votre routine, ensemble.|Sua rotina, em um só lugar.
Keep your workouts, nutrition and progress in one place.|Tus entrenamientos, nutrición y progreso en un solo lugar.|Training, Ernährung und Fortschritt an einem Ort.|Entraînements, nutrition et progrès au même endroit.|Seus treinos, nutrição e progresso em um só lugar.
You control what you share.|Tú controlas lo que compartes.|Du bestimmst, was du teilst.|Vous contrôlez ce que vous partagez.|Você controla o que compartilha.
Optional AI and cloud services|Servicios opcionales de IA y nube|Optionale KI- und Cloud-Dienste|Services IA et cloud facultatifs|Serviços opcionais de IA e nuvem
Redeem gift code|Canjear código de regalo|Geschenkcode einlösen|Utiliser un code cadeau|Resgatar código de presente
Gift code|Código de regalo|Geschenkcode|Code cadeau|Código de presente
Local price at checkout|Precio local al pagar|Lokaler Preis beim Bezahlen|Prix local au paiement|Preço local no pagamento
Language changes display text, not your market or payment currency.|El idioma cambia los textos, no el mercado ni la moneda.|Die Sprache ändert Texte, nicht Markt oder Zahlungswährung.|La langue change les textes, pas le marché ni la devise.|O idioma muda os textos, não o mercado ou a moeda.
Additional languages cover the main interface. Some detailed content and legal documents remain in English.|Los idiomas adicionales cubren la interfaz principal. Algunos contenidos detallados y documentos legales siguen en inglés.|Zusätzliche Sprachen decken die Hauptoberfläche ab. Einige ausführliche Inhalte und Rechtsdokumente bleiben auf Englisch.|Les langues supplémentaires couvrent l’interface principale. Certains contenus détaillés et documents juridiques restent en anglais.|Os idiomas adicionais cobrem a interface principal. Alguns conteúdos detalhados e documentos legais permanecem em inglês.`;
const releaseTranslations=`Permissions and backup|Permisos y copias|Berechtigungen und Sicherung|Autorisations et sauvegarde|Permissões e backup
Premium AI ready|IA Premium lista|Premium-KI bereit|IA Premium prête|IA Premium pronta
Syncing AI membership|Sincronizando suscripción IA|KI-Mitgliedschaft synchronisieren|Synchronisation de l’abonnement IA|Sincronizando assinatura IA
Your store subscription is preserved. Check membership for AI access; do not pay again.|Tu suscripción se conserva. Comprueba el acceso IA; no pagues de nuevo.|Dein Abonnement bleibt erhalten. Prüfe den KI-Zugang; zahle nicht erneut.|Votre abonnement est conservé. Vérifiez l’accès IA sans repayer.|Sua assinatura está preservada. Confira o acesso IA; não pague novamente.
FITNESS · NUTRITION · PROGRESS|FITNESS · NUTRICIÓN · PROGRESO|FITNESS · ERNÄHRUNG · FORTSCHRITT|SPORT · NUTRITION · PROGRÈS|FITNESS · NUTRIÇÃO · PROGRESSO
PREVIEW|VISTA PREVIA|VORSCHAU|APERÇU|PRÉVIA
YOUR DAILY ROUTINE|TU RUTINA DIARIA|DEIN TAGESABLAUF|VOTRE ROUTINE QUOTIDIENNE|SUA ROTINA DIÁRIA
A little stronger.|Un poco más fuerte.|Ein bisschen stärker.|Un peu plus fort.|Um pouco mais forte.
Every day.|Cada día.|Jeden Tag.|Chaque jour.|Todos os dias.
kcal logged|kcal registradas|kcal erfasst|kcal enregistrées|kcal registradas
Carbs|Carbohidratos|Kohlenhydrate|Glucides|Carboidratos
Fat|Grasas|Fett|Lipides|Gorduras
Your next workout|Tu próximo entrenamiento|Dein nächstes Training|Votre prochaine séance|Seu próximo treino
Full body · 35 min|Cuerpo completo · 35 min|Ganzkörper · 35 Min.|Corps entier · 35 min|Corpo inteiro · 35 min
Hydration|Hidratación|Flüssigkeitszufuhr|Hydratation|Hidratação
Keep your daily rhythm|Mantén tu ritmo diario|Behalte deinen Tagesrhythmus|Gardez votre rythme quotidien|Mantenha seu ritmo diário
Example values · Your goals are personal|Valores de ejemplo · Tus metas son personales|Beispielwerte · Deine Ziele sind individuell|Valeurs indicatives · Vos objectifs sont personnels|Valores de exemplo · Suas metas são pessoais
One place for your next step.|Un lugar para tu próximo paso.|Ein Ort für deinen nächsten Schritt.|Un espace pour votre prochaine étape.|Um lugar para seu próximo passo.
Personal workout and nutrition preferences|Preferencias personales de entrenamiento y nutrición|Persönliche Trainings- und Ernährungswünsche|Préférences personnelles de sport et de nutrition|Preferências pessoais de treino e nutrição
Food search with brands and nutrition labels|Búsqueda de alimentos con marcas y valores nutricionales|Lebensmittelsuche mit Marken und Nährwertangaben|Recherche d’aliments avec marques et valeurs nutritionnelles|Busca de alimentos com marcas e informações nutricionais
Optional AI guidance and weekly progress|Orientación IA opcional y progreso semanal|Optionale KI-Beratung und Wochenfortschritt|Conseils IA facultatifs et progrès hebdomadaires|Orientação IA opcional e progresso semanal
Complete your profile|Completa tu perfil|Vervollständige dein Profil|Complétez votre profil|Complete seu perfil
You’re signed in. Set up your goals to personalize your experience.|Ya has iniciado sesión. Configura tus metas para personalizar tu experiencia.|Du bist angemeldet. Lege deine Ziele fest, um dein Erlebnis anzupassen.|Vous êtes connecté. Définissez vos objectifs pour personnaliser votre expérience.|Você está conectado. Defina suas metas para personalizar sua experiência.
Sign in or create your account to get started.|Inicia sesión o crea tu cuenta para empezar.|Melde dich an oder erstelle ein Konto, um loszulegen.|Connectez-vous ou créez votre compte pour commencer.|Entre ou crie sua conta para começar.
Continue setup|Continuar configuración|Einrichtung fortsetzen|Continuer la configuration|Continuar configuração
Continue to sign in|Continuar al inicio de sesión|Weiter zur Anmeldung|Continuer vers la connexion|Continuar para entrar
For adults 18 and older. Available in the United States.|Para mayores de 18 años. Disponible en Estados Unidos.|Für Erwachsene ab 18 Jahren. In den USA verfügbar.|Pour les adultes de 18 ans et plus. Disponible aux États-Unis.|Para adultos a partir de 18 anos. Disponível nos Estados Unidos.
Try before signing in|Prueba antes de iniciar sesión|Vor der Anmeldung ausprobieren|Essayer avant de se connecter|Experimente antes de entrar
Explore demo|Explorar demo|Demo ansehen|Explorer la démo|Explorar demonstração
Continue on this device|Continuar en este dispositivo|Auf diesem Gerät fortfahren|Continuer sur cet appareil|Continuar neste dispositivo
Guest records stay on this device and are not automatically transferred to an account.|Los registros de invitado permanecen en este dispositivo y no se transfieren automáticamente a una cuenta.|Gastdaten bleiben auf diesem Gerät und werden nicht automatisch in ein Konto übertragen.|Les données invité restent sur cet appareil sans transfert automatique vers un compte.|Os registros de visitante ficam neste dispositivo e não são transferidos automaticamente para uma conta.
Pricing|Precios|Preise|Tarifs|Preços
Refunds|Reembolsos|Erstattungen|Remboursements|Reembolsos
Membership|Suscripción|Mitgliedschaft|Abonnement|Assinatura
FitRota membership|Suscripción FitRota|FitRota-Mitgliedschaft|Abonnement FitRota|Assinatura FitRota
Loading your plan details…|Cargando detalles de tu plan…|Deine Plandetails werden geladen…|Chargement des détails de votre formule…|Carregando os detalhes do plano…
Your plan is updating in the background. You can keep using FitRota.|Tu plan se actualiza en segundo plano. Puedes seguir usando FitRota.|Dein Plan wird im Hintergrund aktualisiert. Du kannst FitRota weiter nutzen.|Votre formule se met à jour en arrière-plan. Vous pouvez continuer à utiliser FitRota.|Seu plano está sendo atualizado. Você pode continuar usando o FitRota.
We couldn’t verify your membership. Please reconnect and try again.|No pudimos verificar tu suscripción. Conéctate e inténtalo de nuevo.|Deine Mitgliedschaft konnte nicht geprüft werden. Verbinde dich erneut und versuche es noch einmal.|Nous n’avons pas pu vérifier votre abonnement. Reconnectez-vous et réessayez.|Não foi possível verificar sua assinatura. Reconecte-se e tente novamente.
Permissions and automatic backup|Permisos y copia automática|Berechtigungen und automatische Sicherung|Autorisations et sauvegarde automatique|Permissões e backup automático
Backup and account actions|Copia de seguridad y cuenta|Sicherung und Kontoaktionen|Sauvegarde et gestion du compte|Backup e ações da conta
Automatic backup|Copia automática|Automatische Sicherung|Sauvegarde automatique|Backup automático
Private notes and chats|Notas y chats privados|Private Notizen und Chats|Notes et discussions privées|Notas e conversas privadas
I agree to share my messages and selected plan information with OpenAI.|Acepto compartir mis mensajes y la información del plan elegida con OpenAI.|Ich stimme zu, meine Nachrichten und ausgewählte Planinformationen mit OpenAI zu teilen.|J’accepte de partager mes messages et les informations de programme choisies avec OpenAI.|Concordo em compartilhar minhas mensagens e informações do plano selecionadas com a OpenAI.
Save my profile and progress to my account.|Guardar mi perfil y progreso en mi cuenta.|Mein Profil und meinen Fortschritt im Konto speichern.|Enregistrer mon profil et mes progrès dans mon compte.|Salvar meu perfil e progresso na minha conta.
Include my day notes and AI chats in backups.|Incluir mis notas diarias y chats IA en las copias.|Meine Tagesnotizen und KI-Chats in Sicherungen aufnehmen.|Inclure mes notes quotidiennes et discussions IA dans les sauvegardes.|Incluir minhas notas diárias e conversas IA nos backups.
Secure sign-in|Inicio de sesión seguro|Sichere Anmeldung|Connexion sécurisée|Entrada segura
Your routine, together.|Tu rutina, en un lugar.|Deine Routine, an einem Ort.|Votre routine, au même endroit.|Sua rotina, em um só lugar.
Keep your workouts, nutrition and progress in one place.|Mantén tus entrenamientos, nutrición y progreso en un lugar.|Behalte Training, Ernährung und Fortschritt an einem Ort.|Regroupez sport, nutrition et progrès au même endroit.|Mantenha treinos, nutrição e progresso em um só lugar.
Continue securely with your account. New here? Your account is created when you first sign in.|Continúa con tu cuenta de forma segura. Tu cuenta se crea al iniciar sesión por primera vez.|Melde dich sicher an. Dein Konto wird bei der ersten Anmeldung erstellt.|Connectez-vous en toute sécurité. Votre compte est créé lors de la première connexion.|Entre com segurança. Sua conta é criada no primeiro acesso.
Automatic services|Servicios automáticos|Automatische Dienste|Services automatiques|Serviços automáticos
Save choices|Guardar preferencias|Auswahl speichern|Enregistrer les choix|Salvar escolhas
Continue with Apple|Continuar con Apple|Mit Apple fortfahren|Continuer avec Apple|Continuar com Apple
I am 18+. I accept the terms and have read the privacy notice.|Soy mayor de 18 años. Acepto los términos y he leído el aviso de privacidad.|Ich bin mindestens 18 Jahre alt. Ich akzeptiere die Bedingungen und habe die Datenschutzhinweise gelesen.|J’ai au moins 18 ans. J’accepte les conditions et j’ai lu la politique de confidentialité.|Tenho 18 anos ou mais. Aceito os termos e li o aviso de privacidade.
Sign in with your account first.|Primero inicia sesión con tu cuenta.|Melde dich zuerst mit deinem Konto an.|Connectez-vous d’abord avec votre compte.|Entre primeiro com sua conta.
Checking your plan…|Comprobando tu plan…|Dein Plan wird geprüft…|Vérification de votre formule…|Verificando seu plano…
Continue to Google Play|Continuar a Google Play|Weiter zu Google Play|Continuer vers Google Play|Continuar para o Google Play
Your price comes from Google Play. Currency and regional pricing follow your Play account, not your app language.|El precio viene de Google Play. La moneda depende de tu cuenta Play, no del idioma.|Der Preis stammt von Google Play. Währung und regionale Preise richten sich nach deinem Play-Konto, nicht nach der Sprache.|Le prix vient de Google Play. La devise dépend de votre compte Play et non de la langue.|O preço vem do Google Play. A moeda depende da conta Play, não do idioma.
Subscriptions renew automatically until cancelled. Review the final price and renewal terms in Google Play before confirming.|La suscripción se renueva hasta cancelarla. Revisa el precio final y las condiciones en Google Play antes de confirmar.|Abonnements verlängern sich bis zur Kündigung automatisch. Prüfe Preis und Verlängerungsbedingungen vor der Bestätigung in Google Play.|L’abonnement se renouvelle jusqu’à résiliation. Vérifiez le prix et les conditions dans Google Play avant de confirmer.|A assinatura renova até ser cancelada. Confira o preço final e os termos no Google Play antes de confirmar.
Premium AI verification pending|Verificación de IA Premium pendiente|Premium-KI-Prüfung ausstehend|Vérification de l’IA Premium en attente|Verificação da IA Premium pendente
Your store membership is active, but the AI server has not verified the same access. Do not purchase again.|Tu suscripción está activa, pero el servidor IA aún no la ha verificado. No vuelvas a comprar.|Deine Mitgliedschaft ist aktiv, aber der KI-Server hat den Zugang noch nicht bestätigt. Kaufe nicht erneut.|Votre abonnement est actif mais le serveur IA n’a pas encore confirmé l’accès. Ne rachetez pas l’abonnement.|Sua assinatura está ativa, mas o servidor IA ainda não confirmou o acesso. Não compre novamente.
Sync membership|Sincronizar suscripción|Mitgliedschaft synchronisieren|Synchroniser l’abonnement|Sincronizar assinatura`;
const uiTranslations=Object.fromEntries((uiRows+'\n'+releaseTranslations).split('\n').map(row=>{const [key,...values]=row.split('|');return [key,Object.fromEntries(['es','de','fr','pt'].map((lang,i)=>[lang,values[i]]))];}));
export function uiText(tr,en,language='en') {
  if(language==='tr')return tr;
  return uiTranslations[en]?.[language]||en;
}
