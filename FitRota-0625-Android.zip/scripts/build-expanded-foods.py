"""Add all usable generic CoFID 2021 records to manual food search, not automatic diets."""
from pathlib import Path
import json,openpyxl
root=Path(__file__).resolve().parent.parent
b=openpyxl.load_workbook(root/'research/cofid.xlsx',read_only=True,data_only=True)
m={r[0]:r for r in b['1.4 Inorganics'].values if r[0]}
existing={f['code'] for f in json.loads((root/'src/food-data.js').read_text().split('export const basicFoods=')[1].split(';')[0])}
exact={'11-859':'Basmati pirinç (kolay pişen, çiğ / kuru)','11-860':'Basmati pirinç (kolay pişen, tuzsuz haşlanmış)','11-857':'Basmati pirinç (çiğ / kuru)','11-858':'Basmati pirinç (tuzsuz haşlanmış)','11-866':'Esmer basmati pirinç (çiğ / kuru)','11-867':'Esmer basmati pirinç (tuzsuz haşlanmış)','17-671':'Patates cipsi (ayçiçek yağında kızarmış)','17-693':'Patates cipsi (az yağlı)','17-648':'Sütlü çikolata','17-491':'Bitter çikolata','17-091':'Beyaz çikolata','17-692':'Tuzlu patlamış mısır','17-691':'Şekerli patlamış mısır','11-815':'Çikolata parçalı kurabiye','11-816':'Amerikan tipi çikolata parçalı kurabiye','11-799':'Sade digestive bisküvi','11-807':'Çikolata kaplı digestive bisküvi','11-812':'Çikolata kaplı gofret','11-813':'Kremalı sandviç bisküvi','11-936':'Peynirli domatesli pizza','11-1015':'Etli pizza','11-1014':'Sebzeli pizza','11-1012':'Tavuklu pizza','12-508':'Vanilyalı sütlü dondurma','12-509':'Vanilyalı dondurma (süt dışı yağ)','12-510':'Çikolata kaplı dondurma barı','17-687':'Çikolatalı fındık kreması','11-1127':'Çikolatalı brownie (ev yapımı)'}
words=[('boiled in unsalted water','tuzsuz suda haşlanmış'),('stir-fried','tavada hızlı pişmiş'),('pan-fried','tavada kızarmış'),('deep fried','bol yağda kızarmış'),('fried in sunflower oil','ayçiçek yağında kızarmış'),('fried in','kızarmış; kullanılan yağ:'),('oven-baked','fırında pişmiş'),('raw','çiğ'),('cooked','pişmiş'),('boiled','haşlanmış'),('fried','kızarmış'),('grilled','ızgara'),('roasted','fırınlanmış'),('baked','fırınlanmış'),('steamed','buharda pişmiş'),('canned','konserve'),('dried','kurutulmuş'),('frozen','dondurulmuş'),('with skin','derili'),('skinless','derisiz'),('flesh only','yalnız yenebilir et'),('drained','süzülmüş'),('unsalted','tuzsuz'),('salted','tuzlu'),('rice','pirinç'),('basmati','basmati'),('chicken','tavuk'),('beef','dana eti'),('pork','domuz eti'),('lamb','kuzu eti'),('turkey','hindi'),('fish','balık'),('potatoes','patates'),('potato','patates'),('chips','patates kızartması'),('crisps','cips'),('biscuits','bisküvi'),('cookies','kurabiye'),('chocolate','çikolata'),('milk','süt'),('cheese','peynir'),('cream','krema'),('eggs','yumurta'),('egg','yumurta'),('yogurt','yoğurt'),('bread','ekmek'),('wholemeal','tam tahıllı'),('wholewheat','tam buğday'),('pasta','makarna'),('noodles','noodle'),('tomatoes','domates'),('tomato','domates'),('onions','soğan'),('carrots','havuç'),('apples','elma'),('apple','elma'),('bananas','muz'),('banana','muz'),('orange','portakal'),('juice','meyve suyu'),('water','su'),('oil','yağ'),('butter','tereyağı'),('sugar','şeker'),('white','beyaz'),('brown','esmer'),('plain','sade'),('retail','genel market ürünü'),('takeaway','paket servis'),('homemade','ev yapımı')]
def num(v):
 if v=='Tr':return 0.0
 try:return float(v)
 except (ValueError,TypeError):return None
foods=[]
seen=set()
for r in b['1.3 Proximates'].values:
 if not isinstance(r[1],str) or r[0] in existing or r[0] not in m or r[0] in seen:continue
 n={k:num(r[i]) for k,i in {'kcal':12,'protein':9,'carbs':11,'fat':10,'fiber':25,'sugar':16,'saturatedFat':27,'cholesterol':46}.items()};mrow=m[r[0]];n.update({k:num(mrow[i]) for k,i in {'sodium':7,'potassium':8,'calcium':9,'iron':12}.items()})
 if any(n[k] is None or n[k]<0 for k in ['kcal','protein','carbs','fat']):continue
 translated=r[1].lower()
 import re
 for en,tr in words:translated=re.sub(r'\b'+re.escape(en)+r'\b',tr,translated)
 name=exact.get(r[0],translated[0].upper()+translated[1:])
 seen.add(r[0])
 foods.append({'id':'cofid-'+r[0],'code':r[0],'name':[name,r[1]],'unit':'g',**n})
(root/'src/expanded-foods.js').write_text('// Generic UK CoFID 2021 data. Brands are not inferred. Original English names are retained.\nexport const additionalFoods='+json.dumps(foods,ensure_ascii=False,separators=(',',':'))+';\n')
print(len(foods),'additional generic records; source workbook CoFID 2021')
