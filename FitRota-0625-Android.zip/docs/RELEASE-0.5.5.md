# FitRota 0.5.5 — İçerik ve besin günlüğü

- 60 hareket: kas grubu, ev/salon ve arama filtreleri; ekipman, seviye, adım adım anlatım ve alternatifler. İleri seviye hareketler otomatik başlangıç planına eklenmez.
- 80 özgün tarif: 20 kahvaltı, 23 öğle, 23 akşam, 14 ara öğün. Malzemeler gramla, hazırlık numaralı adımlarla; porsiyon değişince malzemeler ve besin değerleri güncellenir.
- 160 temel besin: besin/tarif filtresi, gramla günlük kayıt; kuru/pişmiş ve yenebilir kısım açıklamaları.
- Sodyum ve kolesterol günlük toplamda; ayrıca şeker, doymuş yağ, potasyum, kalsiyum ve demir. Kaynakta bulunmayan değerler bilinmiyor olarak korunur.
- Günlük kayıtları besin değerlerinin anlık kopyasını saklar; eski kayıtlara sonradan mikro değer uydurulmaz.

## Telefonda yükleme

Önce uygulamanın Ayarlar bölümünden yedek indir. Site verilerini temizleme.

1. GitHub deposunun köküne **FitRota-0.5.5.zip** yükle; telefonda çıkartma.
2. Render → Fitrota → Settings → Build Command:

```sh
python3 -m zipfile -e FitRota-0.5.5.zip . && npm ci --include=dev && npm run build
```

Start Command:

```sh
HOST=0.0.0.0 node server/index.mjs
```

3. Manual Deploy → Deploy latest commit. Live olduktan sonra uygulamayı açıp güncelleme bildirimiyle yenile. Ayarlar'da 0.5.5 görünmeli.
4. Beslenme → Günlüğüm: besin ekle, temel besinleri filtrele ve gram yaz. Tarifler bölümünde öğün gruplarını dene. Antrenman → Hareketler bölümünde 60 hareket vardır.

0.5.4 için database/002_ai_quota.sql zaten çalıştırıldıysa yeni SQL veya ortam anahtarı gerekmez. Kota kurulumu yapılmadıysa docs/RELEASE-0.5.4.md adımlarını tamamla. Bu içerik sürümü AI/hesap sunucusunu değiştirmez.

## Kontrol ve sınırlar

35 birim testi; yeni gram/porsiyon, eksik besin verisi, yedek ve içerik kontrolleri geçti. Yeni mobil içerik akışları, 96 mevcut ekran/düzen kontrolü ve 48 özellik düzen kontrolü geçti. Hesaplı koç, onay, yeniden açılma ve kota yenilenmesi sahte sağlayıcıyla doğrulandı. Gerçek OpenAI çağrısı veya canlı Supabase değişikliği yapılmadı. Chromium ile test edildi; gerçek Android/iPhone testi ve imzalı mağaza paketi bu işlemde üretilmedi.

Besinler CoFID 2021 genel değerleridir; marka etiketleri ve kişisel klinik değerlendirme yerine geçmez. Kaynaklar docs/CONTENT-SOURCES.md içinde. Ödeme/reklam ve yayın belgelerinin gerçek incelemesi önceki sürümdeki gibi ayrıca tamamlanmalıdır. Paket kendi başına canlı siteyi güncellemez.
